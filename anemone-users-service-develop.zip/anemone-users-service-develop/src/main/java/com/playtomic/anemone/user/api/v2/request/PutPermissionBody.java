package com.playtomic.anemone.user.api.v2.request;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.user.model.permissions.PermissionLevel;
import com.playtomic.anemone.user.domain.tenant.TenantId;

import lombok.Getter;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

@Getter
public class PutPermissionBody {

    @Nonnull
    private final TenantId tenantId;

    @Nullable
    private final PermissionLevel level;

    @JsonCreator
    public PutPermissionBody(@JsonProperty(value = "tenant_id", required = true) @Nonnull TenantId tenantId,
                             @JsonProperty(value = "permission_level") @Nullable PermissionLevel level) {
        this.tenantId = tenantId;
        this.level = level;
    }
}

package com.playtomic.anemone.user.service.exception;

public class InvalidPasswordException extends RuntimeException {
}

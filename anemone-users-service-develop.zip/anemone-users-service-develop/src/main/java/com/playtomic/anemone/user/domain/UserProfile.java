package com.playtomic.anemone.user.domain;

import com.playtomic.anemone.domain.user.UserId;
import com.playtomic.anemone.user.model.PrivacyProfile;
import org.apache.commons.lang3.LocaleUtils;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;


public interface UserProfile {

    Map<String, Locale> internationalizedCountries = new HashMap<>() {{

        // Spain & Latin America -> Spanish (Spain)
        put("es", LocaleUtils.toLocale("es_ES"));
        put("ad", LocaleUtils.toLocale("es_ES"));
        put("ar", LocaleUtils.toLocale("es_ES"));
        put("ve", LocaleUtils.toLocale("es_ES"));
        put("cl", LocaleUtils.toLocale("es_ES"));
        put("co", LocaleUtils.toLocale("es_ES"));
        put("ec", LocaleUtils.toLocale("es_ES"));

        // Mexico -> Spanish (Mexico)
        put("mx", LocaleUtils.toLocale("es_MX"));

        // Finland -> Finnish
        put("fi", LocaleUtils.toLocale("fi_FI"));

        // Sweden -> Swedish
        put("se", LocaleUtils.toLocale("sv_SE"));

        // Portugal & Brazil -> Portuguese (Portugal)
        put("pt", LocaleUtils.toLocale("pt_PT"));
        put("br", LocaleUtils.toLocale("pt_PT"));
    }};

    Locale ENGLISH_LOCALE = LocaleUtils.toLocale("en_EN");

    @Nonnull
    UserId getId();

    @Nullable
    String getEmail();

    @Nullable
    String getPhone();

    @Nonnull
    String getName();

    boolean isValidated();

    @Nullable
    String getBio();

    @Nonnull
    String getCountryCode();

    @Nonnull
    Locale getCommunicationsLanguage();

    @Nonnull
    PrivacyProfile getPrivacyProfile();

    boolean isPremium();

    @Nonnull
    static Locale generateCommunicationsLanguage(@Nonnull String countryCode) {
        String comparableCountryCode = countryCode.toLowerCase();
        return internationalizedCountries.getOrDefault(comparableCountryCode, ENGLISH_LOCALE);
    }

}

package com.playtomic.anemone.user.domain;

import com.playtomic.anemone.user.domain.validation.constants.PasswordValidationMode;
import com.playtomic.anemone.user.service.exception.InvalidPasswordException;
import java.util.List;
import java.util.Map;
import javax.annotation.Nonnull;
import javax.annotation.ParametersAreNullableByDefault;

/**
 * A class to validate passwords
 */
@ParametersAreNullableByDefault
public class PasswordValidator {

  private static final int PASSWORD_MIN_SIZE = 6;
  private static final int PASSWORD_MAX_SIZE = 72;

  private static final Map<PasswordValidationMode, List<PasswordValidation<String>>> modeValidationsMap =
      Map.of(
          PasswordValidationMode.SIZE_ONLY, List.of(new PasswordSizeValidator()),
          PasswordValidationMode.ALL, List.of(new PasswordSizeValidator(), new PasswordPatternValidator()));

  private PasswordValidator() {
  }

  public static void validate(String password, @Nonnull PasswordValidationMode mode) {
    modeValidationsMap.get(mode).forEach(passwordValidator -> passwordValidator.validate(password));
  }

  public static boolean isValid(String password) {
    return validSize(password) && validPattern(password);
  }

  public static boolean validSize(String password) {
    // Password must be set and it must be at least six characters long.
    return password != null && password.length() >= PASSWORD_MIN_SIZE && password.length() <= PASSWORD_MAX_SIZE;
  }

  public static boolean validPattern(String password) {
    return password != null && password.matches("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d).+$");
  }

  interface PasswordValidation<T>{
    void validate(T object);
  }

  @ParametersAreNullableByDefault
  public static class PasswordSizeValidator implements PasswordValidation<String> {

    @Override
    public void validate(String password) {
      if(!validSize(password)){
        throw new InvalidPasswordException();
      }
    }
  }

  @ParametersAreNullableByDefault
  public static class PasswordPatternValidator implements PasswordValidation<String> {

    @Override
    public void validate(String password) {
      if(!validPattern(password)){
        throw new InvalidPasswordException();
      }
    }
  }


}
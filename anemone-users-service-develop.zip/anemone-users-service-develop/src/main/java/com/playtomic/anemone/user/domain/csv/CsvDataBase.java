package com.playtomic.anemone.user.domain.csv;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public abstract class CsvDataBase<T> {

    private final int position;
    private final T value;
}

package com.playtomic.anemone.category.config;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties("users-memberships.emails")
@Getter
@Setter
public class MembershipEmailsConfiguration {

    private EmailConfiguration newMemberEmailConfig;

    private EmailConfiguration removedMemberEmailConfig;

    @Getter
    @Setter
    public static class EmailConfiguration{

        @Nonnull
        private String templateId;

        @Nonnull
        private String from;

        @Nullable
        private String to;

        @Nonnull
        private String emailPropertiesPrefix;
    }

}

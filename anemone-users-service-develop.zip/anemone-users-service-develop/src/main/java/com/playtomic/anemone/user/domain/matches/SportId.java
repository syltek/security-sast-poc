package com.playtomic.anemone.user.domain.matches;

import com.playtomic.anemone.domain.generic.AbstractStringId;
import javax.annotation.Nonnull;

public class SportId extends AbstractStringId {

	protected SportId(@Nonnull String id) {
		super(id);
	}

	@Nonnull
	public static SportId valueOf(@Nonnull String id) {
		return new SportId(id);
	}

}

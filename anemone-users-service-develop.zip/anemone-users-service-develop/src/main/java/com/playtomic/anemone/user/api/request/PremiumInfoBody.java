package com.playtomic.anemone.user.api.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.time.Instant;
import javax.annotation.Nullable;
import lombok.Data;

@Data
public class PremiumInfoBody {

    private boolean isPremium;

    @Nullable
    private Instant expiresAt;

    public PremiumInfoBody(@JsonProperty(value = "is_premium", required = true) boolean isPremium,
                           @JsonProperty("expires_at") @Nullable Instant expiresAt) {
        this.isPremium = isPremium;
        this.expiresAt = expiresAt;
    }
}

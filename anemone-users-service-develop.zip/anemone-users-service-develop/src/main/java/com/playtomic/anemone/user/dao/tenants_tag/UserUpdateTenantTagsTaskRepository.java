package com.playtomic.anemone.user.dao.tenants_tag;

import com.playtomic.anemone.domain.user.UserId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserUpdateTenantTagsTaskRepository extends MongoRepository<UserUpdateTenantTagsTaskDocument, UserId> {

}

package com.playtomic.anemone.user.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.domain.user.UserId;
import com.playtomic.anemone.user.dao.PlaytomicUserType;
import com.playtomic.anemone.user.domain.UserProfile;
import com.playtomic.anemone.user.domain.permissions.Permission;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import com.playtomic.anemone.user.model.role.PlaytomicUserRole;
import java.net.URL;
import java.time.ZonedDateTime;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.stream.Collectors;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.persistence.Column;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CustomerUserProfile implements UserProfile {

    @JsonProperty(value = "user_id")
    @Nonnull
    private UserId id;

    @JsonProperty(value = "full_name")
    @Nonnull
    private String name;

    @JsonProperty(value = "email")
    @Nullable
    private String email;

    @JsonProperty(value = "is_validated")
    public boolean isValidated;

    @JsonProperty(value = "is_email_verified")
    private boolean isEmailVerified;

    @JsonProperty("picture")
    @Nullable
    private URL picture;

    @JsonProperty("phone")
    @Nullable
    private String phone;

    @JsonProperty("is_phone_verified")
    private boolean isPhoneVerified;

    @JsonProperty("is_deleted")
    private boolean isDeleted;

    @JsonProperty("accepts_privacy")
    @Nullable
    public Boolean acceptsPrivacy;

    @JsonProperty("accepts_commercial")
    @Nullable
    public Boolean acceptsCommercial;

    @JsonProperty("linked_accounts")
    @Nonnull
    public Set<LinkedAccount> linkedTenantsAccounts;

    @JsonProperty("coach_accounts")
    @Nonnull
    public Set<CoachAccount> coachAccounts;

    @JsonProperty("tenant_owner_accounts")
    @Nonnull
    public Set<TenantOwnerAccount> tenantOwnerAccounts;

    @JsonProperty("birth_date")
    @Nullable
    private ZonedDateTime birthDate;

    @JsonProperty("gender")
    @Nullable
    private UserGender gender;

    @JsonProperty("bio")
    @Nullable
    private String bio;

    @JsonProperty("country_code")
    @Nonnull
    private String countryCode;

    @JsonProperty("communications_language")
    @Nonnull
    public Locale communicationsLanguage;

    @JsonProperty("user_roles")
    @Nonnull
    private List<ExtendedUserRole> userRoles;

    @JsonProperty("tenant_tags")
    @Nonnull
    private Set<TenantTag> tenantTags;

    @JsonProperty("address")
    @Nonnull
    private CustomerAddress address;

    @JsonProperty("active_permissions")
    @Nullable
    private List<Permission> activePermissions;

    @JsonProperty("created_by_user")
    @Nullable
    private String createdByUser;

    @JsonProperty("created_by_tenant")
    @Nullable
    private String createdByTenant;

    @JsonProperty("privacy_profile")
    @Nonnull
    private PrivacyProfile privacyProfile;

    @JsonProperty("type")
    @Nullable // TODO: change it to @Nonnull when existing users will be populated with correct value
    private PlaytomicUserType type;

    @JsonProperty("is_premium")
    private boolean isPremium;

    @Nonnull
    public Collection<TenantId> getLinkedTenantIds() {
        return linkedTenantsAccounts.stream().map(LinkedAccount::getTenantId).collect(Collectors.toSet());
    }

    @Nonnull
    public Collection<TenantId> getManagedTenantIds() {
        return userRoles.stream()
            .filter(ur -> PlaytomicUserRole.ROLE_TENANT_MANAGER.equals(ur.getUserRole()))
            .map(ExtendedUserRole::getTenantId)
            .collect(Collectors.toSet());
    }

    @Nonnull
    public Collection<TenantId> getLinkedAsCoachTenantIds() {
        return coachAccounts.stream().map(a -> a.getTenantId()).collect(Collectors.toSet());
    }

    public boolean isCreatedByTenant(@Nonnull TenantId tenantId) {
        return tenantId.toString().equals(createdByTenant);
    }

    public boolean isLinkedTo(@Nonnull TenantId tenantId) {
        return this.getLinkedTenantIds().contains(tenantId);
    }
}

package com.playtomic.anemone.user.domain.voucher;

import com.playtomic.anemone.domain.generic.AbstractStringId;
import javax.annotation.Nonnull;

public class VoucherRedemptionId extends AbstractStringId {
    protected VoucherRedemptionId(@Nonnull String id) {
        super(id);
    }

    public static VoucherRedemptionId valueOf(String id) {
        return new VoucherRedemptionId(id);
    }
}

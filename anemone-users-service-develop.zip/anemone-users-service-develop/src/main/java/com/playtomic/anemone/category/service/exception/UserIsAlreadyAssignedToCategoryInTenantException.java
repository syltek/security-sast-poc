package com.playtomic.anemone.category.service.exception;

import javax.annotation.Nonnull;

public class UserIsAlreadyAssignedToCategoryInTenantException extends RuntimeException {

    public UserIsAlreadyAssignedToCategoryInTenantException(@Nonnull String message) {
        super(message);
    }
}

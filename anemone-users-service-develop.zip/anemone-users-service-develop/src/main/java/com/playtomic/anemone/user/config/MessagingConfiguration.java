package com.playtomic.anemone.user.config;

import com.playtomic.anemone.converter.CustomMappingJackson2HttpMessageConverter;
import com.playtomic.anemone.spring.messaging.AnemoneStreamMessageConverter;
import com.playtomic.anemone.user.config.MessagingConfiguration.CategoriesTopic;
import com.playtomic.anemone.user.config.MessagingConfiguration.MatchesTopic;
import com.playtomic.anemone.user.config.MessagingConfiguration.MembershipsTopic;
import com.playtomic.anemone.user.config.MessagingConfiguration.ReservationsTopic;
import com.playtomic.anemone.user.config.MessagingConfiguration.UserImportsTopicInput;
import com.playtomic.anemone.user.config.MessagingConfiguration.UserImportsTopicOutput;
import com.playtomic.anemone.user.config.MessagingConfiguration.UserUpdateTenantTagsTopicInput;
import com.playtomic.anemone.user.config.MessagingConfiguration.UserUpdateTenantTagsTopicOutput;
import com.playtomic.anemone.user.config.MessagingConfiguration.UsersTopic;
import javax.annotation.Nonnull;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.Input;
import org.springframework.cloud.stream.annotation.Output;
import org.springframework.cloud.stream.annotation.StreamMessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.SubscribableChannel;
import org.springframework.messaging.converter.MessageConverter;

@EnableBinding({
    MatchesTopic.class,
    ReservationsTopic.class,
    MembershipsTopic.class,
    UsersTopic.class,
    UserImportsTopicInput.class,
    UserImportsTopicOutput.class,
    CategoriesTopic.class,
    UserUpdateTenantTagsTopicInput.class,
    UserUpdateTenantTagsTopicOutput.class})
public class MessagingConfiguration {


    public interface MatchesTopic {
        String INPUT = "matches-channel";

        @Input(INPUT)
        SubscribableChannel input();
    }

    public interface ReservationsTopic {
        String INPUT = "reservations-channel";

        @Input(INPUT)
        SubscribableChannel input();
    }

    public interface MembershipsTopic {
        String INPUT = "memberships-channel";

        @Input(INPUT)
        SubscribableChannel input();
    }

    public interface UsersTopic {
        String OUTPUT = "users-channel";

        @Output(OUTPUT)
        @Nonnull
        MessageChannel output();
    }

    public interface UserImportsTopicInput {
        String INPUT = "user-imports-input-channel";

        @Input(INPUT)
        SubscribableChannel input();
    }

    public interface UserImportsTopicOutput {
        String OUTPUT = "user-imports-output-channel";

        @Output(OUTPUT)
        MessageChannel output();
    }

    public interface CategoriesTopic {
        String OUTPUT = "categories-channel";

        @Output(OUTPUT)
        MessageChannel output();
    }

    public interface UserUpdateTenantTagsTopicInput {
        String INPUT = "user-update-tenant-tags-input-channel";

        @Input(INPUT)
        SubscribableChannel input();
    }

    public interface UserUpdateTenantTagsTopicOutput {
        String OUTPUT = "user-update-tenant-tags-output-channel";

        @Output(OUTPUT)
        MessageChannel output();
    }

    @Bean
    @StreamMessageConverter
    public MessageConverter anemoneMessageConverter(
        CustomMappingJackson2HttpMessageConverter converter) {
        return new AnemoneStreamMessageConverter(converter.getObjectMapper());
    }
}
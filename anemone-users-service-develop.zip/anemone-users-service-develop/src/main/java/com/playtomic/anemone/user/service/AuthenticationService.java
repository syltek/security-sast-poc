package com.playtomic.anemone.user.service;

import com.playtomic.anemone.domain.Email;
import com.playtomic.anemone.domain.user.User;
import com.playtomic.anemone.domain.user.UserId;
import com.playtomic.anemone.jwt.AccessJwtToken;
import com.playtomic.anemone.jwt.InvalidJwtToken;
import com.playtomic.anemone.jwt.JwtSettings;
import com.playtomic.anemone.jwt.JwtToken;
import com.playtomic.anemone.jwt.JwtTokenFactory;
import com.playtomic.anemone.jwt.JwtUser;
import com.playtomic.anemone.jwt.RefreshJwtToken;
import com.playtomic.anemone.service.AbstractLocalizableService;
import com.playtomic.anemone.user.dao.JwtTokenEntity;
import com.playtomic.anemone.user.dao.JwtTokenRepository;
import com.playtomic.anemone.user.dao.UserEntity;
import com.playtomic.anemone.user.dao.UserRepository;
import com.playtomic.anemone.user.dao.UserRoleEntity;
import com.playtomic.anemone.user.domain.permissions.Permission;
import com.playtomic.anemone.user.domain.users.UserLegacy;
import com.playtomic.anemone.user.domain.validation.annotation.Password;
import com.playtomic.anemone.user.domain.validation.constants.PasswordValidationMode;
import com.playtomic.anemone.user.model.LoginAuthTokens;
import com.playtomic.anemone.user.model.permissions.AnemonePermissionsToAuthorities;
import com.playtomic.anemone.user.model.role.PlaytomicUserRole;
import com.playtomic.anemone.user.model.role.RoleWithTenantsIdsData;
import com.playtomic.anemone.user.service.apple.AppleUserData;
import com.playtomic.anemone.user.service.exception.InvalidPasswordException;
import com.playtomic.anemone.user.service.exception.UserNotFoundException;
import com.playtomic.anemone.user.service.facebook.FacebookUserData;
import com.playtomic.anemone.user.service.google.GoogleUserData;
import com.playtomic.anemone.user.service.messaging.MessagingBroker;
import com.playtomic.anemone.user.service.messaging.UserEvent;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jws;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.validation.ClockProvider;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.context.MessageSource;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.annotation.Validated;

@Validated
@Service
@Slf4j
public class AuthenticationService extends AbstractLocalizableService {

    @Nonnull
    private final JwtTokenRepository jwtTokenRepository;

    @Nonnull
    private final UserRepository userRepository;

    @Nonnull
    private final PermissionService permissionService;

    @Nonnull
    private final JwtTokenFactory jwtTokenFactory;

    @Nonnull
    private final JwtSettings jwtSettings;

    @Nonnull
    private final ClockProvider clockProvider;

    @Nonnull
    private final MessagingBroker messagingBroker;

    @Nonnull
    private final UserServicePersistenceComponent userServicePersistenceComponent;

    public AuthenticationService(@Nonnull MessageSource messageSource,
                                 @Nonnull DiscoveryClient discoveryClient,
                                 @Nonnull JwtTokenRepository jwtTokenRepository,
                                 @Nonnull UserRepository userRepository,
                                 @Nonnull PermissionService permissionService,
                                 @Nonnull JwtTokenFactory jwtTokenFactory,
                                 @Nonnull JwtSettings jwtSettings,
                                 @Nonnull ClockProvider clockProvider,
                                 @Nonnull MessagingBroker messagingBroker,
                                 @Nonnull UserServicePersistenceComponent userServicePersistenceComponent) {
        super(messageSource, discoveryClient);
        this.jwtTokenRepository = jwtTokenRepository;
        this.userRepository = userRepository;
        this.permissionService = permissionService;
        this.jwtTokenFactory = jwtTokenFactory;
        this.jwtSettings = jwtSettings;
        this.clockProvider = clockProvider;
        this.messagingBroker = messagingBroker;
        this.userServicePersistenceComponent = userServicePersistenceComponent;
    }

    @Transactional
    @Nonnull
    public LoginAuthTokens login(@Nonnull UserId userId) {
        UserEntity user = userRepository
                .findById(UserLegacy.asSafeLong(userId))
                .orElseThrow(UserNotFoundException::new);

        log.info("User log-in from sign-up. user_id {}", userId);

        return loginUser(user);
    }

    @Transactional
    @Nonnull
    public LoginAuthTokens login(@Nonnull JwtToken refreshToken) throws InvalidJwtToken {
        try {
            //Check validity of token and extract token id.
            Jws<Claims> validatedClaims = jwtTokenFactory.validateJwtTokenAndParseClaims(refreshToken);
            String jti = validatedClaims.getBody().getId();

            JwtTokenEntity refreshTokenEntityById = jwtTokenRepository.findByRefreshTokenId(jti);
            boolean refreshTokenEntityByIdFound = refreshTokenEntityById != null;

            if (!refreshTokenEntityByIdFound) {
                throw new InvalidJwtToken();
            }

            JwtUser jwtUser = jwtTokenFactory.readJwtToken(refreshToken);

            log.info("User log-in with refresh token. user_id={} jti={}", jwtUser.getId(), jti);

            jwtTokenRepository.deleteById(refreshTokenEntityById.getId());
            return login(jwtUser.getId());
        } catch (BadCredentialsException | ExpiredJwtException e) {
            throw new InvalidJwtToken();
        }
    }

    @Transactional
    @Nonnull
    public LoginAuthTokens login(
        @Nonnull Email email,
        @Nonnull @Password(mode = PasswordValidationMode.SIZE_ONLY) String password) {

        UserEntity userEntity = userRepository.findUserByEmail(email.getEmail())
                .orElseThrow(UserNotFoundException::new);
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        if (!encoder.matches(password, userEntity.getPasswordHash())) {
            throw new InvalidPasswordException();
        }

        log.info("User log-in with email {} and password", email);
        return loginUser(userEntity);
    }

    public void logout(@Nonnull UserId userId) {
        log.info("Logout user_id {}", userId);

        jwtTokenRepository.deleteByUserId(UserLegacy.asSafeLong(userId));
    }

    @Transactional
    @Nonnull
    public LoginAuthTokens loginWithFacebook(@Nonnull FacebookUserData userData) {
        return userRepository.findUserByFacebookId(userData.getFacebookId().getValue())
            .map(this::loginUser)
            .orElseGet(() -> loginUser(assignExistingUserToFacebook(userData)));
    }

    @Transactional
    @Nonnull
    public LoginAuthTokens loginWithGoogle(@Nonnull GoogleUserData userData) {
        return userRepository.findUserByGoogleId(userData.getGoogleId().getValue())
            .map(this::loginUser)
            .orElseGet(() -> loginUser(assignExistingUserToGoogle(userData)));
    }

    @Transactional
    @Nonnull
    public LoginAuthTokens loginWithApple(@Nonnull AppleUserData userData) {
        return userRepository.findUserByAppleId(userData.getAppleId().getValue())
            .map(this::loginUser)
            .orElseGet(() -> loginUser(assignExistingUserToApple(userData)));
    }

    @Nonnull
    private UserEntity assignExistingUserToApple(@Nonnull AppleUserData userData) {
        UserEntity userByEmail = getVerifiedUserEntity(userData.isVerified(), userData.getEmail());

        log.info("Existing account {} found for apple user. Assigning the new apple id and returning the existing one", userByEmail.getId());
        userByEmail.setAppleId(userData.getAppleId().getValue());
        userByEmail.setEmailVerified(true);
        saveUser(userByEmail);
        return userByEmail;
    }

    @Nonnull
    private UserEntity assignExistingUserToGoogle(@Nonnull GoogleUserData userData) {
        UserEntity userByEmail = getVerifiedUserEntity(userData.isVerified(), userData.getEmail());

        log.info("Existing account {} found for google user. Assigning the new google id and returning the existing one", userByEmail.getId());
        userByEmail.setGoogleId(userData.getGoogleId().getValue());
        userByEmail.setEmailVerified(true);
        saveUser(userByEmail);
        return userByEmail;
    }


    @Nonnull
    private UserEntity assignExistingUserToFacebook(@Nonnull FacebookUserData userData) {
        UserEntity userByEmail = getVerifiedUserEntity(userData.isVerified(), userData.getEmail());

        log.info("Existing account {} found for facebook user. Assigning the new facebook id and returning the existing one", userByEmail.getId());
        userByEmail.setFacebookId(userData.getFacebookId().getValue());
        userByEmail.setEmailVerified(true);
        saveUser(userByEmail);
        return userByEmail;
    }

    private UserEntity getVerifiedUserEntity(boolean verified, @Nullable Email email) {
        // try to fetch by email, but only if email is verified in apple (otherwise it could be a user pretending to be another one)
        if (!verified || email == null) {
            throw new UserNotFoundException();
        }
        return userRepository.findUserByEmail(email.getEmail())
            .orElseThrow(UserNotFoundException::new);
    }

    @Nonnull
    private LoginAuthTokens loginUser(@Nonnull UserEntity userEntity) {
        UserId userId =  UserLegacy.valueOf(userEntity.getId());
        String email = userEntity.getEmail();

        // By now, every User has ROLE_CUSTOMER by default
        List<GrantedAuthority> roles = new ArrayList<>();
        roles.add(PlaytomicUserRole.ROLE_CUSTOMER.getAnemoneRole().getGa());
        if (!CollectionUtils.isEmpty(userEntity.getUserRoles())) {
            roles.addAll(userEntity.getUserRoles().stream()
                    .map(e -> e.getUserRole().getAnemoneRole().getGa())
                    .collect(Collectors.toSet())
            );
        }

        //Note that expiration can not be read from refreshToken.getClaims().getExpiration() because
        // currently library is not storing it there.
        Instant now = clockProvider.getClock().instant();
        Instant authTokenExpiration = now.plusSeconds(jwtSettings.getTokenExpirationSeconds());
        Instant refreshTokenExpiration = now.plusSeconds(jwtSettings.getRefreshTokenExpirationSeconds());

        AccessJwtToken authToken = jwtTokenFactory.createAccessJwtTokenWithCustomClaims(
                userId.toString(),
                email,
                roles,
                buildRoleBasedCustomClaims(userEntity, roles));

        User user = JwtUser.create(userId, email, roles);
        RefreshJwtToken refreshToken = jwtTokenFactory.createRefreshToken(user);

        JwtTokenEntity tokens = new JwtTokenEntity(userEntity.getId(), authToken.getJti(), refreshToken.getJti());
        jwtTokenRepository.save(tokens);

        return new LoginAuthTokens(authToken, authTokenExpiration, refreshToken, refreshTokenExpiration, user.getId());
    }

    @Nullable
    private Map<String, Object> buildRoleBasedCustomClaims(@Nonnull UserEntity userEntity, @Nonnull List<GrantedAuthority> roles) {
        Map<String, Object> customClaims = new HashMap<>();

        addCustomClaimsByRoles(customClaims, PlaytomicUserRole.ROLE_ACTIVITY_MANAGER, userEntity, roles);
        addCustomClaimsByRoles(customClaims, PlaytomicUserRole.ROLE_TENANT_MANAGER, userEntity, roles);

        //addCustomClaimsAuthoritiesByTenant(customClaims, userEntity);

        return CollectionUtils.isEmpty(customClaims) ? null : customClaims;
    }

    private void addCustomClaimsByRoles(@Nonnull Map<String, Object> customClaims, @Nonnull PlaytomicUserRole role, @Nonnull UserEntity userEntity, @Nonnull List<GrantedAuthority> roles) {
        if (roles.contains(role.getAnemoneRole().getGa())) {
            RoleWithTenantsIdsData customClaimData = getTenantDataForRole(role, userEntity);
            customClaims.put(role.name().toLowerCase(), customClaimData);
        }
    }

    //FIXME This will generate too big tokens that break requests
    private void addCustomClaimsAuthoritiesByTenantBroken(@Nonnull Map<String, Object> customClaims, @Nonnull UserEntity userEntity) {
        // User has permissions set from Manager
        List<Permission> activePermissions = permissionService.getActivePermissions(UserId.valueOf(userEntity.getId().toString()));
        Map<String, Set<String>> authoritiesByTenant = getAuthoritiesByTenant(activePermissions);

        if (!CollectionUtils.isEmpty(authoritiesByTenant)) {
            customClaims.put(JwtTokenFactory.AUTHORITIES_BY_TENANT, authoritiesByTenant);
        }
    }

    @Nonnull
    private RoleWithTenantsIdsData getTenantDataForRole(@Nonnull PlaytomicUserRole role, @Nonnull UserEntity userEntity) {
        Set<String> managedTenantIds = userEntity.getUserRoles().stream()
                .filter(userRoleEntity -> userRoleEntity.getUserRole().equals(role))
                .map(UserRoleEntity::getTenantId)
                .collect(Collectors.toSet());

        return new RoleWithTenantsIdsData(managedTenantIds);
    }

    @Nullable
    private Map<String, Set<String>> getAuthoritiesByTenant(List<Permission> userPermissions) {
        Map<String, Set<String>> authoritiesByTenant = new HashMap<>();
        for (Permission permissionsByTenant : userPermissions) {
            authoritiesByTenant.put(permissionsByTenant.getTenantId().getValue(), AnemonePermissionsToAuthorities.translate(permissionsByTenant.getPermissions()));
        }
        return CollectionUtils.isEmpty(authoritiesByTenant) ? null : authoritiesByTenant;
    }

    private void saveUser(@Nonnull UserEntity user) {
        userRepository.save(user);

        messagingBroker.sendEvent(new UserEvent(
                UserEvent.UserEventType.UPDATED,
                userServicePersistenceComponent.mapUserEntityToDomain(user)
        ));
    }
}

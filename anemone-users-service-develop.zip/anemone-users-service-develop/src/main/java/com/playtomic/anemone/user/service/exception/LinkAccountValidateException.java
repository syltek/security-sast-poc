package com.playtomic.anemone.user.service.exception;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

public class LinkAccountValidateException extends RuntimeException {

    public LinkAccountValidateException(@Nullable String e) {
        super(e);
    }

    public LinkAccountValidateException(@Nonnull Exception e) {
        super(e);
    }
}

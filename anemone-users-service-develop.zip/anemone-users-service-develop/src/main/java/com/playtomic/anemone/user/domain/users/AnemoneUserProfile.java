package com.playtomic.anemone.user.domain.users;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.domain.user.UserId;
import com.playtomic.anemone.user.domain.UserProfile;
import com.playtomic.anemone.user.model.PrivacyProfile;

import java.util.Locale;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;

public class AnemoneUserProfile implements UserProfile {

    @JsonProperty("user_id")
    @Nonnull
    @Override
    public UserId getId() {
        return UserId.valueOf("0");
    }

    @Nullable
    @Override
    public String getEmail() {
        return "activities@playtomic.io";
    }

    @Nullable
    @Override
    public String getPhone() {
        return null;
    }

    @JsonProperty("full_name")
    @Nonnull
    @Override
    public String getName() {
        return "anemone";
    }

    @JsonProperty("is_validated")
    @Override
    public boolean isValidated() {
        return true;
    }

    @Nullable
    @Override
    public String getBio() {
        return null;
    }

    @Nonnull
    @Override
    public String getCountryCode() {
        return "ES";
    }

    @JsonProperty("communications_language")
    @Nonnull
    @Override
    public Locale getCommunicationsLanguage() {
        return Locale.ENGLISH;
    }

    @JsonProperty("privacy_profile")
    @Nonnull
    @Override
    public PrivacyProfile getPrivacyProfile() {
        return PrivacyProfile.PUBLIC;
    }

    @JsonProperty("is_premium")
    @Override
    public boolean isPremium() {
        return false;
    }
}

package com.playtomic.anemone.category.service.exception;

import javax.annotation.ParametersAreNonnullByDefault;

@ParametersAreNonnullByDefault
public class CategoryMembersUpdateRejectedException extends RuntimeException{

  public CategoryMembersUpdateRejectedException(String message) {
    super(message);
  }
}

package com.playtomic.anemone.user.service.anemone;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.domain.user.UserId;
import com.playtomic.anemone.jwt.JwtTokenFactory;
import com.playtomic.anemone.spring.ForceAnemoneAuthenticationCredentialsAccessor;
import com.playtomic.anemone.spring.feign.AnemoneFeignConfiguration;
import com.playtomic.anemone.spring.feign.AuthenticationHeaderFeignInterceptor;
import lombok.Data;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;
import javax.annotation.Nonnull;
import feign.RequestInterceptor;

@FeignClient(name = "payments-service", configuration = PaymentsServiceClient.Configuration.class, url="${payments-service.url}")
public interface PaymentsServiceClient {

    @GetMapping("/v1/debts?is_settled=false&user_id={user_id}&size=1")
    @Nonnull
    List<Debt> findUserDebt(@PathVariable(name = "user_id") @Nonnull UserId userId);

    @Data
    class Debt {
        @Nonnull
        private String debtId;

        @JsonCreator
        public Debt(@JsonProperty("debt_id") @Nonnull String debtId) {
            this.debtId = debtId;
        }
    }

    class Configuration extends AnemoneFeignConfiguration {
        @Bean
        public RequestInterceptor requestInterceptor(@Nonnull JwtTokenFactory jwtTokenFactory) {
            return new AuthenticationHeaderFeignInterceptor(new ForceAnemoneAuthenticationCredentialsAccessor(jwtTokenFactory));
        }

    }
}

package com.playtomic.anemone.user.service.userimports;

import com.playtomic.anemone.dao.OptimisticLockingRetryableExecutor;
import com.playtomic.anemone.user.config.UserImportConfiguration;
import com.playtomic.anemone.user.dao.userimports.UserImportRepository;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import com.playtomic.anemone.user.domain.userimports.UserImport;
import com.playtomic.anemone.user.domain.userimports.UserImportError;
import com.playtomic.anemone.user.domain.userimports.UserImportId;
import com.playtomic.anemone.user.domain.userimports.UserImportStatus;
import com.playtomic.anemone.user.service.exception.UserImportNotFoundException;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.UUID;
import javax.annotation.Nonnull;

@Component
public class UserImportServicePersistenceComponent {

    @Nonnull
    private final UserImportRepository userImportRepository;

    public UserImportServicePersistenceComponent(
        @Nonnull UserImportRepository userImportRepository) {
        this.userImportRepository = userImportRepository;
    }

    @Nonnull
    public UserImport createUserImport(@Nonnull String userImportName,
                                       @Nonnull TenantId tenantId,
                                       long rowsSize) {
        UserImport userImport = UserImport.builder()
            .id(UserImportId.valueOf(UUID.randomUUID().toString()))
            .name(userImportName)
            .tenantId(tenantId)
            .status(UserImportStatus.PROCESSING)
            .totalFileRows(rowsSize)
            .build();

       return userImportRepository.save(userImport);
    }

    @Nonnull
    public UserImport getUserImportById(@Nonnull UserImportId userImportId) {
        return userImportRepository.findById(userImportId).orElseThrow(UserImportNotFoundException::new);
    }

    @Nonnull
    public UserImport updateUserImportUserLinked(@Nonnull UserImportId userImportId) {
        OptimisticLockingRetryableExecutor.OptimisticLockingRetryableAction<UserImport> action =
            () -> {
                UserImport userImport = userImportRepository.findById(userImportId)
                    .orElseThrow(UserImportNotFoundException::new);

                userImport.setExistingLinkedUsers(userImport.getExistingLinkedUsers() + 1);

                if (userImport.isFinished()) {
                    UserImportStatus resultStatus = userImport.getTotalErrors() > 0 ?
                        UserImportStatus.FINISHED_WITH_ERRORS :
                        UserImportStatus.FINISHED;

                    userImport.setStatus(resultStatus);
                }

                return userImportRepository.save(userImport);
            };

        OptimisticLockingRetryableExecutor<UserImport> executor = new OptimisticLockingRetryableExecutor<>(action,
            UserImportConfiguration.OPTIMISTIC_LOCKING_RETRIES);
        return executor.execute();
    }

    @Nonnull
    public UserImport updateUserImportAccountCreated(@Nonnull UserImportId userImportId) {
        OptimisticLockingRetryableExecutor.OptimisticLockingRetryableAction<UserImport> action =
            () -> {
                UserImport userImport = userImportRepository.findById(userImportId)
                    .orElseThrow(UserImportNotFoundException::new);

                userImport.setNewCreatedUsers(userImport.getNewCreatedUsers() + 1);
                if (userImport.isFinished()) {
                    UserImportStatus resultStatus = userImport.getTotalErrors() > 0 ?
                        UserImportStatus.FINISHED_WITH_ERRORS :
                        UserImportStatus.FINISHED;

                    userImport.setStatus(resultStatus);
                }

                return userImportRepository.save(userImport);
            };

        OptimisticLockingRetryableExecutor<UserImport> executor = new OptimisticLockingRetryableExecutor<>(action,
            UserImportConfiguration.OPTIMISTIC_LOCKING_RETRIES);
        return executor.execute();
    }

    @Nonnull
    public UserImport updateUserImportErrors(@Nonnull UserImportId userImportId,
                                             @Nonnull List<UserImportError> userImportErrors) {
        OptimisticLockingRetryableExecutor.OptimisticLockingRetryableAction<UserImport> action =
            () -> {
                UserImport userImport = userImportRepository.findById(userImportId)
                    .orElseThrow(UserImportNotFoundException::new);

                userImport.getErrorDetails().addAll(userImportErrors);
                userImport.setTotalErrors(userImport.getTotalErrors() + userImportErrors.size());

                if (userImport.isFinished()) {
                    UserImportStatus resultStatus = userImport.getTotalErrors() > 0 ?
                        UserImportStatus.FINISHED_WITH_ERRORS :
                        UserImportStatus.FINISHED;

                    userImport.setStatus(resultStatus);
                }

                return userImportRepository.save(userImport);
            };

        OptimisticLockingRetryableExecutor<UserImport> executor = new OptimisticLockingRetryableExecutor<>(action,
            UserImportConfiguration.OPTIMISTIC_LOCKING_RETRIES);
        return executor.execute();
    }

    @Nonnull
    public UserImport updateUserImportStatus(@Nonnull UserImportId userImportId,
                                             @Nonnull UserImportStatus userImportStatus) {
        OptimisticLockingRetryableExecutor.OptimisticLockingRetryableAction<UserImport> action =
            () -> {
                UserImport userImport = userImportRepository.findById(userImportId)
                    .orElseThrow(UserImportNotFoundException::new);
                userImport.setStatus(userImportStatus);
                return userImportRepository.save(userImport);
            };

        OptimisticLockingRetryableExecutor<UserImport> executor = new OptimisticLockingRetryableExecutor<>(action,
            UserImportConfiguration.OPTIMISTIC_LOCKING_RETRIES);
        return executor.execute();
    }

}

package com.playtomic.anemone.user.service.messaging;

import com.playtomic.anemone.domain.user.UserId;
import com.playtomic.anemone.user.config.MessagingConfiguration;
import com.playtomic.anemone.user.dao.LinkedAccountRepository;
import com.playtomic.anemone.user.domain.reservation.MerchantUserId;
import com.playtomic.anemone.user.domain.reservation.Reservation;
import com.playtomic.anemone.user.domain.tenant.ReservationTenant;
import com.playtomic.anemone.user.domain.tenant.Tenant;
import com.playtomic.anemone.user.service.UserLinkingTenantService;
import com.playtomic.anemone.user.service.anemone.TenantServiceClient;
import com.playtomic.anemone.user.service.exception.AutoLinkAccountAtAnemoneVenueException;
import com.playtomic.anemone.user.service.exception.LinkAccountValidateException;
import com.playtomic.anemone.user.service.exception.TenantNotFoundException;
import com.playtomic.anemone.user.service.exception.UserNotFoundException;
import com.playtomic.anemone.user.service.messaging.ReservationEvent.ReservationEventType;
import javax.annotation.Nonnull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.context.annotation.Lazy;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@Lazy(false)
public class ReservationsProcessor {
    public static final String INTERNAL_USER_ID = "0";

    @Nonnull
    private final TenantServiceClient tenantServiceClient;

    @Nonnull
    private final LinkedAccountRepository linkedAccountRepository;
    @Nonnull
    private final UserLinkingTenantService userLinkingTenantService;


    @StreamListener(MessagingConfiguration.ReservationsTopic.INPUT)
    public void handle(@Nonnull Message<ReservationEvent> reservationMessage) {
        log.info("Received Reservation Event: {}", reservationMessage);

        try {
            internalHandle(reservationMessage);
        } catch (Exception e) {
            log.error("Unhandled error when processing this message. Discarding", e);
        }

    }
    public ReservationsProcessor(
        @Nonnull TenantServiceClient tenantServiceClient,
        @Nonnull LinkedAccountRepository linkedAccountRepository,
        @Nonnull UserLinkingTenantService userLinkingTenantService) {
        this.tenantServiceClient = tenantServiceClient;
        this.linkedAccountRepository = linkedAccountRepository;
        this.userLinkingTenantService = userLinkingTenantService;
    }

    private void internalHandle(@Nonnull Message<ReservationEvent> reservationMessage) {
        Reservation reservation = reservationMessage.getPayload().getReservation();
        ReservationEventType eventType = reservationMessage.getPayload().getEventType();

        if(eventType != null && (ReservationEventType.RESERVATION_CANCELED.equals(eventType) ||
            ReservationEventType.RESERVATION_PRERESERVED.equals(eventType))){
            log.info("Ignoring creating prereservation or canceling reservation events - Don't try to autolink in this case");
            return;
        } else{
            autolink(reservation);
        }
    }

    private void autolink(@Nonnull Reservation reservation) {
        if ("PRERESERVATION".equalsIgnoreCase(reservation.getStatus())) {
            log.info("Ignoring PRERESERVATION - Don't try to autolink in this case.");
            return;
        }

        UserId userId = reservation.getUserId();
        //Skip special internally used user
        if (userId.getValue().equals(INTERNAL_USER_ID)) {
            log.info("Autolink skipped for user {}", INTERNAL_USER_ID);
            return;
        }

        // We are trying to remove tenant dependency from reservation, so get the data from the service.
        Tenant tenant;
        ReservationTenant reservationTenant = reservation.getTenant();
        //Skip user if already linked
        if (linkedAccountRepository.countByTenantIdAndUserId(reservationTenant.getTenantId().getValue(), Long.valueOf(userId.getValue())) > 0) {
            log.info("Autolink skipped for user {} (already linked account)", userId);
            return;
        }

        try {
            tenant = tenantServiceClient.getById(reservationTenant.getTenantId().getValue());
        } catch (TenantNotFoundException e) {
            log.info("Tenant with id {} not found. Discarding event", reservationTenant.getTenantId());
            return;
        }

        MerchantUserId merchantUserId = reservation.getMerchantUserId();
        try {
            if (merchantUserId != null) {
                userLinkingTenantService.linkTenant(userId, tenant, merchantUserId, null);
            } else {
                userLinkingTenantService.autolinkTenant(userId, tenant);
            }
        } catch (UserNotFoundException e) {
            log.warn("User {} not found", userId);
        } catch (LinkAccountValidateException e) {
            log.info("Account not linked because the user_id {} is not validated", userId);
        } catch (AutoLinkAccountAtAnemoneVenueException e) {
            log.info("Account not linked because tenant of anemone type");
        }
    }
}

package com.playtomic.anemone.user.service.email;

import com.playtomic.anemone.domain.Email;
import com.playtomic.anemone.domain.user.User;
import com.playtomic.anemone.service.AbstractLocalizableService;
import com.playtomic.anemone.user.api.v2.request.SuggestionTenantRequestBody;
import com.playtomic.anemone.user.service.anemone.EmailServiceClient;
import com.playtomic.anemone.user.service.email.UserEmailServiceConfiguration.EmailConfiguration;
import com.playtomic.anemone.user.service.email.UserEmailServiceConfiguration.WelcomeEmail;
import java.net.URI;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import javax.annotation.Nonnull;
import javax.annotation.ParametersAreNonnullByDefault;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@ParametersAreNonnullByDefault
public class UserEmailService extends AbstractLocalizableService {

    private static final String USER_ID = "userId";
    private static final String USER_NAME = "userName";
    private static final String USER_EMAIL = "userEmail";
    private static final String TENANT_NAME = "tenantName";
    private static final String TENANT_ADDRESS = "tenantAddress";
    private static final String TENANT_EMAIL = "tenantEmail";
    private static final String TENANT_PHONE = "tenantPhone";
    private static final String COMMENTS = "comments";
    private static final String SUBJECT = "subject";
    private static final String RESET_PASSWORD_URL = "resetPasswordUrl";
    private static final String VALIDATE_EMAIL_URL = "validateEmailUrl";
    private static final String ASCII_ENCODING_OF_PLUS = "%2B";

    @Nonnull
    private final UserEmailServiceConfiguration config;

    @Nonnull
    private final EmailServiceClient emailServiceClient;

    public UserEmailService(@Nonnull MessageSource messageSource,
        @Nonnull DiscoveryClient discoveryClient,
        @Nonnull UserEmailServiceConfiguration config,
        @Nonnull EmailServiceClient emailServiceClient) {
        super(messageSource, discoveryClient);
        this.config = config;
        this.emailServiceClient = emailServiceClient;
    }

    public void sendWelcomeEmail(String email, Map<String, Object> dynamicData, Locale locale) {
        WelcomeEmail welcomeEmail = config.getWelcomeEmail();
        EmailMessage request = new EmailMessage(welcomeEmail.getTemplateId(), welcomeEmail.getFrom(), Collections.singletonList(email),
            dynamicData, locale);

        sendEmail(request);
    }

    public void sendPasswordResetEmailManagerNewUser(String email, Locale locale, String resetUrlString) {

        EmailConfiguration emailConfiguration = config.getResetPasswordManagerNewUserConfig();

        Map<String, Object[]> placeHolderValuesMap = Map.of(
            EmailConstants.SUBJECT_KEY, new String[]{},
            EmailConstants.TITLE_KEY, new String[]{},
            EmailConstants.MESSAGE_KEY, new String[]{},
            EmailConstants.BUTTON_LABEL_KEY, new String[]{});

        EmailMessage emailMessage = buildEmailMessage(List.of(email), emailConfiguration, locale, placeHolderValuesMap);
        emailMessage.getDynamicData().put(EmailConstants.BUTTON_URL, resetUrlString);

        sendEmail(emailMessage);
    }

    public void sendManagerRoleAssignedEmail(String email, Locale locale, String loginUrlString, String tenantName) {
        EmailConfiguration emailConfiguration = config.getManagerRoleAddedConfig();

        Map<String, Object[]> placeHolderValuesMap = Map.of(
            EmailConstants.SUBJECT_KEY, new String[]{tenantName},
            EmailConstants.TITLE_KEY, new String[]{tenantName},
            EmailConstants.MESSAGE_KEY, new String[]{},
            EmailConstants.BUTTON_LABEL_KEY, new String[]{});

        EmailMessage emailMessage = buildEmailMessage(List.of(email), emailConfiguration, locale, placeHolderValuesMap);
        emailMessage.getDynamicData().put(EmailConstants.BUTTON_URL, loginUrlString);

        sendEmail(emailMessage);
    }

    public void sendResetCustomerPasswordEmail(@Nonnull Email email, @Nonnull Locale locale, boolean isNewUser, @Nonnull URI resetPasswordUrl){

        Map<String, Object> dynamicData = new HashMap<>();
        String resetUrlString = resetPasswordUrl.toString();
        //Sadly encoders that we are using doesn't scape '+'.
        resetUrlString = resetUrlString.replace("+", ASCII_ENCODING_OF_PLUS);
        dynamicData.put(RESET_PASSWORD_URL, resetUrlString);
        dynamicData.put(SUBJECT, getMessage("Email.Playtomic.ResetPasswordEmail.Subject", locale));

        EmailConfiguration emailConfig = isNewUser ? config.getResetPasswordManagerNewUserConfig()
            : config.getResetPasswordExistingUserConfig();
        EmailMessage emailMessage = new EmailMessage(emailConfig.getTemplateId(),
            emailConfig.getFrom(), List.of(email.getEmail()), dynamicData, locale);
        emailServiceClient.sendEmail(emailMessage);
    }

    public void sendValidationEmail(@Nonnull String email, @Nonnull Locale userLocale, @Nonnull URI validateUrl) {
        log.info("Sending validation email to {}", email);
        Map<String, Object> dynamicData = new HashMap<>();
        dynamicData.put(VALIDATE_EMAIL_URL, validateUrl);
        dynamicData.put(SUBJECT, getMessage("Email.Playtomic.ValidateEmail.Subject", userLocale));

        EmailConfiguration emailConfig = config.getValidateUserConfig();
        EmailMessage emailMessage = new EmailMessage(emailConfig.getTemplateId(),
            emailConfig.getFrom(), List.of(email), dynamicData, userLocale);
        emailServiceClient.sendEmail(emailMessage);
    }

    public void sendCustomerSuggestionEmail(@Nonnull SuggestionTenantRequestBody body,
        @Nonnull User currentUser, @Nonnull String username, @Nonnull Locale locale) {
        Map<String, Object> dynamicData = new HashMap<>();
        dynamicData.put(USER_ID, currentUser.getId());
        dynamicData.put(USER_NAME, username);
        dynamicData.put(USER_EMAIL, currentUser.getEmail());
        dynamicData.put(TENANT_NAME, body.getTenantName());
        dynamicData.put(TENANT_ADDRESS, body.getTenantAddress());
        dynamicData.put(COMMENTS, body.getComments());
        dynamicData.put(SUBJECT, getMessage("Email.Playtomic.Suggestion.CustomerSubject", locale));
        EmailConfiguration emailConfig = config.getCustomerSuggestionConfig();
        sendSuggestionEmail(dynamicData, emailConfig, locale);
    }

    //sendTenantSuggestionEmail and sendFeedbackEmail are using same template
    public void sendTenantSuggestionEmail(@Nonnull SuggestionTenantRequestBody body,
        @Nonnull User currentUser, @Nonnull String username, @Nonnull Locale locale) {
        Map<String, Object> dynamicData = new HashMap<>();
        dynamicData.put(USER_ID, currentUser.getId());
        dynamicData.put(USER_NAME, username);
        dynamicData.put(USER_EMAIL, currentUser.getEmail());
        dynamicData.put(TENANT_NAME, body.getTenantName());
        dynamicData.put(TENANT_EMAIL, body.getTenantEmail());
        dynamicData.put(TENANT_PHONE, body.getTenantPhone());
        dynamicData.put(SUBJECT, getMessage("Email.Playtomic.Suggestion.TenantSubject", locale));
        dynamicData.put(EmailConstants.LOCALE_KEY, locale);
        EmailConfiguration emailConfig = config.getTenantSuggestionConfig();
        sendSuggestionEmail(dynamicData, emailConfig, locale);
    }

    public void sendFeedbackEmail(@Nonnull String comments, @Nonnull User currentUser,
        @Nonnull String username, @Nonnull Locale locale) {
        Map<String, Object> dynamicData = new HashMap<>();
        dynamicData.put(USER_ID, currentUser.getId());
        dynamicData.put(USER_NAME, username);
        dynamicData.put(USER_EMAIL, currentUser.getEmail());
        dynamicData.put(COMMENTS, comments);
        dynamicData.put(SUBJECT, getMessage("Email.Playtomic.Feedback.Subject", locale));
        EmailConfiguration emailConfig = config.getTenantSuggestionConfig();
        sendSuggestionEmail(dynamicData, emailConfig, locale);
    }

    private void sendSuggestionEmail(@Nonnull Map<String, Object> dynamicData, @Nonnull EmailConfiguration emailConfig, @Nonnull Locale locale) {
        EmailMessage emailMessage = new EmailMessage(emailConfig.getTemplateId(),
            emailConfig.getFrom(), List.of(emailConfig.getTo()), dynamicData, locale);
        emailServiceClient.sendEmail(emailMessage);
    }

    @Nonnull
    private EmailMessage buildEmailMessage(List<String> emailToList,
        EmailConfiguration emailConfiguration, Locale locale,
        Map<String, Object[]> placeHolderValueMap) {

        Map<String, Object> dynamicData = placeHolderValueMap.entrySet().stream()
            .collect(Collectors.toMap(
                Entry::getKey,
                entry -> getMessage(emailConfiguration.getEmailPropertiesPrefix() + "." + StringUtils.capitalize(entry.getKey()), entry.getValue(),
                    locale)));
        dynamicData.put(EmailConstants.LOCALE_KEY, locale);

        return EmailMessage.builder()
            .templateId(emailConfiguration.getTemplateId())
            .from(emailConfiguration.getFrom())
            .to(emailToList)
            .dynamicData(dynamicData)
            .locale(locale)
            .build();
    }

    private void sendEmail(EmailMessage request){
        try {
            emailServiceClient.sendEmail(request);
            log.info("Welcome email is sent to {}", request);
        } catch (Exception e) {
            log.error("Unable to send welcome email", e);
        }
    }
}

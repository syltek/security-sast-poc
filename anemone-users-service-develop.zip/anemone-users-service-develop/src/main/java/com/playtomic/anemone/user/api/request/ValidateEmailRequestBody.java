package com.playtomic.anemone.user.api.request;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.domain.Email;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;

public class ValidateEmailRequestBody {

    @Nullable
    public Email email;

    @Nonnull
    public String validateToken;

    public ValidateEmailRequestBody() {
    }

    @JsonCreator
    public ValidateEmailRequestBody(
        @JsonProperty(value = "email", required = false) @Nullable Email email,
        @JsonProperty(value = "validate_token", required = true) @Nonnull String validateToken) {
        this.email = email;
        this.validateToken = validateToken;
    }
}

package com.playtomic.anemone.user.service.messaging;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.user.domain.matches.Match;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.annotation.Nonnull;

@ToString
@Getter
@Builder
@NoArgsConstructor
public class MatchEvent {

    @JsonProperty(value = "event_type", required = true)
    @Nonnull
    private String eventType;

    @JsonProperty(value = "event_data", required = true)
    @Nonnull
    private Match match;

    @JsonCreator
    protected MatchEvent(
        @JsonProperty(value = "event_type", required = true) @Nonnull String eventType,
        @JsonProperty(value = "event_data", required = true) @Nonnull Match match) {
        this.eventType = eventType;
        this.match = match;
    }
}

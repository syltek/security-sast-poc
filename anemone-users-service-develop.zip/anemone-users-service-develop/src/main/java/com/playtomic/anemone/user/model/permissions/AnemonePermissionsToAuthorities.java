package com.playtomic.anemone.user.model.permissions;

import java.util.Collections;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import javax.annotation.Nonnull;

public class AnemonePermissionsToAuthorities {

    private static final Map<PermissionName, PermissionsToAuthorities> permissionsMap;

    static {
        Map<PermissionName, PermissionsToAuthorities> realMap = new HashMap<>();
        permissionsMap = Collections.unmodifiableMap(realMap);

        realMap.put(PermissionName.SCHEDULE_PERMISSION, new SchedulerPermissionsToAuthorities());
        realMap.put(PermissionName.DASHBOARD_PERMISSION, new DashboardPermissionsToAuthorities());
        realMap.put(PermissionName.MATCHES_PERMISSION, new MatchPermissionsToAuthorities());
        realMap.put(PermissionName.CHATS_PERMISSION, new ChatPermissionsToAuthorities());
        realMap.put(PermissionName.TOURNAMENTS_PERMISSION, new TournamentPermissionsToAuthorities());
        realMap.put(PermissionName.LESSONS_PERMISSION, new LessonPermissionsToAuthorities());
        realMap.put(PermissionName.BILLING_PERMISSION, new BillingPermissionsToAuthorities());
        realMap.put(PermissionName.CUSTOMER_LIST_PERMISSION, new CustomerListPermissionsToAuthorities());
        realMap.put(PermissionName.EXPORT_CUSTOMER_PERMISSION, new ExportCustomerPermissionsToAuthorities());
        realMap.put(PermissionName.CUSTOMER_RECURRING_RESERVATIONS_PERMISSION, new CustomerRecurringReservationPermissionsToAuthorities());
        realMap.put(PermissionName.CUSTOMER_BENEFITS_PERMISSION, new CustomerBenefitPermissionsToAuthorities());
        realMap.put(PermissionName.SETTINGS_PERMISSION, new SettingPermissionsToAuthorities());

        realMap.put(PermissionName.INVOICES_PERMISSION, new InvoicePermissionsToAuthorities());
        realMap.put(PermissionName.COACHES_PERMISSION, new CoachPermissionsToAuthorities());
        realMap.put(PermissionName.LEAGUES_PERMISSION, new LeaguePermissionsToAuthorities());
        realMap.put(PermissionName.PREMIUM_PERMISSION, new PremiumPermissionsToAuthorities());
        realMap.put(PermissionName.ANEMONE_WALLETS_PERMISSION, new AnemoneWalletPermissionsToAuthorities());
        realMap.put(PermissionName.CUSTOMER_CATEGORIES_PERMISSION, new AnemoneCategoriesPermissionsToAuthorities());
    }

    @Nonnull
    public static Set<String> translate(@Nonnull EnumMap<PermissionName, PermissionLevel> permissions) {
        Set<String> authorities = new HashSet<>();
        for (Map.Entry<PermissionName, PermissionLevel> permission : permissions.entrySet()) {
            authorities.addAll(permissionsMap.get(permission.getKey()).translate(permission.getValue()));
        }
        return authorities;
    }
}

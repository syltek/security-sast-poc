package com.playtomic.anemone.user.service.exception;

public class InvalidCountryCodeException extends RuntimeException {
}

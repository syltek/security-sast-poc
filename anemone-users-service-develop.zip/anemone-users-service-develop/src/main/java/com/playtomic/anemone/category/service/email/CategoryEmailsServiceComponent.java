package com.playtomic.anemone.category.service.email;

import com.playtomic.anemone.category.config.CategoryEmailsConfiguration;
import com.playtomic.anemone.category.config.CategoryEmailsConfiguration.EmailConfiguration;
import com.playtomic.anemone.service.AbstractLocalizableService;
import com.playtomic.anemone.user.dao.TenantTagEntity;
import com.playtomic.anemone.user.dao.UserEntity;
import com.playtomic.anemone.user.domain.tenant.Tenant;
import com.playtomic.anemone.user.service.anemone.EmailServiceClient;
import com.playtomic.anemone.user.service.email.EmailMessage;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import javax.annotation.Nonnull;
import javax.annotation.ParametersAreNonnullByDefault;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.context.MessageSource;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

@ParametersAreNonnullByDefault
@Slf4j
@Component
public class CategoryEmailsServiceComponent extends AbstractLocalizableService {

    @Nonnull
    private final CategoryEmailsConfiguration categoryEmailsConfiguration;

    @Nonnull
    private final EmailServiceClient emailServiceClient;

    @Nonnull
    @Value("#{T(java.time.LocalTime).parse('${users-categories.emails.send-start-time}', T(java.time.format.DateTimeFormatter).ISO_LOCAL_TIME)}")
    private LocalTime emailSendStartTime;

    @Nonnull
    @Value("#{T(java.time.LocalTime).parse('${users-categories.emails.send-end-time}', T(java.time.format.DateTimeFormatter).ISO_LOCAL_TIME)}")
    private LocalTime emailSendEndTime;

    public CategoryEmailsServiceComponent(@Nonnull MessageSource messageSource,
        @Nonnull DiscoveryClient discoveryClient,
        @Nonnull CategoryEmailsConfiguration categoryEmailsConfiguration,
        @Nonnull EmailServiceClient emailServiceClient) {
        super(messageSource, discoveryClient);
        this.categoryEmailsConfiguration = categoryEmailsConfiguration;
        this.emailServiceClient = emailServiceClient;
    }

    @Async
    public void sendNewMemberEmail(List<UserEntity> users, String categoryName, Tenant tenant) {
        if (shouldSendNotifications(tenant)) {
            List<EmailMessage> emailMessages = users.stream()
                .filter(UserEntity::isEmailVerified)
                .map(userEntity -> buildNewMemberEmail(userEntity, tenant.getTenantName(), categoryName, tenant.getTenantAddress().getZoneId()))
                .collect(Collectors.toList());

            sendEmailBatch(emailMessages);
        }
    }

    @Async
    public void sendExpirationReminderEmail(UserEntity userEntity, String categoryName, Instant expiresAt, Tenant tenant) {
        if (shouldSendNotifications(tenant) && userEntity.isEmailVerified()) {
            EmailMessage emailMessage = buildExpirationReminderEmail(userEntity, tenant.getTenantName(), categoryName, expiresAt,
                tenant.getTenantAddress().getZoneId());

            sendEmailBatch(List.of(emailMessage));
        }
    }

    @Async
    public void sendCategoryRemovedEmails(List<TenantTagEntity> tenantTagEntityList, String categoryName, Tenant tenant) {
        if (shouldSendNotifications(tenant)) {
            List<EmailMessage> emailMessages = tenantTagEntityList.stream()
                .filter(tenantTagEntity -> tenantTagEntity.getUser().isEmailVerified())
                .map(tenantTagEntity -> buildMemberRemovedEmail(tenantTagEntity.getUser(), tenant.getTenantName(), categoryName,
                    tenant.getTenantAddress().getZoneId()))

                .collect(Collectors.toList());

            sendEmailBatch(emailMessages);
        }
    }

    @Nonnull
    private EmailMessage buildNewMemberEmail(UserEntity user, String tenantName, String categoryName, ZoneId tenantZoneId) {

        EmailConfiguration emailConfiguration = categoryEmailsConfiguration.getNewMemberEmailConfig();

        Map<String, Object[]> placeHolderValuesMap = Map.of(
            EmailConstants.SUBJECT_KEY, new String[]{},
            EmailConstants.TITLE_KEY, new String[]{categoryName},
            EmailConstants.MESSAGE_KEY, new String[]{tenantName, categoryName});

        return buildEmailMessage(List.of(user.getEmail()), emailConfiguration, user.getCommunicationsLanguageLocale(), placeHolderValuesMap,
            tenantZoneId);
    }

    private EmailMessage buildExpirationReminderEmail(UserEntity user, String tenantName, String categoryName, Instant expirationDate,
        ZoneId tenantZoneId) {

        EmailConfiguration emailConfiguration = categoryEmailsConfiguration.getExpirationReminderEmailConfig();

        Locale locale = user.getCommunicationsLanguageLocale();
        String dateOfExpiration = LocalDate.ofInstant(expirationDate, tenantZoneId)
            .format(DateTimeFormatter.ofLocalizedDate(FormatStyle.LONG).localizedBy(locale));

        Map<String, Object[]> placeHolderValuesMap = Map.of(
            EmailConstants.SUBJECT_KEY, new String[]{},
            EmailConstants.TITLE_KEY, new String[]{categoryName},
            EmailConstants.MESSAGE_KEY, new String[]{dateOfExpiration, tenantName, categoryName});

        return buildEmailMessage(List.of(user.getEmail()), emailConfiguration, locale, placeHolderValuesMap, tenantZoneId);
    }

    private EmailMessage buildMemberRemovedEmail(UserEntity user, String tenantName, String categoryName, ZoneId tenantZoneId) {

        EmailConfiguration emailConfiguration = categoryEmailsConfiguration.getRemovedMemberEmailConfig();

        Map<String, Object[]> placeHolderValuesMap = Map.of(
            EmailConstants.SUBJECT_KEY, new String[]{},
            EmailConstants.TITLE_KEY, new String[]{categoryName},
            EmailConstants.MESSAGE_KEY, new String[]{tenantName, categoryName});

        return buildEmailMessage(Collections.singletonList(user.getEmail()), emailConfiguration, user.getCommunicationsLanguageLocale(),
            placeHolderValuesMap, tenantZoneId);
    }

    @Nonnull
    private EmailMessage buildEmailMessage(List<String> emailToList, EmailConfiguration emailConfiguration, Locale locale,
        Map<String, Object[]> placeHolderValueMap, ZoneId tenantZoneId) {

        Map<String, Object> dynamicData = placeHolderValueMap.entrySet().stream()
            .collect(Collectors.toMap(
                Entry::getKey,
                entry -> getMessage(emailConfiguration.getEmailPropertiesPrefix() + "." + StringUtils.capitalize(entry.getKey()), entry.getValue(),
                    locale)));
        dynamicData.put(EmailConstants.LOCALE_KEY, locale);

        return EmailMessage.builder()
            .templateId(emailConfiguration.getTemplateId())
            .from(emailConfiguration.getFrom())
            .to(emailToList)
            .sendTimeZoneId(tenantZoneId)
            .sendAfterTime(emailSendStartTime)
            .sendBeforeTime(emailSendEndTime)
            .dynamicData(dynamicData)
            .locale(locale)
            .build();
    }

    private void sendEmailBatch(List<EmailMessage> emailMessages) {
        if (!emailMessages.isEmpty()) {
            emailServiceClient.sendEmailBatch(emailMessages);
        }
    }

    // Requested by Product team: We only skip the notifications if the tenant is inactive
    // With UNBOOKABLE and ACTIVE status we should maintain the notifications
    private boolean shouldSendNotifications(Tenant tenant) {
        return !tenant.isInactive();
    }

}

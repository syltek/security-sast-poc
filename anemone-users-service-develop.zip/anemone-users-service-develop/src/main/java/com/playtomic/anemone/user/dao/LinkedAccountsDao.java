package com.playtomic.anemone.user.dao;

import com.playtomic.anemone.domain.user.UserId;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;
import javax.annotation.Nonnull;
import javax.persistence.EntityManager;
import org.springframework.stereotype.Service;

/**
 * This is a DAO and not a Repository because we don't want to give access
 * to all the method of a repository for linked_accounts. This is just an optimization.
 */
@Service
public class LinkedAccountsDao {

    @Nonnull
    private EntityManager em;

    @Nonnull
    private String query;

    public LinkedAccountsDao(@Nonnull EntityManager em) {
        this.em = em;

        this.query = String.format("SELECT tenantId from %s where user_id = ?1", LinkedAccountEntity.class.getSimpleName());
    }

    @Nonnull
    public Collection<TenantId> getLinkedAccountsIds(@Nonnull UserId userId) {
        List<String> tenantIds = em.createQuery(query)
            .setParameter(1, userId.toString())
            .getResultList();

        return tenantIds.stream().map(s -> TenantId.valueOf(s)).collect(Collectors.toList());
    }
}

package com.playtomic.anemone.user.service.exception;

import lombok.Getter;

import java.util.List;
import javax.annotation.Nonnull;

@Getter
public class UserImportMismatchException extends RuntimeException {

    @Nonnull
    private final List<String> missingHeaders;

    @Nonnull
    private final List<String> extraHeaders;

    public UserImportMismatchException(@Nonnull List<String> missingHeaders,
                                       @Nonnull List<String> extraHeaders,
                                       @Nonnull String message) {
        super(message);
        this.missingHeaders = missingHeaders;
        this.extraHeaders = extraHeaders;
    }
}

package com.playtomic.anemone.user.domain.matches;

import com.playtomic.anemone.domain.generic.AbstractStringId;

import javax.annotation.Nonnull;

public class MatchId extends AbstractStringId {

	protected MatchId(@Nonnull String id) {
		super(id);
	}

	@Nonnull
	public static MatchId valueOf(@Nonnull String id) {
		return new MatchId(id);
	}

}

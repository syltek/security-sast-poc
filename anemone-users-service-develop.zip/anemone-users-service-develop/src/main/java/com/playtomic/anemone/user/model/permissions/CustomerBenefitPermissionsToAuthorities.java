package com.playtomic.anemone.user.model.permissions;

import java.util.Map;

public class CustomerBenefitPermissionsToAuthorities extends PermissionsToAuthorities {

    private static final Map<PermissionLevel, String[]> authorities = Map.ofEntries(
            e(PermissionLevel.READ_ONLY, "read_price_benefits", "read_tenant_tags"),
            e(PermissionLevel.READ_WRITE, "write_price_benefits", "write_tenant_tags")
    );

    public CustomerBenefitPermissionsToAuthorities() {
        super(authorities);
    }

}

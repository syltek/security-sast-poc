package com.playtomic.anemone.user.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import com.playtomic.anemone.user.model.role.PlaytomicUserRole;

import lombok.Getter;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

@Getter
public class ExtendedUserRole {

    @Nonnull
    @JsonProperty("user_role")
    private PlaytomicUserRole userRole;

    @Nullable
    @JsonProperty("tenant_id")
    private TenantId tenantId;

    @JsonCreator
    public ExtendedUserRole(
            @JsonProperty(value = "user_role", required = true) @Nonnull PlaytomicUserRole userRole,
            @JsonProperty(value = "tenant_id", required = false) @Nullable TenantId tenantId) {
        this.userRole = userRole;
        this.tenantId = tenantId;
    }

}

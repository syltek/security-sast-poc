package com.playtomic.anemone.user.service;

import com.playtomic.anemone.domain.user.UserId;
import com.playtomic.anemone.user.domain.UserProfile;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import com.playtomic.anemone.user.model.TenantTag;
import com.playtomic.anemone.user.service.messaging.MessagingBroker;
import com.playtomic.anemone.user.service.messaging.UserEvent;
import com.playtomic.anemone.user.service.messaging.UserEvent.UserEventType;
import java.util.Set;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
@ParametersAreNonnullByDefault
public class UserTenantTagService {

  @Nonnull
  private final MessagingBroker messagingBroker;

  @Nonnull
  private final UserServicePersistenceComponent userServicePersistenceComponent;

  @Nonnull
  public UserProfile createTenantTags(UserId userId, TenantTag tenantTag) {
    UserProfile saved = userServicePersistenceComponent.createTenantTags(userId, tenantTag);
    sendUserUpdateEvent(saved);

    return saved;
  }

  @Nonnull
  public UserProfile updateTenantTags(UserId userId, Set<TenantTag> tenantTags) {
    UserProfile saved = userServicePersistenceComponent.updateTenantTags(userId, tenantTags);
    sendUserUpdateEvent(saved);

    return saved;
  }

  @Nonnull
  public UserProfile updateTenantTagsForTenantId(UserId userId, TenantId tenantId, Set<String> tenantTags) {
    UserProfile saved = userServicePersistenceComponent.updateTenantTagsForTenantId(userId, tenantId, tenantTags);
    sendUserUpdateEvent(saved);

    return saved;
  }

  @Nonnull
  public UserProfile removeTenantTags(UserId userId, @Nullable Set<String> tenantTags, TenantId tenantId) {
    UserProfile saved = userServicePersistenceComponent.removeTenantTags(userId, tenantTags, tenantId);
    sendUserUpdateEvent(saved);

    return saved;
  }

  private void sendUserUpdateEvent(UserProfile user) {
    messagingBroker.sendEvent(new UserEvent(UserEventType.UPDATED, user));
  }
}

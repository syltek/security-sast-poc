package com.playtomic.anemone.user.service.anemone;

public class AnemoneServices {
    public final static String AVAILABILITY_SERVICE = "anemone-availability-service";
    public final static String CONFIGURATION_SERVICE = "anemone-configuration-service";
    public final static String TENANTS_SERVICE = "anemone-tenants-service";
    public final static String USER_SERVICE = "user-service";
    public final static String VOUCHERS_SERVICE = "anemone-vouchers-service";
    public final static String PAYMENTS_SERVICE = "anemone-payments-service";

    public static String[] required() {
        return new String[] {USER_SERVICE, VOUCHERS_SERVICE, PAYMENTS_SERVICE};
    }
}
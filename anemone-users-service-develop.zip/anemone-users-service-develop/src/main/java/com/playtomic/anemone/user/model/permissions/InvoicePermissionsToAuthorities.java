package com.playtomic.anemone.user.model.permissions;

import java.util.Map;

public class InvoicePermissionsToAuthorities extends PermissionsToAuthorities {

    private static final Map<PermissionLevel, String[]> authorities = Map.ofEntries(
            e(PermissionLevel.READ_ONLY, "read_customer_invoices"),
            e(PermissionLevel.READ_WRITE, "create_customer_invoices", "update_customer_invoices", "write_customer_invoices_payments")
    );

    public InvoicePermissionsToAuthorities() {
        super(authorities);
    }

}

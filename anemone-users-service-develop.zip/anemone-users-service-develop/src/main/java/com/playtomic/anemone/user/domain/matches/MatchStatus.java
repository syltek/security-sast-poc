package com.playtomic.anemone.user.domain.matches;

public enum MatchStatus {
    PENDING,
    IN_PROGRESS,
    PLAYED,
    VALIDATING,
    CONFIRMED,
    REJECTED,
    EXPIRED,
    CANCELED
}

package com.playtomic.anemone.user.service.facebook.exception;

public class InvalidFacebookTokenException extends RuntimeException {
    public InvalidFacebookTokenException(Exception e) {
        super(e);
    }
}

package com.playtomic.anemone.user.service.messaging;

import com.playtomic.anemone.user.config.MessagingConfiguration;
import com.playtomic.anemone.user.domain.userimports.UserImport;
import com.playtomic.anemone.user.domain.userimports.UserImportDataRow;
import com.playtomic.anemone.user.domain.userimports.UserImportId;
import com.playtomic.anemone.user.service.userimports.UserImportProcessorServiceComponent;
import com.playtomic.anemone.user.service.userimports.UserImportServicePersistenceComponent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Service;

import javax.annotation.Nonnull;

@Service
@Slf4j
public class UserImportsProcessor {

    @Nonnull
    private final UserImportProcessorServiceComponent userImportProcessor;

    @Nonnull
    private final UserImportServicePersistenceComponent userImportServicePersistenceComponent;

    public UserImportsProcessor(@Nonnull UserImportProcessorServiceComponent userImportProcessor,
                                @Nonnull UserImportServicePersistenceComponent userImportServicePersistenceComponent) {
        this.userImportProcessor = userImportProcessor;
        this.userImportServicePersistenceComponent = userImportServicePersistenceComponent;
    }

    @StreamListener(MessagingConfiguration.UserImportsTopicInput.INPUT)
    public void handle(@Nonnull Message<UserImportEvent> userImportMessage) {
        try {
            internalHandle(userImportMessage);
        } catch (Exception e) {
            log.error("Unhandled error when processing this message. Discarding", e);
        }
    }

    private void internalHandle(@Nonnull Message<UserImportEvent> userImportMessage) {
        UserImportDataRow userImportDataRow = userImportMessage.getPayload().getUserImportDataRow();

        UserImportId userImportId = userImportDataRow.getUserImportId();
        if (userImportId == null) {
            log.error("Cannot process imports without specifying userImportId. Ignoring event.");
            return;
        }

        // Check that the import has not been manually stopped
        UserImport userImport = userImportServicePersistenceComponent.getUserImportById(userImportId);
        if (userImport.isManuallyStopped() || userImport.hasExpired()) {
            log.debug("Interrupted user import {}. Reason: {}", userImport.getId(), userImport.getStatus());
            return;
        }

        userImportProcessor.processEventData(userImportId, userImportDataRow);
    }

}

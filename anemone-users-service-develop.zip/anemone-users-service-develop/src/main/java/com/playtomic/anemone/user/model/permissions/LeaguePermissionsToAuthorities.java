package com.playtomic.anemone.user.model.permissions;

import java.util.Map;

public class LeaguePermissionsToAuthorities extends PermissionsToAuthorities {

    private static final Map<PermissionLevel, String[]> authorities = Map.ofEntries(
            e(PermissionLevel.READ_ONLY, "read_leagues", "read_private_data"),
            e(PermissionLevel.READ_WRITE, "write_leagues", "delete_team", "add_team")
    );

    public LeaguePermissionsToAuthorities() {
        super(authorities);
    }

}

package com.playtomic.anemone.user.model.permissions;

import java.util.Map;
import javax.annotation.Nonnull;

public class AnemoneCategoriesPermissionsToAuthorities extends PermissionsToAuthorities {

    @Nonnull
    private static final Map<PermissionLevel, String[]> AUTHORITIES = Map.ofEntries(
        e(PermissionLevel.READ_ONLY, "read_categories"),
        e(PermissionLevel.READ_WRITE, "write_categories")
    );

    public AnemoneCategoriesPermissionsToAuthorities() {
        super(AUTHORITIES);
    }
}

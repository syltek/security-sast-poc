package com.playtomic.anemone.user.api.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;

@AllArgsConstructor
public class PhoneTokenResponseBody {

    @JsonProperty(value = "phone_token")
    public String phoneToken;
}
package com.playtomic.anemone.user.domain.userimports;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.user.domain.tenant.Tenant;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Builder;
import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Field;

@Data
@Builder
public class UserImportDataRow {

    @Nonnull
    @JsonProperty(value = "name")
    @Field(value = "name")
    private String name;

    @Nonnull
    @JsonProperty(value = "email")
    @Field(value = "email")
    private String email;

    @Nullable
    @JsonProperty(value = "phone_number")
    @Field(value = "phone_number")
    private String phoneNumber;

    @Nullable
    @JsonProperty(value = "gender")
    @Field(value = "gender")
    private String gender;

    @Nullable
    @JsonProperty(value = "birthdate")
    @Field(value = "birthdate")
    private String birthDate;

    @JsonProperty("category_name")
    @Nullable
    private String categoryName;

    @Nullable
    @JsonProperty("category_expires_at")
    private String categoryExpiresAt;

    @Nullable
    @JsonProperty(value = "user_import_id")
    private UserImportId userImportId;

    @Nullable
    @JsonProperty(value = "tenant")
    private Tenant tenant;

    @JsonProperty("welcome_message")
    @Nullable
    private String welcomeMessage;

    @Nullable
    @JsonProperty("created_by")
    private String createdBy;

    @JsonCreator
    public UserImportDataRow(@JsonProperty(value = "name", required = true) @Nonnull String name,
        @JsonProperty(value = "email", required = true) @Nonnull String email,
        @JsonProperty(value = "phone_number") @Nullable String phoneNumber,
        @JsonProperty(value = "gender") @Nullable String gender,
        @JsonProperty(value = "birthdate") @Nullable String birthDate,
        @JsonProperty(value = "category_name") @Nullable String categoryName,
        @JsonProperty(value = "category_expires_at") @Nullable String categoryExpiresAt,
        @JsonProperty(value = "user_import_id") @Nullable UserImportId userImportId,
        @JsonProperty(value = "tenant") @Nullable Tenant tenant,
        @JsonProperty(value = "welcome_message") @Nullable String welcomeMessage,
        @JsonProperty(value = "created_by") @Nullable String createdBy) {
        this.name = name;
        this.email = email;
        this.phoneNumber = phoneNumber != null && !phoneNumber.isEmpty() ? phoneNumber : null;
        this.gender = gender;
        this.birthDate = birthDate;
        this.categoryName = categoryName;
        this.categoryExpiresAt = categoryExpiresAt;
        this.userImportId = userImportId;
        this.tenant = tenant;
        this.welcomeMessage = welcomeMessage;
        this.createdBy = createdBy;
    }

}

package com.playtomic.anemone.user.service.apple;

import com.playtomic.anemone.domain.Email;
import lombok.Data;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

@Data
public class AppleUserData {
    @Nonnull
    private AppleId appleId;

    @Nullable
    private Email email;

    private boolean isVerified;

    public AppleUserData(@Nonnull AppleId appleId,
                         @Nullable Email email,
                         boolean isVerified) {
        this.appleId = appleId;
        this.email = email;
        this.isVerified = isVerified;
    }
}

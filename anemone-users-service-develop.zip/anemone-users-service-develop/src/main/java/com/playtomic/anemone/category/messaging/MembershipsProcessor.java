package com.playtomic.anemone.category.messaging;

import com.playtomic.anemone.category.messaging.MembershipEvent.MembershipEventType;
import com.playtomic.anemone.category.service.CategoryService;
import com.playtomic.anemone.user.config.MessagingConfiguration;
import javax.annotation.Nonnull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class MembershipsProcessor {

    @Nonnull
    private final CategoryService categoryService;

    public MembershipsProcessor(@Nonnull CategoryService categoryService) {
        this.categoryService = categoryService;
    }

    @StreamListener(MessagingConfiguration.MembershipsTopic.INPUT)
    public void handle(@Nonnull Message<MembershipEvent> membershipMessage) {
        log.info("Received membership event: {}", membershipMessage);
        try {
            var membershipEvent = membershipMessage.getPayload();
            internalHandle(membershipEvent.getEventType(), membershipEvent.getUserId(), membershipEvent.getMembershipProductId());
        } catch (Exception e) {
            //Should we discard them or retry them a few times?
            log.error("Unhandled error when processing this membership message. Discarding", e);
        }
    }

    private void internalHandle(@Nonnull MembershipEventType eventType, @Nonnull String userId, @Nonnull String membershipProductId) {
        switch(eventType){
            case MEMBERSHIP_SUBSCRIPTION_ACTIVATED:
                categoryService.addMemberToMembership(userId, membershipProductId);
                break;
            case MEMBERSHIP_SUBSCRIPTION_CANCELLED:
                categoryService.removeMemberFromMembership(userId, membershipProductId);
                break;
        }
    }

}

package com.playtomic.anemone.user.service.exception;

import java.io.IOException;
import javax.annotation.Nonnull;
import javax.annotation.ParametersAreNonnullByDefault;

@ParametersAreNonnullByDefault
public class ExportCsvException extends RuntimeException {

    public ExportCsvException(@Nonnull String message) {
        super("Error exporting csv " + message);
    }

    public ExportCsvException(@Nonnull IOException exception) {
        this(exception.getMessage());
    }
}

package com.playtomic.anemone.user.domain.voucher;

import com.playtomic.anemone.domain.generic.AbstractStringId;
import javax.annotation.Nonnull;

/**
 *
 */
public class VoucherId extends AbstractStringId {
    protected VoucherId(@Nonnull String id) {
        super(id);
    }

    public static VoucherId valueOf(String id) {
        return new VoucherId(id);
    }

}

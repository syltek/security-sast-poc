package com.playtomic.anemone.category.dao;

import com.playtomic.anemone.category.domain.CategoryId;
import com.playtomic.anemone.category.domain.CategoryType;
import com.playtomic.anemone.category.domain.MembershipProductId;
import com.playtomic.anemone.category.domain.Visibility;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import java.util.List;
import java.util.Optional;
import javax.annotation.Nonnull;
import javax.annotation.ParametersAreNonnullByDefault;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

@ParametersAreNonnullByDefault
public interface CategoryRepository extends MongoRepository<CategoryDocument, CategoryId> {

    @Nonnull
    Optional<CategoryDocument> findByTenantIdAndNameIgnoreCase(TenantId tenantId, String name);

    @Nonnull
    Page<CategoryDocument> findByTenantId(TenantId tenantId, Pageable pageable);

    @Nonnull
    Page<CategoryDocument> findByTenantIdAndNameLikeIgnoreCase(TenantId tenantId, String name, Pageable pageable);

    @Nonnull
    Page<CategoryDocument> findByIdInAndTenantId(List<CategoryId> categoryIds, TenantId tenantId, Pageable pageable);

    @Nonnull
    Page<CategoryDocument> findByCategoryTypeAndTenantId(CategoryType categoryType, TenantId tenantId, Pageable pageable);

    @Nonnull
    Page<CategoryDocument> findByIdIn(List<CategoryId> categoryIds, Pageable pageable);

    @Nonnull
    @Query("{'membership_details' : {$ne:null}, 'membership_details.visibility' : ?0 , 'tenant_id' : ?1 }")
    Page<CategoryDocument> findByVisibilityAndTenantId(Visibility visibility, TenantId tenantId, Pageable pageable);

    @Nonnull
    @Query("{ 'membership_details.membership_product_id' : ?0 }")
    Optional<CategoryDocument> findByMembershipProductId(MembershipProductId membershipProductId);
}

package com.playtomic.anemone.user.model.permissions;

import java.util.Map;

public class ExportCustomerPermissionsToAuthorities extends PermissionsToAuthorities {

  private static final Map<PermissionLevel, String[]> authorities = Map.ofEntries(
      e(PermissionLevel.READ_ONLY, "export_customer_data"),
      e(PermissionLevel.READ_WRITE, "export_customer_data")
  );

  public ExportCustomerPermissionsToAuthorities() {
    super(authorities);
  }
}

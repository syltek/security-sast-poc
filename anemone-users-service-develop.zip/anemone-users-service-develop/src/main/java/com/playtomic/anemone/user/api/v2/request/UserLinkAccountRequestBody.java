package com.playtomic.anemone.user.api.v2.request;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.domain.Email;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;

public class UserLinkAccountRequestBody {

    @Nonnull
    public TenantId tenantId;

    @Nullable
    public Email email;

    @Nullable
    public String password;

    public boolean autoregister;

    @Nullable
    public Boolean acceptsCommercial;

    @JsonCreator
    public UserLinkAccountRequestBody(
        @JsonProperty(value = "tenant_id", required = true) @Nonnull TenantId tenantId,
        @JsonProperty(value = "email") @Nullable Email email,
        @JsonProperty(value = "tenant_password") @Nullable String password,
        @JsonProperty(value = "autoregister", defaultValue = "false") boolean autoregister,
        @JsonProperty(value = "accepts_commercial") @Nullable Boolean acceptsCommercial) {
        this.tenantId = tenantId;
        this.email = email;
        this.password = password;
        this.autoregister = autoregister;
        this.acceptsCommercial = acceptsCommercial;
    }
}

package com.playtomic.anemone.user.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.domain.user.UserId;
import com.playtomic.anemone.user.domain.UserProfile;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.net.URL;
import java.util.Locale;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;

@AllArgsConstructor
@Data
public class PublicUserProfile implements UserProfile {

    @JsonProperty("user_id")
    @Nonnull
    private UserId id;

    @JsonProperty("full_name")
    @Nonnull
    private String name;

    @JsonProperty("picture")
    @Nullable
    private URL picture;

    @JsonProperty("is_validated")
    private boolean isValidated;

    @JsonProperty("is_email_verified")
    private boolean isEmailVerified;

    @JsonProperty("is_phone_verified")
    private boolean isPhoneVerified;

    @JsonProperty("bio")
    @Nullable
    private String bio;

    @JsonProperty("communications_language")
    @Nonnull
    private Locale communicationsLanguage;

    @JsonProperty("country_code")
    @Nonnull
    private String countryCode;

    @JsonProperty("email")
    @Nullable
    private String email;

    @JsonProperty("phone")
    @Nullable
    private String phone;

    @JsonProperty("facebook_id")
    @Nullable
    private String facebookId;

    @JsonProperty("address")
    @Nullable
    private PublicCustomerAddress address;

    @JsonProperty("privacy_profile")
    @Nonnull
    private PrivacyProfile privacyProfile;

    @JsonProperty("is_premium")
    private boolean isPremium;

    // This method exists because we have to read the complete CustomerUserProfile to check
    // is the caller have access
    public PublicUserProfile(@Nonnull UserProfile user, boolean includeContactData) {
        id = user.getId();
        name = user.getName();
        if (user instanceof CustomerUserProfile) {
            CustomerUserProfile userProfile = (CustomerUserProfile)user;
            picture = userProfile.getPicture();
            isPhoneVerified = userProfile.isPhoneVerified();
            isEmailVerified = userProfile.isEmailVerified();
            this.address = new PublicCustomerAddress(userProfile.getAddress());
        }
        this.privacyProfile = user.getPrivacyProfile();
        isValidated = user.isValidated();
        bio = user.getBio();
        communicationsLanguage = user.getCommunicationsLanguage();
        countryCode = user.getCountryCode();
        isPremium = user.isPremium();

        if (includeContactData) {
            this.email = user.getEmail();
            this.phone = user.getPhone();
        }
    }

    @Nullable
    @Override
    public String getEmail() {
        return null;
    }
}

package com.playtomic.anemone.category.service.exception;

import javax.annotation.Nonnull;

public class StripeProductCreationFailedException extends RuntimeException {

    public StripeProductCreationFailedException(@Nonnull String categoryName) {
        super(String.format("Membership category %s could not be created because of a failure on the Stripe product creation process", categoryName));
    }
}


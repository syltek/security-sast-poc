package com.playtomic.anemone.user.api.v2.request;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.domain.Email;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import com.playtomic.anemone.user.model.CustomerAddress;
import com.playtomic.anemone.user.model.ExtendedUserRole;
import com.playtomic.anemone.user.model.UserGender;
import java.time.ZonedDateTime;
import java.util.Collections;
import java.util.Locale;
import java.util.Set;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Data;
import org.apache.kafka.common.config.types.Password;

@Data
public class PostUserBody {

    @Nonnull
    private Email email;

    @Nullable
    private Password password;

    @Nonnull
    private String fullName;

    @Nullable
    private String phone;

    @Nonnull
    private String countryCode;

    @Nullable
    private Locale communicationsLanguage;

    @Nullable
    private ZonedDateTime birthDate;

    @Nullable
    private UserGender gender;

    @Nullable
    public CustomerAddress address;

    @Nullable
    public String pictureBase64;

    @Nullable
    private TenantId tenantId;

    @Nonnull
    private Set<ExtendedUserRole> roles;

    @JsonCreator
    public PostUserBody(
            @JsonProperty(value = "email", required = true) @Nonnull Email email,
            @JsonProperty(value = "password", required = false) @Nullable String password,
            @JsonProperty(value = "full_name", required = true) @Nonnull String fullName,
            @JsonProperty(value = "phone") @Nullable String phone,
            @JsonProperty(value = "country_code", required = true) @Nonnull String countryCode,
            @JsonProperty(value = "communications_language", required = false) @Nullable Locale communicationsLanguage,
            @JsonProperty(value = "birth_date", required = false) @Nullable ZonedDateTime birthDate,
            @JsonProperty(value = "gender", required = false) @Nullable UserGender gender,
            @JsonProperty(value = "address", required = false) @Nullable CustomerAddress address,
            @JsonProperty(value = "picture", required = false) @Nullable String pictureBase64,
            @JsonProperty(value = "created_by_tenant_id") @Nullable TenantId tenantId,
            @JsonProperty(value = "user_roles") @Nullable Set<ExtendedUserRole> roles
    ) {
        this.email = email;
        this.password = password == null ? null : new Password(password);
        this.fullName = fullName;
        this.phone = phone;
        this.countryCode = countryCode;
        this.communicationsLanguage = communicationsLanguage;
        this.birthDate = birthDate;
        this.gender = gender;
        this.address = address;
        this.pictureBase64 = pictureBase64;
        this.tenantId = tenantId;
        this.roles = roles == null ? Collections.emptySet() : roles;
    }
}

package com.playtomic.anemone.user.config;

import com.github.benmanes.caffeine.cache.Caffeine;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;
import javax.annotation.Nonnull;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.caffeine.CaffeineCache;
import org.springframework.cache.support.SimpleCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableCaching
@ConfigurationProperties("cache")
public class CacheConfiguration {

    @Nonnull
    public static final Duration MONGODB_CACHE_EXPIRATION_TIME = Duration.ofDays(1);

    // By default, 12h => Half of the MONGODB_CACHE_EXPIRATION_TIME
    // It can be overwritten using cache.timeout_seconds.
    private int timeoutSeconds = (int) MONGODB_CACHE_EXPIRATION_TIME.dividedBy(2).toSeconds();

    // We are storing 50k users in this cache.
    // As this cache is used in the kafka processor and the key of the events is the user_id, we actually can store 50k * #instances users.
    private int maximumSize = 50000;

    @Bean
    public CacheManager cacheManager() {
        CaffeineCache userUpdateTenantTags = buildCache("userUpdateTenantTags", timeoutSeconds);

        SimpleCacheManager manager = new SimpleCacheManager();
        manager.setCaches(List.of(userUpdateTenantTags));

        return manager;
    }

    private CaffeineCache buildCache(String name, int secondsToExpire) {
        return new CaffeineCache(name, Caffeine.newBuilder()
                                               .expireAfterWrite(secondsToExpire, TimeUnit.SECONDS)
                                               .maximumSize(maximumSize)
                                               .recordStats()
                                               .build());
    }
}
package com.playtomic.anemone.category.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MembershipDetails {

    @NotNull
    @JsonProperty("membership_product_id")
    private MembershipProductId membershipProductId;

    @NotNull
    @JsonProperty("visibility")
    private Visibility visibility;

    @NotNull
    @JsonProperty("description")
    private String description;

    @NotEmpty
    @JsonProperty("membership_prices")
    private List<MembershipPrice> membershipPrices;
}

package com.playtomic.anemone.category.domain;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.playtomic.anemone.category.domain.converter.CancellationPolicyDeserializer;
import com.playtomic.anemone.category.domain.converter.CancellationPolicyDurationSerializer;
import java.time.Duration;
import javax.annotation.Nonnull;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;

@Getter
@EqualsAndHashCode
@AllArgsConstructor
@JsonDeserialize(using = CancellationPolicyDeserializer.class)
@JsonSerialize(using = CancellationPolicyDurationSerializer.class)
public class CancellationPolicyDuration {

    @Nonnull
    private final Duration duration;

}

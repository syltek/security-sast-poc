package com.playtomic.anemone.user.api.v2.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import javax.annotation.ParametersAreNullableByDefault;
import javax.validation.constraints.AssertTrue;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@ParametersAreNullableByDefault
public class PatchTenantOwnerAccount {

    @JsonProperty("accepts_marketing_communications")
    private Boolean acceptsMarketingCommunications;

    @JsonProperty("accepts_marketing_behaviour_analysis")
    private Boolean acceptsMarketingBehaviourAnalysis;

    @JsonProperty("accepts_cx_questionnaires")
    private Boolean acceptsCxQuestionnaires;

    @JsonProperty("accepts_cx_whatsapp_communications")
    private Boolean acceptsCxWhatsappCommunications;

    @AssertTrue(message = "At least one field must be set in the request body")
    private boolean isBodyWithAtLeastOneFieldNotNull() {
        return acceptsMarketingCommunications != null || acceptsMarketingBehaviourAnalysis != null || acceptsCxQuestionnaires != null
            || acceptsCxWhatsappCommunications != null;
    }
}

package com.playtomic.anemone.user.service.google.exception;

public class InvalidGoogleTokenException extends RuntimeException {
    public InvalidGoogleTokenException(Throwable cause) {
        super(cause);
    }
}

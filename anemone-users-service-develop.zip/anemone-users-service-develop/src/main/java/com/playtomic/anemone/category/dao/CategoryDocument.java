package com.playtomic.anemone.category.dao;

import com.playtomic.anemone.category.domain.CategoryId;
import com.playtomic.anemone.category.domain.CategoryType;
import com.playtomic.anemone.dao.BaseDocument;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import java.math.BigDecimal;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Getter
@NoArgsConstructor
@AllArgsConstructor
@ParametersAreNonnullByDefault
@Document(collection = "categories")
public class CategoryDocument extends BaseDocument {

    @Nonnull
    @Id
    private CategoryId id;
    @Nonnull
    @Field("tenant_id")
    private TenantId tenantId;
    @Nonnull
    @Field("name")
    private String name;
    @Setter
    @Nonnull
    @Field("status")
    private Status status;
    @Setter
    @Nullable
    @Field("expiration")
    private CategoryExpirationField expiration;
    @Nullable
    @Field("booking_privilege")
    private BookingPrivilegeField bookingPrivilege;
    @Setter
    @Nullable
    @Field("pricing_type")
    private PricingType pricingType;
    @Setter
    @Field("allow_single_payment_when_price_is_customized")
    private boolean allowSinglePaymentWhenPriceIsCustomized;
    @Setter
    @Nullable
    @Field("vat_rate")
    private BigDecimal vatRate;

    @Setter
    @Nullable
    @Field("category_type")
    private CategoryType categoryType;

    @Setter
    @Nullable
    @Field("membership_details")
    private MembershipDetailsField membershipDetails;

    public CategoryDocument(CategoryId categoryId, TenantId tenantId, String name, @Nullable CategoryExpirationField expiration,
        @Nullable BookingPrivilegeField bookingPrivilege, @Nullable CategoryType categoryType,
        @Nullable MembershipDetailsField membershipDetails) {
        this(categoryId, tenantId, name, Status.ENABLED, expiration, bookingPrivilege, null,
            false, null, categoryType, membershipDetails);
    }

    public CategoryDocument(CategoryId categoryId, TenantId tenantId, String name, @Nullable CategoryExpirationField expiration,
        @Nullable BookingPrivilegeField bookingPrivilege, boolean allowSinglePaymentWhenPriceIsCustomized, @Nullable BigDecimal vatRate,
        @Nullable CategoryType categoryType, @Nullable MembershipDetailsField membershipDetails) {
        this(categoryId, tenantId, name, Status.ENABLED, expiration, bookingPrivilege, null, allowSinglePaymentWhenPriceIsCustomized, vatRate,
            categoryType, membershipDetails);
    }

    public boolean isDisabled() {
        return Status.DISABLED == this.status;
    }

    public boolean isEnabled() {
        return Status.ENABLED == this.status;
    }

    public boolean isMembership() {
        return CategoryType.MEMBERSHIP == this.categoryType;
    }

    public boolean isSimple() {
        return this.categoryType == null || CategoryType.SIMPLE == this.categoryType;
    }

    public void update(String name, @Nullable CategoryExpirationField expiration, @Nullable BookingPrivilegeField bookingPrivilege,
        Boolean allowSinglePaymentWhenPriceIsCustomized, @Nullable BigDecimal vatRate) {
        this.name = name;
        this.expiration = expiration;
        this.bookingPrivilege = bookingPrivilege;
        this.allowSinglePaymentWhenPriceIsCustomized = allowSinglePaymentWhenPriceIsCustomized;
        this.vatRate = vatRate;
    }

    public enum Status {
        ENABLED,
        DISABLED
    }

    public enum PricingType {
        SIMPLE,
        ADVANCED
    }
}

package com.playtomic.anemone.user.service.exception;

public class UserImportAlreadyStoppedException extends RuntimeException{
}


package com.playtomic.anemone.user.service;

import com.playtomic.anemone.domain.Email;
import com.playtomic.anemone.domain.EmailValidator;
import com.playtomic.anemone.http.PublicUrlService;
import com.playtomic.anemone.service.AbstractLocalizableService;
import com.playtomic.anemone.user.dao.PasswordResetRequestEntity;
import com.playtomic.anemone.user.dao.PasswordResetRequestRepository;
import com.playtomic.anemone.user.dao.UserEntity;
import com.playtomic.anemone.user.dao.UserRepository;
import com.playtomic.anemone.user.domain.tenant.Tenant;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import com.playtomic.anemone.user.model.CustomerUserProfile;
import com.playtomic.anemone.user.service.anemone.SmsServiceClient;
import com.playtomic.anemone.user.service.email.UserEmailService;
import com.playtomic.anemone.user.service.exception.InvalidEmailTokenException;
import com.playtomic.anemone.user.service.exception.InvalidPhoneTokenException;
import com.playtomic.anemone.user.service.exception.PasswordResetRequestNotFound;
import com.playtomic.anemone.user.service.exception.UserNotFoundException;
import java.math.BigInteger;
import java.net.URI;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.Collections;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.context.MessageSource;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

@Slf4j
@Service
public class UserCredentialService extends AbstractLocalizableService {

    @Nonnull
    private SecureRandom randomTokenGenerator = new SecureRandom();

    @Nonnull
    final private PublicUrlService publicUrlService;

    @Nonnull
    final private UserRepository userRepository;

    @Nonnull
    final private PasswordResetRequestRepository passwordResetRequestRepository;

    @Nonnull
    private final UserEmailService userEmailService;

    @Nonnull
    final private SmsServiceClient smsServiceClient;

    @Value("${anemone.emails-hash.key}")
    private String emailPrivateKey;

    @Value("${anemone.phones-hash.key}")
    private String phonePrivateKey;

    @Value("${anemone.reset-password.default-path}")
    @Nonnull
    private String resetPasswordDefaultPath;

    @Value("${anemone.reset-password.manager-path}")
    @Nonnull
    private String resetPasswordManagerPath;

    @Value("${manager.login-path}")
    @Nonnull
    private String managerLoginPath;

    private String generatePasswordResetToken() {
        return new BigInteger(256, randomTokenGenerator).toString(32);
    }

    public UserCredentialService(@Nonnull MessageSource messageSource,
                                 @Nonnull DiscoveryClient discoveryClient,
                                 @Nonnull PublicUrlService publicUrlService,
                                 @Nonnull UserRepository userRepository,
                                 @Nonnull PasswordResetRequestRepository passwordResetRequestRepository,
                                 @Nonnull UserEmailService userEmailService,
                                 @Nonnull SmsServiceClient smsServiceClient) {
        super(messageSource, discoveryClient);
        this.publicUrlService = publicUrlService;
        this.userRepository = userRepository;
        this.passwordResetRequestRepository = passwordResetRequestRepository;
        this.userEmailService = userEmailService;
        this.smsServiceClient = smsServiceClient;
    }

    @Transactional
    public void requestPasswordReset(@Nonnull Email email, boolean isNewUser, @Nonnull String source) throws UserNotFoundException {
        log.info("Sending password reset email to {}", email);

        final UserEntity user = userRepository.findUserByEmail(email.getEmail())
                .filter(u -> !u.isPlaytomicOnsite())
                .orElseThrow(UserNotFoundException::new);

        // Data preparation
        String securityToken = generatePasswordResetToken();
        URI resetPasswordUrl = generateRedirectResetPasswordUrl(email, securityToken, source);
        setupPasswordResetRequest(email, securityToken);
        userEmailService.sendResetCustomerPasswordEmail(email, user.getCommunicationsLanguageLocale(), isNewUser, resetPasswordUrl);
    }

    @Transactional
    public void requestPasswordResetNewUserWithManagerRole(@Nonnull Email email, @Nonnull Locale locale) throws UserNotFoundException {
        log.info("Sending password reset email to {}", email);

        // Data preparation
        String securityToken = generatePasswordResetToken();
        URI resetPasswordUrl = generateRedirectResetPasswordUrl(email, securityToken, "MANAGER");
        setupPasswordResetRequest(email, securityToken);
        String resetUrlString = resetPasswordUrl.toString();
        //Sadly encoders that we are using doesn't scape '+'.
        resetUrlString = resetUrlString.replace("+", "%2B");

        userEmailService.sendPasswordResetEmailManagerNewUser(email.getEmail(), locale, resetUrlString);
    }

    private void setupPasswordResetRequest(@Nonnull Email email, @Nonnull String securityToken){
        // Don't store several requests by user
        passwordResetRequestRepository.deleteByEmail(email.getEmail());
        PasswordResetRequestEntity request = new PasswordResetRequestEntity(email, securityToken);
        passwordResetRequestRepository.save(request);
    }

    @Transactional
    public void resetPassword(Email email, String token, String newPassword)
            throws PasswordResetRequestNotFound {

        PasswordResetRequestEntity existingRequest =
                passwordResetRequestRepository.findByEmailIgnoreCaseAndSecurityToken(email.getEmail(), token);

        if (existingRequest == null) {
            throw new PasswordResetRequestNotFound(email);
        }

        try {
            updateUserPassword(email, newPassword);
        } catch (UserNotFoundException e) {
            throw new PasswordResetRequestNotFound(email);
        }

        // Token consumed
        passwordResetRequestRepository.deleteByEmail(email.getEmail());
    }

    public void sendManagerRoleAssignedEmail(@Nonnull String email, @Nonnull Locale locale, @Nonnull Tenant tenant){
        userEmailService.sendManagerRoleAssignedEmail(email, locale, generateManagerLoginUrl(tenant.getTenantId()).toString(), tenant.getTenantName());
    }

    @Transactional
    public void verifyEmailToken(@Nonnull String emailToken) throws UserNotFoundException, InvalidEmailTokenException {
        Email email = decodeEmail(emailToken);

        UserEntity
                userEntity =
                userRepository.findUserByEmail(email.getEmail()).orElseThrow(UserNotFoundException::new);
        userEntity.setEmailVerified(true);
        userRepository.save(userEntity);
    }

    @Nonnull
    private URI generateManagerLoginUrl(@Nullable TenantId tenantId) {
        UriComponentsBuilder uriComponentsBuilder = ServletUriComponentsBuilder
            .fromUriString(managerLoginPath);

        if(tenantId != null){
            uriComponentsBuilder.queryParam("tid", tenantId);
        }

        return uriComponentsBuilder.build(false).encode().toUri();
    }

    @Nonnull
    private URI generateRedirectResetPasswordUrl(@Nonnull Email email, @Nonnull String securityToken, @Nonnull String source) {
        UriComponentsBuilder builder;
        if (source.equalsIgnoreCase("MANAGER")) {
            builder = ServletUriComponentsBuilder.fromUriString(resetPasswordManagerPath);
        } else {
            builder = publicUrlService.getBuilderFromFrontendPath(resetPasswordDefaultPath);
        }
        UriComponents uri = builder
                        .queryParam("email", email)
                        .queryParam("reset_token", securityToken)
                        .build(false)
                        .encode();

        return uri.toUri();
    }

    @Nonnull
    public URI generateRedirectValidateUserUrl(@Nonnull Email email, @Nonnull String encodedEmail) {
        return
                publicUrlService
                        .getBuilderFromFrontendPath("/auth/validate")
                        .queryParam("email", email)
                        .queryParam("validate_token", encodedEmail)
                        .build(false)
                        .encode()
                        .toUri();
    }

    @Nonnull
    public URI generateRedirectValidateUserUrlWithReturnPath(@Nonnull Email email, @Nonnull String encodedEmail, @Nonnull String returnPath) {
        return
                publicUrlService
                        .getBuilderFromFrontendPath("/auth/validate")
                        .queryParam("email", email)
                        .queryParam("validate_token", encodedEmail)
                        .queryParam("return_path", returnPath)
                        .build(false)
                        .encode()
                        .toUri();
    }

    private void updateUserPassword(@Nonnull Email email, @Nonnull String newPassword) throws UserNotFoundException {
        UserEntity userEntity = userRepository.findUserByEmail(email.getEmail())
                .orElseThrow(UserNotFoundException::new);

        // If a user has received the password reset email and has reset his password then he has effectively verified his email.
        // This is the case for example when a user is created by a manager.
        userEntity.setEmailVerified(!userEntity.isEmailVerified() || userEntity.isEmailVerified());
        userEntity.setPasswordHash(hashPassword(newPassword));
        userRepository.save(userEntity);
    }

    @Nonnull
    public String encodeEmail(@Nonnull Email email) {
        String hashSignature = emailPrivateKey + email.getEmail();
        String hash = email + ";" + getBCryptPasswordEncoder().encode(hashSignature);
        return Base64.getUrlEncoder().encodeToString(hash.getBytes());
    }

    @Nonnull
    public Email decodeEmail(@Nonnull String encodedEmail) throws InvalidEmailTokenException {
        String hash;
        try {
            hash = new String(Base64.getUrlDecoder().decode(encodedEmail));
        } catch(IllegalArgumentException ex) {
            throw new InvalidEmailTokenException(ex);
        }

        String[] parts = hash.split(";");
        if (parts.length != 2) {
            throw new InvalidEmailTokenException();
        }
        String email = parts[0];
        String hashSignature = emailPrivateKey + email;
        if (!getBCryptPasswordEncoder().matches(hashSignature, parts[1])) {
            throw new InvalidEmailTokenException();
        }

        if (!EmailValidator.isValid(email)) {
            throw new InvalidEmailTokenException();
        }

        return new Email(email);
    }

    @Nonnull
    public String hashPhone(@Nonnull String phone) {
        byte[] md5Bytes = DigestUtils.md5(phonePrivateKey + phone);
        String hash = Base64.getUrlEncoder().encodeToString(md5Bytes);
        // We reduce the hash to the first 5 alphanumeric characters. This reduces the hash strength to 36^5,
        // or 60.466.176 values. So an attacker would need 30.233.088 attempts in average to validate his phone
        // without having the hash value
        return hash.replaceAll("[^A-Za-z0-9]", "").substring(0, 5).toLowerCase();
    }

    public boolean isVerifiedPhone(@Nonnull String phone, @Nonnull String tokenHash) throws InvalidPhoneTokenException {
        String validHash = hashPhone(phone);
        return tokenHash.equalsIgnoreCase(validHash);
    }

    @Nonnull
    public String hashPassword(@Nonnull String password) {
        BCryptPasswordEncoder encoder = getBCryptPasswordEncoder();
        return encoder.encode(password);
    }

    public void sendWelcomeEmail(@Nonnull Email email, @Nonnull Locale locale) {
        Map<String, Object> emailProps = new HashMap<>();
        String encodedEmail = encodeEmail(email);
        emailProps.put("locale", locale);
        emailProps.put("confirmYourEmailText", getMessage("Email.Playtomic.ConfirmYourEmailText", locale));
        emailProps.put("confirmYourEmailButtonLabel", getMessage("Email.Playtomic.ConfirmYourEmailButtonLabel", locale));
        emailProps.put("emailValidationUrl", generateRedirectValidateUserUrl(email, encodedEmail));
        emailProps.put("subject", getMessage("Email.Playtomic.WelcomeEmail.Subject", locale));
        emailProps.put("title", getMessage("Email.Playtomic.WelcomeEmail.Title", locale));

        userEmailService.sendWelcomeEmail(email.getEmail(), emailProps, locale);
    }

    public void sendValidationEmail(@Nonnull Email email, @Nonnull Locale userLocale, @Nullable String returnPath) {
        log.info("Sending validation email to {}", email);

        // Data Preparation
        String encodedEmail = encodeEmail(email);
        URI validateUrl = returnPath != null ?
            generateRedirectValidateUserUrlWithReturnPath(email, encodedEmail, returnPath) :
            generateRedirectValidateUserUrl(email, encodedEmail);
        userEmailService.sendValidationEmail(email.getEmail(), userLocale, validateUrl);
    }

    private BCryptPasswordEncoder getBCryptPasswordEncoder() {
        return new BCryptPasswordEncoder();
    }

    public void sendValidationSms(@Nonnull CustomerUserProfile user, @Nonnull String phone) {
        String phoneToken = hashPhone(phone);

        String message = getMessage("Sms.PhoneValidation.Message", new Object[]{phoneToken}, user.getCommunicationsLanguage());

        SmsServiceClient.SmsBody smsBody = new SmsServiceClient.SmsBody(
                Collections.singletonList(phone),
                message);

        smsServiceClient.sendSms(smsBody);
    }
}

package com.playtomic.anemone.category.dao;

import com.playtomic.anemone.category.domain.ExpirationUnit;
import javax.annotation.Nonnull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.springframework.data.mongodb.core.mapping.Field;

@Getter
@AllArgsConstructor
public class CategoryExpirationField {

    @Nonnull
    @Field("unit")
    private final ExpirationUnit unit;

    @Field("value")
    private final int value;

}

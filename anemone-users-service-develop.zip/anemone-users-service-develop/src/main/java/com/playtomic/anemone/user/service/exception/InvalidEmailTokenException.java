package com.playtomic.anemone.user.service.exception;

import javax.annotation.Nonnull;

public class InvalidEmailTokenException extends RuntimeException {

    public InvalidEmailTokenException() {
    }

    public InvalidEmailTokenException(@Nonnull Throwable cause) {
        super(cause);
    }
}

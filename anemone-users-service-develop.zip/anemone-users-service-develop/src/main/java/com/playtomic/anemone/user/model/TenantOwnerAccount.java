package com.playtomic.anemone.user.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import java.time.Instant;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TenantOwnerAccount {

    @Nonnull
    @JsonProperty("tenant_id")
    TenantId tenantId;

    @Nullable
    @JsonProperty("created_at")
    public Instant createdAt;

    @JsonProperty("accepts_marketing_communications")
    private boolean acceptsMarketingCommunications;

    @JsonProperty("accepts_marketing_behaviour_analysis")
    private boolean acceptsMarketingBehaviourAnalysis;

    @JsonProperty("accepts_cx_questionnaires")
    private boolean acceptsCxQuestionnaires;

    @JsonProperty("accepts_cx_whatsapp_communications")
    private boolean acceptsCxWhatsappCommunications;

}

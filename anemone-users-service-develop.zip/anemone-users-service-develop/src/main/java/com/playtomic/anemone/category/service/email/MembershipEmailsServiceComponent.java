package com.playtomic.anemone.category.service.email;

import com.playtomic.anemone.category.config.MembershipEmailsConfiguration;
import com.playtomic.anemone.category.config.MembershipEmailsConfiguration.EmailConfiguration;
import com.playtomic.anemone.service.AbstractLocalizableService;
import com.playtomic.anemone.user.dao.TenantTagEntity;
import com.playtomic.anemone.user.dao.UserEntity;
import com.playtomic.anemone.user.domain.tenant.Tenant;
import com.playtomic.anemone.user.service.anemone.EmailServiceClient;
import com.playtomic.anemone.user.service.email.EmailMessage;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import javax.annotation.Nonnull;
import javax.annotation.ParametersAreNonnullByDefault;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.context.MessageSource;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

@ParametersAreNonnullByDefault
@Slf4j
@Component
public class MembershipEmailsServiceComponent extends AbstractLocalizableService {
    @Nonnull
    private final MembershipEmailsConfiguration membershipEmailsConfiguration;

    @Nonnull
    private final EmailServiceClient emailServiceClient;

    @Nonnull
    @Value("#{T(java.time.LocalTime).parse('${users-memberships.emails.send-start-time}', T(java.time.format.DateTimeFormatter).ISO_LOCAL_TIME)}")
    private LocalTime emailSendStartTime;

    @Nonnull
    @Value("#{T(java.time.LocalTime).parse('${users-memberships.emails.send-end-time}', T(java.time.format.DateTimeFormatter).ISO_LOCAL_TIME)}")
    private LocalTime emailSendEndTime;

    public MembershipEmailsServiceComponent(@Nonnull MessageSource messageSource,
                                            @Nonnull DiscoveryClient discoveryClient,
                                            @Nonnull MembershipEmailsConfiguration membershipEmailsConfiguration,
                                            @Nonnull EmailServiceClient emailServiceClient) {
        super(messageSource, discoveryClient);
        this.membershipEmailsConfiguration = membershipEmailsConfiguration;
        this.emailServiceClient = emailServiceClient;
    }

    @Async
    public void sendNewMemberEmail(List<UserEntity> users, String categoryName, Tenant tenant) {
        if (shouldSendNotifications(tenant)) {
            List<EmailMessage> emailMessages = users.stream()
                .filter(UserEntity::isEmailVerified)
                .map(userEntity -> buildNewMemberEmail(userEntity, tenant.getTenantName(), categoryName, tenant.getTenantAddress().getZoneId()))
                .collect(Collectors.toList());

            sendEmailBatch(emailMessages);
        }
    }

    @Async
    public void sendMembershipRemovedEmails(List<TenantTagEntity> tenantTagEntityList, String categoryName, Tenant tenant) {
        if (shouldSendNotifications(tenant)) {
            List<EmailMessage> emailMessages = tenantTagEntityList.stream()
                .filter(tenantTagEntity -> tenantTagEntity.getUser().isEmailVerified())
                .map(tenantTagEntity -> buildMemberRemovedEmail(tenantTagEntity.getUser(), tenant.getTenantName(), categoryName,
                                                                tenant.getTenantAddress().getZoneId()))

                .collect(Collectors.toList());

            sendEmailBatch(emailMessages);
        }
    }

    @Nonnull
    private EmailMessage buildNewMemberEmail(UserEntity user, String tenantName, String categoryName, ZoneId tenantZoneId) {

        EmailConfiguration emailConfiguration = membershipEmailsConfiguration.getNewMemberEmailConfig();

        Map<String, Object[]> placeHolderValuesMap = Map.of(
            EmailConstants.SUBJECT_KEY, new String[]{},
            EmailConstants.TITLE_KEY, new String[]{categoryName},
            EmailConstants.MESSAGE_KEY, new String[]{tenantName, categoryName});

        return buildEmailMessage(List.of(user.getEmail()), emailConfiguration, user.getCommunicationsLanguageLocale(), placeHolderValuesMap,
                                 tenantZoneId);
    }

    private EmailMessage buildMemberRemovedEmail(UserEntity user, String tenantName, String categoryName, ZoneId tenantZoneId) {

        EmailConfiguration emailConfiguration = membershipEmailsConfiguration.getRemovedMemberEmailConfig();

        Map<String, Object[]> placeHolderValuesMap = Map.of(
            EmailConstants.SUBJECT_KEY, new String[]{},
            EmailConstants.TITLE_KEY, new String[]{categoryName},
            EmailConstants.MESSAGE_KEY, new String[]{tenantName, categoryName});

        return buildEmailMessage(Collections.singletonList(user.getEmail()), emailConfiguration, user.getCommunicationsLanguageLocale(),
                                 placeHolderValuesMap, tenantZoneId);
    }

    @Nonnull
    private EmailMessage buildEmailMessage(List<String> emailToList, EmailConfiguration emailConfiguration, Locale locale,
                                           Map<String, Object[]> placeHolderValueMap, ZoneId tenantZoneId) {

        Map<String, Object> dynamicData = placeHolderValueMap.entrySet().stream()
            .collect(Collectors.toMap(
                Entry::getKey,
                entry -> getMessage(emailConfiguration.getEmailPropertiesPrefix() + "." + StringUtils.capitalize(entry.getKey()), entry.getValue(),
                                    locale)));
        dynamicData.put(EmailConstants.LOCALE_KEY, locale);

        return EmailMessage.builder()
            .templateId(emailConfiguration.getTemplateId())
            .from(emailConfiguration.getFrom())
            .to(emailToList)
            .sendTimeZoneId(tenantZoneId)
            .sendAfterTime(emailSendStartTime)
            .sendBeforeTime(emailSendEndTime)
            .dynamicData(dynamicData)
            .locale(locale)
            .build();
    }

    private void sendEmailBatch(List<EmailMessage> emailMessages) {
        if (!emailMessages.isEmpty()) {
            emailServiceClient.sendEmailBatch(emailMessages);
        }
    }

    /**
     * @see CategoryEmailsServiceComponent#shouldSendNotifications(Tenant)
     */
    private boolean shouldSendNotifications(Tenant tenant) {
        return !tenant.isInactive();
    }
}

package com.playtomic.anemone.user.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import javax.annotation.Nullable;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class CustomerAddress {

    @JsonProperty("street")
    @Nullable
    private String street;

    @JsonProperty("zip_code")
    @Nullable
    private String zipCode;

    @JsonProperty("city")
    @Nullable
    private String city;

    @JsonProperty("state")
    @Nullable
    private String state;

    //To improve future reading APIs, this filed is included for output, but not for input.
    @JsonProperty("country_code")
    @Nullable
    private String countryCode;

    @JsonCreator
    public CustomerAddress(
        @JsonProperty(value = "street",required = false) @Nullable String street,
        @JsonProperty(value = "zip_code",required = false) @Nullable String zipCode,
        @JsonProperty(value = "city",required = false) @Nullable String city,
        @JsonProperty(value = "state",required = false) @Nullable String state
    ) {
        this.street = street;
        this.zipCode = zipCode;
        this.city = city;
        this.state = state;
    }
}

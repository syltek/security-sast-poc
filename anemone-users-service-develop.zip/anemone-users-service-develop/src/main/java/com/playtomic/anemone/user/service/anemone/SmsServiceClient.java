package com.playtomic.anemone.user.service.anemone;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.jwt.JwtTokenFactory;
import com.playtomic.anemone.spring.AnemoneAuthenticationCredentialsAccessor;
import com.playtomic.anemone.spring.feign.AnemoneFeignConfiguration;
import com.playtomic.anemone.spring.feign.AuthenticationHeaderFeignInterceptor;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;
import javax.annotation.Nonnull;
import feign.RequestInterceptor;

@FeignClient(name = "sms-service", configuration = SmsServiceClient.Configuration.class, url = "${sms-service.url}")
public interface SmsServiceClient {

    @RequestMapping(method = RequestMethod.POST, value = "/v1/sms", consumes = "application/json")
    void sendSms(@Nonnull SmsBody body);

    @Data
    @AllArgsConstructor
    class SmsBody {
        @JsonProperty(value = "phones")
        @Nonnull
        private List<String> phones;

        @JsonProperty(value = "message")
        @Nonnull
        private String message;
    }

    class Configuration extends AnemoneFeignConfiguration {

        @Bean
        public RequestInterceptor requestInterceptor(@Nonnull JwtTokenFactory jwtTokenFactory) {
            return new AuthenticationHeaderFeignInterceptor(new AnemoneAuthenticationCredentialsAccessor(jwtTokenFactory));
        }

    }
}

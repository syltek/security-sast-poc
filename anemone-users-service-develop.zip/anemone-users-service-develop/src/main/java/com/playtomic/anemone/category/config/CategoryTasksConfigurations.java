package com.playtomic.anemone.category.config;

import javax.annotation.Nonnull;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Setter
@Getter
@Configuration
@ConfigurationProperties(prefix = "users-categories.scheduler-tasks")
public class CategoryTasksConfigurations {

    @Nonnull
    private String callBackHost;
    @Nonnull
    private String callBackPort;

    private TaskConfiguration memberDeleteExpired;

    private TaskConfiguration memberExpirationReminder;


    @Getter
    @Setter
    public static class TaskConfiguration {

        @Nonnull
        private String groupId;

        @Nonnull
        private String targetEndpoint;

        @Nonnull
        private String description;

        @Nonnull
        private Integer triggerDelayMinutes;

        private boolean recoverable;

        @Nonnull
        private String misfiredPolicy;
    }

}

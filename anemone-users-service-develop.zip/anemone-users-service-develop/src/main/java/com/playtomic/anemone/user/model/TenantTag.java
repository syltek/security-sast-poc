package com.playtomic.anemone.user.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import java.util.Objects;
import java.util.Set;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Getter;

@Getter
public class TenantTag {

    @Nonnull
    @JsonProperty("tags")
    private Set<String> tags;

    @Nullable
    @JsonProperty("tags_details")
    private Set<TenantTagDetails> tagsDetails;

    @Nonnull
    @JsonProperty("tenant_id")
    private TenantId tenantId;

    @JsonCreator
    public TenantTag(
        @JsonProperty(value = "tags", required = true) @Nonnull Set<String> tags,
        @JsonProperty(value = "tags_details") @Nullable Set<TenantTagDetails> tagsDetails, // for now it's nullable
        @JsonProperty(value = "tenant_id", required = true) @Nonnull TenantId tenantId
    ) {
        this.tags = tags;
        this.tagsDetails = tagsDetails;
        this.tenantId = tenantId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        TenantTag tenantTag = (TenantTag) o;
        return tags.equals(tenantTag.tags) &&
            tenantId.equals(tenantTag.tenantId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(tags, tenantId);
    }
}

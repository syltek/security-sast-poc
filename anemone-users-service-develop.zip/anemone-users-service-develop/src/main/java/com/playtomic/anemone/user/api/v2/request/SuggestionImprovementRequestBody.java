package com.playtomic.anemone.user.api.v2.request;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 *
 */
public class SuggestionImprovementRequestBody {
    @JsonProperty(value = "comments", required = true)
    public String comments;

    public SuggestionImprovementRequestBody() {
    }

    public SuggestionImprovementRequestBody(String comments) {
        this.comments = comments;
    }
}

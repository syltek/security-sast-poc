package com.playtomic.anemone.user.api.v2;

import static org.springframework.http.ResponseEntity.unprocessableEntity;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.category.service.exception.CategoryCannotBeDisabledException;
import com.playtomic.anemone.category.service.exception.CategoryIsDisabledException;
import com.playtomic.anemone.category.service.exception.CategoryMembersUpdateRejectedException;
import com.playtomic.anemone.category.service.exception.CategoryNotFoundException;
import com.playtomic.anemone.category.service.exception.CategoryUpdateRejectedException;
import com.playtomic.anemone.category.service.exception.CategoryWithThisNameAlreadyExistsException;
import com.playtomic.anemone.category.service.exception.StripeProductCreationFailedException;
import com.playtomic.anemone.category.service.exception.UserIsAlreadyAssignedToCategoryInTenantException;
import com.playtomic.anemone.http.response.GenericResponseBody;
import com.playtomic.anemone.service.AbstractRestController;
import com.playtomic.anemone.user.service.IllegalEmailUpdateForOnsiteUserException;
import com.playtomic.anemone.user.service.exception.AutoLinkAccountAtAnemoneVenueException;
import com.playtomic.anemone.user.service.exception.CoachNotFoundException;
import com.playtomic.anemone.user.service.exception.CustomerProfileImageNotSaveException;
import com.playtomic.anemone.user.service.exception.EmailNotAvailableException;
import com.playtomic.anemone.user.service.exception.InvalidBirthDateException;
import com.playtomic.anemone.user.service.exception.InvalidCountryCodeException;
import com.playtomic.anemone.user.service.exception.InvalidEmailException;
import com.playtomic.anemone.user.service.exception.InvalidEmailTokenException;
import com.playtomic.anemone.user.service.exception.InvalidPasswordException;
import com.playtomic.anemone.user.service.exception.InvalidPhoneException;
import com.playtomic.anemone.user.service.exception.InvalidPhoneTokenException;
import com.playtomic.anemone.user.service.exception.InvalidSearchParametersException;
import com.playtomic.anemone.user.service.exception.LinkAccountRegisterException;
import com.playtomic.anemone.user.service.exception.LinkAccountValidateException;
import com.playtomic.anemone.user.service.exception.PhoneAlreadyValidatedException;
import com.playtomic.anemone.user.service.exception.PhoneNotAvailableException;
import com.playtomic.anemone.user.service.exception.TenantNotFoundException;
import com.playtomic.anemone.user.service.exception.UserDeletionConflictException;
import com.playtomic.anemone.user.service.exception.UserImportAlreadyStoppedException;
import com.playtomic.anemone.user.service.exception.UserImportEmptyFileException;
import com.playtomic.anemone.user.service.exception.UserImportFileInvalidFormatException;
import com.playtomic.anemone.user.service.exception.UserImportMismatchException;
import com.playtomic.anemone.user.service.exception.UserImportNotFoundException;
import com.playtomic.anemone.user.service.exception.UserImportOnInactiveTenantException;
import com.playtomic.anemone.user.service.exception.UserImportTooFewColumnsInRecordException;
import com.playtomic.anemone.user.service.exception.UserImportTooManyRowsException;
import com.playtomic.anemone.user.service.exception.UserNotFoundException;
import com.playtomic.anemone.user.service.exception.UserNotValidatedException;
import com.playtomic.anemone.user.service.exception.UserPrivacyProfileConflictException;
import com.playtomic.anemone.user.service.exception.UserRoleAlreadyDefinedException;
import com.playtomic.anemone.user.service.exception.UserRoleNotFoundException;
import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import lombok.Getter;
import lombok.SneakyThrows;
import org.hibernate.validator.internal.engine.path.PathImpl;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.multipart.MaxUploadSizeExceededException;

@ControllerAdvice
public class UserExceptionHandler extends AbstractRestController {

    @Nonnull
    @Value("${users.import.max-rows-number}")
    private String maxRowsNumber;
    @Nonnull
    @Value("${spring.servlet.multipart.max-file-size}")
    private String maxFileSize;

    public UserExceptionHandler(@Nonnull MessageSource messageSource,
        @Nonnull DiscoveryClient discoveryClient) {
        super(messageSource, discoveryClient);
    }

    @ExceptionHandler(InvalidSearchParametersException.class)
    public ResponseEntity handleInvalidSearchParametersException(InvalidSearchParametersException exception) {
        GenericResponseBody response =
            new GenericResponseBody(UserControllerV2.ErrorCodes.MISSING_REQUIRED_PARAMETERS,
                "You must specify one of the following parameters: q, name, user_id, email, phone");

        return badRequest(response);
    }

    @ExceptionHandler(InvalidPhoneException.class)
    public ResponseEntity handleInvalidPhoneException(InvalidPhoneException exception) {
        // FIXME: security issue, we should not return this number in the response because it is an input parameter!
        GenericResponseBody response = getMessageBody(ErrorCodes.INVALID_PHONE, exception.getPhone());
        return badRequest(response);
    }

    @ExceptionHandler(InvalidBirthDateException.class)
    public ResponseEntity handleInvalidBirthDateException(InvalidBirthDateException exception) {
        GenericResponseBody response = getMessageBody(ErrorCodes.INVALID_BIRTH_DATE);
        return badRequest(response);
    }

    @ExceptionHandler(InvalidEmailException.class)
    public ResponseEntity handleInvalidEmailException(InvalidEmailException exception) {
        return getErrorResponse(ErrorCodes.INVALID_EMAIL, "AuthenticationService.Register.InvalidEmail",
            HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(InvalidEmailTokenException.class)
    public ResponseEntity handleInvalidEmailTokenException(InvalidEmailTokenException exception) {
        return getErrorResponse(ErrorCodes.INVALID_EMAIL_TOKEN, "AuthenticationService.Login.InvalidToken",
            HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(EmailNotAvailableException.class)
    public ResponseEntity handleInvalidEmailException(EmailNotAvailableException exception) {
        return getErrorResponse(ErrorCodes.INVALID_EMAIL, "AuthenticationService.Register.EmailInUse",
            HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(IllegalEmailUpdateForOnsiteUserException.class)
    public ResponseEntity handleIllegalEmailUpdateForOnsiteUserException(IllegalEmailUpdateForOnsiteUserException exception) {
        var messageBody = getMessageBody(ErrorCodes.ILLEGAL_EMAIL_UPDATE);
        return badRequest(messageBody);
    }

    @ExceptionHandler(InvalidPasswordException.class)
    public ResponseEntity handleInvalidPasswordException(InvalidPasswordException exception) {
        return getErrorResponse(ErrorCodes.INVALID_PASSWORD, "AuthenticationService.Register.InvalidPassword",
            HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(InvalidCountryCodeException.class)
    public ResponseEntity handleInvalidCountryCodeException(InvalidCountryCodeException exception) {
        return getErrorResponse(ErrorCodes.INVALID_COUNTRY_CODE, "AuthenticationService.Register.InvalidCountryCode",
            HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(UserNotFoundException.class)
    public ResponseEntity handleUserNotFoundException(UserNotFoundException exception) {
        return getErrorResponse(ErrorCodes.USER_NOT_FOUND, "AuthenticationService.General.UserNotFound",
            HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(CoachNotFoundException.class)
    public ResponseEntity handleCoachNotFoundException(CoachNotFoundException exception) {
        return getErrorResponse(ErrorCodes.USER_NOT_FOUND, "AuthenticationService.General.UserNotFound",
            HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(CustomerProfileImageNotSaveException.class)
    public ResponseEntity handleCustomerProfileImageNotSaveException(CustomerProfileImageNotSaveException exception) {
        GenericResponseBody errorBody = new GenericResponseBody(ErrorCodes.PROFILE_PHOTO_NOT_UPLOADED, "Error uploading image");

        return new ResponseEntity(errorBody, HttpStatus.UNPROCESSABLE_ENTITY);
    }

    @ExceptionHandler(TenantNotFoundException.class)
    public ResponseEntity handleTenantNotFoundException() {
        GenericResponseBody response = getMessageBody(ErrorCodes.TENANT_NOT_FOUND);
        return notFound(response);
    }

    @ExceptionHandler(LinkAccountValidateException.class)
    public ResponseEntity handleLinkAccountValidateException() {
        GenericResponseBody response = getMessageBody(ErrorCodes.INVALID_LINK_CREDENTIALS);
        return unprocessableEntity().body(response);
    }

    @ExceptionHandler(AutoLinkAccountAtAnemoneVenueException.class)
    public ResponseEntity handleAutoLinkAccountAtAnemoneVenueException(AutoLinkAccountAtAnemoneVenueException e) {
        GenericResponseBody response = new GenericResponseBody(ErrorCodes.AUTO_LINK_ACCOUNT_AT_ANEMONE_VENUE, "Accounts can't be auto-linked in anemone venues");
        return unprocessableEntity().body(response);
    }

    @ExceptionHandler(LinkAccountRegisterException.class)
    public ResponseEntity handleLinkAccountRegisterException() {
        GenericResponseBody response = getMessageBody(ErrorCodes.EXISTING_ACCOUNT);
        return unprocessableEntity().body(response);
    }

    @ExceptionHandler(UserNotValidatedException.class)
    public ResponseEntity handleUserNotValidatedException() {
        GenericResponseBody response = getMessageBody(ErrorCodes.USER_NOT_VALIDATED);
        return unprocessableEntity().body(response);
    }

    @ExceptionHandler(UserRoleAlreadyDefinedException.class)
    public ResponseEntity handleUserRoleAlreadyDefinedexception() {
        GenericResponseBody response = getMessageBody(ErrorCodes.USER_ROLE_ALREADY_DEFINED);
        return unprocessableEntity().body(response);
    }

    @ExceptionHandler(UserRoleNotFoundException.class)
    public ResponseEntity handleUserRoleNotFoundException() {
        GenericResponseBody response = getMessageBody(ErrorCodes.USER_ROLE_NOT_FOUND);
        return notFound(response);
    }

    @ExceptionHandler(InvalidPhoneTokenException.class)
    public ResponseEntity handleInvalidPhoneTokenException(InvalidPhoneTokenException exception) {
        return getErrorResponse(ErrorCodes.INVALID_PHONE_TOKEN, "AuthenticationService.Login.InvalidToken",
            HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(PhoneNotAvailableException.class)
    public ResponseEntity handlePhoneNotAvailableException(PhoneNotAvailableException exception) {
        return getErrorResponse(ErrorCodes.PHONE_ALREADY_IN_USE, "AuthenticationService.Register.PhoneInUse",
            HttpStatus.UNPROCESSABLE_ENTITY);
    }

    @ExceptionHandler(PhoneAlreadyValidatedException.class)
    public ResponseEntity handlePhoneAlreadyVerifiedException(PhoneAlreadyValidatedException exception) {
        GenericResponseBody response = getMessageBody(ErrorCodes.PHONE_ALREADY_VALIDATED);
        return unprocessableEntity().body(response);
    }

    @ExceptionHandler(UserImportNotFoundException.class)
    public ResponseEntity handleUserImportNotFoundException(UserImportNotFoundException exception) {
        GenericResponseBody response = getMessageBody(ErrorCodes.USER_IMPORT_NOT_FOUND);
        return notFound(response);
    }

    @ExceptionHandler(UserImportMismatchException.class)
    public ResponseEntity handleUserImportMismatchException(UserImportMismatchException exception) {
        UserImportMismatchErrorBody body = new UserImportMismatchErrorBody(exception.getMissingHeaders(), exception.getExtraHeaders(),
            exception.getLocalizedMessage());
        return badRequest(body);
    }

    @ExceptionHandler(UserImportEmptyFileException.class)
    public ResponseEntity handleUserImportEmptyFileException(UserImportEmptyFileException exception) {
        GenericResponseBody response = getMessageBody(ErrorCodes.USER_IMPORT_EMPTY_FILE);
        return badRequest(response);
    }

    @ExceptionHandler(UserImportAlreadyStoppedException.class)
    public ResponseEntity handleUserImportAlreadyStoppedException(UserImportAlreadyStoppedException exception) {
        GenericResponseBody response = getMessageBody(ErrorCodes.USER_IMPORT_ALREADY_STOPPED);
        return badRequest(response);
    }

    @ExceptionHandler(UserImportFileInvalidFormatException.class)
    public ResponseEntity handleUserImportFileInvalidFormatException(UserImportFileInvalidFormatException exception) {
        GenericResponseBody response = getMessageBody(ErrorCodes.USER_IMPORT_INVALID_FORMAT);
        return badRequest(response);
    }

    @ExceptionHandler(value = {UserImportTooManyRowsException.class})
    public ResponseEntity handleUserImportTooManyRowsException(UserImportTooManyRowsException exc) {
        GenericResponseBody response = getMessageBody(ErrorCodes.USER_IMPORT_FILE_CONTAINS_TOO_MANY_ROWS, maxRowsNumber);
        return badRequest(response);
    }

    @ExceptionHandler(value = {MaxUploadSizeExceededException.class})
    public ResponseEntity handleMaxUploadSizeExceededException(MaxUploadSizeExceededException exc) {
        GenericResponseBody response = getMessageBody(ErrorCodes.USER_IMPORT_FILE_IS_TOO_BIG, maxFileSize);
        return badRequest(response);
    }

    @Nonnull
    @ExceptionHandler(value = MethodArgumentNotValidException.class)
    public ResponseEntity handleMethodArgumentNotValidException(@Nonnull MethodArgumentNotValidException exception) {
        var bindingResult = exception.getBindingResult();
        var target = bindingResult.getTarget();
        if (target == null) {
            return badRequest(new GenericResponseBody(ErrorCodes.VALIDATION_FAILED, exception.getLocalizedMessage()));
        }
        var targetClass = target.getClass();
        var errors = bindingResult.getFieldErrors()
            .stream()
            .map(err -> getErrorMessage(targetClass, err))
            .collect(Collectors.joining(". "));
        return badRequest(new GenericResponseBody(ErrorCodes.VALIDATION_FAILED, errors));
    }

    @Nonnull
    @SneakyThrows
    @ExceptionHandler(value = ConstraintViolationException.class)
    public ResponseEntity handleConstraintViolationException(@Nonnull ConstraintViolationException exception) {
        var errors = exception.getConstraintViolations()
            .stream()
            .map(this::getErrorMessage)
            .collect(Collectors.joining(". "));
        return badRequest(new GenericResponseBody(ErrorCodes.VALIDATION_FAILED, errors));
    }

    @ExceptionHandler(CategoryNotFoundException.class)
    public ResponseEntity handleCategoryNotFoundException(@Nonnull CategoryNotFoundException exception) {
        return notFound(getMessageBody(ErrorCodes.CATEGORY_NOT_FOUND, exception.getLocalizedMessage()));
    }

    @ExceptionHandler(UserIsAlreadyAssignedToCategoryInTenantException.class)
    public ResponseEntity handleUserIsAlreadyAssignedToCategoryInTenantException(
        @Nonnull UserIsAlreadyAssignedToCategoryInTenantException exception) {
        return badRequest(getMessageBody(ErrorCodes.USER_ALREADY_ASSIGNED_TO_CATEGORY, exception.getLocalizedMessage()));
    }

    @ExceptionHandler(CategoryWithThisNameAlreadyExistsException.class)
    public ResponseEntity handleCategoryWithSuchNameAlreadyExistsException(@Nonnull CategoryWithThisNameAlreadyExistsException exception) {
        return badRequest(getMessageBody(ErrorCodes.NAME_ALREADY_EXISTS, exception.getLocalizedMessage()));
    }

    @ExceptionHandler(CategoryCannotBeDisabledException.class)
    public ResponseEntity handleCategoryCannotBeDisabledException(@Nonnull CategoryCannotBeDisabledException exception) {
        return badRequest(getMessageBody(ErrorCodes.CATEGORY_CANNOT_BE_DISABLED, exception.getLocalizedMessage()));
    }

    @ExceptionHandler(CategoryIsDisabledException.class)
    public ResponseEntity handleCategoryCannotBeDisabledException(@Nonnull CategoryIsDisabledException exception) {
        return badRequest(getMessageBody(ErrorCodes.CATEGORY_IS_DISABLED, exception.getLocalizedMessage()));
    }

    @ExceptionHandler(CategoryMembersUpdateRejectedException.class)
    public ResponseEntity handleCategoryMemberRejectedException(@Nonnull CategoryMembersUpdateRejectedException exception) {
        return badRequest(new GenericResponseBody<>(ErrorCodes.CATEGORY_MEMBER_UPDATE_REJECTED, exception.getMessage()));
    }

    @ExceptionHandler(CategoryUpdateRejectedException.class)
    public ResponseEntity handleCategoryUpdateRejectedException(@Nonnull CategoryUpdateRejectedException exception) {
        return badRequest(new GenericResponseBody<>(ErrorCodes.CATEGORY_UPDATE_REJECTED, exception.getMessage()));
    }

    @ExceptionHandler(UserImportOnInactiveTenantException.class)
    public ResponseEntity handleUserImportOnInactiveTenantException(@Nonnull UserImportOnInactiveTenantException exc) {
        GenericResponseBody response = getMessageBody(ErrorCodes.USER_IMPORT_ON_INACTIVE_TENANT);
        return new ResponseEntity(response, HttpStatus.UNPROCESSABLE_ENTITY);
    }

    @ExceptionHandler(UserImportTooFewColumnsInRecordException.class)
    public ResponseEntity handleUserImportTooFewColumnsInRecordException(@Nonnull UserImportTooFewColumnsInRecordException e) {
        GenericResponseBody response = getMessageBody(ErrorCodes.USER_IMPORT_TOO_FEW_COLUMNS_IN_RECORD, ""+e.getRecordNumber(), ""+e.getFoundColumns(), ""+e.getExpectedColumns());
        return new ResponseEntity(response, HttpStatus.UNPROCESSABLE_ENTITY);
    }

    @ExceptionHandler(UserDeletionConflictException.class)
    public ResponseEntity handleUserDeletionConflictException(@Nonnull UserDeletionConflictException e) {
        ErrorCodes errorCode =  e.getReason() == UserDeletionConflictException.Type.PENDING_DEBTS
                        ? ErrorCodes.USER_DELETION_NOT_ALLOWED_PENDING_DEBTS
                        : ErrorCodes.USER_DELETION_NOT_ALLOWED_PENDING_ACTIVITIES;
        GenericResponseBody response = getMessageBody(errorCode);
        return new ResponseEntity(response, HttpStatus.CONFLICT);
    }

    @ExceptionHandler(UserPrivacyProfileConflictException.class)
    public ResponseEntity handleUserPrivacyProfileConflictException(@Nonnull UserPrivacyProfileConflictException e) {
        GenericResponseBody response = getMessageBody(ErrorCodes.USER_PRIVACY_PROFILE_NOT_ALLOWED_PENDING_MATCHES);
        return new ResponseEntity(response, HttpStatus.CONFLICT);
    }

    @ExceptionHandler(StripeProductCreationFailedException.class)
    public ResponseEntity handleStripeProductCreationFailedException(@Nonnull StripeProductCreationFailedException e) {
        GenericResponseBody response = getMessageBody(ErrorCodes.STRIPE_PRODUCT_CREATION_FAILED);
        return new ResponseEntity(response, HttpStatus.UNPROCESSABLE_ENTITY);
    }

    protected enum ErrorCodes {
        CATEGORY_NOT_FOUND,
        CATEGORY_CANNOT_BE_DISABLED,
        CATEGORY_IS_DISABLED,
        CATEGORY_UPDATE_REJECTED,
        CATEGORY_MEMBER_UPDATE_REJECTED,
        NAME_ALREADY_EXISTS,
        USER_ALREADY_ASSIGNED_TO_CATEGORY,
        USER_NOT_FOUND,
        ILLEGAL_EMAIL_UPDATE,
        INVALID_EMAIL,
        INVALID_EMAIL_TOKEN,
        INVALID_PASSWORD,
        INVALID_PHONE,
        INVALID_PHONE_TOKEN,
        INVALID_BIRTH_DATE,
        EMAIL_NOT_SENT,
        PROFILE_PHOTO_NOT_UPLOADED,
        INVALID_LINK_CREDENTIALS,
        AUTO_LINK_ACCOUNT_AT_ANEMONE_VENUE,
        EXISTING_ACCOUNT,
        TENANT_NOT_FOUND,
        USER_NOT_VALIDATED,
        INVALID_COUNTRY_CODE,
        USER_ROLE_ALREADY_DEFINED,
        USER_ROLE_NOT_FOUND,
        PHONE_ALREADY_VALIDATED,
        PHONE_ALREADY_IN_USE,
        VALIDATION_FAILED,
        USER_IMPORT_NOT_FOUND,
        USER_IMPORT_MISMATCH,
        USER_IMPORT_EMPTY_FILE,
        USER_IMPORT_ALREADY_STOPPED,
        USER_IMPORT_INVALID_FORMAT,
        USER_IMPORT_FILE_IS_TOO_BIG,
        USER_IMPORT_FILE_CONTAINS_TOO_MANY_ROWS,
        USER_IMPORT_ON_INACTIVE_TENANT,
        USER_IMPORT_TOO_FEW_COLUMNS_IN_RECORD,
        USER_DELETION_NOT_ALLOWED_PENDING_DEBTS,
        USER_DELETION_NOT_ALLOWED_PENDING_ACTIVITIES,
        USER_PRIVACY_PROFILE_NOT_ALLOWED_PENDING_MATCHES,
        STRIPE_PRODUCT_CREATION_FAILED
    }

    @Getter
    private class UserImportMismatchErrorBody extends GenericResponseBody<ErrorCodes> {

        @JsonProperty("missing_headers")
        private List<String> missingHeaders;

        @JsonProperty("extra_headers")
        private List<String> extraHeaders;

        public UserImportMismatchErrorBody(@Nonnull List<String> missingHeaders, @Nonnull List<String> extraHeaders,
            @Nonnull String localizedMessage) {
            super(ErrorCodes.USER_IMPORT_MISMATCH, localizedMessage);
            this.missingHeaders = missingHeaders;
            this.extraHeaders = extraHeaders;
        }
    }

    @Nonnull
    private String getErrorMessage(@Nonnull Class<?> targetClass, @Nonnull FieldError fieldError) {
        var fullRejectedFieldName = fieldError.getField();
        var fieldNames = fullRejectedFieldName.split("\\.");
        var rejectedField = getField(targetClass, fieldNames, 0);
        var message = fieldError.getDefaultMessage();

        if(rejectedField != null){
            var jsonRejectedName = getJsonPropertyName(rejectedField);
            message = getErrorMessage(fieldError.getRejectedValue(), jsonRejectedName, fieldError.getDefaultMessage());

        }

        return message;
    }

    @Nonnull
    private String getErrorMessage(@Nonnull ConstraintViolation<?> violation) {
        var fieldName = ((PathImpl) violation.getPropertyPath()).getLeafNode().getName();
        var rejectObjectClass = violation.getLeafBean().getClass();
        try {
            var rejectedField = rejectObjectClass.getDeclaredField(fieldName);
            var jsonRejectedName = getJsonPropertyName(rejectedField);
            return getErrorMessage(violation.getInvalidValue(), jsonRejectedName, violation.getMessage());
        } catch (NoSuchFieldException e) {
            return getErrorMessage(violation.getInvalidValue(), fieldName, violation.getMessage());
        }
    }

    @Nonnull
    private String getErrorMessage(@Nullable Object rejectedValue, @Nonnull String jsonRejectedName, @Nullable String defaultMessage) {
        return "Invalid value " + rejectedValue + " for " + jsonRejectedName + ", " + defaultMessage;
    }

    @Nonnull
    private String getJsonPropertyName(@Nonnull Field rejectedField) {
        return rejectedField.isAnnotationPresent(JsonProperty.class)
            ? rejectedField.getAnnotation(JsonProperty.class).value()
            : rejectedField.getName();
    }

    @Nullable
    @SneakyThrows
    private Field getField(@Nonnull Class<?> objectClass, @Nonnull String[] fieldNames, int index) {
        var fieldsMap = getFieldsMap(objectClass);
        var fieldName = fieldNames[index];
        if (isCollectionField(fieldName)) {
            var fieldNameWithoutBrackets = fieldName.replaceAll("\\[[^\\[]*]", "");
            var field = fieldsMap.get(fieldNameWithoutBrackets);
            var collectionFieldRealClass = getCollectionFieldRealClass(field);
            return getField(collectionFieldRealClass, fieldNames, ++index);
        } else {
            var field = fieldsMap.get(fieldName);
            return index == fieldNames.length - 1 ? field : getField(field.getType(), fieldNames, ++index);
        }
    }

    private Class<?> getCollectionFieldRealClass(@Nonnull Field field) throws ClassNotFoundException {
        var actualTypeArguments = ((ParameterizedType) (field.getGenericType())).getActualTypeArguments();
        return Class.forName(((Class) actualTypeArguments[0]).getCanonicalName());
    }

    private boolean isCollectionField(@Nonnull String fieldName) {
        return fieldName.contains("[") && fieldName.contains("]");
    }

    @Nonnull
    private Map<String, Field> getFieldsMap(Class<?> aClass) {
        return Arrays.stream(aClass.getDeclaredFields()).collect(Collectors.toMap(Field::getName, f -> f));
    }

}

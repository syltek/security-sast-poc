package com.playtomic.anemone.user.model.permissions;

import java.util.Map;

public class BillingPermissionsToAuthorities extends PermissionsToAuthorities {

    private static final Map<PermissionLevel, String[]> authorities = Map.ofEntries(
            e(PermissionLevel.READ_ONLY, "get_invoices"),
            e(PermissionLevel.READ_WRITE)
    );

    public BillingPermissionsToAuthorities() {
        super(authorities);
    }

}

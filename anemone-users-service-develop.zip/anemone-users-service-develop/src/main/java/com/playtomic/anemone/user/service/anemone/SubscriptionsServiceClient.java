package com.playtomic.anemone.user.service.anemone;

import com.playtomic.anemone.jwt.JwtTokenFactory;
import com.playtomic.anemone.spring.ForceAnemoneAuthenticationCredentialsAccessor;
import com.playtomic.anemone.spring.feign.AnemoneFeignConfiguration;
import com.playtomic.anemone.spring.feign.AuthenticationHeaderFeignInterceptor;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import feign.RequestInterceptor;
import java.util.List;
import javax.annotation.Nonnull;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "subscriptions-service", configuration = SubscriptionsServiceClient.Configuration.class, url = "${subscriptions-service.url}")
public interface SubscriptionsServiceClient {

    @GetMapping(value = "/v1/vendor_subscriptions/subscribed_modules?tenant_id={tenant_id}", consumes = "application/json")
    @Nonnull
    List<SubscriptionModule> getSubscribedModules(@Nonnull @PathVariable("tenant_id") TenantId tenantId);

    @PostMapping(value = "/v1/membership_products", consumes = "application/json")
    @Nonnull
    String createMembershipProduct(@Nonnull @RequestBody CreateProductBody body);

    @DeleteMapping(value = "/v1/membership_products/{membership_product_id}")
    void deleteMembershipProduct(@Nonnull @PathVariable("membership_product_id") String membershipProductId);

    @PutMapping(value = "/v1/membership_products/{membership_product_id}")
    void updateMembershipProduct(@Nonnull @PathVariable("membership_product_id") String membershipProductId, @Nonnull @RequestBody PutMembershipProductBody putMembershipProductBody);

    @DeleteMapping(value = "/v1/membership_subscriptions")
    void deleteMembershipSubscription(@Nonnull @RequestBody DeleteMembershipSubscriptionBody body);


    class Configuration extends AnemoneFeignConfiguration {
        @Bean
        public RequestInterceptor requestInterceptor(@Nonnull JwtTokenFactory jwtTokenFactory) {
            return new AuthenticationHeaderFeignInterceptor(new ForceAnemoneAuthenticationCredentialsAccessor(jwtTokenFactory));
        }

    }
}

package com.playtomic.anemone.user.model.permissions;

import java.util.Map;

public class LessonPermissionsToAuthorities extends PermissionsToAuthorities {

    private static final Map<PermissionLevel, String[]> authorities = Map.ofEntries(
            e(PermissionLevel.READ_ONLY),
            e(PermissionLevel.READ_WRITE, "create_tournaments", "write_tournaments", "delete_tournaments", "invite_players", "remove_players")
    );

    public LessonPermissionsToAuthorities() {
        super(authorities);
    }

}

package com.playtomic.anemone.user.dao;

import com.playtomic.anemone.user.domain.tenant.TenantId;
import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import javax.annotation.Nonnull;
import javax.annotation.ParametersAreNonnullByDefault;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

@ParametersAreNonnullByDefault
public interface TenantTagRepository extends CrudRepository<TenantTagEntity, UUID> {

    @Nonnull
    Optional<TenantTagEntity> findByTenantIdAndUserIdAndTag(String tenantId, Long userId, String tag);

    @Nonnull
    @Transactional
    List<TenantTagEntity> deleteAllByTagAndType(String tag, TenantTagEntity.Type type, Pageable pageable);

    @Nonnull
    @Transactional
    List<TenantTagEntity> deleteAllByTagAndTypeAndUserIdIn(String tag, TenantTagEntity.Type type, List<Long> userIds);

    long countByTagAndType(String tag, TenantTagEntity.Type type);

    void deleteAllByExpiresAtIsBefore(Instant instant);

    List<TenantTagEntity> findAllByTenantIdAndUserIdAndExpiresAtIsBefore(String tenantId, Long id, Instant now);
}

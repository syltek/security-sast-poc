package com.playtomic.anemone.user.dao;

import com.playtomic.anemone.domain.user.UserId;
import com.playtomic.anemone.user.model.role.PlaytomicUserRole;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.persistence.LockModeType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

public interface UserRepository extends PagingAndSortingRepository<UserEntity, Long>, JpaSpecificationExecutor<UserEntity> {

    @Transactional
    Optional<UserEntity> findUserByEmail(@Param("email") String email);

    @Transactional
    Optional<UserEntity> findUserByFacebookId(@Param("facebookId") String facebookId);

    @Transactional
    Optional<UserEntity> findUserByGoogleId(@Param("googleId") String googleId);

    @Transactional
    Optional<UserEntity> findUserByAppleId(@Param("appleId") String appleId);

    @Transactional
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    Optional<UserEntity> findOneForUpdateById(@Param("id") Long id);

    @Transactional
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    List<UserEntity> findAllForUpdateByPhone(@Param("phone") String phone);

    long countByPhoneAndPhoneVerified(@Param("phone") @Nonnull String phone, @Param("phone_verified") boolean phoneVerified);

    @Transactional(readOnly = true)
    Stream<UserEntity> findByUserRoles_UserRole(PlaytomicUserRole role);

    @Query("SELECT u FROM UserEntity as u inner join LinkedAccountEntity as la "
        +" WITH la.user = u "
        + "AND la.tenantId = :tenantId "
        + "AND u.fullName like :nameLike "
        + "AND (u.acceptsPrivacyPolicy = true or u.acceptsPrivacyPolicy IS NULL)"
    )
    @Nonnull
    Page<UserEntity> findLinkedAccountByNameLike(@Param("tenantId") @Nonnull String tenantId,
        @Param("nameLike") @Nonnull String nameLike,
        @Nonnull Pageable page);

    @Query("SELECT u FROM UserEntity as u inner join LinkedAccountEntity as la "
        + "WITH la.user = u "
        + "AND la.tenantId = :tenantId "
        + "AND (u.acceptsPrivacyPolicy = true or u.acceptsPrivacyPolicy IS NULL)"
    )
    @Nonnull
    Page<UserEntity> findLinkedAccounts(@Param("tenantId") @Nonnull String tenantId,
        @Nonnull Pageable page);

    @Query("SELECT u FROM UserEntity as u inner join  UserRoleEntity as r ON  r.user = u "
        + "AND r.tenantId = :tenantId "
        + "AND r.userRole = com.playtomic.anemone.user.model.role.PlaytomicUserRole.ROLE_TENANT_MANAGER "
        + "AND (u.acceptsPrivacyPolicy = true or u.acceptsPrivacyPolicy IS NULL)"
    )
    @Nonnull
    Page<UserEntity> findAdmins(@Param("tenantId") @Nonnull String tenantId, @Nonnull Pageable pageable);

    @Query("SELECT u FROM UserEntity as u inner join  UserRoleEntity as r ON  r.user = u "
        + "AND r.tenantId = :tenantId "
        + "AND r.userRole = com.playtomic.anemone.user.model.role.PlaytomicUserRole.ROLE_TENANT_MANAGER "
        + "AND u.fullName like :nameLike "
        + "AND (u.acceptsPrivacyPolicy = true or u.acceptsPrivacyPolicy IS NULL)"
    )
    @Nonnull
    Page<UserEntity> findAdminsByNameLike(@Param("tenantId") @Nonnull String tenantId, @Param("nameLike") @Nonnull String nameLike, @Nonnull Pageable pageable);

    @Nonnull
    Page<UserEntity> findByTenantTags_tagAndTenantTags_Type(@Nonnull String tag, @Nonnull TenantTagEntity.Type type, @Nonnull Pageable pageable);

    @Nonnull
    Page<UserEntity> findByFullNameLikeAndTenantTags_tagAndTenantTags_Type(@Nonnull String nameLike, @Nonnull String tag, @Nonnull TenantTagEntity.Type type, @Nonnull Pageable pageable);

    @Query("SELECT u FROM UserEntity as u inner join LinkedAccountEntity as la "
        + "WITH la.user = u "
        + "AND la.tenantId = :tenantId "
        + "AND (u.acceptsPrivacyPolicy = true or u.acceptsPrivacyPolicy IS NULL) "
        + "AND ((:acceptsCommercialCommunications is null and la.acceptsCommercialCommunications IS NULL)  "
        + "OR  la.acceptsCommercialCommunications = :acceptsCommercialCommunications) "
        + "ORDER BY u.fullName"
    )
    Stream<UserEntity> findByLinkedAccountAndAcceptsCommercialCommunications(@Param("tenantId") @Nonnull String tenantId,
        @Nullable @Param("acceptsCommercialCommunications") Boolean acceptsCommercialCommunications);
}

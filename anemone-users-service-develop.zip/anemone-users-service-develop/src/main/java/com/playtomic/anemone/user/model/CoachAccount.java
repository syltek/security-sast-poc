package com.playtomic.anemone.user.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.user.domain.matches.SportId;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import java.time.Instant;
import java.util.List;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CoachAccount {

    @Nonnull
    @JsonProperty("tenant_id")
    TenantId tenantId;

    @Nullable
    @JsonProperty("created_at")
    public Instant createdAt;

    @JsonProperty("sport_ids")
    @Nonnull
    private List<SportId> sportIds;

    @JsonProperty("experience")
    @Nullable
    private String experience;

    @JsonProperty("ages")
    @Nullable
    private String ages;

    @JsonProperty("description")
    @Nullable
    private String description;
}

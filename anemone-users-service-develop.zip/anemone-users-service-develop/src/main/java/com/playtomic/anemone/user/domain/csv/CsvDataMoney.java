package com.playtomic.anemone.user.domain.csv;

import org.javamoney.moneta.Money;

public class CsvDataMoney extends CsvDataBase<Money> {
    public CsvDataMoney(int position, Money value) {
        super(position, value);
    }
}

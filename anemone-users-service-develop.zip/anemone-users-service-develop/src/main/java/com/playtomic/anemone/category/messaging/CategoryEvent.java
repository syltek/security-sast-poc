package com.playtomic.anemone.category.messaging;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.category.domain.Category;
import javax.annotation.Nonnull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

@ToString
@Getter
@AllArgsConstructor
@Builder
public class CategoryEvent {

    public enum CategoryEventType {
        CATEGORY_CREATED,
        CATEGORY_UPDATED
    }

    @JsonProperty(value = "event_type", required = true)
    @Nonnull
    private final CategoryEventType eventType;

    @JsonProperty(value = "event_data", required = true)
    @Nonnull
    private final Category category;

    @JsonIgnore
    @Nonnull
    public String getKey() {
        return category.getId().toString();
    }
}

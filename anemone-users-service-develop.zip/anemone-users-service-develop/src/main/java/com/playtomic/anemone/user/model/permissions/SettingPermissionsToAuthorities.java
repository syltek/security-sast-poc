package com.playtomic.anemone.user.model.permissions;

import java.util.Map;

public class SettingPermissionsToAuthorities extends PermissionsToAuthorities {

    private static final Map<PermissionLevel, String[]> authorities = Map.ofEntries(
            e(PermissionLevel.READ_ONLY, "read_billing_information", "read_all_resources", "read_court_pricing_rules", "read_product_extras", "read_commission_rules"),
            e(PermissionLevel.READ_WRITE, "create_onboarding_tenants", "write_tenants", "write_billing_information", "write_court_pricing_rules", "write_product_extras")
    );

    public SettingPermissionsToAuthorities() {
        super(authorities);
    }

}

package com.playtomic.anemone.user.dao.permissions;

import com.playtomic.anemone.dao.BaseDocument;
import com.playtomic.anemone.domain.user.UserId;
import com.playtomic.anemone.user.model.permissions.PermissionLevel;
import com.playtomic.anemone.user.model.permissions.PermissionName;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.CompoundIndexes;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.util.EnumMap;
import javax.annotation.Nonnull;

@Document(collection = "permissions")
@CompoundIndexes({
        @CompoundIndex(name = "user_and_tenant", def = "{'user_id': 1, 'tenant_id': 1 }", unique = true)
})
@AllArgsConstructor
@Data
public class PermissionDocument extends BaseDocument {

    @Id
    @Nonnull
    private String id;

    @Field("user_id")
    @Nonnull
    private UserId userId;

    @Field("tenant_id")
    @Nonnull
    private TenantId tenantId;

    @Field("permissions")
    @Nonnull
    private EnumMap<PermissionName, PermissionLevel> permissions;

}

package com.playtomic.anemone.user.domain.users;

import com.playtomic.anemone.domain.user.UserId;
import javax.annotation.Nonnull;

public class UserLegacy {
    public static long asLong(@Nonnull UserId userId) throws NumberFormatException {
        return Long.parseLong(userId.getValue());
    }

    public static long asSafeLong(@Nonnull UserId userId) throws NumberFormatException {
        try {
            return asLong(userId);
        // I've change NumberFormatException by Throwable because there are some NPE that are
        // not detected on execution time due to @Nonnull. They usually happens when clients
        // specify me but pass no jwt-token.
        } catch (Throwable e) {
            // There is no users with id -1
            return -1;
        }
    }

    @Nonnull
    public static UserId valueOf(@Nonnull Long id) {
        return UserId.valueOf(Long.toString(id));
    }
}

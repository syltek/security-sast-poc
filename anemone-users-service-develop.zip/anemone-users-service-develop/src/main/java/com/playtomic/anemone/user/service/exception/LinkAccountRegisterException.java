package com.playtomic.anemone.user.service.exception;

import javax.annotation.Nonnull;

public class LinkAccountRegisterException extends RuntimeException {

    public LinkAccountRegisterException(@Nonnull String m) {
        super(m);
    }

    public LinkAccountRegisterException(@Nonnull Exception e) {
        super(e);
    }
}

package com.playtomic.anemone.user.domain.users;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.domain.location.Location;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import javax.annotation.Nullable;
import lombok.Data;

@Data
public class GameLocation {

    @JsonProperty("tenant_id")
    @Nullable
    private TenantId tenantId;

    @JsonProperty("coordinates")
    @Nullable
    private Location location;

    public GameLocation(
        @JsonProperty("tenant_id") @Nullable TenantId tenantId,
        @JsonProperty("coordinates") @Nullable Location location) {
        this.tenantId = tenantId;
        this.location = location;
    }
}

package com.playtomic.anemone.user.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.user.dao.TenantTagEntity;
import java.time.Instant;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class TenantTagDetails {

    @Nonnull
    @JsonProperty("tag")
    private String tag;
    @Nullable
    @JsonProperty("type")
    private TenantTagEntity.Type type;
    @Nullable
    @JsonProperty("expires_at")
    private Instant expiresAt;

}

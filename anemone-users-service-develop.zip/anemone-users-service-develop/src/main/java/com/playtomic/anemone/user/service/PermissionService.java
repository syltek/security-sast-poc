package com.playtomic.anemone.user.service;

import com.playtomic.anemone.dao.OptimisticLockingRetryableExecutor;
import com.playtomic.anemone.domain.user.UserId;
import com.playtomic.anemone.domain.user.UserRole;
import com.playtomic.anemone.http.BadRequestException;
import com.playtomic.anemone.spring.config.AnemoneUserPrincipal;
import com.playtomic.anemone.user.dao.PermissionRepository;
import com.playtomic.anemone.user.dao.UserEntity;
import com.playtomic.anemone.user.dao.UserRepository;
import com.playtomic.anemone.user.dao.UserRoleEntity;
import com.playtomic.anemone.user.dao.permissions.PermissionDocument;
import com.playtomic.anemone.user.domain.permissions.Permission;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import com.playtomic.anemone.user.domain.users.UserLegacy;
import com.playtomic.anemone.user.model.permissions.PermissionLevel;
import com.playtomic.anemone.user.model.permissions.PermissionName;
import com.playtomic.anemone.user.model.role.PlaytomicUserRole;
import com.playtomic.anemone.user.service.anemone.SubscriptionModule;
import com.playtomic.anemone.user.service.anemone.SubscriptionsServiceClient;
import com.playtomic.anemone.user.service.exception.UserNotFoundException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.transaction.Transactional;

@Service
@RequiredArgsConstructor
@Slf4j
public class PermissionService {

    private static final boolean DISABLE_SUBSCRIPTIONS_FILTERING = true;

    @Nonnull
    // Mapping Subscription modules to Anemone permissions
    private static final Map<String, List<PermissionName>> mapSubscriptionModulesToPermissions = Map.of(
            "COACHES", List.of(PermissionName.COACHES_PERMISSION),
            "INVOICES", List.of(PermissionName.INVOICES_PERMISSION),
            "LEAGUES", List.of(PermissionName.LEAGUES_PERMISSION),
            "ANEMONE_WALLETS", List.of(PermissionName.ANEMONE_WALLETS_PERMISSION),
            "ANEMONE_CATEGORIES", List.of(PermissionName.CUSTOMER_CATEGORIES_PERMISSION),
            "PREMIUM", List.of(
                    PermissionName.COACHES_PERMISSION,
                    PermissionName.INVOICES_PERMISSION,
                    PermissionName.LEAGUES_PERMISSION,
                    PermissionName.ANEMONE_WALLETS_PERMISSION,
                    PermissionName.PREMIUM_PERMISSION)
    );

    @Nonnull
    private final PermissionRepository permissionRepository;

    @Nonnull
    private final UserRepository userRepository;

    @Nonnull
    private final SubscriptionsServiceClient subscriptionsServiceClient;

    @Nonnull
    public Permission getPermissionsInTenant(@Nonnull UserId userId,  @Nonnull TenantId tenantId) {
        Optional<PermissionDocument> optDoc = permissionRepository.findByUserIdAndTenantId(userId, tenantId);
        return optDoc
                .map(permissionDocument -> new Permission(tenantId, permissionDocument.getPermissions()))
                /* if there is no permissions for user_id and tenant_id, it returns an empty map */
                .orElseGet(() -> new Permission(tenantId, new EnumMap<>(PermissionName.class)));
    }

    @Nonnull
    public Permission setPermissionsInTenant(@Nonnull UserId userId,
                                             @Nonnull TenantId tenantId,
                                             @Nonnull EnumMap<PermissionName, PermissionLevel> permissions)
            throws UserNotFoundException {

        if (permissions.containsKey(PermissionName.PREMIUM_PERMISSION)) {
            throw new BadRequestException("It is not allowed to set the Premium permission.");
        }

        // Checking user exists
        userRepository.findById(UserLegacy.asSafeLong(userId)).orElseThrow(UserNotFoundException::new);

        OptimisticLockingRetryableExecutor.OptimisticLockingRetryableAction<PermissionDocument> action =
                () -> {
                    Optional<PermissionDocument> optDoc = permissionRepository.findByUserIdAndTenantId(userId, tenantId);
                    PermissionDocument permissionDoc;
                    if (optDoc.isPresent()) {
                        permissionDoc = optDoc.get();
                        permissionDoc.setPermissions(permissions);
                    } else {
                        permissionDoc = new PermissionDocument(UUID.randomUUID().toString(), userId, tenantId, permissions);
                    }

                    return permissionRepository.save(permissionDoc);
                };

        OptimisticLockingRetryableExecutor<PermissionDocument> executor = new OptimisticLockingRetryableExecutor<>(action, 5);

        return convertToDomain(executor.execute());
    }

    public void deletePermissionsInTenant(@Nonnull UserId userId, @Nonnull TenantId tenantId) throws UserNotFoundException {
        userRepository.findById(UserLegacy.asSafeLong(userId)).orElseThrow(UserNotFoundException::new);
        OptimisticLockingRetryableExecutor.OptimisticLockingRetryableAction<Void> action =
            () -> {
                permissionRepository.findByUserIdAndTenantId(userId, tenantId).ifPresent(permissionRepository::delete);
                return null;
            };
        OptimisticLockingRetryableExecutor<Void> executor = new OptimisticLockingRetryableExecutor<>(action, 5);

        executor.execute();
    }

    @Nonnull
    public Permission updatePermissionInTenant(@Nonnull UserId userId,
                                               @Nonnull TenantId tenantId,
                                               @Nonnull PermissionName permissionName,
                                               @Nullable PermissionLevel permissionLevel) {

        OptimisticLockingRetryableExecutor.OptimisticLockingRetryableAction<PermissionDocument> action =
                () -> {
                    Optional<PermissionDocument> optDoc = permissionRepository.findByUserIdAndTenantId(userId, tenantId);

                    PermissionDocument permissionDoc;
                    if (optDoc.isPresent()) {
                        // There is a record in DB for user_id and tenant_id
                        permissionDoc = optDoc.get();
                        if (permissionLevel == null) {
                            // Remove permission
                            permissionDoc.getPermissions().remove(permissionName);
                        } else {
                            // Update permission
                            permissionDoc.getPermissions().put(permissionName, permissionLevel);
                        }
                    } else if (permissionLevel != null) {
                        // It has to create a new record in DB for user_id and tenant_id
                        // Checking user exists
                        try {
                            userRepository.findById(UserLegacy.asSafeLong(userId)).orElseThrow(UserNotFoundException::new);
                        } catch (UserNotFoundException e) {
                            throw new BadRequestException("User does not exist!");
                        }

                        EnumMap<PermissionName, PermissionLevel> permissions = new EnumMap<>(PermissionName.class);
                        permissions.put(permissionName, permissionLevel);
                        permissionDoc = new PermissionDocument(UUID.randomUUID().toString(), userId, tenantId, permissions);
                    } else {
                        // Just in case: There is no record in DB and the new level is null
                        throw new BadRequestException("A new permission with null level is not allowed");
                    }

                    return permissionRepository.save(permissionDoc);
                };

        OptimisticLockingRetryableExecutor<PermissionDocument> executor = new OptimisticLockingRetryableExecutor<>(action, 5);

        return convertToDomain(executor.execute());
    }

    @Nonnull
    public List<Permission> getActivePermissions(@Nonnull UserId userId) {
        List<PermissionDocument> userPermissions = permissionRepository.findByUserId(userId);
        List<Permission> activePermissions = new ArrayList<>();

        for (PermissionDocument userPermission : userPermissions) {
            TenantId tenantId = userPermission.getTenantId();
            EnumMap<PermissionName, PermissionLevel> permissions = userPermission.getPermissions();
            if (!DISABLE_SUBSCRIPTIONS_FILTERING) {
                List<SubscriptionModule> subscribedModules = subscriptionsServiceClient.getSubscribedModules(tenantId);
                filterPermissionsFromSubscribedModules(permissions, subscribedModules);
            }
            activePermissions.add(new Permission(tenantId, permissions));
        }

        return activePermissions;
    }

    /**
     * This operation will find all tenant managers without any assigned permission for a tenant
     * and add all the permissions to that same tenant.
     */
    // This could be deleted after creation of all permissions
    @Transactional
    public int migrateTenantManagersWithoutPermissions() {
        log.info("Migration started");

        // All tenantManagerPermissions in READ_WRITE level except PREMIUM
        EnumMap<PermissionName, PermissionLevel> tenantManagerPermissions = new EnumMap<PermissionName, PermissionLevel>(
            Arrays.stream(PermissionName.values())
                .filter(p -> !PermissionName.PREMIUM_PERMISSION.equals(p))
                .collect(Collectors.toMap(p -> p, p -> PermissionLevel.READ_WRITE)));

        Stream<UserEntity> allTenantManagers = userRepository.findByUserRoles_UserRole(PlaytomicUserRole.ROLE_TENANT_MANAGER);
        int processedManagers = allTenantManagers
            .mapToInt(manager -> migrateUserWithoutPermissions(tenantManagerPermissions, manager, PlaytomicUserRole.ROLE_TENANT_MANAGER))
            .sum();
        ;

        HashMap<PermissionName, PermissionLevel> activityManagerPermissionsMap = new HashMap<>();
        activityManagerPermissionsMap.put(PermissionName.DASHBOARD_PERMISSION, PermissionLevel.READ_WRITE);
        activityManagerPermissionsMap.put(PermissionName.MATCHES_PERMISSION, PermissionLevel.READ_WRITE);
        activityManagerPermissionsMap.put(PermissionName.CHATS_PERMISSION, PermissionLevel.READ_WRITE);
        activityManagerPermissionsMap.put(PermissionName.TOURNAMENTS_PERMISSION, PermissionLevel.READ_WRITE);
        activityManagerPermissionsMap.put(PermissionName.LESSONS_PERMISSION, PermissionLevel.READ_WRITE);
        EnumMap<PermissionName, PermissionLevel> activityManagerPermissions = new EnumMap<>(activityManagerPermissionsMap);

        Stream<UserEntity> allActivityManagers = userRepository.findByUserRoles_UserRole(PlaytomicUserRole.ROLE_ACTIVITY_MANAGER);
        int processedActivityManager = allActivityManagers
            .mapToInt(manager -> migrateUserWithoutPermissions(activityManagerPermissions, manager, PlaytomicUserRole.ROLE_ACTIVITY_MANAGER))
            .sum();

        log.info("Migration completed after migrating {} managers and {} activity managers", processedManagers, processedActivityManager);

        return processedManagers + processedActivityManager;
    }

    public int migrateUserWithoutPermissions(
        @Nonnull EnumMap<PermissionName, PermissionLevel> permissionsToAdd,
        @Nonnull UserEntity userToMigrate, @Nonnull PlaytomicUserRole roleToMigrate) {

        UserId userId = UserId.valueOf(userToMigrate.getId().toString());
        int migratedRoles = 0;
        //Find the related tenant to each of the tenant userToMigrate roles
        for (UserRoleEntity role : userToMigrate.getUserRoles()) {
            if (roleToMigrate.equals(role.getUserRole())
                && validTenantId(role.getTenantId())) {
                TenantId tenantId = TenantId.valueOf(role.getTenantId());
                Optional<PermissionDocument> permissionDoc = permissionRepository.findByUserIdAndTenantId(userId, tenantId);
                //Not permissionsToAdd found for this user+tenant, adding all.
                if (permissionDoc.isEmpty()) {
                    log.info("Creating permissions for the user {} in tenant {} for role {}", userId, tenantId, roleToMigrate);
                    PermissionDocument newPermissionDow = new PermissionDocument(UUID.randomUUID().toString(), userId, tenantId, permissionsToAdd);
                    permissionRepository.save(newPermissionDow);
                    migratedRoles++;
                }
            }
        }

        return migratedRoles;
    }

    private boolean validTenantId(@Nullable String tenantId) {
        return tenantId != null && !tenantId.equals("*");
    }

    @Nonnull
    private Permission convertToDomain(@Nonnull PermissionDocument model) {
        return new Permission(model.getTenantId(), model.getPermissions());
    }

    private void filterPermissionsFromSubscribedModules(@Nonnull EnumMap<PermissionName, PermissionLevel> permissions,
                                                        @Nonnull List<SubscriptionModule> subscribedModules) {
        Set<PermissionName> subscribedPermissions = new HashSet<>();
        for (SubscriptionModule module : subscribedModules) {
            subscribedPermissions.addAll(mapSubscriptionModulesToPermissions.get(module.getModuleType()));
        }

        permissions.keySet().removeIf(k -> k.isActivatedBySubscription() && !subscribedPermissions.contains(k));

        // Special case: PREMIUM MODULE cannot be set by Manager
        if (subscribedPermissions.contains(PermissionName.PREMIUM_PERMISSION)) {
            permissions.put(PermissionName.PREMIUM_PERMISSION, PermissionLevel.READ_WRITE);
        }
    }

    public boolean isManager(@Nonnull TenantId tenantId, @Nonnull Authentication auth) {
        // sgmoratilla: repeat 100x with me: this is shit, because authorities are not well defined. Everything
        //              Authorities and roles are mixed in an incompatible way: anemone is admin_matches,
        //              but not that's not true because tenant_mangers can do things that anemone cannot.

        if (auth.getPrincipal() instanceof AnemoneUserPrincipal) {
            AnemoneUserPrincipal principal = (AnemoneUserPrincipal)auth.getPrincipal();

            // sgmoratilla: hasClaimFor does not support "*", enjoy this check
            return
                principal.hasClaimsFor("role_tenant_manager", "tenant_ids", tenantId.getValue()) ||
                    principal.hasClaimsFor("role_tenant_manager", "tenant_ids", "*") ||
                    principal.hasClaimsFor("role_activity_manager", "tenant_ids", tenantId.getValue()) ||
                    principal.hasClaimsFor("role_activity_manager", "tenant_ids", "*");

        }

        return false;
    }

    public void checkCategoriesReadPermission(@Nonnull UserId userId, @Nonnull AnemoneUserPrincipal requestUser) {
        if (requestUser.getExpandedAuthorities().contains(UserRole.ROLE_ANEMONE.getGa()) ||
            requestUser.getExpandedAuthorities().contains(UserRole.ROLE_ADMIN.getGa()) ||
            requestUser.getExpandedAuthorities().contains(UserRole.ROLE_TENANT_MANAGER.getGa()) ||
            requestUser.getExpandedAuthorities().contains(UserRole.ROLE_ACTIVITY_MANAGER.getGa())) {
            return;
        }

        if (userId.equals(requestUser.getId())) {
            return;
        }

        throw new AccessDeniedException("You don't have permission to read the categories from user " + userId.toString());
    }
}

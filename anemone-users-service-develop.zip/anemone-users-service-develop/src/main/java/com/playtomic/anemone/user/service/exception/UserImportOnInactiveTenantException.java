package com.playtomic.anemone.user.service.exception;

import lombok.Getter;

@Getter
public class UserImportOnInactiveTenantException extends RuntimeException {

}

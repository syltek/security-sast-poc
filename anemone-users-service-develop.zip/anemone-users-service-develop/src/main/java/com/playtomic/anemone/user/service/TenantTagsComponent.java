package com.playtomic.anemone.user.service;

import com.google.common.collect.ImmutableSet;
import com.playtomic.anemone.domain.Email;
import com.playtomic.anemone.domain.user.UserId;
import com.playtomic.anemone.thirdparties.syltekcrm.PadelclickService;
import com.playtomic.anemone.thirdparties.syltekcrm.PadelclickTenant;
import com.playtomic.anemone.thirdparties.syltekcrm.PadelclickUser;
import com.playtomic.anemone.thirdparties.syltekcrm.impl.PadelclickFindCustomerException;
import com.playtomic.anemone.user.dao.LinkedAccountEntity;
import com.playtomic.anemone.user.dao.TenantTagEntity;
import com.playtomic.anemone.user.dao.UserDocumentRepository;
import com.playtomic.anemone.user.dao.UserEntity;
import com.playtomic.anemone.user.dao.UserRepository;
import com.playtomic.anemone.user.domain.tenant.Tenant;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import com.playtomic.anemone.user.domain.users.UserLegacy;
import com.playtomic.anemone.user.model.TenantTag;
import com.playtomic.anemone.user.model.TenantTagDetails;
import static com.playtomic.anemone.user.service.UserServicePersistenceComponent.SYLTEK_CUSTOMER_TYPE_PREFIX;
import com.playtomic.anemone.user.service.anemone.TenantServiceClient;
import com.playtomic.anemone.user.service.exception.UserNotFoundException;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.persistence.EntityManager;
import javax.validation.ClockProvider;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

@Component
@Slf4j
@RequiredArgsConstructor
public class TenantTagsComponent {

    protected static final String CUSTOMER_TYPE_NOT_FOUND_PREFIX = "NOT_FOUND";

    @Nonnull
    private final TenantServiceClient tenantServiceClient;

    @Nonnull
    private final PadelclickService padelclickService;

    @Nonnull
    private final UserRepository userRepository;

    @Nonnull
    private final EntityManager entityManager;

    @Nonnull
    private final ClockProvider clockProvider;

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public boolean checkAndUpdateTags(@Nonnull UserId userId) {
        try {
            List<Tenant> tenantsToBeSynced = checkSyltekCrmLinkedAccountsUserTags(userId);
            if (!tenantsToBeSynced.isEmpty()) {
                UserEntity userEntity = findUserForUpdate(userId);
                syncTenantTagsFromSyltekCrm(userEntity, tenantsToBeSynced);
            }

            return true;
        } catch (UserNotFoundException e) {
            log.error("User {} not found when synchronizing tenants tags.", userId, e);
            return false;
        }
    }

    @Nonnull
    protected UserEntity findUserForUpdate(@Nonnull UserId userId) {
        return userRepository
            .findOneForUpdateById(UserLegacy.asSafeLong(userId))
            .orElseThrow(UserNotFoundException::new);
    }

    @Nonnull
    protected UserEntity createTenantTags(@Nonnull UserEntity userEntity, @Nonnull TenantTag tenantTag) {
        // No tags received, nothing to be done
        if (CollectionUtils.isEmpty(tenantTag.getTags())) {
            return userEntity;
        }

        // If received tags are already set, there is nothing to be done
        Set<TenantTagEntity> tenantTagEntitiesForTenantId = userEntity.getTenantTags(tenantTag.getTenantId(), false);
        // These are the tags that need to be added to the user
        Set<String> tagsToBeAdded = getTagsToBeAdded(tenantTagEntitiesForTenantId, tenantTag);
        Set<String> tagsToBeRemoved = getTagsToBeRemoved(tenantTagEntitiesForTenantId, tenantTag);
        if (CollectionUtils.isEmpty(tagsToBeAdded) && CollectionUtils.isEmpty(tagsToBeRemoved)) {
            log.trace("Tenant tag specified {} has already been defined for that tenant_id {}.",
                    String.join(",", tenantTag.getTags()), tenantTag.getTenantId());
            return userEntity;
        }

        log.warn("Adding tenant tags {} for tenant_id {} and user_id {}. Why was not it already in sync?",
                  String.join(",", tenantTag.getTags()), tenantTag.getTenantId(), userEntity.getId());

        // Add new tenantTags
        tagsToBeAdded
            .forEach(newTenantTag -> userEntity.addTenantTag(
                new TenantTagEntity(userEntity, newTenantTag, tenantTag.getTenantId())));

        userEntity.getTenantTags().removeIf(tag -> {
            boolean toRemove = tag.getTenantId().equals(tenantTag.getTenantId().getValue()) && tagsToBeRemoved.contains(tag.getTag());
            if (toRemove) {
                entityManager.remove(tag);
            }
            return toRemove;
        });

        UserEntity saved = userRepository.save(userEntity);
        return saved;
    }

    @Nonnull
    @Transactional
    public UserEntity setTenantTags(@Nonnull UserId userId, @Nonnull Set<TenantTag> tenantTags) {
        var userEntity = findUserForUpdate(userId);
        userEntity.getTenantTags().forEach(entityManager::remove);
        userEntity.removeAllTenantTag();
        entityManager.flush();

        var tenantTagEntities = tenantTags.stream()
            .map(tenantTag -> toTenantTagEntities(userEntity, tenantTag))
            .flatMap(Collection::stream)
            .collect(Collectors.toSet());
        userEntity.addTenantTags(tenantTagEntities);

        return userRepository.save(userEntity);
    }

    @Nonnull
    @Transactional
    public UserEntity setTenantTagsForTenant(@Nonnull UserId userId, @Nonnull TenantTag tenantTag) {
        var userEntity = findUserForUpdate(userId);
        var tenantTagEntities = userEntity.getTenantTags(tenantTag.getTenantId(), false);

        tenantTagEntities.forEach(entityManager::remove);
        userEntity.removeTenantTags(tenantTagEntities);
        entityManager.flush();

        var tenantId = tenantTag.getTenantId();
        var categoryActiveAt = userEntity.getCategoryActiveAt(tenantId, clockProvider.getClock().instant());
        var newTenantTagEntities = tenantTag.getTags().stream()
            .filter(tag -> categoryActiveAt.filter(c -> c.getTag().equals(tag)).isEmpty())
            .map(tag -> new TenantTagEntity(userEntity, tag, tenantTag.getTenantId()))
            .collect(Collectors.toSet());
        userEntity.addTenantTags(newTenantTagEntities);

        return userRepository.save(userEntity);
    }

    @Nonnull
    @Transactional
    public UserEntity removeTenantTags(@Nonnull UserId userId, @Nullable Set<String> tenantTags, @Nonnull TenantId tenantId) {
        UserEntity userEntity = findUserForUpdate(userId);
        Set<TenantTagEntity> tenantTagEntities = userEntity.getTenantTags(tenantId, false);
        if (tenantTagEntities.isEmpty()) {
            return userEntity;
        }

        // Delete some tags for tenantId
        if (tenantTags != null) {
            tenantTagEntities = tenantTagEntities.stream()
                    .filter(tenantTagEntity -> tenantTags.contains(tenantTagEntity.getTag()))
                    .collect(Collectors.toSet());
        }

        userEntity.removeTenantTags(tenantTagEntities);
        tenantTagEntities.forEach(entityManager::remove);

        return userRepository.save(userEntity);
    }

    @Nonnull
    private Set<String> getTagsToBeAdded(@Nonnull Set<TenantTagEntity> existingTenantTagEntitiesForTenantId, @Nonnull TenantTag tenantTag) {
        if (tenantTag.getTags().isEmpty()) {
            return new HashSet<>();
        }

        Set<String> existingTags = existingTenantTagEntitiesForTenantId.stream().map(TenantTagEntity::getTag).collect(Collectors.toSet());
        return tenantTag.getTags().stream()
                .filter(tenantTagValue -> !existingTags.contains(tenantTagValue))
                .collect(Collectors.toSet());
    }

    @Nonnull
    private Set<String> getTagsToBeRemoved(@Nonnull Set<TenantTagEntity> existingTenantTagEntitiesForTenantId, @Nonnull TenantTag tenantTag) {
        Set<String> existingTags = existingTenantTagEntitiesForTenantId.stream().map(TenantTagEntity::getTag).collect(Collectors.toSet());
        existingTags.removeIf(t -> tenantTag.getTags().contains(t));
        return existingTags;
    }

    /**
     * Checks if a user with a linked account has also tags imported from CRM. If the user has a linked account but
     * no tags, then tags are fetched from CRM. Users should have at least one tag for each linked account in CRM
     * (at least, the user type)
     */
    @Nonnull
    private List<Tenant> checkSyltekCrmLinkedAccountsUserTags(@Nonnull UserId userId) {
        UserEntity user = userRepository.findById(UserLegacy.asSafeLong(userId)).orElseThrow(UserNotFoundException::new);

        Set<String> tenantsWithTags = user.getTenantTags().stream().map(TenantTagEntity::getTenantId).collect(Collectors.toSet());
        Set<LinkedAccountEntity> accounts = ImmutableSet.copyOf(user.getLinkedAccounts());

        // Check which tenants need to be sync'd. This is there is no tag set for linkedAccount tenantId
        List<String> tenantIdsToBeSync = accounts.stream()
            .map(LinkedAccountEntity::getTenantId)
            .filter(tenantId -> !tenantsWithTags.contains(tenantId))
            .collect(Collectors.toList());

        // If every linkedAccount.tenantId has set tags. Do nothing.
        if (CollectionUtils.isEmpty(tenantIdsToBeSync)) {
            return new ArrayList<>();
        }

        // Fetch tenants by tenantsToBeSync and filter active ones
        List<Tenant> tenantsToBeSync = tenantServiceClient.getByIds(tenantIdsToBeSync).stream()
            .filter(tenant -> tenant.isActive() && tenant.isSyltekCrm())
            .collect(Collectors.toList());

        return tenantsToBeSync;
    }

    @Nonnull
    private Set<TenantTagEntity> toTenantTagEntities(UserEntity userEntity, TenantTag tenantTag) {
        return tenantTag.getTags().stream()
            .map(tagValue -> new TenantTagEntity(userEntity, tagValue, tenantTag.getTenantId())).
            collect(Collectors.toSet());
    }

    // This method is being called with every GET putting a lot of pressure in tenants.
    // It was intented to sync the tenant tags, but SyltekCRM is sending those events via Kafka now,
    // so this method should be removed.
    private void syncTenantTagsFromSyltekCrm(@Nonnull UserEntity user, @Nonnull List<Tenant> tenantsToBeSyncd) {
        // Sync those tenants tags at tenant that need to be synchronized
        for (Tenant tenant : tenantsToBeSyncd) {
            try {
                PadelclickTenant padelclickTenant = UserService.toPadelclick(tenant);

                // Remotely search for user at CRM tenant
                PadelclickUser padelclickUser = padelclickService.findCustomer(padelclickTenant, new Email(user.getEmail()));

                // Create tenantTag for user
                String tenantTagValue = SYLTEK_CUSTOMER_TYPE_PREFIX + padelclickUser.getDetail().getIdCustomerType();
                TenantTag tenantTag = new TenantTag(Collections.singleton(tenantTagValue), Collections.singleton(new TenantTagDetails(tenantTagValue, null, null)), tenant.getTenantId());

                createTenantTags(user, tenantTag);

            } catch (PadelclickFindCustomerException ex) {

                String tag = SYLTEK_CUSTOMER_TYPE_PREFIX + CUSTOMER_TYPE_NOT_FOUND_PREFIX;
                log.debug("User {} not found in CRM. Tag {} has been added", user.getId(), tag, ex);

                try {
                    TenantTag tenantTag =  new TenantTag(Collections.singleton(tag), Collections.singleton(new TenantTagDetails(tag, null, null)), tenant.getTenantId());
                    createTenantTags(user, tenantTag);

                } catch (UserNotFoundException e) {
                    log.debug("Error creating tags for user {} and tenant {}. Ignoring linked account", user.getId(), tenant.getTenantId());
                }

            } catch (Exception e) {
                log.debug("Error looking for tags for user {} in CRM tenant {}. Ignoring linked account", user.getId(), tenant.getTenantId(), e);
            }
        }
    }
}

package com.playtomic.anemone.user.service.messaging;

import com.playtomic.anemone.domain.user.UserId;
import com.playtomic.anemone.user.config.CacheConfiguration;
import com.playtomic.anemone.user.dao.tenants_tag.UserUpdateTenantTagsTaskDocument;
import com.playtomic.anemone.user.dao.tenants_tag.UserUpdateTenantTagsTaskRepository;
import java.time.Instant;
import javax.annotation.Nonnull;
import javax.validation.ClockProvider;
import lombok.RequiredArgsConstructor;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class UserUpdateTenantTagsCache {

    @Nonnull
    private final UserUpdateTenantTagsTaskRepository tenantTagsTaskRepository;

    @Nonnull
    private final ClockProvider clockProvider;

    @Cacheable(value = "userUpdateTenantTags", key = "#userId")
    public boolean seenTooEarly(@Nonnull UserId userId) {
        return tenantTagsTaskRepository.findById(userId).isPresent();
    }

    @CacheEvict(value = "userUpdateTenantTags", key = "#userId")
    public void recordUpdated(@Nonnull UserId userId) {
        Instant expiresAt = clockProvider.getClock()
                                         .instant()
                                         .plus(CacheConfiguration.MONGODB_CACHE_EXPIRATION_TIME);

        UserUpdateTenantTagsTaskDocument doc = UserUpdateTenantTagsTaskDocument
            .builder()
            .userId(userId)
            .expiresAt(expiresAt)
            .build();

        tenantTagsTaskRepository.save(doc);
    }

}

package com.playtomic.anemone.user.dao;

import javax.annotation.Nonnull;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;

public interface LinkedAccountRepository extends PagingAndSortingRepository<LinkedAccountEntity, Long>,JpaSpecificationExecutor<LinkedAccountEntity>{

    @Nonnull
    long countByTenantIdAndUserId(@Param("tenant_id") @Nonnull String tenantId,@Param("user_id") @Nonnull Long userId);

}

package com.playtomic.anemone.user.service;

import com.google.common.collect.ImmutableMap;

import com.cloudinary.Cloudinary;
import com.cloudinary.Transformation;
import com.cloudinary.utils.ObjectUtils;
import com.playtomic.anemone.user.config.CloudinaryConfiguration;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Map;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;

@Service
@Slf4j
public class CloudinaryService {

    private final static String BASE64_URI_PREFIX = "data:image";

    private final static String BASE64_JPG_URI_PREFIX = "data:image/jpeg;base64,";

    @Nonnull
    private CloudinaryConfiguration cloudinaryConfiguration;

    @Nonnull
    private Cloudinary cloudinary;

    // Use 1280px width or lower if the original image is smaller.
    private final Transformation defaultTransformation = new Transformation().width(1280).crop("limit");

    public CloudinaryService(@Nonnull CloudinaryConfiguration cloudinaryConfiguration) {
        this.cloudinaryConfiguration = cloudinaryConfiguration;
        this.cloudinary = new Cloudinary(cloudinaryConfiguration.toMap());
    }

    public URL getFacebookURL(@Nonnull String facebookId, @Nullable String overlay) {
        try {
            return new URL(cloudinary.url().transformation(addOverlay(overlay,
                    new Transformation(defaultTransformation))).publicId(facebookId).type("facebook").generate());
        } catch (MalformedURLException e) {
            log.info("Error generating Cloudinary URL for facebookId {}", facebookId);
            return null;
        }
    }

    public URL getURL(@Nonnull String fileId, @Nonnull String folder, @Nullable String overlay) {
        String publicId = cloudinaryConfiguration.getRootFolder() + "/" + folder + fileId;
        try {
            return new URL(cloudinary.url().transformation(addOverlay(overlay,
                    new Transformation(defaultTransformation))).publicId(publicId).generate());
        } catch (MalformedURLException e) {
            log.info("Error generating Cloudinary URL for fileId {}", fileId);
            return null;
        }
    }

    private Transformation addOverlay(String overlay, Transformation transformation) {
        if (!StringUtils.isEmpty(overlay)) {
            return new Transformation().crop("fill").height(1280).effect("grayscale").aspectRatio(1,1)
                    .chain().overlay(overlay).height(0.5).gravity("center").color("white").x(0.2).y(0.2).flags("relative");
        } else {
            return transformation;
        }
    }


    public Content uploadImages(@Nonnull String publicId, @Nonnull String imageBase64, @Nonnull String folder)
            throws IOException {

        // We are accepting both base64 formats now: URI format and binary formats.
        // If there is no prefix, assume jpg base64 (this is the legacy behaviour)
        if (!imageBase64.startsWith(BASE64_URI_PREFIX)) {
            imageBase64 = BASE64_JPG_URI_PREFIX + imageBase64;
            
        // If prefix is present, it must be base64 jpg
        } else if (!imageBase64.startsWith(BASE64_JPG_URI_PREFIX)) {
            throw new IOException("Invalid image format. Expected " + BASE64_JPG_URI_PREFIX);
        }

        String cleanFolder = cloudinaryConfiguration.getRootFolder() + "/" + cleanDirectorySlashes(folder, false);

        Map config =
                ImmutableMap.of(
                        "resource_type", "image",
                        "public_id", publicId,
                        "folder", cleanFolder,
                        "format", "jpg",
                        "use_filename", "true");


        Map r = cloudinary.uploader().upload(imageBase64, config);

        URL url = toUrl(r.get("url").toString());
        String newPublicId = r.get("public_id").toString();

        return new Content(url, newPublicId);
    }

    public void deleteImage(@Nonnull String publicId, @Nonnull String folder) throws IOException {
        String cleanFolder = cloudinaryConfiguration.getRootFolder() + "/" + cleanDirectorySlashes(folder, false);
        String completePublicId = cleanFolder + "/" + publicId;

        cloudinary.uploader().destroy(completePublicId, ObjectUtils.emptyMap());
    }


    @Data
    public static class Content {
        @Nonnull
        public URL url;

        @Nonnull
        public String publicId;
    }

    private static String cleanDirectorySlashes(String folder, boolean isAbsolute) {
        String fixFolder = folder.replaceFirst("/$", "");

        if (isAbsolute) {
            return folder.startsWith("/") ? fixFolder : "/" + fixFolder;
        }

        return fixFolder.replaceFirst("^/", "");
    }

    private static URL toUrl(String url)  {
        try {
            return new URL(url);
        } catch (MalformedURLException e) {
            throw new IllegalStateException(e);
        }
    }

}

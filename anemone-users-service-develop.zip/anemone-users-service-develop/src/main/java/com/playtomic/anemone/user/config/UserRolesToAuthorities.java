package com.playtomic.anemone.user.config;

import com.playtomic.anemone.domain.user.UserRole;
import com.playtomic.anemone.spring.security.MapAnemoneRoleToAuthorities;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Component;

@Component
public class UserRolesToAuthorities extends MapAnemoneRoleToAuthorities {

    /**
     * This is an authority to detect when a user might be able to read the user profile of another user.
     * That only happens with tenant and activity managers. The owner of the user, admin or anemone always can.
     */
    final public static GrantedAuthority MIGHT_READ_OTHERS_PRIVATE_PROFILE = new SimpleGrantedAuthority("might_read_others_private_profile");


    public UserRolesToAuthorities() {
        super(true);

        r(UserRole.ROLE_CUSTOMER.getGa(), "read_private_profile", "write_private_profile", "delete_private_profile", "write_contact_data", "read_linked_accounts", "write_linked_accounts");

        r(UserRole.ROLE_TENANT_MANAGER.getGa(),
            "create_customers",
            "read_linked_accounts", "write_linked_accounts",
            "read_tenant_tags", "write_tenant_tags",
            "read_contact_data",
            "read_user_roles", "write_user_roles",
            "read_user_permissions", "write_user_permissions",
            "search_by_name",
            "read_private_profile",
            "read_coach_accounts", "write_coach_accounts",
            "read_user_imports", "write_user_imports",
            "read_categories", "write_categories",
            "export_customer_data",
            MIGHT_READ_OTHERS_PRIVATE_PROFILE.getAuthority()
        );

        r(UserRole.ROLE_ACTIVITY_MANAGER.getGa(),
            "create_customers",
            "read_linked_accounts", "write_linked_accounts",
            "read_tenant_tags", "write_tenant_tags",
            "read_contact_data",
            "read_user_roles", "write_user_roles",
            "search_by_name",
            "read_private_profile",
            MIGHT_READ_OTHERS_PRIVATE_PROFILE.getAuthority()
        );

        // sgmoratilla: admin_users should be removed from this role at some point.
        r(UserRole.ROLE_SUPPORT.getGa(), "admin_users",
            "read_private_profile", "write_private_profile",
            "write_verification_data",
            "read_linked_accounts",
            "write_user_roles",
            "search_by_name",
            "create_tenant_managers",
            "impersonate",
            MIGHT_READ_OTHERS_PRIVATE_PROFILE.getAuthority()
        );

        r(UserRole.ROLE_ANEMONE.getGa(), "admin_users");
        r(UserRole.ROLE_ADMIN.getGa(), "admin_users");
    }
}

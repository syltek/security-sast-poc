package com.playtomic.anemone.user.service.anemone;

import com.fasterxml.jackson.annotation.JsonProperty;
import javax.annotation.Nonnull;
import lombok.AllArgsConstructor;


@AllArgsConstructor
public class DeleteMembershipSubscriptionBody {

    @Nonnull
    @JsonProperty("user_id")
    private String userId;

    @Nonnull
    @JsonProperty("membership_product_id")
    private String membershipProductId;

}
package com.playtomic.anemone.user.model.permissions;

import java.util.Map;

public class DashboardPermissionsToAuthorities extends PermissionsToAuthorities {

    private static final Map<PermissionLevel, String[]> authorities = Map.ofEntries(
            e(PermissionLevel.READ_ONLY),
            e(PermissionLevel.READ_WRITE)
    );

    public DashboardPermissionsToAuthorities() {
        super(authorities);
    }

}

package com.playtomic.anemone.user.model.permissions;

/**
 * Represent the list of permissions used in Manager 2.0
 */
public enum PermissionName {
    SCHEDULE_PERMISSION,
    DASHBOARD_PERMISSION,
    MATCHES_PERMISSION,
    CHATS_PERMISSION,
    TOURNAMENTS_PERMISSION,
    LESSONS_PERMISSION,
    BILLING_PERMISSION,
    CUSTOMER_LIST_PERMISSION,
    EXPORT_CUSTOMER_PERMISSION,
    CUSTOMER_RECURRING_RESERVATIONS_PERMISSION,
    CUSTOMER_BENEFITS_PERMISSION,
    CUSTOMER_CATEGORIES_PERMISSION,
    // todo remove it after removing it from db
    ANEMONE_CATEGORIES_PERMISSIONS,
    INVOICES_PERMISSION,
    COACHES_PERMISSION,
    SETTINGS_PERMISSION,
    LEAGUES_PERMISSION,
    PREMIUM_PERMISSION,
    ANEMONE_WALLETS_PERMISSION;

    public boolean isActivatedBySubscription() {
        switch (this) {
            case INVOICES_PERMISSION:
            case COACHES_PERMISSION:
            case LEAGUES_PERMISSION:
            case PREMIUM_PERMISSION:
            case ANEMONE_WALLETS_PERMISSION:
            case CUSTOMER_CATEGORIES_PERMISSION:
                return true;
            default:
                return false;
        }
    }
}

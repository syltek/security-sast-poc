package com.playtomic.anemone.user.api.v3;

import com.google.common.collect.ImmutableMap;
import com.playtomic.anemone.Constants;
import com.playtomic.anemone.domain.Email;
import com.playtomic.anemone.domain.EmailValidator;
import com.playtomic.anemone.domain.user.AnonymousUser;
import com.playtomic.anemone.domain.user.UserId;
import com.playtomic.anemone.jwt.InvalidJwtToken;
import com.playtomic.anemone.jwt.JwtExpiredTokenException;
import com.playtomic.anemone.service.AbstractRestController;
import com.playtomic.anemone.user.api.request.ImpersonateRequestBody;
import com.playtomic.anemone.user.api.request.LoginRequestBody;
import com.playtomic.anemone.user.api.request.PasswordResetRequestBody;
import com.playtomic.anemone.user.api.request.PasswordSendRequestBody;
import com.playtomic.anemone.user.api.request.RefreshTokenRequestBody;
import com.playtomic.anemone.user.api.request.RegisterRequestBody;
import com.playtomic.anemone.user.api.request.ValidateEmailRequestBody;
import com.playtomic.anemone.user.api.response.RequestPasswordResetResponseBody;
import com.playtomic.anemone.user.api.response.RequestPasswordResetResponseBody.RequestPasswordResetResponseStatus;
import com.playtomic.anemone.user.config.SecurityConfig;
import com.playtomic.anemone.user.domain.CountryCodeValidator;
import com.playtomic.anemone.user.domain.PhoneValidator;
import com.playtomic.anemone.user.domain.UserProfile;
import com.playtomic.anemone.user.model.LoginAuthTokens;
import com.playtomic.anemone.user.service.AuthenticationService;
import com.playtomic.anemone.user.service.UserCredentialService;
import com.playtomic.anemone.user.service.UserService;
import com.playtomic.anemone.user.service.apple.AppleService;
import com.playtomic.anemone.user.service.apple.AppleUserData;
import com.playtomic.anemone.user.service.apple.exception.InvalidAppleTokenException;
import com.playtomic.anemone.user.service.exception.InvalidCountryCodeException;
import com.playtomic.anemone.user.service.exception.InvalidEmailException;
import com.playtomic.anemone.user.service.exception.InvalidEmailTokenException;
import com.playtomic.anemone.user.service.exception.InvalidPasswordException;
import com.playtomic.anemone.user.service.exception.InvalidPhoneException;
import com.playtomic.anemone.user.service.exception.PhoneNotAvailableException;
import com.playtomic.anemone.user.service.exception.UserNotFoundException;
import com.playtomic.anemone.user.service.facebook.FacebookService;
import com.playtomic.anemone.user.service.facebook.FacebookUserData;
import com.playtomic.anemone.user.service.facebook.exception.InvalidFacebookTokenException;
import com.playtomic.anemone.user.service.google.GoogleService;
import com.playtomic.anemone.user.service.google.GoogleUserData;
import com.playtomic.anemone.user.service.google.exception.InvalidGoogleTokenException;
import java.util.Collections;
import java.util.Map;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * Authentication is performed via Filters and Spring Security modules. <p> This controller is intended to check whether
 * the user is authorized or not, which roles are assigned, when the session expires...
 * @see SecurityConfig
 */
@RestController
@RequestMapping(path = "/v3/auth")
@Slf4j
public class AuthenticationControllerV3 extends AbstractRestController {

    @Nonnull
    private UserService userService;

    @Nonnull
    private UserCredentialService userCredentialService;

    @Nonnull
    private AuthenticationService authenticationService;

    @Nonnull
    private FacebookService facebookService;

    @Nonnull
    private GoogleService googleService;

    @Nonnull
    private AppleService appleService;

    public AuthenticationControllerV3(@Nonnull MessageSource messageSource,
                                      @Nonnull DiscoveryClient discoveryClient,
                                      @Nonnull UserService userService,
                                      @Nonnull UserCredentialService userCredentialService,
                                      @Nonnull AuthenticationService authenticationService,
                                      @Nonnull FacebookService facebookService,
                                      @Nonnull GoogleService googleService,
                                      @Nonnull AppleService appleService) {
        super(messageSource, discoveryClient);
        this.userService = userService;
        this.userCredentialService = userCredentialService;
        this.authenticationService = authenticationService;
        this.facebookService = facebookService;
        this.googleService = googleService;
        this.appleService = appleService;
    }

    @RequestMapping(path = "/login", method = RequestMethod.POST, consumes = Constants.CONSUMES_JSON)
    public ResponseEntity login(@RequestBody LoginRequestBody body)
            throws InvalidEmailException, PhoneNotAvailableException {
        return this.loginLogic(body);
    }

    @RequestMapping(path = "/login", method = RequestMethod.DELETE)
    public ResponseEntity logoutSuccessfulResult() {
        UserId userId = getCurrentUser().getId();
        authenticationService.logout(userId);
        return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
    }

    @RequestMapping(path = "/token", method = RequestMethod.POST, consumes = Constants.CONSUMES_JSON)
    public ResponseEntity refreshAuth(@RequestBody RefreshTokenRequestBody body) {
        try {
            LoginAuthTokens tokens = authenticationService.login(body.refreshToken);
            return createLoginResponse(tokens);
        } catch (UserNotFoundException | InvalidJwtToken | JwtExpiredTokenException e) {
            return getErrorResponse(ErrorCodes.USER_NOT_FOUND, "AuthenticationService.Login.InvalidToken",
                    HttpStatus.UNAUTHORIZED);
        }
    }

    @PreAuthorize("hasAnyAuthority('admin_users', 'impersonate')")
    @RequestMapping(path = "/impersonation", method = RequestMethod.POST, consumes = Constants.CONSUMES_JSON)
    public ResponseEntity impersonate(@RequestBody ImpersonateRequestBody body) {
        try {
            LoginAuthTokens tokens = authenticationService.login(body.getUserId());
            return createLoginResponse(tokens);
        } catch (UserNotFoundException | JwtExpiredTokenException e) {
            return getErrorResponse(ErrorCodes.USER_NOT_FOUND, "AuthenticationService.Login.InvalidToken", HttpStatus.UNAUTHORIZED);
        }
    }

    @RequestMapping(path = "/register", method = RequestMethod.POST, consumes = Constants.CONSUMES_JSON)
    public ResponseEntity register(@RequestBody RegisterRequestBody body) {
        String authenticatedUserId = getCurrentUser() instanceof AnonymousUser ? null : getCurrentUser().getId().getValue();
        return this.registerLogic(body, true, authenticatedUserId);
    }


    // From version 2.15.0 clients are using v2/users/me with an email token to validate, but it's still used on web
    @Deprecated
    @RequestMapping(path = "/validate", method = RequestMethod.PUT, consumes = Constants.CONSUMES_JSON)
    public ResponseEntity validateUser(@RequestBody ValidateEmailRequestBody body) {
        log.info("Validating user {}:", body.email);

        try {
            userCredentialService.verifyEmailToken(body.validateToken);
        } catch (UserNotFoundException ex) {
            log.info("Validating user failed {}:", body.email, ex);
            // Do not provide information if email exists or not, just fail with invalid token in any case
            throw new InvalidEmailTokenException(ex);
        }
        return ResponseEntity.ok().build();
    }

    @RequestMapping(path = "/password/request", method = RequestMethod.POST, consumes = Constants.CONSUMES_JSON)
    public ResponseEntity requestPasswordReset(@RequestBody PasswordSendRequestBody body) {
        try {
            userCredentialService.requestPasswordReset(body.email, body.isNewUser, body.source);
        } catch (UserNotFoundException e) {
            // We are logging the fail, but we are NOT notifying the client due to security reasons.
            log.info("Requesting user-password reset for non existing email: {}", body.email);
        }

        RequestPasswordResetResponseStatus status =
                RequestPasswordResetResponseBody.RequestPasswordResetResponseStatus.SENT;

        String message = getMessage(status.toString(), LocaleContextHolder.getLocale());

        return new ResponseEntity<>(new RequestPasswordResetResponseBody(status, message), HttpStatus.OK);
    }

    @RequestMapping(path = "/password/reset", method = RequestMethod.POST, consumes = Constants.CONSUMES_JSON)
    public ResponseEntity resetPassword(@RequestBody PasswordResetRequestBody body) {
        log.info("Resetting password for {}:", body.email);
        try {
            UserProfile user = userService.getUserByEmailCheckingTags(body.email);
            userCredentialService.resetPassword(body.email, body.resetToken, body.password);
            return createNewSessionResponse(user.getId());
        } catch (Exception e) {
            log.info("Invalid try of password reset for {}:", body.email, e);
            return getErrorResponse(ErrorCodes.TOKEN_NOT_FOUND,
                    "AuthenticationService.ResetPassword.SecurityTokenNotFound", HttpStatus.NOT_FOUND);
        }
    }

    public ResponseEntity loginLogic(@Nonnull LoginRequestBody body) {
        try {
            if (body.facebookToken != null) {
                FacebookUserData facebookUserData = facebookService.getUserData(body.facebookToken);
                log.info("Trying to log facebook user {}", facebookUserData);
                return createLoginResponse(authenticationService.loginWithFacebook(facebookUserData));
            } else if (body.googleToken != null) {
                GoogleUserData googleUserData = googleService.getUserData(body.googleToken);
                log.info("Trying to log google user {}", googleUserData);
                return createLoginResponse(authenticationService.loginWithGoogle(googleUserData));
            } else if (body.appleToken != null) {
                AppleUserData appleUserData = appleService.getUserData(body.appleToken);
                log.info("Trying to log apple user {}", appleUserData);
                return createLoginResponse(authenticationService.loginWithApple(appleUserData));
            } else if (body.email != null && body.password != null) {
                try {
                    return createLoginResponse(authenticationService.login(body.email, body.password));
                } catch (UserNotFoundException ex) {
                    // In case of email, convert user not found into invalid password to not reveal existing emails
                    throw new InvalidPasswordException();
                }
            } else {
                return ResponseEntity.badRequest().build();
            }
        } catch (InvalidFacebookTokenException e) {
            return getErrorResponse(ErrorCodes.INVALID_FACEBOOK_TOKEN, "AuthenticationService.Login.InvalidFacebookToken",
                    HttpStatus.UNAUTHORIZED);
        } catch (InvalidGoogleTokenException e) {
            return getErrorResponse(ErrorCodes.INVALID_GOOGLE_TOKEN, "AuthenticationService.Login.InvalidGoogleToken",
                    HttpStatus.UNAUTHORIZED);
        } catch (InvalidAppleTokenException e) {
            return getErrorResponse(ErrorCodes.INVALID_APPLE_TOKEN, "AuthenticationService.Login.InvalidAppleToken",
                    HttpStatus.UNAUTHORIZED);
        } catch (InvalidPasswordException e) {
            return getErrorResponse(ErrorCodes.INVALID_PASSWORD, "AuthenticationService.Login.InvalidPassword",
                    HttpStatus.UNAUTHORIZED);
        } catch (UserNotFoundException e) {
            return ResponseEntity.unprocessableEntity().build();
        }
    }

    @Nonnull
    public ResponseEntity registerLogic(@Nonnull RegisterRequestBody body, boolean registerWithWelcomeVoucher, @Nullable String createdBy) {
        // Check one of the mandatory fields to create an account is present
        if (body.password == null && body.facebookToken == null && body.googleToken == null && body.appleToken == null) {
            return getErrorResponse(ErrorCodes.INVALID_PASSWORD,
                "AuthenticationService.Register.InvalidPassword", HttpStatus.BAD_REQUEST);
        }

        // Check common validations (phone and country code)
        if (!StringUtils.isEmpty(body.phone)) {
            body.phone = PhoneValidator.formattedPhone(body.phone, null)
                    .orElseThrow(() -> new InvalidPhoneException(body.phone));
        }

        if (!CountryCodeValidator.isValid(body.countryCode)) {
            throw new InvalidCountryCodeException();
        }

        UserProfile user;
        // 1. Facebook Registration
        if (body.facebookToken != null) {
            FacebookUserData facebookUserData = facebookService.getUserData(body.facebookToken);
            log.info("Trying to register user {}", facebookUserData);
            user = userService
                .registerFacebookUser(facebookUserData, body.phone, body.countryCode, body.acceptsPrivacy,
                    body.acceptsCommercial, registerWithWelcomeVoucher, createdBy);
        }
        // 2. Google Registration
        else if (body.googleToken != null) {
            GoogleUserData googleUserData = googleService.getUserData(body.googleToken);
            log.info("Trying to register user {}", googleUserData);
            user = userService.registerGoogleUser(googleUserData, body.phone, body.countryCode, body.acceptsPrivacy,
                body.acceptsCommercial, registerWithWelcomeVoucher, createdBy);
        }
        // 3. Apple Registration
        else if (body.appleToken != null) {
            AppleUserData appleUserData = appleService.getUserData(body.appleToken);
            // In some cases the token might not contain an email. Add the email if provided with the registration but make sure it is not validated (provided by user)
            if (appleUserData.getEmail() == null && body.email != null) {
                appleUserData.setEmail(Email.of(body.email).orElse(null));
                appleUserData.setVerified(false);
            }
            log.info("Trying to register user {}", appleUserData);
            user = userService.registerAppleUser(appleUserData, body.name, body.phone, body.countryCode, body.acceptsPrivacy,
                body.acceptsCommercial, registerWithWelcomeVoucher, createdBy);
        }
        // 4. Email+Password Registration
        else {
            if (!EmailValidator.isValid(body.email)) {
                throw new InvalidEmailException();
            }

            user = userService.registerEmailUser(new Email(body.email.toLowerCase()), body.password,
                body.name, body.phone, body.acceptsPrivacy, body.acceptsCommercial, body.countryCode, body.address,
                registerWithWelcomeVoucher, body.communicationsLanguage, createdBy, null, Collections.emptyList());
        }

        // If phone token provided, try to optionally verify (not required and no error if invalid). Note that as
        // side effect, this update can nullify other people phone numbers if duplicated
        if (body.phoneToken != null) {
            try {
                userService.updateCustomer(user.getId(), null, null, null, null, null,
                        body.phoneToken, null, null, null, null, null, null,
                        null, null, null, null, null);
            } catch(Throwable t) {
                log.info("Invalid phone token during registration");
            }
        }

        return createNewSessionResponse(user.getId());
    }

    private ResponseEntity createLoginResponse(@Nonnull LoginAuthTokens authTokens) {
        Map<String, Object> body = ImmutableMap.of(
                "access_token",
                authTokens.getAccessToken().getToken(),
                "access_token_expiration",
                authTokens.getAccessTokenExpiration(),
                "refresh_token",
                authTokens.getRefreshToken().getToken(),
                "refresh_token_expiration",
                authTokens.getRefreshTokenExpiration(),
                "user_id",
                authTokens.getUserId().getValue());

        return new ResponseEntity<>(body, HttpStatus.OK);
    }

    private ResponseEntity createNewSessionResponse(@Nonnull UserId userId) throws UserNotFoundException {
        LoginAuthTokens login = authenticationService.login(userId);
        return createLoginResponse(login);
    }

    protected enum ErrorCodes {
        TOKEN_NOT_FOUND,
        USER_NOT_FOUND,
        INVALID_EMAIL,
        INVALID_FACEBOOK_TOKEN,
        INVALID_GOOGLE_TOKEN,
        INVALID_APPLE_TOKEN,
        INVALID_PASSWORD
    }
}

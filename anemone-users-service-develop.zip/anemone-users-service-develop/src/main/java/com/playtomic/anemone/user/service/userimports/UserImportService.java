package com.playtomic.anemone.user.service.userimports;

import com.playtomic.anemone.domain.user.User;
import com.playtomic.anemone.service.AbstractLocalizableService;
import com.playtomic.anemone.spring.config.AnemoneUserPrincipal;
import com.playtomic.anemone.user.config.UserImportConfiguration;
import com.playtomic.anemone.user.dao.userimports.UserImportRepository;
import com.playtomic.anemone.user.domain.tenant.Tenant;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import com.playtomic.anemone.user.domain.userimports.UserImport;
import com.playtomic.anemone.user.domain.userimports.UserImportDataRow;
import com.playtomic.anemone.user.domain.userimports.UserImportId;
import com.playtomic.anemone.user.domain.userimports.UserImportStatus;
import com.playtomic.anemone.user.service.anemone.TenantCommunicationSettings;
import com.playtomic.anemone.user.service.anemone.TenantServiceClient;
import com.playtomic.anemone.user.service.exception.TenantNotFoundException;
import com.playtomic.anemone.user.service.exception.UserImportAlreadyStoppedException;
import com.playtomic.anemone.user.service.exception.UserImportEmptyFileException;
import com.playtomic.anemone.user.service.exception.UserImportFileInvalidFormatException;
import com.playtomic.anemone.user.service.exception.UserImportMismatchException;
import com.playtomic.anemone.user.service.exception.UserImportTooFewColumnsInRecordException;
import com.playtomic.anemone.user.service.exception.UserImportTooManyRowsException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.validation.ClockProvider;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.context.MessageSource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import org.springframework.web.multipart.MultipartFile;

@Slf4j
@Service
public class UserImportService extends AbstractLocalizableService {

    @Nonnull
    private final ClockProvider clockProvider;

    @Nonnull
    private final UserImportProcessorServiceComponent userImportProcessor;

    @Nonnull
    private final UserImportServicePersistenceComponent userImportServicePersistenceComponent;

    @Nonnull
    private final UserImportRepository userImportRepository;

    @Nonnull
    private final TenantServiceClient tenantServiceClient;

    @Value("${users.import.max-rows-number}")
    private int maxRowsNumber;

    public UserImportService(@Nonnull MessageSource messageSource,
                             @Nonnull DiscoveryClient discoveryClient,
                             @Nonnull ClockProvider clockProvider,
                             @Nonnull UserImportProcessorServiceComponent userImportProcessor,
                             @Nonnull UserImportServicePersistenceComponent userImportServicePersistenceComponent,
                             @Nonnull UserImportRepository userImportRepository,
                             @Nonnull TenantServiceClient tenantServiceClient) {
        super(messageSource, discoveryClient);
        this.clockProvider = clockProvider;
        this.userImportProcessor = userImportProcessor;
        this.userImportServicePersistenceComponent = userImportServicePersistenceComponent;
        this.userImportRepository = userImportRepository;
        this.tenantServiceClient = tenantServiceClient;
    }

    @Nonnull
    public UserImport createUserImport(@Nonnull String name,
                                       @Nonnull TenantId tenantId,
                                       @Nonnull MultipartFile file,
                                       @Nullable Map<String, String> customMapping)
        throws IOException, TenantNotFoundException {

        Tenant tenant = safeGetTenant(tenantId);
        String welcomeMessage = tenantServiceClient.getTenantCommunicationSettings(tenantId)
            .map(TenantCommunicationSettings::getWelcomeMessage)
            .orElse(null);

        // Extract rows from file
        List<UserImportDataRow> userImportDataRows = readFile(file, tenant, welcomeMessage, customMapping);

        // Create user import entity as basis for processing
        UserImport userImport = userImportServicePersistenceComponent.createUserImport(name, tenantId, userImportDataRows.size());

        // Validate format, save errors and send events for asynchronous processing
        userImportProcessor.validateAndPrepareProcessing(userImport.getId(), userImportDataRows);

        return userImport;
    }

    @Nonnull
    public UserImport getUserImportById(@Nonnull UserImportId userImportId) {
        UserImport userImport = userImportServicePersistenceComponent.getUserImportById(userImportId);

        return checkAndExpireBlockedImport(userImport);
    }

    // Note: if the API filtering needs grow, this should be enabled using a filter
    @Nonnull
    public Page<UserImport> searchUserImports(@Nullable TenantId tenantId, @Nonnull Pageable pageable) {
        Page<UserImport> foundUserImports = tenantId != null ?
            userImportRepository.findUserImportByTenantId(tenantId, pageable) :
            userImportRepository.findAll(pageable);

        return checkAndExpireBlockedImports(foundUserImports);
    }

    @Nonnull
    public UserImport stopImport(@Nonnull UserImportId userImportId) {
        UserImport userImport = userImportServicePersistenceComponent.getUserImportById(userImportId);

        if (!userImport.getStatus().equals(UserImportStatus.PROCESSING)) {
            throw new UserImportAlreadyStoppedException();
        }
        return userImportServicePersistenceComponent.updateUserImportStatus(userImportId, UserImportStatus.MANUAL_STOP);
    }

    @Nonnull
    public byte[] generateErrorsCSV(@Nonnull UserImportId userImportId) {

        UserImport userImport = this.getUserImportById(userImportId);

        List<String> fileLines = new ArrayList<>();

        // Prepare header
        List<String> headerValues = new ArrayList<>(UserImportConfiguration.HEADERS);
        headerValues.add("error");
        String fileHeader = String.join(String.valueOf(UserImportConfiguration.DELIMITER), headerValues);
        fileLines.add(fileHeader + "\n");

        // Add error lines
        for (var error : userImport.getErrorDetails()) {
            fileLines.add(error.generateCSVLine());
        }

        // Write output file
        StringBuilder sb = new StringBuilder();
        fileLines.forEach(sb::append);
        return sb.toString().getBytes(StandardCharsets.UTF_8);
    }

    @Nonnull
    private Tenant safeGetTenant(@Nonnull TenantId tenantId) throws TenantNotFoundException {
        Tenant tenant = tenantServiceClient.getById(tenantId.getValue());
        Assert.isTrue(tenant.isAnemone(), "Imports are only supported for ANEMONE tenants");

        //Product requested to allow non active clubs to import users so the on-boarding new clubs is more efficient. This if statement used to throw an exception.
        if (!"FINISHED".equals(tenant.getOnboardingStatus()) || !tenant.isActive()) {
            log.warn("Tenant with ID:{}, PLAYTOMIC_STATUS: {} and ONBOARDING_STATUS: {} is importing users", tenantId,
                tenant.getPlaytomicStatus(), tenant.getOnboardingStatus());
        }

        return tenant;
    }

    @Nonnull
    private List<UserImportDataRow> readFile(@Nonnull MultipartFile file,
                                             @Nonnull Tenant tenant,
                                             @Nullable String welcomeMessage,
                                             @Nullable Map<String, String> customMapping) throws IOException {
        Reader reader = new InputStreamReader(file.getInputStream());
        CSVParser parser = new CSVParser(reader, UserImportConfiguration.CSV_FORMAT);

        String nameHeader;
        String emailHeader;
        String phoneNumberHeader;
        String genderHeader;
        String birthDateHeader;
        String categoryNameHeader;
        String categoryExpiresAtHeader;

        // Check file format is correct
        List<String> fileHeaders = parser.getHeaderNames();
        boolean fileHasAllHeaders = fileHeaders.containsAll(UserImportConfiguration.HEADERS);

        if (fileHasAllHeaders) {
            // Initialize Headers to file headers
            nameHeader = UserImportConfiguration.HEADERS.get(0);
            emailHeader = UserImportConfiguration.HEADERS.get(1);
            phoneNumberHeader = UserImportConfiguration.HEADERS.get(2);
            genderHeader = UserImportConfiguration.HEADERS.get(3);
            birthDateHeader = UserImportConfiguration.HEADERS.get(4);
            categoryNameHeader = UserImportConfiguration.HEADERS.get(5);
            categoryExpiresAtHeader = UserImportConfiguration.HEADERS.get(6);
        } else {
            // Calculate missing headers
            List<String> missingHeaders = UserImportConfiguration.HEADERS.stream()
                .filter(header -> !fileHeaders.contains(header))
                .collect(Collectors.toList());

            if (customMapping == null || !customMapping.keySet().containsAll(missingHeaders)) {
                // Calculate extra headers
                List<String> extraHeaders = new ArrayList<>(fileHeaders);
                extraHeaders.removeAll(UserImportConfiguration.HEADERS);

                throw new UserImportMismatchException(missingHeaders, extraHeaders, "There are some missing fields in the uploaded file");
            }

            // Initialize Headers to file headers if they match expected, set mapped value otherwise
            nameHeader = fileHeaders.contains(UserImportConfiguration.HEADERS.get(0)) ?
                UserImportConfiguration.HEADERS.get(0) :
                customMapping.get(UserImportConfiguration.HEADERS.get(0));

            emailHeader = fileHeaders.contains(UserImportConfiguration.HEADERS.get(1)) ?
                UserImportConfiguration.HEADERS.get(1) :
                customMapping.get(UserImportConfiguration.HEADERS.get(1));

            phoneNumberHeader = fileHeaders.contains(UserImportConfiguration.HEADERS.get(2)) ?
                UserImportConfiguration.HEADERS.get(2) :
                customMapping.get(UserImportConfiguration.HEADERS.get(2));

            genderHeader = fileHeaders.contains(UserImportConfiguration.HEADERS.get(3)) ?
                UserImportConfiguration.HEADERS.get(3) :
                customMapping.get(UserImportConfiguration.HEADERS.get(3));

            birthDateHeader = fileHeaders.contains(UserImportConfiguration.HEADERS.get(4)) ?
                UserImportConfiguration.HEADERS.get(4) :
                customMapping.get(UserImportConfiguration.HEADERS.get(4));

            categoryNameHeader = fileHeaders.contains(UserImportConfiguration.HEADERS.get(5)) ?
                UserImportConfiguration.HEADERS.get(5) :
                customMapping.get(UserImportConfiguration.HEADERS.get(5));

            categoryExpiresAtHeader = fileHeaders.contains(UserImportConfiguration.HEADERS.get(6)) ?
                UserImportConfiguration.HEADERS.get(6) :
                customMapping.get(UserImportConfiguration.HEADERS.get(6));
        }

        return readRows(parser, nameHeader, emailHeader, phoneNumberHeader, genderHeader, birthDateHeader, categoryNameHeader, categoryExpiresAtHeader, tenant, welcomeMessage);
    }

    @Nonnull
    private List<UserImportDataRow> readRows(@Nonnull CSVParser parser,
        @Nonnull String nameHeader,
        @Nonnull String emailHeader,
        @Nonnull String phoneNumberHeader,
        @Nonnull String genderHeader,
        @Nonnull String birthDateHeader,
        @Nullable String categoryNameHeader,
        @Nullable String categoryExpiresAtHeader,
        @Nonnull Tenant tenant,
        @Nullable String welcomeMessage) throws IOException {
        User user = ((AnemoneUserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getUser();
        List<CSVRecord> records = parser.getRecords();

        if (records.size() > maxRowsNumber) {
            throw new UserImportTooManyRowsException();
        }

        List<UserImportDataRow> rows = new ArrayList<>();
        try {
            for (CSVRecord record : records) {
                if (record.size() < UserImportConfiguration.EXPECTED_COLUMNS_COUNT) {
                    throw new UserImportTooFewColumnsInRecordException(record.getRecordNumber(), UserImportConfiguration.EXPECTED_COLUMNS_COUNT, record.size());
                }
                rows.add(
                    UserImportDataRow.builder()
                        .name(record.get(nameHeader))
                        .email(record.get(emailHeader))
                        .phoneNumber(record.get(phoneNumberHeader))
                        .gender(record.get(genderHeader))
                        .birthDate(record.get(birthDateHeader))
                        .categoryName(record.get(categoryNameHeader))
                        .categoryExpiresAt(record.get(categoryExpiresAtHeader))
                        .tenant(tenant)
                        .welcomeMessage(welcomeMessage)
                        .createdBy(user.getId().getValue())
                        .build()
                );

            }
        } catch (IllegalArgumentException ex) {
            log.error("Invalid csv file format ", ex);
            throw new UserImportFileInvalidFormatException();
        }

        if (rows.isEmpty()) {
            throw new UserImportEmptyFileException();
        }

        return rows;
    }

    @Nonnull
    private UserImport checkAndExpireBlockedImport(@Nonnull UserImport userImport) {
        boolean importHasExpired = userImport.getStatus().equals(UserImportStatus.PROCESSING) &&
            userImport.getLastModified().plus(Duration.ofSeconds(UserImportConfiguration.FAILED_THRESHOLD_SECONDS))
                .isBefore(Instant.now(clockProvider.getClock()));

        return importHasExpired ?
            userImportServicePersistenceComponent.updateUserImportStatus(userImport.getId(), UserImportStatus.TIMEOUT_FAILED) :
            userImport;
    }

    @Nonnull
    private Page<UserImport> checkAndExpireBlockedImports(@Nonnull Page<UserImport> userImports) {
        List<UserImport> updatedUserImports = userImports.stream().peek(this::checkAndExpireBlockedImport).collect(Collectors.toList());
        return new PageImpl<>(updatedUserImports, userImports.getPageable(), userImports.getTotalElements());
    }

}

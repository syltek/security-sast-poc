package com.playtomic.anemone.user.service.exception;

import com.playtomic.anemone.domain.user.UserId;
import javax.annotation.Nonnull;

public class UserNotValidatedException extends RuntimeException {

    public UserNotValidatedException(@Nonnull UserId id) {
        super(String.format("User with id=%s is not validated", id));
    }

}

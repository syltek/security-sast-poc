package com.playtomic.anemone.user.service.exception;

import javax.annotation.Nonnull;

public class InvalidPhoneTokenException extends RuntimeException {

    public InvalidPhoneTokenException() {
    }

    public InvalidPhoneTokenException(@Nonnull Throwable cause) {
        super(cause);
    }
}

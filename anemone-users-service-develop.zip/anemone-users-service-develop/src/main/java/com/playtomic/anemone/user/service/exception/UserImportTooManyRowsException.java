package com.playtomic.anemone.user.service.exception;

public class UserImportTooManyRowsException extends RuntimeException {

}

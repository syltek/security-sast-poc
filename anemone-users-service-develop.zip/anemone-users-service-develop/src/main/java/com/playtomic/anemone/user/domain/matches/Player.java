package com.playtomic.anemone.user.domain.matches;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.domain.user.UserId;
import com.playtomic.anemone.user.domain.reservation.MerchantUserId;
import lombok.Data;

import javax.annotation.Nullable;

@Data
public class Player {

    @Nullable
    private UserId userId;

    @Nullable
    private MerchantUserId merchantPlayerId;

    @Nullable
    private String contactId;

    @JsonCreator
    public Player(@JsonProperty("user_id") @Nullable UserId userId,
                  @JsonProperty("merchant_player_id") @Nullable MerchantUserId merchantPlayerId,
                  @JsonProperty("contact_id") @Nullable String contactId) {
        this.userId = userId;
        this.merchantPlayerId = merchantPlayerId;
        this.contactId = contactId;
    }
}

package com.playtomic.anemone.user.domain.userimports;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.dao.BaseDocument;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import lombok.Builder;
import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.persistence.Id;

@Data
@Builder
@Document("user_imports")
public class UserImport extends BaseDocument {

    @Id
    @Nonnull
    @JsonProperty(value = "user_import_id")
    private UserImportId id;

    @Nonnull
    @JsonProperty(value = "name")
    @Field("name")
    private String name;

    @Nonnull
    @Indexed
    @JsonProperty(value = "tenant_id")
    @Field("tenant_id")
    private TenantId tenantId;

    @Nonnull
    @JsonProperty(value = "status")
    @Field("status")
    private UserImportStatus status;

    @Nonnull
    @JsonProperty(value = "error_details")
    @Field("error_details")
    @Builder.Default
    private List<UserImportError> errorDetails = new ArrayList<>();

    @Field("total_file_rows")
    @Builder.Default
    private long totalFileRows = 0;

    @Field("total_errors")
    @Builder.Default
    private long totalErrors = 0;

    @Field("existing_linked_users")
    @Builder.Default
    private long existingLinkedUsers = 0;

    @Field("new_created_users")
    @Builder.Default
    private long newCreatedUsers = 0;

    @Nullable
    @Field("created_by")
    @CreatedBy
    private String createdBy;

    @Nonnull
    @JsonProperty(value = "result")
    private UserImportResult getUserImportResult() {
        long successRows = existingLinkedUsers + newCreatedUsers;
        long processedRows = successRows + totalErrors;
        return new UserImportResult(totalFileRows, processedRows, successRows, totalErrors);
    }

    @Nullable
    @JsonProperty(value = "created_at")
    private Instant getCreationDate() {
        return this.getCreatedAt();
    }

    public boolean isManuallyStopped() {
        return status.equals(UserImportStatus.MANUAL_STOP);
    }

    public boolean hasExpired() {
        return status.equals(UserImportStatus.TIMEOUT_FAILED);
    }

    public boolean isFinished() {
        return totalFileRows == existingLinkedUsers + newCreatedUsers + totalErrors;
    }
}

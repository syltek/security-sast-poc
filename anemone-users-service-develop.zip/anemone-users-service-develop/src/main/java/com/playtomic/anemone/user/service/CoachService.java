package com.playtomic.anemone.user.service;

import com.playtomic.anemone.domain.user.UserId;
import com.playtomic.anemone.user.api.v2.request.LinkCoachAccountData;
import com.playtomic.anemone.user.dao.UserEntity;
import com.playtomic.anemone.user.dao.UserRepository;
import com.playtomic.anemone.user.domain.UserProfile;
import com.playtomic.anemone.user.domain.matches.SportId;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import com.playtomic.anemone.user.model.CustomerUserProfile;
import com.playtomic.anemone.user.model.UserFilter;
import com.playtomic.anemone.user.service.messaging.MessagingBroker;
import com.playtomic.anemone.user.service.messaging.UserEvent;
import com.playtomic.anemone.user.service.messaging.UserEvent.UserEventType;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
@ParametersAreNonnullByDefault
public class CoachService {

    @Nonnull
    private final MessagingBroker messagingBroker;
    @Nonnull
    private final UserRepository userRepository;
    @Nonnull
    private final UserServicePersistenceComponent userServicePersistenceComponent;
    @Nonnull
    private final UserService userService;

    @Nonnull
    public CustomerUserProfile putCoachAccount(UserId userId, TenantId tenantId, LinkCoachAccountData data) {
        userServicePersistenceComponent.putCoachAccount(userId, tenantId, data);

        return userService.getUserById(userId);
    }

    @Nonnull
    public CustomerUserProfile deleteCoachAccount(UserId userId, TenantId tenantId) {
        UserProfile userProfile = userServicePersistenceComponent.deleteCoachAccount(userId, tenantId);
        sendUserUpdateEvent(userProfile);

        return userService.getUserById(userId);
    }

    @Nonnull
    public Page<CustomerUserProfile> searchCoaches(TenantId tenantId, @Nullable SportId sportId, @Nullable String filter, Pageable pageable) {
        Page<UserEntity> coaches = userRepository.findAll(UserFilter.getCoachesSpecification(tenantId, sportId, filter), pageable);

        return coaches.map(userServicePersistenceComponent::mapUserEntityToDomain);
    }

    private void sendUserUpdateEvent(UserProfile user) {
        messagingBroker.sendEvent(new UserEvent(UserEventType.UPDATED, user));
    }
}

package com.playtomic.anemone.user.service.messaging;

import com.playtomic.anemone.domain.user.UserId;
import com.playtomic.anemone.user.config.MessagingConfiguration.UserUpdateTenantTagsTopicInput;
import com.playtomic.anemone.user.service.TenantTagsComponent;
import javax.annotation.Nonnull;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
@Slf4j
public class UserUpdateTenantTagsProcessor {

    @Nonnull
    private final TenantTagsComponent tenantTagsComponent;


    @Nonnull
    private final UserUpdateTenantTagsCache userUpdateTenantTagsCache;

    @StreamListener(UserUpdateTenantTagsTopicInput.INPUT)
    public void handle(@Nonnull Message<UserUpdateTenantTagEvent> updateTenantTags) {
        try {
            internalHandle(updateTenantTags);
        } catch (Exception e) {
            log.error("Unhandled error when processing this message. Discarding", e);
        }
    }

    private void internalHandle(@Nonnull Message<UserUpdateTenantTagEvent> updateTenantTags) {
        UserId userId = updateTenantTags.getPayload().getUserId();

        if (userUpdateTenantTagsCache.seenTooEarly(userId)) {
            log.debug("Event to update tenant tags received too early. Skipping this update");
            return;
        }

        tenantTagsComponent.checkAndUpdateTags(userId);
        userUpdateTenantTagsCache.recordUpdated(userId);
    }

}

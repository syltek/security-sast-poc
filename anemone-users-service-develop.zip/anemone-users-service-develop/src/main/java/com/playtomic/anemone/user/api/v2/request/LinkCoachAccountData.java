package com.playtomic.anemone.user.api.v2.request;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.user.domain.matches.SportId;
import java.util.List;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Data;

@Data
public class LinkCoachAccountData {

    @Nonnull
    private List<SportId> sportIds;

    @Nullable
    private String experience;

    @Nullable
    private String ages;

    @Nullable
    private String description;

    @JsonCreator
    public LinkCoachAccountData(
        @JsonProperty(value = "sport_ids") @Nonnull List<SportId> sportIds,
        @JsonProperty(value = "experience") @Nullable String experience,
        @JsonProperty(value = "ages") @Nullable String ages,
        @JsonProperty(value = "description") @Nullable String description) {

        this.sportIds = sportIds;
        this.experience = experience;
        this.ages = ages;
        this.description = description;
    }
}

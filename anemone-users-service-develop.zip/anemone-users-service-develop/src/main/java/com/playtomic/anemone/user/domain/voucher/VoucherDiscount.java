package com.playtomic.anemone.user.domain.voucher;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.annotation.Nonnull;
import java.math.BigDecimal;

public class VoucherDiscount {
    @JsonProperty(value = "amount_off", required = true)
    private BigDecimal amountOff;

    @Nonnull
    public BigDecimal getAmountOff() {
        return amountOff;
    }
}

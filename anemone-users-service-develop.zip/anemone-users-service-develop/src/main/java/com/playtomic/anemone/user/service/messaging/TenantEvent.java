package com.playtomic.anemone.user.service.messaging;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

@ToString
@Getter
@Builder
@NoArgsConstructor
public class TenantEvent {

    // Currently not checking this value.
    @Nullable
    private String eventType;

    @Nullable
    private SimplifiedTenant tenant;

    @JsonCreator
    protected TenantEvent(
            @JsonProperty(value = "event_type") @Nullable String eventType,
            @JsonProperty(value = "event_data", required = true) @Nonnull SimplifiedTenant tenant) {
        this.eventType = eventType;
        this.tenant = tenant;
    }
}

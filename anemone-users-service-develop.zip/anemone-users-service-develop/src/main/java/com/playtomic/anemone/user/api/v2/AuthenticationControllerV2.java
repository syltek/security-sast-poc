package com.playtomic.anemone.user.api.v2;

import com.playtomic.anemone.Constants;
import com.playtomic.anemone.domain.Email;
import com.playtomic.anemone.domain.user.AnonymousUser;
import com.playtomic.anemone.http.response.StatusResponseBody;
import com.playtomic.anemone.jwt.RawAccessJwtToken;
import com.playtomic.anemone.service.AbstractRestController;
import com.playtomic.anemone.spring.config.AnemoneUserPrincipal;
import com.playtomic.anemone.user.api.request.LoginRequestBody;
import com.playtomic.anemone.user.api.request.PasswordResetRequestBody;
import com.playtomic.anemone.user.api.request.PasswordSendRequestBody;
import com.playtomic.anemone.user.api.request.RefreshTokenRequestBody;
import com.playtomic.anemone.user.api.request.RegisterRequestBody;
import com.playtomic.anemone.user.api.request.ValidateEmailRequestBody;
import com.playtomic.anemone.user.api.v3.AuthenticationControllerV3;
import com.playtomic.anemone.user.config.SecurityConfig;
import com.playtomic.anemone.user.service.AuthenticationService;
import com.playtomic.anemone.user.service.apple.exception.InvalidAppleTokenException;
import com.playtomic.anemone.user.service.exception.EmailNotAvailableException;
import com.playtomic.anemone.user.service.exception.InvalidCountryCodeException;
import com.playtomic.anemone.user.service.exception.InvalidEmailException;
import com.playtomic.anemone.user.service.exception.InvalidEmailTokenException;
import com.playtomic.anemone.user.service.exception.InvalidPasswordException;
import com.playtomic.anemone.user.service.exception.PhoneNotAvailableException;
import com.playtomic.anemone.user.service.exception.TenantNotFoundException;
import com.playtomic.anemone.user.service.exception.UserNotFoundException;
import com.playtomic.anemone.user.service.exception.UserRoleAlreadyDefinedException;
import com.playtomic.anemone.user.service.facebook.exception.InvalidFacebookTokenException;
import com.playtomic.anemone.user.service.google.exception.InvalidGoogleTokenException;
import javax.annotation.Nonnull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Authentication is performed via Filters and Spring Security modules. <p> This controller is intended to check whether
 * the user is authorized or not, which roles are assigned, when the session expires...
 * @see SecurityConfig
 */
@RestController
@RequestMapping(path = "/v2/auth")
@Slf4j
public class AuthenticationControllerV2 extends AbstractRestController {

    @Nonnull
    final private AuthenticationService authenticationService;

    @Nonnull
    final private AuthenticationControllerV3 authenticationControllerV3;

    public AuthenticationControllerV2(@Nonnull MessageSource messageSource,
                                      @Nonnull DiscoveryClient discoveryClient,
                                      @Nonnull AuthenticationService authenticationService,
                                      @Nonnull AuthenticationControllerV3 authenticationControllerV3) {
        super(messageSource, discoveryClient);
        this.authenticationService = authenticationService;
        this.authenticationControllerV3 = authenticationControllerV3;
    }

    @RequestMapping(path = "/login", method = RequestMethod.POST, consumes = Constants.CONSUMES_JSON)
    public ResponseEntity login(@RequestBody LoginRequestBody body) {
        StatusResponseBody response = new StatusResponseBody(
                "DISCONTINUED",
                "This Api is no longer available. Please, use /v3/auth/login instead"
        );
        return new ResponseEntity(response, HttpStatus.GONE);
    }

    @Deprecated
    @RequestMapping(path = "/login", method = RequestMethod.POST, consumes = Constants.CONSUMES_X_WWW_FORM)
    public ResponseEntity login(
            @RequestParam(name = "email", required = false) Email email,
            @RequestParam(name = "password", required = false) String password,
            @RequestParam(name = "facebook_token", required = false) String facebookToken,
            @RequestParam(name = "google_token", required = false) String googleToken) {
        return login(new LoginRequestBody(email, password, facebookToken, googleToken, null));
    }

    // Should be POST, but it is not really important
    @RequestMapping(path = "/logout")
    public ResponseEntity logoutSuccessfulResult() {
        AnemoneUserPrincipal user = getUserDetails();
        authenticationService.logout(user.getId());
        return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
    }

    @RequestMapping(path = "/token", method = RequestMethod.POST, consumes = Constants.CONSUMES_JSON)
    public ResponseEntity refreshAuth(@RequestBody RefreshTokenRequestBody body) {
        return authenticationControllerV3.refreshAuth(body);
    }

    @Deprecated
    @RequestMapping(path = "/token", method = RequestMethod.POST, consumes = Constants.CONSUMES_X_WWW_FORM)
    public ResponseEntity refreshAuth(@RequestParam(name = "refresh_token") RawAccessJwtToken refreshToken) {
        return refreshAuth(new RefreshTokenRequestBody(refreshToken));
    }

    @RequestMapping(path = "/register", method = RequestMethod.POST, consumes = Constants.CONSUMES_JSON)
    public ResponseEntity register(@RequestBody RegisterRequestBody body)
        throws InvalidEmailException, InvalidPasswordException, UserNotFoundException, InvalidCountryCodeException,
        EmailNotAvailableException, InvalidFacebookTokenException, InvalidGoogleTokenException,
        PhoneNotAvailableException, UserRoleAlreadyDefinedException, InvalidAppleTokenException, TenantNotFoundException {
        String authenticatedUserId = getCurrentUser() instanceof AnonymousUser ? null : getCurrentUser().getId().getValue();
        return authenticationControllerV3.registerLogic(body, false, authenticatedUserId);
    }

    @Deprecated
    @RequestMapping(path = "/validate", method = RequestMethod.PUT, consumes = Constants.CONSUMES_JSON)
    public ResponseEntity validateUser(@RequestBody ValidateEmailRequestBody body)
            throws InvalidEmailTokenException {
        return authenticationControllerV3.validateUser(body);
    }

    @Deprecated
    @RequestMapping(path = "/validate", method = RequestMethod.PUT, consumes = Constants.CONSUMES_X_WWW_FORM)
    public ResponseEntity validateUser(@RequestParam(value = "email", required = false) Email email,
                                       @RequestParam("validate_token") String validateToken)
            throws InvalidEmailTokenException {
        return validateUser(new ValidateEmailRequestBody(email, validateToken));
    }

    @RequestMapping(path = "/password/request", method = RequestMethod.POST, consumes = Constants.CONSUMES_JSON)
    public ResponseEntity requestPasswordReset(@RequestBody PasswordSendRequestBody body) {
        return authenticationControllerV3.requestPasswordReset(body);
    }

    @Deprecated
    @RequestMapping(path = "/password/request", method = RequestMethod.POST, consumes = Constants.CONSUMES_X_WWW_FORM)
    public ResponseEntity requestPasswordReset(@RequestParam(name = "email") Email email) {
        return requestPasswordReset(new PasswordSendRequestBody(email, false, null));
    }

    @RequestMapping(path = "/password/reset", method = RequestMethod.POST, consumes = Constants.CONSUMES_JSON)
    public ResponseEntity resetPassword(@RequestBody PasswordResetRequestBody body) {
        return authenticationControllerV3.resetPassword(body);
    }

    @Deprecated
    @RequestMapping(path = "/password/reset", method = RequestMethod.POST, consumes = Constants.CONSUMES_X_WWW_FORM)
    public ResponseEntity resetPassword(@RequestParam(name = "email") Email email,
                                        @RequestParam(name = "password") String password,
                                        @RequestParam(name = "reset_token") String resetToken) {
        return resetPassword(new PasswordResetRequestBody(email, password, resetToken));
    }

}

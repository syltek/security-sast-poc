package com.playtomic.anemone.category.domain.converter;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import com.playtomic.anemone.category.domain.CancellationPolicyDuration;
import java.io.IOException;
import java.time.Duration;
import java.time.temporal.ChronoUnit;
import javax.annotation.Nonnull;

public class CancellationPolicyDeserializer extends StdDeserializer<CancellationPolicyDuration> {

    private static final long serialVersionUID = 1L;

    public CancellationPolicyDeserializer() {
        super(CancellationPolicyDuration.class);
    }

    @Nonnull
    @Override
    public CancellationPolicyDuration deserialize(@Nonnull JsonParser jp, @Nonnull DeserializationContext ctxt) throws IOException {
        var oc = jp.getCodec();
        JsonNode node = oc.readTree(jp);
        var quantity = node.get("amount").asLong();
        var unit = ChronoUnit.valueOf(node.get("unit").asText());
        return new CancellationPolicyDuration(Duration.of(quantity, unit));
    }
}

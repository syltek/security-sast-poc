package com.playtomic.anemone.user.domain.userimports;

public enum UserImportStatus {
    PROCESSING,
    FINISHED,
    FINISHED_WITH_ERRORS,
    MANUAL_STOP,
    TIMEOUT_FAILED,
    UNEXPECTED_FAILED
}

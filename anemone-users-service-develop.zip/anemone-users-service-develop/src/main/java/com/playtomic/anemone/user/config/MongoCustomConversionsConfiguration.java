package com.playtomic.anemone.user.config;

import com.playtomic.anemone.dao.BigDecimalMongoReadConverter;
import com.playtomic.anemone.dao.BigDecimalMongoWriteConverter;
import com.playtomic.anemone.dao.CurrencyUnitMongoReadConverter;
import com.playtomic.anemone.dao.CurrencyUnitMongoWriteConverter;
import com.playtomic.anemone.dao.InstantMongoReadConverter;
import com.playtomic.anemone.dao.InstantMongoWriteConverter;
import com.playtomic.anemone.dao.MoneyMongoReadConverter;
import com.playtomic.anemone.dao.MoneyMongoWriteConverter;
import com.playtomic.anemone.dao.StringIdMongoWriteConverter;
import com.playtomic.anemone.dao.UuidIdMongoWriteConverter;
import com.playtomic.anemone.spring.config.AnemoneMongoCustomConversionsConfiguration;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nonnull;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.convert.converter.Converter;

@Configuration
public class MongoCustomConversionsConfiguration extends AnemoneMongoCustomConversionsConfiguration {

    @Override
    @Nonnull
    protected List<Converter> converters() {
        List<Converter> converters = new ArrayList();
        converters.add(new MoneyMongoReadConverter());
        converters.add(new MoneyMongoWriteConverter());
        converters.add(new CurrencyUnitMongoReadConverter());
        converters.add(new CurrencyUnitMongoWriteConverter());
        converters.add(new BigDecimalMongoReadConverter());
        converters.add(new BigDecimalMongoWriteConverter(4, RoundingMode.HALF_DOWN));
        converters.add(new StringIdMongoWriteConverter());
        converters.add(new UuidIdMongoWriteConverter());
        this.autoconfigureAbstractStringId(converters);
        converters.add(new InstantMongoReadConverter());
        converters.add(new InstantMongoWriteConverter());
        return converters;
    }
}

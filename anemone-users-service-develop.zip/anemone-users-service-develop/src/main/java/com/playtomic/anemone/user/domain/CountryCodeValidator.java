package com.playtomic.anemone.user.domain;

import java.util.Arrays;
import java.util.Locale;
import javax.annotation.Nullable;

public class CountryCodeValidator {
    public static boolean isValid(@Nullable String countryCode) {
        // countryCode must be included in ISO 3166 2-digit countryCode list
        return Arrays.asList(Locale.getISOCountries()).contains(countryCode);
    }
}
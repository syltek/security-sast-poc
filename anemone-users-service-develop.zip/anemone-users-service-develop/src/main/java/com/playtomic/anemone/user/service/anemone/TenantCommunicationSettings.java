package com.playtomic.anemone.user.service.anemone;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import javax.annotation.Nullable;
import lombok.Getter;

@Getter
public class TenantCommunicationSettings {

    @Nullable
    private final String welcomeMessage;

    @JsonCreator
    public TenantCommunicationSettings(@JsonProperty("welcome_message") @Nullable String welcomeMessage) {
        this.welcomeMessage = welcomeMessage;
    }
}

package com.playtomic.anemone.user.service.apple;

import com.auth0.jwk.Jwk;
import com.auth0.jwk.JwkProvider;
import com.auth0.jwk.UrlJwkProvider;
import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.playtomic.anemone.domain.Email;
import com.playtomic.anemone.user.service.apple.exception.InvalidAppleTokenException;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.URL;
import java.security.interfaces.RSAPublicKey;
import java.util.Calendar;
import java.util.Map;
import javax.annotation.Nonnull;
import javax.validation.ClockProvider;

@Service
@ConfigurationProperties("anemone.apple")
public class AppleService {

    @Nonnull
    private final ClockProvider clockProvider;

    @Setter
    @Getter
    private String clientId = "";

    @Setter
    @Getter
    private String server = "";

    public AppleService(@Nonnull ClockProvider clockProvider) {
        this.clockProvider = clockProvider;
    }

    @Nonnull
    public AppleUserData getUserData(@Nonnull String identityToken) {
        try {
            DecodedJWT jwt = JWT.decode(identityToken);
            URL url = new URI(server + "/auth/keys").normalize().toURL();
            JwkProvider provider = new UrlJwkProvider(url);
            Jwk jwk = provider.get(jwt.getKeyId());
            Algorithm algorithm = Algorithm.RSA256((RSAPublicKey) jwk.getPublicKey(), null);

            // Check signature
            algorithm.verify(jwt);

            // Check other fields
            if (clockProvider.getClock().instant().isAfter(jwt.getExpiresAt().toInstant())) {
                throw new RuntimeException("Expired token");
            }
            if (!jwt.getAudience().contains(clientId)) {
                throw new RuntimeException("Invalid audience");
            }

            Map<String, Claim> claims = jwt.getClaims();
            return new AppleUserData(
                    AppleId.valueOf(jwt.getSubject()),
                    Email.of(claims.get("email").asString()).orElse(null),
                    claims.get("email_verified").asString().equals("true")      // @agarcia: Apple is sending email_verified as a string
            );
        } catch (Exception e) {
            throw new InvalidAppleTokenException(e);
        }
    }
}

package com.playtomic.anemone.user.service.exception;

import javax.annotation.Nonnull;

public class TaskConfigurationException extends RuntimeException{

    public TaskConfigurationException(@Nonnull String message) {
        super(message);
    }
}

package com.playtomic.anemone.user.service.anemone;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.category.domain.MembershipPrice;
import java.util.List;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.AllArgsConstructor;

@AllArgsConstructor
public class CreateProductBody {

    @Nonnull
    @JsonProperty("name")
    private String name;

    @Nullable
    @JsonProperty("description")
    private String description;

    @Nonnull
    @JsonProperty("tenant_id")
    private String tenantId;

    @Nonnull
    @JsonProperty("tenant_name")
    private String tenantName;

    @Nonnull
    @JsonProperty("prices")
    private List<MembershipPrice> prices;

}
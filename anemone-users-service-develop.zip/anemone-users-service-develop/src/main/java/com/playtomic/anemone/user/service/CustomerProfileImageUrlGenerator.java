package com.playtomic.anemone.user.service;

import com.playtomic.anemone.http.AnemoneRestTemplateFactory;
import com.playtomic.anemone.service.AbstractRemoteRestService;
import com.playtomic.anemone.user.dao.UserEntity;
import java.net.URL;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@Slf4j
public class CustomerProfileImageUrlGenerator {

    @Nonnull
    private CloudinaryService cloudinaryService;

    public CustomerProfileImageUrlGenerator(@Nonnull CloudinaryService cloudinaryService) {
        this.cloudinaryService = cloudinaryService;
    }

    @Nullable
    public URL generatePublicProfilePictureUrl(@Nonnull UserEntity userEntity) {
        String overlay = null;
        if (userEntity.getBadges() != null && userEntity.getBadges().split(",").length == 1) {
            overlay = "playtomic:badge:" + userEntity.getBadges();
        }


        // Use playtomic profile first
        if (userEntity.getProfilePhotoFilename() != null) {
            return cloudinaryService.getURL(userEntity.getId() + "/" + userEntity.getProfilePhotoFilename(), "users/", overlay);
        }

        // Otherwise, use facebook id
        if (userEntity.getFacebookId() != null) {
            // Using facebook though cloudinary! yay!
            return cloudinaryService.getFacebookURL(userEntity.getFacebookId(), overlay);
        }

        return null;
    }
}

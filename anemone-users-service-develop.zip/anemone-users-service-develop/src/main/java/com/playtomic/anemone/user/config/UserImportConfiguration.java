package com.playtomic.anemone.user.config;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.QuoteMode;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
public class UserImportConfiguration {

    public static final String DEFAULT_COUNTRY_CODE = "ES";

    public static final List<String> HEADERS = List.of("name", "email", "phone_number", "gender", "birthdate", "category_name", "category_expires_at");

    public static final int EXPECTED_COLUMNS_COUNT = HEADERS.size();

    public static final char DELIMITER = ',';

    public static final CSVFormat CSV_FORMAT = CSVFormat
        .MYSQL
        .withDelimiter(DELIMITER)
        .withQuote('"')
        .withTrim()
        .withHeader()
        .withIgnoreHeaderCase(true)
        .withQuoteMode(QuoteMode.MINIMAL);

    public static final long FAILED_THRESHOLD_SECONDS = 60 * 150; // 2h 30 min <- estimated time for 50K rows

    public static final int OPTIMISTIC_LOCKING_RETRIES = 3;

}

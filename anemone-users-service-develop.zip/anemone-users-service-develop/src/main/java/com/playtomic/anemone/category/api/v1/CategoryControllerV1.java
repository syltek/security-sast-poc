package com.playtomic.anemone.category.api.v1;

import com.playtomic.anemone.category.api.v1.request.CreateCategoryRequestBody;
import com.playtomic.anemone.category.api.v1.request.PatchCategory;
import com.playtomic.anemone.category.api.v1.request.UpdateCategoryRequestBody;
import com.playtomic.anemone.category.domain.Category;
import com.playtomic.anemone.category.domain.CategoryId;
import com.playtomic.anemone.category.domain.CategoryType;
import com.playtomic.anemone.category.domain.MembershipPrice;
import com.playtomic.anemone.category.domain.UserIdAndCategoryExpiration;
import com.playtomic.anemone.category.domain.Visibility;
import com.playtomic.anemone.category.domain.scheduler.MemberTaskDetails;
import com.playtomic.anemone.category.service.CategoryService;
import com.playtomic.anemone.domain.user.UserId;
import com.playtomic.anemone.http.BadRequestException;
import com.playtomic.anemone.http.LinkHeader;
import com.playtomic.anemone.service.AbstractRestController;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import com.playtomic.anemone.user.service.PermissionService;
import com.playtomic.anemone.user.service.exception.TenantNotFoundException;
import com.playtomic.anemone.user.service.exception.UserNotFoundException;
import java.time.Instant;
import java.util.List;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.validation.Valid;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.context.MessageSource;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Validated
@RestController
@RequestMapping("/v1")
@ParametersAreNonnullByDefault
public class CategoryControllerV1 extends AbstractRestController {

    @Nonnull
    private final CategoryService categoryService;

    @Nonnull
    private final PermissionService permissionService;

    public CategoryControllerV1(MessageSource messageSource,
        DiscoveryClient discoveryClient, CategoryService categoryService,
        PermissionService permissionService) {
        super(messageSource, discoveryClient);
        this.categoryService = categoryService;
        this.permissionService = permissionService;
    }

    @Nonnull
    @PostMapping("/categories")
    @PreAuthorize("hasPermission(#body.tenantId, 'write_categories')")
    public Category createCategory(@RequestBody @Valid CreateCategoryRequestBody body) throws TenantNotFoundException {

        String description = body.getMembershipDetails() == null ? null : body.getMembershipDetails().getDescription();
        Visibility visibility = body.getMembershipDetails() == null ? null : body.getMembershipDetails().getVisibility();
        List<MembershipPrice> membershipPrices = body.getMembershipDetails() == null ? null : body.getMembershipDetails().getMembershipPrices();

        return categoryService.createCategory(body.getTenantId(), body.getName(),
            body.getExpiration(), body.getBookingPrivilege(),
            body.getAllowSinglePaymentWhenPriceIsCustomized(), body.getVatRate(),
            body.getCategoryType(), visibility,
            membershipPrices, description);
    }

    @Nonnull
    @GetMapping("/categories")
    @PreAuthorize("true")
    public ResponseEntity<List<Category>> findCategories(@RequestParam("tenant_id") @Nullable TenantId tenantId,
        @RequestParam(name = "category_id", required = false) @Nullable List<CategoryId> categoryIds,
        @RequestParam(name = "name", required = false) @Nullable String name,
        @RequestParam(name = "user_id", required = false) @Nullable UserId userId,
        @RequestParam(name = "active_at", required = false) @Nullable Instant activeAt,
        @RequestParam(name = "category_type", required = false) @Nullable CategoryType categoryType,
        @RequestParam(name = "visibility", required = false) @Nullable Visibility visibility,
        @Nonnull Pageable pageable) throws UserNotFoundException {

        if ((name != null && userId != null) || (name != null && categoryIds != null) || (userId != null && categoryIds != null)) {
            throw new BadRequestException("Only one of name, category_id or user_id param can be sent");
        }
        if (userId != null) {

            //We check that you can read the categories from this user (you're that user or you're manager or higher)
            permissionService.checkCategoriesReadPermission(userId, getUserDetails());

            if(tenantId == null && activeAt != null){
                throw new BadRequestException("Tenant id cannot be null when active_at is set");
            }

            if (tenantId != null && activeAt != null) {
                return ResponseEntity.ok(categoryService.findCategoriesForUserActiveAt(userId, tenantId, activeAt));
            }

            return LinkHeader.toResponse(categoryService.findActiveCategoriesForUser(userId, tenantId, pageable));
        }

        if(tenantId == null){
            throw new BadRequestException("Tenant id cannot be null if user id is null");
        }

        var categories = categoryService.findCategories(tenantId, categoryIds, name, categoryType, visibility, pageable);
        return LinkHeader.toResponse(categories);
    }

    @Nonnull
    @GetMapping("/categories/{category_id}")
    @PreAuthorize("hasPermission(#categoryId, 'read_categories')")
    public Category getCategory(@PathVariable("category_id") CategoryId categoryId) {
        return categoryService.getCategory(categoryId);
    }

    @Nonnull
    @PutMapping("/categories/{category_id}")
    @PreAuthorize("hasPermission(#categoryId, 'write_categories')")
    public Category updateCategory(@PathVariable("category_id") CategoryId categoryId, @RequestBody @Valid UpdateCategoryRequestBody body) {

        String description = body.getMembershipDetails() == null ? null : body.getMembershipDetails().getDescription();
        Visibility visibility = body.getMembershipDetails() == null ? null : body.getMembershipDetails().getVisibility();

        return categoryService.updateCategory(categoryId, body.getName(), body.getExpiration(), body.getBookingPrivilege(),
            body.getAllowSinglePaymentWhenPriceIsCustomized(), body.getVatRate(), visibility, description);
    }

    @Nonnull
    @PatchMapping("/categories/{category_id}")
    @PreAuthorize("hasPermission(#categoryId, 'write_categories')")
    public Category updateCategory(@PathVariable("category_id") CategoryId categoryId, @RequestBody @Valid PatchCategory body) {
        return categoryService.updateCategory(categoryId, body);
    }

    @Nonnull
    @PostMapping("/categories/{category_id}/members")
    @PreAuthorize("hasPermission(#categoryId, 'write_categories')")
    public ResponseEntity addMembersToCategory(@PathVariable("category_id") CategoryId categoryId,
        @RequestBody List<@Valid UserIdAndCategoryExpiration> body) throws TenantNotFoundException {
        categoryService.addMembersToCategory(categoryId, body);
        return ResponseEntity.noContent().build();
    }

    @Nonnull
    @PutMapping("/categories/{category_id}/members")
    @PreAuthorize("hasPermission(#categoryId, 'write_categories')")
    public ResponseEntity updateMembersInCategory(@PathVariable("category_id") CategoryId categoryId,
        @RequestBody List<@Valid UserIdAndCategoryExpiration> body) throws TenantNotFoundException {
        categoryService.updateMembersInCategory(categoryId, body);
        return ResponseEntity.noContent().build();
    }

    @Nonnull
    @DeleteMapping("/categories/{category_id}/members")
    @PreAuthorize("hasPermission(#categoryId, 'write_categories')")
    public ResponseEntity removeMembersFromCategory(@PathVariable("category_id") CategoryId categoryId,
        @RequestParam(name = "user_id", required = false) @Nullable List<Long> userIds) throws TenantNotFoundException {
        categoryService.removeMembersFromCategory(categoryId, userIds);
        return ResponseEntity.noContent().build();
    }

    @Nonnull
    @PostMapping("/categories/{category_id}/members/expired-deletion")
    @PreAuthorize("hasAnyAuthority('admin_users')")
    public ResponseEntity deleteExpiredMember(@PathVariable("category_id") CategoryId categoryId,
        @RequestBody MemberTaskDetails memberTaskDetails) throws TenantNotFoundException {
        categoryService.deleteExpiredMembers(categoryId, memberTaskDetails);
        return ResponseEntity.noContent().build();
    }

    @Nonnull
    @PostMapping("/categories/{category_id}/members/send-expiration-reminder")
    @PreAuthorize("hasAnyAuthority('admin_users')")
    public ResponseEntity sendExpiringCategoryReminders(@PathVariable("category_id") CategoryId categoryId,
        @RequestBody MemberTaskDetails memberTaskDetails) throws TenantNotFoundException {
        categoryService.sendExpirationReminders(categoryId, memberTaskDetails);
        return ResponseEntity.noContent().build();
    }

    // TODO: delete this when expiration will be fixed
    @Nonnull
    @DeleteMapping("/categories/members/expired")
    @PreAuthorize("hasAnyAuthority('admin_users')")
    public ResponseEntity deleteExpiredMembers()  {
        categoryService.deleteAllExpiredMembers();
        return ResponseEntity.noContent().build();
    }

}

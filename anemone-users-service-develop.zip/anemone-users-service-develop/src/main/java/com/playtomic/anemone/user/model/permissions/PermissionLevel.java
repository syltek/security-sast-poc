package com.playtomic.anemone.user.model.permissions;

public enum PermissionLevel {
    READ_ONLY,
    READ_WRITE
}

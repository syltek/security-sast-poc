package com.playtomic.anemone.user.api.v2.request;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class PatchLinkedAccountRequestBody {

    public boolean acceptsCommercial;

    @JsonCreator
    public PatchLinkedAccountRequestBody(@JsonProperty("accepts_commercial") boolean acceptsCommercial) {
        this.acceptsCommercial = acceptsCommercial;
    }
}

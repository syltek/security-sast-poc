package com.playtomic.anemone.user.domain.matches;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import lombok.Getter;
import org.springframework.data.mongodb.core.mapping.Field;

import javax.annotation.Nonnull;

@Getter
public class MatchTenant {

    @Field("tenant_id")
    private TenantId tenantId;

    @JsonCreator
    public MatchTenant(
        @JsonProperty("tenant_id") @Nonnull TenantId tenantId) {
        this.tenantId = tenantId;
    }
}

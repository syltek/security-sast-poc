package com.playtomic.anemone.user.dao;

import com.playtomic.anemone.dao.BaseEntity;
import com.playtomic.anemone.user.domain.LinkingType;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "linked_account")
@Access(AccessType.FIELD)
@Data
@NoArgsConstructor
public class LinkedAccountEntity extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    @Nullable
    private Long id;

    @ManyToOne
    @JoinColumn(name="user_id", nullable = false)
    @Nonnull
    private UserEntity user;

    @Column(name="tenant_id", nullable = false)
    @Nonnull
    private String tenantId;

    @Column(name = "merchant_user_id")
    @Nonnull
    private String merchantUserId;

    @Column(name = "accepts_commercial_communications")
    @Nullable
    private Boolean acceptsCommercialCommunications;

    @Column(name = "linking_type", nullable = true)
    @Enumerated(EnumType.STRING)
    @Nullable
    private LinkingType linkingType;

    public LinkedAccountEntity(@Nonnull UserEntity user,
                               @Nonnull String tenantId,
                               @Nonnull String merchantUserId,
                               @Nullable Boolean acceptsCommercialCommunications,
                               @Nullable LinkingType linkingType) {
        this.user = user;
        this.tenantId = tenantId;
        this.merchantUserId = merchantUserId;
        this.acceptsCommercialCommunications = acceptsCommercialCommunications;
        this.linkingType = linkingType;
    }
}

package com.playtomic.anemone.user.model.permissions;

import lombok.AllArgsConstructor;

import java.util.AbstractMap;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import javax.annotation.Nonnull;

@AllArgsConstructor
public abstract class PermissionsToAuthorities {

    private final Map<PermissionLevel, String[]> mapPermissionsToAuthorities;

    @Nonnull
    protected Set<String> translate(@Nonnull PermissionLevel permissionLevel) {
        Set<String> authorities = new HashSet<>();

        if (PermissionLevel.READ_WRITE.equals(permissionLevel)) {
            authorities.addAll(Arrays.asList(mapPermissionsToAuthorities.get(PermissionLevel.READ_ONLY)));
        }
        authorities.addAll(Arrays.asList(mapPermissionsToAuthorities.get(permissionLevel)));

        return authorities;
    }

    @Nonnull
    protected static Map.Entry<PermissionLevel, String[]> e(@Nonnull PermissionLevel level, String... authorities) {
        return new AbstractMap.SimpleEntry<>(level, authorities);
    }
}

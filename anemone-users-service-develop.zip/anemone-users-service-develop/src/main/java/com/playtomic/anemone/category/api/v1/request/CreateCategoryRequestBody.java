package com.playtomic.anemone.category.api.v1.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.category.domain.BookingPrivilege;
import com.playtomic.anemone.category.domain.CategoryExpiration;
import com.playtomic.anemone.category.domain.CategoryType;
import com.playtomic.anemone.category.domain.MembershipPrice;
import com.playtomic.anemone.category.domain.Visibility;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.validation.Valid;
import javax.validation.constraints.AssertTrue;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import lombok.Getter;

@Getter
@ParametersAreNonnullByDefault
public class CreateCategoryRequestBody {

    public static final String MEMBERSHIP_NOT_ALLOWED_FOR_SIMPLE_CATEGORY_MSG = "Simple categories cannot have membership product information";
    public static final String MEMBERSHIP_DETAILS_MUST_BE_SET_FOR_MEMBERSHIP_CATEGORY_MSG = "Membership categories need membership details";
    public static final String EXPIRATION_NOT_ALLOWED_FOR_MEMBERSHIP_CATEGORY_MSG = "Membership categories cannot have expiration";

    @NotNull
    @JsonProperty(value = "tenant_id")
    private TenantId tenantId;
    @NotNull
    @JsonProperty(value = "name")
    private String name;
    @Valid
    @Nullable
    @JsonProperty("expiration")
    private CategoryExpiration expiration;
    @Valid
    @Nullable
    @JsonProperty("booking_privilege")
    private BookingPrivilege bookingPrivilege;
    @Nullable
    @JsonProperty("allow_single_payment_when_price_is_customized")
    private Boolean allowSinglePaymentWhenPriceIsCustomized;
    @Min(0)
    @Max(1)
    @Nullable
    @JsonProperty("vat_rate")
    private BigDecimal vatRate;

    @Nullable
    @JsonProperty("category_type")
    private CategoryType categoryType;

    @Valid
    @Nullable
    @JsonProperty("membership_details")
    private CreateCategoryMembershipDetails membershipDetails;

    @AssertTrue(message = MEMBERSHIP_NOT_ALLOWED_FOR_SIMPLE_CATEGORY_MSG)
    private boolean isSimpleCategoryAndHasNoMembershipConfig() {
        return ((categoryType == CategoryType.SIMPLE || Objects.isNull(categoryType)) && membershipDetails == null) || categoryType == CategoryType.MEMBERSHIP;
    }

    @AssertTrue(message = MEMBERSHIP_DETAILS_MUST_BE_SET_FOR_MEMBERSHIP_CATEGORY_MSG)
    private boolean isMembershipCategoryAndHasMembershipConfig() {
        return (categoryType == CategoryType.MEMBERSHIP && membershipDetails != null) || (categoryType == CategoryType.SIMPLE || Objects.isNull(categoryType));
    }

    @AssertTrue(message = EXPIRATION_NOT_ALLOWED_FOR_MEMBERSHIP_CATEGORY_MSG)
    private boolean isMembershipCategoryAndExpirationIsNull() {
        return categoryType == CategoryType.MEMBERSHIP && Objects.isNull(expiration) || categoryType == CategoryType.SIMPLE || Objects.isNull(categoryType);
    }

    @Getter
    public static class CreateCategoryMembershipDetails {

      @NotNull
      @JsonProperty("visibility")
      private Visibility visibility;

      @NotNull
      @NotEmpty
      @JsonProperty("membership_prices")
      private List<MembershipPrice> membershipPrices;

      @NotEmpty
      @JsonProperty("description")
      private String description;

    }
}

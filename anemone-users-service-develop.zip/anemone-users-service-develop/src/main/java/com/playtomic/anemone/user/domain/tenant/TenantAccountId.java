package com.playtomic.anemone.user.domain.tenant;

import com.playtomic.anemone.domain.generic.AbstractStringId;

public class TenantAccountId extends AbstractStringId {
    protected TenantAccountId(String id) {
        super(id);
    }

    public static TenantAccountId valueOf(String id) {
        return new TenantAccountId(id);
    }
}
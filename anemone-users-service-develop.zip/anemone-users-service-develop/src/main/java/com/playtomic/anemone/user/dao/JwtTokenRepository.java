package com.playtomic.anemone.user.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

public interface JwtTokenRepository extends CrudRepository<JwtTokenEntity, UUID> {

    JwtTokenEntity findByAccessTokenId(String accessToken);
    JwtTokenEntity findByRefreshTokenId(String accessToken);

    @Transactional
    void deleteByUserId(Long userId);
}

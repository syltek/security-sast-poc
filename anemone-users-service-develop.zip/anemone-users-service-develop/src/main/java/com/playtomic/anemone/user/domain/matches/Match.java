package com.playtomic.anemone.user.domain.matches;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import java.util.Collections;
import java.util.List;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;

@Data
@Slf4j
@Builder
public class Match {

    @Nonnull
    private MatchId matchId;

    @Nullable
    private MatchTenant tenant;

    @Nonnull
    private List<Team> teams;

    @Nonnull
    private MatchStatus matchStatus;

    private boolean isPlaytomicManaged;

    @JsonCreator
    public Match(@JsonProperty(value = "match_id", required = true) @Nonnull MatchId matchId,
                 @JsonProperty(value = "tenant", required = false) @Nullable MatchTenant tenant,
                 @JsonProperty(value = "teams") @Nullable List<Team> teams,
                 @JsonProperty(value = "status", required = true) @Nonnull MatchStatus matchStatus,
                 @JsonProperty(value = "is_playtomic_managed") boolean isPlaytomicManaged) {
        this.matchId = matchId;
        this.tenant = tenant;
        this.teams = teams == null ? Collections.emptyList() : teams;
        this.matchStatus = matchStatus;
        this.isPlaytomicManaged = isPlaytomicManaged;
    }
}

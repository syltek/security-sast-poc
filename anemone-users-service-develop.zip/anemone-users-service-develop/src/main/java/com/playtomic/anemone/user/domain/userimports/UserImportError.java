package com.playtomic.anemone.user.domain.userimports;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.user.config.UserImportConfiguration;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.PersistenceConstructor;

public class UserImportError extends UserImportDataRow {

    @Getter
    @Setter
    @Nonnull
    @JsonProperty(value = "error")
    private UserImportErrorCause error;

    @Getter
    @Setter
    @Nullable
    private String detailedMessage;


    public UserImportError(@Nonnull UserImportDataRow row,
                           @Nonnull UserImportErrorCause error) {
        this(row, error, null);
    }

    public UserImportError(@Nonnull UserImportDataRow row,
                           @Nonnull UserImportErrorCause error,
                           @Nullable String detailedMessage) {
        super(row.getName(), row.getEmail(), row.getPhoneNumber(), row.getGender(), row.getBirthDate(), row.getCategoryName(),
            row.getCategoryExpiresAt(), row.getUserImportId(), null, null, row.getCreatedBy());
        this.error = error;
        this.detailedMessage = detailedMessage;
    }

    @PersistenceConstructor
    public UserImportError(@Nonnull String name,
        @Nonnull String email,
        @Nullable String phoneNumber,
        @Nullable String gender,
        @Nullable String birthDate,
        @Nullable String categoryName,
        @Nullable String categoryExpiresAt,
        @Nullable String createdBy,
        @Nullable UserImportId userImportId,
        @Nonnull UserImportErrorCause error,
        @Nullable String detailedMessage) {
        super(name, email, phoneNumber, gender, birthDate, categoryName, categoryExpiresAt, userImportId, null, null, createdBy);
        this.error = error;
        this.detailedMessage = detailedMessage;
    }

    public String generateCSVLine() {
        String[] lineElements = new String[] {
            this.getName(),
            this.getEmail(),
            this.getPhoneNumber(),
            this.getGender(),
            this.getBirthDate(),
            this.getCategoryName(),
            this.getCategoryExpiresAt(),
            error.name()
        };

        return String.join(String.valueOf(UserImportConfiguration.DELIMITER), lineElements) + "\n";
    }

}

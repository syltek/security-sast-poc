package com.playtomic.anemone.user.domain.csv;

import javax.annotation.Nonnull;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class WalletCsvData {

    @Nonnull
    private final Long userId;

    @Nonnull
    private final CsvDataString walletName;

    @Nonnull
    private final CsvDataMoney balance;
}

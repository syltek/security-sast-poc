package com.playtomic.anemone.user.service.google;

import com.playtomic.anemone.domain.generic.AbstractStringId;
import javax.annotation.Nonnull;

public class GoogleId extends AbstractStringId {
    protected GoogleId(@Nonnull String id) {
        super(id);
    }
    public static GoogleId valueOf(String id) {
        return new GoogleId(id);
    }
}

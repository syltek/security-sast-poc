package com.playtomic.anemone.user.api.request;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.domain.Email;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;

public class PasswordSendRequestBody {

    @Nonnull
    @JsonProperty(value = "email", required = true)
    public Email email;

    @JsonProperty(value = "is_new_user")
    public boolean isNewUser;

    @JsonProperty(value = "source")
    @Nonnull
    public String source;

    public PasswordSendRequestBody() {
    }

    @JsonCreator
    public PasswordSendRequestBody(@JsonProperty(value = "email", required = true) @Nonnull Email email,
                                   @JsonProperty(value = "is_new_user", defaultValue = "false") boolean isNewUser,
                                   @JsonProperty(value = "source", required = false) @Nullable String source
        ) {
        this.email = email;
        this.isNewUser = isNewUser;
        this.source = source == null ? "PLAYTOMIC" : source;
    }
}

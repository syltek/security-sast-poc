package com.playtomic.anemone.category.dao;

import com.playtomic.anemone.category.domain.MembershipPrice;
import com.playtomic.anemone.category.domain.MembershipProductId;
import com.playtomic.anemone.category.domain.Visibility;
import java.util.List;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Field;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MembershipDetailsField {

    @NotNull
    @Indexed
    @Field("membership_product_id")
    private MembershipProductId membershipProductId;

    @NotNull
    @Field("visibility")
    private Visibility visibility;

    @NotNull
    @Field("description")
    private String description;

    @NotEmpty
    @Field("membership_prices")
    private List<MembershipPrice> membershipPrices;
}

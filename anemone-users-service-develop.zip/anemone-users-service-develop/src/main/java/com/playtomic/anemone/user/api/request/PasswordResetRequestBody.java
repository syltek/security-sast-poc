package com.playtomic.anemone.user.api.request;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.domain.Email;
import javax.annotation.Nonnull;

public class PasswordResetRequestBody {

    @Nonnull
    public Email email;

    @Nonnull
    public String password;

    @Nonnull
    public String resetToken;

    public PasswordResetRequestBody() {
    }

    @JsonCreator
    public PasswordResetRequestBody(
        @JsonProperty(value = "email", required = true) @Nonnull Email email,
        @JsonProperty(value = "password", required = true) @Nonnull String password,
        @JsonProperty(value = "reset_token", required = true) @Nonnull String resetToken) {
        this.email = email;
        this.password = password;
        this.resetToken = resetToken;
    }
}

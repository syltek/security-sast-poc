package com.playtomic.anemone.user.dao.tenants_tag;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.dao.BaseDocument;
import com.playtomic.anemone.domain.user.UserId;
import java.time.Instant;
import javax.annotation.Nonnull;
import lombok.Builder;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * This document controls how often the tenant tags should be updated.
 */
@Data
@Document("user_update_tenants_tags_tasks")
@Builder
public class UserUpdateTenantTagsTaskDocument extends BaseDocument {

    @Id
    private UserId userId;

    @Indexed(expireAfterSeconds = 0)
    @JsonProperty("expires_at")
    @Nonnull
    private Instant expiresAt;
}

package com.playtomic.anemone.user.dao;

import lombok.Data;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.Instant;
import java.util.UUID;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "gdpr_audit")
@Access(AccessType.FIELD)
@Data
@EntityListeners(AuditingEntityListener.class)
public class GdprAuditEntity {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "id", columnDefinition = "CHAR(36)", nullable = false)
    @Type(type = "uuid-char")
    private UUID id;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "accepts_privacy_policy")
    private Boolean acceptsPrivacyPolicy;

    @Column(name = "accepts_commercial_communications")
    private Boolean acceptsCommercialCommunications;

    @Column(name = "description")
    private String description;

    @LastModifiedDate
    @Column(name = "last_modified", nullable = false)
    private Instant lastModified;

    public GdprAuditEntity() {
    }

    public GdprAuditEntity(@Nonnull Long userId,
                           @Nullable Boolean acceptsPrivacyPolicy,
                           @Nullable Boolean acceptsCommercialCommunications,
                           @Nullable String description) {
        this.userId = userId;
        this.acceptsPrivacyPolicy = acceptsPrivacyPolicy;
        this.acceptsCommercialCommunications = acceptsCommercialCommunications;
        this.description = description;
    }
}

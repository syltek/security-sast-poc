package com.playtomic.anemone.user.model.permissions;

import java.util.Map;

public class AnemoneWalletPermissionsToAuthorities extends PermissionsToAuthorities {

    private static final Map<PermissionLevel, String[]> authorities = Map.ofEntries(
        e(PermissionLevel.READ_ONLY, "read_merchant_wallet_configurations", "read_wallet_recharge_configurations"),
        e(PermissionLevel.READ_WRITE, "create_movement_with_merchant_wallet_configurations",
            "create_movement_with_wallet_recharge_configurations", "update_merchant_wallet_configurations", "handle_wallet_movements")
    );

    public AnemoneWalletPermissionsToAuthorities() {
        super(authorities);
    }

}

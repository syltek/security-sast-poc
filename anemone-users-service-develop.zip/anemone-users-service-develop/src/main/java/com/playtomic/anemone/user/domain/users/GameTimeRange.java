package com.playtomic.anemone.user.domain.users;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.time.DayOfWeek;
import java.time.LocalTime;
import javax.annotation.Nonnull;
import lombok.Data;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Field;

@Data
public class GameTimeRange {

    @JsonProperty("day_of_week")
    @Field("day_of_week")
    @Nonnull
    @Indexed
    private DayOfWeek dayOfWeek;

    @JsonProperty("start")
    @Field("start")
    @Nonnull
    @Indexed
    private LocalTime start;

    @JsonProperty("end")
    @Field("end")
    @Nonnull
    @Indexed
    private LocalTime end;

    public GameTimeRange(
        @JsonProperty("day_of_week") @Nonnull DayOfWeek dayOfWeek,
        @JsonProperty("start") @Nonnull LocalTime start,
        @JsonProperty("end") @Nonnull LocalTime end) {
        this.dayOfWeek = dayOfWeek;
        this.start = start;
        this.end = end;
    }
}

package com.playtomic.anemone.user.service.messaging;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.domain.user.UserId;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import lombok.Data;

import java.net.URL;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;

@Data
public class SimplifiedTenant {

    public final static String SYLTEKCRM_TENANT_TYPE = "SYLTEKCRM";

    @Nonnull
    private TenantId tenantId;

    @Nullable
    private UserId clientId;

    @JsonCreator
    public SimplifiedTenant(
        @JsonProperty(value = "tenant_id", required = true) @Nonnull TenantId tenantId,
        @JsonProperty(value = "client_id") @Nullable UserId clientId) {
        this.tenantId = tenantId;
        this.clientId = clientId;
    }
}

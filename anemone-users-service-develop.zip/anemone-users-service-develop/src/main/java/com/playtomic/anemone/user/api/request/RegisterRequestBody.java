package com.playtomic.anemone.user.api.request;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.user.model.CustomerAddress;
import com.playtomic.anemone.user.model.role.PlaytomicUserRole;
import lombok.Getter;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;

public class RegisterRequestBody {
    private final static String SPANISH_ISO_3166_CODE = "ES";

    @Nullable
    public String email;

    @Nullable
    public String password;

    @Nullable
    public String name;

    @Nullable
    public String phone;

    @Nullable
    public String phoneToken;

    @Nullable
    public Boolean acceptsPrivacy;

    @Nullable
    public Boolean acceptsCommercial;

    @Nullable
    public String countryCode;

    @Nullable
    public String facebookToken;

    @Nullable
    public String googleToken;

    @Nullable
    public String appleToken;

    @Nullable
    public Locale communicationsLanguage;

    @Nullable
    public CustomerAddress address;

    @JsonCreator
    public RegisterRequestBody(
            @JsonProperty(value = "email") @Nullable String email,
            @JsonProperty(value = "password") @Nullable String password,
            @JsonProperty(value = "name") @Nullable String name,
            @JsonProperty(value = "phone") @Nullable String phone,
            @JsonProperty(value = "phone_token") @Nullable String phoneToken,
            @JsonProperty(value = "accepts_privacy") @Nullable Boolean acceptsPrivacy,
            @JsonProperty(value = "accepts_commercial") @Nullable Boolean acceptsCommercial,
            @JsonProperty(value = "country_code") @Nullable String countryCode,
            @JsonProperty(value = "facebook_token") @Nullable String facebookToken,
            @JsonProperty(value = "google_token") @Nullable String googleToken,
            @JsonProperty(value = "apple_token") @Nullable String appleToken,
            @JsonProperty(value = "roles") @Nullable Set<RegistrationPlaytomicUserRole> roles,
            @JsonProperty(value = "communications_language") @Nullable Locale communicationsLanguage,
            @JsonProperty(value = "address", required = false) @Nullable CustomerAddress address) {
        this.email = email;
        this.password = password;
        this.name = name;
        this.phone = phone;
        this.phoneToken = phoneToken;
        this.acceptsPrivacy = acceptsPrivacy;
        this.acceptsCommercial = acceptsCommercial;
        this.countryCode = countryCode != null ? countryCode : SPANISH_ISO_3166_CODE;
        this.facebookToken = facebookToken;
        this.googleToken = googleToken;
        this.appleToken = appleToken;
        this.communicationsLanguage = communicationsLanguage;
        this.address = address;
    }

    /**
     * Intermediate class to put some extra validation on the input values of this enum.
     */
    @Getter
    public enum RegistrationPlaytomicUserRole {
        // requiredAuthority is null for both, but I want to highlight that security should be taken into account
        // when adding new roles here
        CUSTOMER(PlaytomicUserRole.ROLE_CUSTOMER, null),
        TENANT_MANAGER(PlaytomicUserRole.ROLE_TENANT_MANAGER, null);

        @Nonnull
        private PlaytomicUserRole role;

        @Nullable
        private GrantedAuthority requiredAuthority;

        RegistrationPlaytomicUserRole(@Nonnull PlaytomicUserRole role, @Nullable String requiredAuthority) {
            this.role = role;
            this.requiredAuthority = requiredAuthority == null ? null : new SimpleGrantedAuthority(requiredAuthority);
        }
    }
}

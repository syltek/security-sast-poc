package com.playtomic.anemone.user.model.permissions;

import java.util.Map;

public class CustomerListPermissionsToAuthorities extends PermissionsToAuthorities {

    private static final Map<PermissionLevel, String[]> authorities = Map.ofEntries(
            e(PermissionLevel.READ_ONLY, "read_linked_accounts", "read_contact_data", "read_user_roles", "read_user_permissions", "search_by_name", "read_private_profile"),
            e(PermissionLevel.READ_WRITE, "create_customers", "write_linked_accounts", "write_contact_data", "write_user_roles", "write_user_permissions", "write_private_profile")
    );

    public CustomerListPermissionsToAuthorities() {
        super(authorities);
    }

}

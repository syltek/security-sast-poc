package com.playtomic.anemone.user.api.v2;

import com.playtomic.anemone.domain.user.UserId;
import com.playtomic.anemone.user.api.v2.request.PatchTenantTagsBody;
import com.playtomic.anemone.user.api.v2.request.PutTenantTagsBody;
import com.playtomic.anemone.user.config.UserPermissionService;
import com.playtomic.anemone.user.domain.UserProfile;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import com.playtomic.anemone.user.model.TenantTag;
import com.playtomic.anemone.user.service.PermissionService;
import com.playtomic.anemone.user.service.UserService;
import com.playtomic.anemone.user.service.UserTenantTagService;
import java.util.Set;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.context.MessageSource;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@ParametersAreNonnullByDefault
@RequestMapping(path = "/v2/users/{user_id}/tenant_tags")
public class UserTenantTagControllerV2 extends AbstractUserRestController {

  private final UserTenantTagService userTenantTagService;

  public UserTenantTagControllerV2(MessageSource messageSource,
      DiscoveryClient discoveryClient,
      UserPermissionService userPermissionService,
      PermissionService permissionService,
      UserService userService, UserTenantTagService userTenantTagService) {
    super(messageSource, discoveryClient, userPermissionService, permissionService, userService);
    this.userTenantTagService = userTenantTagService;
  }

  @Nonnull
  @PostMapping
  @PreAuthorize("hasPermission(#body.tenantId, 'write_tenant_tags')")
  public ResponseEntity<UserProfile> addTenantTags(@PathVariable(name = "user_id") UserId userId, @RequestBody TenantTag body) {
    UserProfile user = userTenantTagService.createTenantTags(userId, body);
    return ResponseEntity.ok(user);
  }

  @Nonnull
  @PutMapping
  @PreAuthorize("hasPermission(#userId, 'write_tenant_tags')")
  public ResponseEntity<UserProfile> setTenantTags(@PathVariable(name = "user_id") UserId userId,
      @RequestBody PutTenantTagsBody body) {
    body.getTenantTags()
        .forEach(tag -> assertAllowed(
            userPermissionService.isAllowed(tag.getTenantId(), "write_tenant_tags", getAuthentication())));

    UserProfile user = userTenantTagService.updateTenantTags(userId, body.getTenantTags());

    return ResponseEntity.ok(user);
  }

  @Nonnull
  @PatchMapping
  @PreAuthorize("hasPermission(#userId, 'read_tenant_tags')")
  public ResponseEntity<UserProfile> setTenantTagsForTenantId(@PathVariable(name = "user_id") UserId userId,
      @RequestParam("tenant_id") TenantId tenantId,
      @RequestBody PatchTenantTagsBody body) {
    assertAllowed(userPermissionService.isAllowed(tenantId, "write_tenant_tags", getAuthentication()));

    UserProfile user = userTenantTagService.updateTenantTagsForTenantId(userId, tenantId, body.getTenantTagValues());
    return ResponseEntity.ok(user);
  }

  @Nonnull
  @DeleteMapping
  @PreAuthorize("hasPermission(#tenantId, 'write_tenant_tags')")
  public ResponseEntity<UserProfile> removeTenantTag(@PathVariable(name = "user_id") UserId userId,
      @RequestParam(name = "tags") @Nullable Set<String> tenantTags,
      @RequestParam(name = "tenant_id") TenantId tenantId) {
    UserProfile user = userTenantTagService.removeTenantTags(userId, tenantTags, tenantId);
    return ResponseEntity.ok(user);
  }

}

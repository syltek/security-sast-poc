package com.playtomic.anemone.user.model;


import com.playtomic.anemone.domain.user.UserId;
import com.playtomic.anemone.jwt.AccessJwtToken;
import com.playtomic.anemone.jwt.JwtToken;
import java.time.Instant;
import javax.annotation.Nonnull;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class LoginAuthTokens {

    @Nonnull
    private AccessJwtToken accessToken;

    @Nonnull
    private Instant accessTokenExpiration;

    @Nonnull
    private JwtToken refreshToken;

    @Nonnull
    private Instant refreshTokenExpiration;

    @Nonnull
    private UserId userId;

}

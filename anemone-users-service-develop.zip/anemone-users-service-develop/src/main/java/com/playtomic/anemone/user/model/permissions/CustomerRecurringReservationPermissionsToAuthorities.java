package com.playtomic.anemone.user.model.permissions;

import java.util.Map;

public class CustomerRecurringReservationPermissionsToAuthorities extends PermissionsToAuthorities {

    private static final Map<PermissionLevel, String[]> authorities = Map.ofEntries(
            e(PermissionLevel.READ_ONLY, "read_recurring_match_configurations"),
            e(PermissionLevel.READ_WRITE)
    );

    public CustomerRecurringReservationPermissionsToAuthorities() {
        super(authorities);
    }

}

package com.playtomic.anemone.user.dao;

import com.playtomic.anemone.dao.BaseEntity;
import java.util.UUID;
import javax.annotation.Nonnull;
import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "jwt_token")
@Access(AccessType.FIELD)
@Getter
public class JwtTokenEntity extends BaseEntity {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(columnDefinition = "BINARY(16)")
    private UUID id;

    @Column(name = "user_id")
    private long userId;

    @Column(name = "access_token_id", length = 36)
    @Setter
    private String accessTokenId;

    @Column(name = "refresh_token_id", length = 36)
    @Setter
    private String refreshTokenId;

    public JwtTokenEntity() {
        // jpa stuff
    }

    public JwtTokenEntity(long userId, @Nonnull String accessTokenId, @Nonnull String refreshTokenId) {
        this.userId = userId;
        this.accessTokenId = accessTokenId;
        this.refreshTokenId = refreshTokenId;
    }

}

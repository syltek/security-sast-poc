package com.playtomic.anemone.category.domain.scheduler;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.net.URL;
import java.time.Instant;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;

@Data
@Builder
@RequiredArgsConstructor
@AllArgsConstructor
@NoArgsConstructor
public class ScheduledTask {

    @Nullable
    @JsonProperty
    private String id;

    @Nullable
    @JsonProperty
    private String groupId;

    @Nonnull
    @JsonProperty
    private String description;

    @Nullable
    @JsonProperty
    private Instant startAt;

    @Nullable
    @JsonProperty
    private Instant endAt;

    @Nullable
    @JsonProperty
    private Integer repeatInterval;

    @Nonnull
    @JsonProperty
    private String misfiredPolicy;

    @Nonnull
    @JsonProperty
    private URL callbackUrl;

    @Nullable
    @JsonProperty
    private Object payload;

    @JsonProperty
    private boolean isRecoverable;

}

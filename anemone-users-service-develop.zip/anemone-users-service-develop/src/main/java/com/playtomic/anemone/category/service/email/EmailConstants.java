package com.playtomic.anemone.category.service.email;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class EmailConstants {

    public static final String LOCALE_KEY = "locale";
    public static final String SUBJECT_KEY = "subject";
    public static final String TITLE_KEY = "title";
    public static final String MESSAGE_KEY = "message";


}

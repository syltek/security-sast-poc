package com.playtomic.anemone.user.service.facebook;

import com.playtomic.anemone.domain.Email;
import com.playtomic.anemone.domain.EmailValidator;
import com.playtomic.anemone.user.service.facebook.exception.InvalidFacebookTokenException;
import java.util.Optional;
import javax.annotation.Nonnull;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.social.ApiException;
import org.springframework.social.facebook.api.User;
import org.springframework.social.facebook.api.impl.FacebookTemplate;
import org.springframework.stereotype.Service;

@Service
@ConfigurationProperties("anemone.facebook")
public class FacebookService {

    @Setter @Getter
    private String apiVersion = "3.2";

    @Setter @Getter
    private String[] profileFields = {
        "id",  "email", "languages", "last_name", "locale", "name", "timezone"
    };

    @Nonnull
    public FacebookUserData getUserData(@Nonnull String authToken) {
        try {
            FacebookTemplate fbt = new FacebookTemplate(authToken);
            fbt.setApiVersion(apiVersion);

            User userProfile = fbt.fetchObject("me", User.class, profileFields);

            FacebookId facebookId = FacebookId.valueOf(userProfile.getId());
            //Note that we are getting NULL as email from facebook on some cases. Might be a permission configuration, or not validated on facebook.
            //In any case, email is nullable and then will cause the logging rejection
            Email email = Optional.ofNullable(userProfile.getEmail())
                .filter(EmailValidator::isValid)
                .map(Email::new)
                .orElse(null);
            String name = Optional.ofNullable(userProfile.getName()).orElse("");

            // In Facebook GraphQL >= 3.0, email is returned if it is already validated.
            boolean isVerified = email != null;

            return new FacebookUserData(facebookId, name, email, isVerified);
        } catch (ApiException e) {
            throw new InvalidFacebookTokenException(e);
        }
    }
}

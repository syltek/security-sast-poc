package com.playtomic.anemone;

import com.playtomic.anemone.http.AnemoneRestTemplateFactory;
import com.playtomic.anemone.spring.AbstractAnemoneApplication;
import com.playtomic.anemone.spring.config.MessageSourceConfiguration;
import java.time.Clock;
import javax.annotation.Nonnull;
import javax.validation.ClockProvider;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.mongodb.config.EnableMongoAuditing;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

@SpringBootApplication
@EnableJpaAuditing
@EnableJpaRepositories
@EnableMongoRepositories
@EnableMongoAuditing
@EnableConfigurationProperties
@EnableFeignClients
public class UserApplication extends AbstractAnemoneApplication {

    @Bean
    @ConditionalOnMissingBean(ClockProvider.class)
    public ClockProvider getClockProvider() {
        return () -> Clock.systemDefaultZone();
    }

    public UserApplication(
            @Nonnull AnemoneRestTemplateFactory restTemplateFactory,
            @Nonnull MessageSourceConfiguration messageSourceConfiguration) {
        super(restTemplateFactory, messageSourceConfiguration);
    }

    public static void main(String[] args) {
        SpringApplication.run(UserApplication.class, args);
    }
}

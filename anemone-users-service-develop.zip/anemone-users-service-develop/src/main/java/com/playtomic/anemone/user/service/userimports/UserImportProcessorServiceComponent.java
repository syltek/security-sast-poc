package com.playtomic.anemone.user.service.userimports;

import com.google.api.client.util.Strings;
import com.playtomic.anemone.category.domain.Category;
import com.playtomic.anemone.category.service.CategoryService;
import com.playtomic.anemone.domain.Email;
import com.playtomic.anemone.domain.EmailValidator;
import com.playtomic.anemone.service.AbstractLocalizableService;
import com.playtomic.anemone.user.config.UserImportConfiguration;
import com.playtomic.anemone.user.domain.PasswordGenerator;
import com.playtomic.anemone.user.domain.PhoneValidator;
import com.playtomic.anemone.user.domain.tenant.Tenant;
import com.playtomic.anemone.user.domain.userimports.UserImport;
import com.playtomic.anemone.user.domain.userimports.UserImportDataRow;
import com.playtomic.anemone.user.domain.userimports.UserImportError;
import com.playtomic.anemone.user.domain.userimports.UserImportErrorCause;
import com.playtomic.anemone.user.domain.userimports.UserImportId;
import com.playtomic.anemone.user.domain.userimports.UserImportStatus;
import com.playtomic.anemone.user.domain.users.UserLegacy;
import com.playtomic.anemone.user.model.CustomerUserProfile;
import com.playtomic.anemone.user.model.UserGender;
import com.playtomic.anemone.user.service.UserCredentialService;
import com.playtomic.anemone.user.service.UserLinkingTenantService;
import com.playtomic.anemone.user.service.UserService;
import com.playtomic.anemone.user.service.exception.LinkAccountRegisterException;
import com.playtomic.anemone.user.service.exception.LinkAccountValidateException;
import com.playtomic.anemone.user.service.exception.TenantNotFoundException;
import com.playtomic.anemone.user.service.exception.UserNotFoundException;
import com.playtomic.anemone.user.service.messaging.MessagingBroker;
import com.playtomic.anemone.user.service.messaging.UserEvent;
import com.playtomic.anemone.user.service.messaging.UserImportEvent;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.validation.ClockProvider;
import javax.validation.constraints.NotEmpty;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;

@Slf4j
@Service
public class UserImportProcessorServiceComponent extends AbstractLocalizableService {

    @Nonnull
    private final UserService userService;

    @Nonnull
    private final UserLinkingTenantService userLinkingTenantService;

    @Nonnull
    private final CategoryService categoryService;

    @Nonnull
    private final UserImportServicePersistenceComponent userImportServicePersistenceComponent;

    @Nonnull
    private final UserCredentialService userCredentialService;

    @Nonnull
    private final ClockProvider clockProvider;

    @Nonnull
    private final MessagingBroker messagingBroker;

    public UserImportProcessorServiceComponent(@Nonnull MessageSource messageSource,
        @Nonnull DiscoveryClient discoveryClient,
        @Nonnull UserService userService,
        @Nonnull UserLinkingTenantService userLinkingTenantService, @Nonnull CategoryService categoryService,
        @Nonnull UserImportServicePersistenceComponent userImportServicePersistenceComponent,
        @Nonnull UserCredentialService userCredentialService,
        @Nonnull ClockProvider clockProvider, @Nonnull MessagingBroker messagingBroker) {
        super(messageSource, discoveryClient);
        this.userService = userService;
        this.userLinkingTenantService = userLinkingTenantService;
        this.categoryService = categoryService;
        this.userImportServicePersistenceComponent = userImportServicePersistenceComponent;
        this.userCredentialService = userCredentialService;
        this.clockProvider = clockProvider;
        this.messagingBroker = messagingBroker;
    }

    public void validateAndPrepareProcessing(@Nonnull UserImportId userImportId,
        @Nonnull List<UserImportDataRow> fileRows) {

        // Apply format and duplicity validations
        List<UserImportError> userImportErrors = new ArrayList<>();
        List<UserImportDataRow> validRows = applyDataValidations(fileRows, userImportErrors);

        // If any errors have been found, save them at the userImport
        if (!CollectionUtils.isEmpty(userImportErrors)) {
            userImportServicePersistenceComponent.updateUserImportErrors(userImportId, userImportErrors);
        }

        // Send userImport events for asynchronous processing
        validRows.forEach(row -> {
            row.setUserImportId(userImportId);
            messagingBroker.sendEvent(new UserImportEvent(UserImportEvent.UserImportEventType.IMPORT, row));
        });
    }

    public void processEventData(@Nonnull UserImportId userImportId, @Nonnull UserImportDataRow row) {

        UserImport userImport;

        try {
            // Stage 1. - Link existing accounts
            userImport = searchAndLinkExistingAccount(userImportId, row);

            // Stage 2. - Detect already used verified phones before creating new accounts
            if (userImport == null) {
                userImport = searchAnyUserPreviouslyVerifiedPhone(userImportId, row);
            }

            // Stage 3. - Create new accounts
            if (userImport == null) {
                userImport = createAndLinkNewAccounts(userImportId, row);;
            }

        } catch (Exception ex) {
            // Note that a better characterization of potential issues found might enable that we throw an exception of
            // the processing and retry the import
            log.error("Unexpected error found. Marking row {} as failed.", row.getUserImportId(), ex);
            UserImportError userImportError = new UserImportError(row, UserImportErrorCause.INTERNAL_ERROR, ex.getMessage());
            userImport = userImportServicePersistenceComponent.updateUserImportErrors(userImportId, Collections.singletonList(userImportError));
        }

        if (userImport.getStatus().equals(UserImportStatus.FINISHED) ||
            userImport.getStatus().equals(UserImportStatus.FINISHED_WITH_ERRORS)) {
            log.info("User Import {} for tenant {} has FINISHED successfully", userImport.getId(), userImport.getTenantId());
        }

    }

    @Nonnull
    private List<UserImportDataRow> applyDataValidations(@Nonnull List<UserImportDataRow> fileRows,
        @Nonnull List<UserImportError> userImportErrors) {
        List<UserImportDataRow> validRows = new ArrayList<>(fileRows);

        filterInvalidDataRows(validRows, fileRows, userImportErrors);
        filterDuplicatedEmailDataRows(validRows, userImportErrors);

        return validRows;
    }

    private void filterInvalidDataRows(@Nonnull List<UserImportDataRow> processingRows,
        @Nonnull List<UserImportDataRow> fileChunk,
        @Nonnull List<UserImportError> userImportErrors) {
        for (UserImportDataRow row : fileChunk) {

            boolean removed = false;

            if (!EmailValidator.isValid(row.getEmail())) {
                userImportErrors.add(new UserImportError(row, UserImportErrorCause.INVALID_EMAIL));
                processingRows.remove(row);
                removed = true;
            }

            if (!removed && !Strings.isNullOrEmpty(row.getPhoneNumber()) && !PhoneValidator.isValid(row.getPhoneNumber())) {
                userImportErrors.add(new UserImportError(row, UserImportErrorCause.INVALID_PHONE));
                processingRows.remove(row);
                removed = true;
            }

            if (!removed && !Strings.isNullOrEmpty(row.getBirthDate())) {
                try {
                    parseBirthDate(row.getBirthDate());
                } catch (DateTimeParseException ex) {
                    userImportErrors.add(new UserImportError(row, UserImportErrorCause.INVALID_BIRTHDATE));
                    processingRows.remove(row);
                    removed = true;
                }
            }

            if (!removed && !Strings.isNullOrEmpty(row.getCategoryName())) {
                var category = categoryService.getCategory(row.getTenant().getTenantId(), row.getCategoryName());
                if (category.isEmpty()) {
                    userImportErrors.add(new UserImportError(row, UserImportErrorCause.INVALID_CATEGORY_NAME));
                    processingRows.remove(row);
                    removed = true;
                } else if (category.get().isDisabled()) {
                    userImportErrors.add(new UserImportError(row, UserImportErrorCause.CATEGORY_IS_DISABLED));
                    processingRows.remove(row);
                    removed = true;
                }
            }

            if (!removed && !Strings.isNullOrEmpty(row.getCategoryExpiresAt())) {
                if (Strings.isNullOrEmpty(row.getCategoryName())) {
                    userImportErrors
                        .add(new UserImportError(row, UserImportErrorCause.CATEGORY_EXPIRES_AT_IS_PRESENT_WHEN_THERE_IS_NO_CATEGORY_NAME));
                    processingRows.remove(row);
                    removed = true;
                } else {
                    try {
                        var categoryExpiresAt = parseCategoryExpiresAt(row.getCategoryExpiresAt(), row.getTenant().getTenantAddress().getZoneId());
                        if(clockProvider.getClock().instant().isAfter(categoryExpiresAt)){
                            userImportErrors.add(new UserImportError(row, UserImportErrorCause.INVALID_CATEGORY_EXPIRES_AT_MUST_BE_FUTURE));
                            processingRows.remove(row);
                            removed = true;
                        }
                    } catch (DateTimeParseException ex) {
                        userImportErrors.add(new UserImportError(row, UserImportErrorCause.INVALID_CATEGORY_EXPIRES_AT));
                        processingRows.remove(row);
                        removed = true;
                    }
                }
            }

            if (!removed && !Strings.isNullOrEmpty(row.getGender())) {
                try {
                    parseUserGender(row.getGender());
                } catch (IllegalArgumentException ex) {
                    userImportErrors.add(new UserImportError(row, UserImportErrorCause.INVALID_GENDER));
                    processingRows.remove(row);
                    removed = true;
                }
            }
        }
    }

    private void filterDuplicatedEmailDataRows(@Nonnull List<UserImportDataRow> processingRows,
        @Nonnull List<UserImportError> userImportErrors) {
        // Group rows by email coincidences
        Map<String, List<UserImportDataRow>> emailGroupedRows = processingRows.stream()
            .collect(Collectors.groupingBy(UserImportDataRow::getEmail));

        for (var email : emailGroupedRows.keySet()) {
            List<UserImportDataRow> groupRows = emailGroupedRows.get(email);
            if (groupRows.size() > 1) {
                List<UserImportError> duplicatedEmailErrors = groupRows.stream()
                    .map(r -> new UserImportError(r, UserImportErrorCause.DUPLICATED_EMAIL))
                    .collect(Collectors.toList());

                // Add duplicated email rows to user import errors
                userImportErrors.addAll(duplicatedEmailErrors);

                // Remove duplicated email rows from processing rows
                processingRows.removeAll(groupRows);
            }
        }

    }

    // Stage 1
    @Nullable
    private UserImport searchAndLinkExistingAccount(@Nonnull UserImportId userImportId, @Nonnull UserImportDataRow row) {
        log.debug("Searching existing emails in the database for file emails");

        CustomerUserProfile userFound;
        try {
            userFound = userService.getUserByEmail(new Email(row.getEmail()));
        } catch (UserNotFoundException e) {
            return null;
        }

        Tenant tenant = row.getTenant();
        Assert.notNull(tenant, "It is mandatory to specify a tenant when importing a user");
        try {
            if(!userFound.isLinkedTo(row.getTenant().getTenantId())) {
                log.debug("Linking existing user_id {} to tenant_id {}", userFound.getId(), tenant.getTenantId());
                userLinkingTenantService.registerUserInTenant(userFound.getId(), tenant);
            }
            userService.syncUserCategory(userFound, tenant, row.getCategoryName(), getCategoriesExpiresAt(row, tenant));
            // Note that we increment the amount of existing users linked regardless
            // we perform the linking in the import process or the user is already linked
            return userImportServicePersistenceComponent.updateUserImportUserLinked(userImportId);
        } catch (TenantNotFoundException | UserNotFoundException | LinkAccountValidateException | LinkAccountRegisterException e) {
            log.error("There was an error linking user_id {} to tenant_id {}. Error: {}", userFound.getId(), tenant.getTenantId(), e.getMessage());
            UserImportError userImportError = new UserImportError(row, UserImportErrorCause.LINK_FAILURE, e.getMessage());
            return userImportServicePersistenceComponent.updateUserImportErrors(userImportId, Collections.singletonList(userImportError));
        }
    }

    @Nullable
    private Instant getCategoriesExpiresAt(@Nonnull UserImportDataRow row, @Nonnull Tenant tenant) {
        return Strings.isNullOrEmpty(row.getCategoryExpiresAt()) ? null :
            parseCategoryExpiresAt(row.getCategoryExpiresAt(), tenant.getTenantAddress().getZoneId());
    }

    // Stage 2
    @Nullable
    private UserImport searchAnyUserPreviouslyVerifiedPhone(@Nonnull UserImportId userImportId,
        @Nonnull UserImportDataRow row) {
        log.debug("Searching existing phones in the database for file phones");
        if (row.getPhoneNumber() == null) {
            return null;
        }

        boolean anyUserWithPhoneVerified = userService.existsAnyUserWithPhoneVerified(row.getPhoneNumber()) != 0;
        if (anyUserWithPhoneVerified) {
            UserImportError userImportError = new UserImportError(row, UserImportErrorCause.PHONE_ALREADY_VERIFIED);
            return userImportServicePersistenceComponent.updateUserImportErrors(userImportId, Collections.singletonList(userImportError));
        }

        return null;
    }

    // Stage 3
    @Nonnull
    private UserImport createAndLinkNewAccounts(@Nonnull UserImportId userImportId, @Nonnull UserImportDataRow row) {

        Tenant tenant = row.getTenant();
        Assert.notNull(tenant, "It is mandatory to specify a tenant when importing a user");

        log.debug("Creating new user account");

        // Assign Tenant country code, if there is no country code, assign default.
        String tenantCountryCode = Strings.isNullOrEmpty(tenant.getTenantAddress().getCountryCode()) ?
            UserImportConfiguration.DEFAULT_COUNTRY_CODE :
            tenant.getTenantAddress().getCountryCode();

        // Map birthdate
        Instant birthDate = !Strings.isNullOrEmpty(row.getBirthDate()) ?
            parseBirthDate(row.getBirthDate()) :
            null;

        // Map gender
        UserGender gender = !Strings.isNullOrEmpty(row.getGender()) ?
            parseUserGender(row.getGender()) :
            null;
        var category = getCategory(row, tenant);
        var categoryExpiration = getCategoriesExpiresAt(row, tenant);

        try {
            // Register new imported customer in anemone
            Email email = new Email(row.getEmail());
            CustomerUserProfile user = userService.registerImportedEmailUser(
                email,
                PasswordGenerator.generate(),
                row.getName(),
                row.getPhoneNumber(),
                null,
                null,
                tenantCountryCode,
                null,
                tenant.getCommunicationsLanguage(),
                gender,
                birthDate,
                tenant,
                row.getCreatedBy());
            category.ifPresent(value -> categoryService.addMemberToCategory(tenant, value, UserLegacy.asLong(user.getId()), categoryExpiration));

            // Send update user event
            messagingBroker.sendEvent(new UserEvent(UserEvent.UserEventType.UPDATED, user));

            return userImportServicePersistenceComponent.updateUserImportAccountCreated(userImportId);

        } catch (Exception e) {
            log.error("There was an error creating account for email {} linked to tenant_id {}. Error: {}", row.getEmail(), tenant.getTenantId(),
                e.getMessage());
            UserImportError userImportError = new UserImportError(row, UserImportErrorCause.INTERNAL_ERROR, e.getMessage());
            return userImportServicePersistenceComponent.updateUserImportErrors(userImportId, Collections.singletonList(userImportError));
        }
    }

    @Nonnull
    private Optional<Category> getCategory(@Nonnull UserImportDataRow row, Tenant tenant) {
        return Optional.ofNullable(row.getCategoryName())
            .filter(name -> !name.isEmpty())
            .flatMap(name -> categoryService.getCategory(tenant.getTenantId(), name));
    }

    @Nonnull
    private Instant parseBirthDate(@Nonnull String birthDate) {
        return LocalDate.parse(birthDate).atStartOfDay().toInstant(ZoneOffset.UTC);
    }

    @Nonnull
    private Instant parseCategoryExpiresAt(@Nonnull @NotEmpty String categoryExpiresAt, @Nonnull ZoneId zoneId) {
        var date = LocalDate.parse(categoryExpiresAt);
        var endOfTheDay = LocalDateTime.of(date, LocalTime.MAX);
        return endOfTheDay.atZone(zoneId).toInstant();
    }

    @Nonnull
    private UserGender parseUserGender(@Nonnull String gender) {
        try {
            return UserGender.valueOf(gender);
        } catch (IllegalArgumentException e) {
            String normalizedGender = gender.toUpperCase();
            return UserGender.valueOf(normalizedGender);
        }
    }

}

package com.playtomic.anemone.category.service.exception;

import com.playtomic.anemone.category.domain.CategoryId;
import com.playtomic.anemone.category.domain.MembershipProductId;
import javax.annotation.ParametersAreNonnullByDefault;

@ParametersAreNonnullByDefault
public class CategoryNotFoundException extends RuntimeException {

    public CategoryNotFoundException(CategoryId categoryId) {
        super(String.format("Category with id=%s not found", categoryId));
    }

    public CategoryNotFoundException(String name) {
        super(String.format("Category with name=%s not found", name));
    }

    public CategoryNotFoundException(MembershipProductId membershipProductId) {
        super(String.format("Category with membership product id=%s not found", membershipProductId));
    }

}

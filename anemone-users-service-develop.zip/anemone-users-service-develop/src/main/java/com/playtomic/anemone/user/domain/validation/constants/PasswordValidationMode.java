package com.playtomic.anemone.user.domain.validation.constants;

public enum PasswordValidationMode {
    SIZE_ONLY,
    ALL
}

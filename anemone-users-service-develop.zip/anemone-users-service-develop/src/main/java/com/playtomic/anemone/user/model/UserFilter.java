package com.playtomic.anemone.user.model;

import com.playtomic.anemone.domain.Email;
import com.playtomic.anemone.domain.generic.AbstractStringId;
import com.playtomic.anemone.domain.user.UserId;
import com.playtomic.anemone.user.dao.CoachAccountEntity;
import com.playtomic.anemone.user.dao.LinkedAccountEntity;
import com.playtomic.anemone.user.dao.UserEntity;
import com.playtomic.anemone.user.dao.UserRoleEntity;
import com.playtomic.anemone.user.domain.PhoneValidator;
import com.playtomic.anemone.user.domain.matches.SportId;
import com.playtomic.anemone.user.domain.reservation.MerchantUserId;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import com.playtomic.anemone.user.model.role.PlaytomicUserRole;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import lombok.Builder;
import lombok.Data;
import lombok.experimental.Accessors;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.StringUtils;

@Data
@Accessors(fluent = true, chain = true)
public class UserFilter {

    @Nullable
    private List<UserId> userIds;

    @Nullable
    private String query;

    @Nullable
    private List<Email> emails;

    @Nullable
    private List<String> phones;

    @Nullable
    private List<String> facebookIds;

    @Nullable
    private String defaultPhoneCountryCode;

    @Nullable
    private List<PlaytomicUserRole> userRoles;

    @Nullable
    private List<TenantId> tenantIds;

    @Nullable
    private List<MerchantUserId> merchantUserIds;

    @Nullable
    private Boolean emailVerified;

    @Nullable
    private String nameLike;

    @Nullable
    private Boolean hasLinkedAccount;

    @Nullable
    private Boolean hasCoachAccount;

    @Builder
    public UserFilter(@Nullable List<UserId> userIds,
                      @Nullable String query,
                      @Nullable List<Email> emails,
                      @Nullable List<String> phones,
                      @Nullable List<String> facebookIds,
                      @Nullable String defaultPhoneCountryCode,
                      @Nullable List<PlaytomicUserRole> userRoles,
                      @Nullable List<TenantId> tenantIds,
                      @Nullable List<MerchantUserId> merchantUserIds,
                      @Nullable Boolean emailVerified,
                      @Nullable String nameLike,
                      @Nullable Boolean hasLinkedAccount,
                      @Nullable Boolean hasCoachAccount
    ) {
        this.userIds = userIds;
        this.query = query;
        this.emails = emails;
        this.phones = phones;
        this.facebookIds = facebookIds;
        this.defaultPhoneCountryCode = defaultPhoneCountryCode;
        this.userRoles = userRoles;
        this.tenantIds = tenantIds;
        this.merchantUserIds = merchantUserIds;
        this.emailVerified = emailVerified;
        this.nameLike = nameLike;
        this.hasLinkedAccount = hasLinkedAccount;
        this.hasCoachAccount = hasCoachAccount;
    }

    public Specification<UserEntity> buildSearchSpecifications() {
        List<String> emails = this.emails != null ?
                this.emails.stream().map(Email::getEmail).collect(Collectors.toList()) : new ArrayList<>();
        List<String> phones = this.phones != null ? this.phones : new ArrayList<>();
        List<String> facebookIds = this.facebookIds != null ? this.facebookIds : new ArrayList<>();
        List<PlaytomicUserRole> userRoles = this.userRoles != null ? this.userRoles : new ArrayList<>();
        List<TenantId> tenantIds = this.tenantIds != null ? this.tenantIds : new ArrayList<>();
        List<MerchantUserId> merchantUserIds = this.merchantUserIds != null ? this.merchantUserIds : new ArrayList<>();

        Specification<UserEntity> idSpec = null;
        if (userIds != null) {
            idSpec = (root, criteriaQuery, cb) -> {
                Predicate where = null;
                for (UserId userId : userIds) {
                    Predicate predicate = cb.equal(root.get("id"), userId.getValue());
                    where = where == null ? predicate : cb.or(where, predicate);
                }
                return where;
            };
        }

        Specification<UserEntity> emailsSpecification = getEmailSpecification(emails);

        Specification<UserEntity> phonesSpecification = getPhoneSpecification(phones, defaultPhoneCountryCode);

        Specification<UserEntity> facebookSpecification = getFacebookSpecification(facebookIds);

        Specification<UserEntity> userRolesSpecification = null;
        if (!userRoles.isEmpty()) {
            userRolesSpecification = (root, criteriaQuery, cb) -> {
                criteriaQuery.distinct(true);
                Join<UserEntity, UserRoleEntity> join = root.join("userRoles");
                criteriaQuery.distinct(true);

                if (!tenantIds.isEmpty()) {
                    List<String> stringTenantIds = tenantIds.stream()
                            .map(AbstractStringId::getValue)
                            .collect(Collectors.toList());

                    return cb.and(join.get("userRole").in(userRoles), join.get("tenantId").in(stringTenantIds));
                } else {
                    return join.get("userRole").in(userRoles);
                }
            };
        }

        Specification<UserEntity> merchantUserIdsSpecification = null;
        if (!merchantUserIds.isEmpty()) {
            merchantUserIdsSpecification = (root, criteriaQuery, cb) -> {
                List<String> stringMerchantUserIds = merchantUserIds.stream()
                        .map(AbstractStringId::getValue)
                        .collect(Collectors.toList());
                Join<UserEntity, LinkedAccountEntity> join = root.join("linkedAccounts");
                criteriaQuery.distinct(true);

                if (!tenantIds.isEmpty()) {
                    List<String> stringTenantIds = tenantIds.stream()
                            .map(AbstractStringId::getValue)
                            .collect(Collectors.toList());

                    return cb.and(
                            join.get("merchantUserId").in(stringMerchantUserIds),
                            join.get("tenantId").in(stringTenantIds));
                } else {
                    return join.get("merchantUserId").in(stringMerchantUserIds);
                }
            };
        }

        Specification<UserEntity> nameLikeSpecification = null;
        if (nameLike != null) {
            nameLikeSpecification = (root, criteriaQuery, cb) -> {
                Predicate nameLikePredicate = cb.like(root.get("fullName"), nameLike + "%");

                if (!tenantIds.isEmpty()) {
                    Join<UserEntity, UserRoleEntity> join = root.join("linkedAccounts");
                    criteriaQuery.distinct(true);

                    List<String> stringTenantIds = tenantIds.stream()
                            .map(AbstractStringId::getValue)
                            .collect(Collectors.toList());


                    return cb.and(nameLikePredicate, join.get("tenantId").in(stringTenantIds));
                } else {
                    return nameLikePredicate;
                }
            };
        }

        Specification<UserEntity> hasLinkedAccountSpecification = null;
        if (hasLinkedAccount != null && !tenantIds.isEmpty()) {
            hasLinkedAccountSpecification =  (root, criteriaQuery, cb) -> {
                Join<UserEntity, LinkedAccountEntity> join = root.join("linkedAccounts", JoinType.LEFT);
                criteriaQuery.distinct(true);

                List<String> stringTenantIds = tenantIds.stream()
                    .map(AbstractStringId::getValue)
                    .collect(Collectors.toList());

                return join.get("tenantId").in(stringTenantIds);
            };
        }

        Specification<UserEntity> hasCoachAccountSpecification = null;
        if (hasCoachAccount != null && !tenantIds.isEmpty()) {
            hasLinkedAccountSpecification =  (root, criteriaQuery, cb) -> {
                Join<UserEntity, CoachAccountEntity> join = root.join("coachAccounts", JoinType.LEFT);
                criteriaQuery.distinct(true);

                List<String> stringTenantIds = tenantIds.stream()
                    .map(AbstractStringId::getValue)
                    .collect(Collectors.toList());

                return join.get("tenantId").in(stringTenantIds);
            };
        }

        // Handle ?q=query special case apart.
        if (query != null) {
            return returnQuerySpecification(hasLinkedAccountSpecification);
        }

        return Specification
            .where(idSpec)
            .and(emailsSpecification)
            .and(phonesSpecification)
            .and(facebookSpecification)
            .and(merchantUserIdsSpecification)
            .and(nameLikeSpecification)
            .and(hasLinkedAccountSpecification)
            .and(userRolesSpecification)
            ;
    }

    /**
     * This is a hack for /v2/users?q=query
     * We don't think this should work like this, but Managers are complaining that they cannot add
     * users that don't have linked account in the tenant (obviously, GPPR duh).
     *
     * @deprecated Once managers have access to the version of the Manager where they can link accounts.
     * @param hasLinkedAccountSpecification
     *
     * Previous implementation, to restore when possible:
     * -        Specification<UserEntity> querySpecification = null;
     * -        if (query != null) {
     * -            querySpecification =
     * -                getEmailSpecification(Collections.singletonList(query))
     * -                .or((root, criteriaQuery, cb) -> cb.like(root.get("fullName"), "%" + query + "%"))
     * -                ;
     * -
     * -            if (!PhoneValidator.formattedPhone(query, defaultPhoneCountryCode).isEmpty()) {
     * -                querySpecification = querySpecification.or(getPhoneSpecification(Collections.singletonList(query), defaultPhoneCountryCode));
     * -            }
     * -        }
     *
     * and add this as a and() in the final specification
     */
    @Deprecated
    @Nonnull
    private Specification<UserEntity> returnQuerySpecification(@Nullable Specification<UserEntity> hasLinkedAccountSpecification) {
        Specification<UserEntity> emailsSpec = getEmailSpecification(Collections.singletonList(query));
        Specification<UserEntity> phoneSpec = null;
        if (!PhoneValidator.formattedPhone(query, defaultPhoneCountryCode).isEmpty()) {
            phoneSpec = getPhoneSpecification(Collections.singletonList(query), defaultPhoneCountryCode);
        }

        Specification<UserEntity> nameLikeSpecification = (root, criteriaQuery, cb) -> cb.like(root.get("fullName"), query + "%");
        nameLikeSpecification = nameLikeSpecification.and(hasLinkedAccountSpecification);

        return Specification
            .where(nameLikeSpecification)
            .or(emailsSpec)
            .or(phoneSpec)
        ;
    }

    @Nullable
    public Specification<UserEntity> getEmailSpecification(@Nonnull Collection<String> emails) {
        if (emails.isEmpty()) {
            return null;
        }

        Specification<UserEntity> emailsSpecification = (root, criteriaQuery, cb) -> {
            Predicate where = null;
            for (String email : emails) {
                Predicate predicate = cb.equal(root.get("email"), email);
                where = where == null ? predicate : cb.or(where, predicate);
            }

            if (emailVerified != null) {
                where = cb.and(where, cb.equal(root.get("emailVerified"), emailVerified));
            }

            return where;
        };

        return emailsSpecification;
    }

    public static Specification<UserEntity> getPhoneSpecification(@Nonnull Collection<String> phones, @Nullable String defaultPhoneCountryCode) {
        if (phones.isEmpty()) {
            return null;
        }

        Specification<UserEntity> phonesSpecification = (root, criteriaQuery, cb) -> {
                Predicate where = null;
                for (String unformattedPhone : phones) {
                    String phone = PhoneValidator
                        .formattedPhone(unformattedPhone, defaultPhoneCountryCode)
                        .orElseThrow(() -> new IllegalArgumentException("Invalid phone format"));

                    Predicate predicate = cb.equal(root.get("phone"), phone);
                    where = where == null ? predicate : cb.or(where, predicate);
                }
                return where;
            };

        return phonesSpecification;
    }

    @Nullable
    private Specification<UserEntity> getFacebookSpecification(@Nonnull Collection<String> facebookIds) {
        if (facebookIds.isEmpty()) {
            return null;
        }

        return (root, criteriaQuery, cb) -> {
            Predicate where = null;
            for (String facebookId : facebookIds) {
                Predicate predicate = cb.equal(root.get("facebookId"), facebookId);
                where = where == null ? predicate : cb.or(where, predicate);
            }
            return where;
        };
    }

    @Nonnull
    public static Specification<UserEntity> getCoachesSpecification(@Nonnull TenantId tenantId, @Nullable SportId sportId, @Nullable String filter) {

        Specification<UserEntity> coachesSpecification = (root, criteriaQuery, cb) -> {

            List<Predicate> predicates = new ArrayList<>();
            Join<UserEntity, CoachAccountEntity> coachJoin = root.join("coachAccounts");

            predicates.add(cb.equal(coachJoin.get("tenantId"), tenantId.getValue()));

            if (StringUtils.hasText(filter)) {
                predicates.add(cb.like(root.get("fullName"), "%" + filter + "%"));
            }

            if (sportId != null) {
                List<Predicate> orSportPredicates = new ArrayList<>();
                String sportSeparator = CoachAccountEntity.SPORTS_SEPARATOR;
                String sportIdStr = sportId.getValue();

                // This is awful. But as long as the sport ids are stored as a string with ";" separators, I have to do this to filter by sport (I
                // didn't find a better approach). Notice that it is not as easy as just put "%TENNIS%". We have "BEACH_TENNIS" sport and with "%TENNIS%"
                // we would retrieve coaches with "TENNIS" or "BEACH_TENNIS", which is not correct if we were just looking for "TENNIS" coaches.
                // Maybe, in the future we will migrate all the coach info into a Mongo collection and we will be able to avoid this kind of things.
                orSportPredicates.add(cb.like(coachJoin.get("sportIds").as(String.class), sportIdStr));
                orSportPredicates.add(cb.like(coachJoin.get("sportIds").as(String.class), sportIdStr + sportSeparator + "%"));
                orSportPredicates.add(cb.like(coachJoin.get("sportIds").as(String.class), "%" + sportSeparator + sportIdStr + sportSeparator + "%"));
                orSportPredicates.add(cb.like(coachJoin.get("sportIds").as(String.class), "%" + sportSeparator + sportIdStr));

                predicates.add(cb.or(orSportPredicates.toArray(new Predicate[] {})));
            }

            predicates.add(cb.or(
                cb.isNull(root.get("acceptsPrivacyPolicy")),
                cb.isTrue(root.get("acceptsPrivacyPolicy"))));

            return cb.and(predicates.toArray(new Predicate[] {}));
        };

        return coachesSpecification;
    }
}

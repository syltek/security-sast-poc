package com.playtomic.anemone.user.domain.reservation;

import com.playtomic.anemone.domain.generic.AbstractStringId;
import com.playtomic.anemone.thirdparties.syltekcrm.PadelclickUserId;
import javax.annotation.Nonnull;

public class MerchantUserId extends AbstractStringId {
    protected MerchantUserId(@Nonnull String id) {
        super(id);
    }

    public static MerchantUserId valueOf(@Nonnull String id) {
        return new MerchantUserId(id);
    }

    public static MerchantUserId valueOf(@Nonnull PadelclickUserId padelclickUserId) {
        return valueOf(Long.toString(padelclickUserId.getValue()));
    }
}

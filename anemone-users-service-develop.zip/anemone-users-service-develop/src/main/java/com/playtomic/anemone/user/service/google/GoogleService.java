package com.playtomic.anemone.user.service.google;

import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdTokenVerifier;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.playtomic.anemone.domain.Email;
import com.playtomic.anemone.domain.EmailValidator;
import com.playtomic.anemone.user.service.google.exception.InvalidGoogleTokenException;
import java.util.Objects;
import java.util.Optional;
import javax.annotation.Nonnull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class GoogleService {

    @Autowired
    private GoogleConfiguration configuration;

    @Nonnull
    public GoogleUserData getUserData(@Nonnull String authToken) {
        try {
            GoogleIdTokenVerifier verifier = new GoogleIdTokenVerifier.Builder(new NetHttpTransport(), new JacksonFactory())
                    .setAudience(configuration.getClientIds())
                    .build();

            GoogleIdToken idToken = verifier.verify(authToken);
            GoogleIdToken.Payload payload = idToken.getPayload();

            String userId = payload.getSubject();
            Email email = EmailValidator.isValid(payload.getEmail()) ? new Email(payload.getEmail()) : null;
            boolean emailVerified = payload.getEmailVerified();
            String name = (String) payload.get("name");
            String familyName = (String) payload.get("family_name");
            String givenName = (String) payload.get("given_name");
            String username = name != null ? name : (givenName != null ? givenName : (familyName != null ? familyName : ""));
            return new GoogleUserData(GoogleId.valueOf(userId), username, email, emailVerified);
        } catch (Throwable e) {
            throw new InvalidGoogleTokenException(e);
        }
    }
}

package com.playtomic.anemone.category.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import javax.annotation.Nonnull;
import javax.validation.constraints.Min;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public class CategoryExpiration {

    @Nonnull
    @JsonProperty("unit")
    private ExpirationUnit unit;
    @Min(0)
    @JsonProperty("value")
    private int value;
}

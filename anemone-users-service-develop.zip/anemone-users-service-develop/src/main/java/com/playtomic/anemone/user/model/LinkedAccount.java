package com.playtomic.anemone.user.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.user.domain.LinkingType;
import com.playtomic.anemone.user.domain.tenant.TenantAccountId;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import java.time.Instant;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LinkedAccount {

    @Nonnull
    @JsonProperty("tenant_id")
    TenantId tenantId;

    @Nullable
    @JsonProperty("merchant_user_id")
    TenantAccountId merchantUserId;

    @Nullable
    @JsonProperty("accepts_commercial")
    public Boolean acceptsCommercial;

    @Nullable
    @JsonProperty("linking_type")
    public LinkingType linkingType;

    @Nullable
    @JsonProperty("created_at")
    public Instant createdAt;

}

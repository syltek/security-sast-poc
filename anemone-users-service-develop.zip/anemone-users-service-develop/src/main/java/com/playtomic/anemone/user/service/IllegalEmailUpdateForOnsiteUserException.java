package com.playtomic.anemone.user.service;

public class IllegalEmailUpdateForOnsiteUserException extends RuntimeException {

}

package com.playtomic.anemone.user.model;

public enum PrivacyProfile {
    PUBLIC, PRIVATE
}

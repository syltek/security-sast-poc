package com.playtomic.anemone.user.service.anemone;

import com.playtomic.anemone.domain.user.UserId;
import com.playtomic.anemone.domain.user.UserRole;
import com.playtomic.anemone.http.AnemoneRestTemplateFactory;
import com.playtomic.anemone.jwt.JwtTokenFactory;
import com.playtomic.anemone.service.AbstractRemoteRestService;
import com.playtomic.anemone.spring.AnemoneAuthenticationCredentialsAccessor;
import com.playtomic.anemone.spring.AnemoneAuthenticationHeaderClientHttpRequestInterceptor;
import com.playtomic.anemone.spring.AuthenticationCredentialsAccessor;
import com.playtomic.anemone.spring.ForceAnemoneAuthenticationCredentialsAccessor;
import com.playtomic.anemone.user.domain.voucher.Voucher;
import java.util.Collections;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;

@Service
@Slf4j
public class VoucherServiceClient extends AbstractRemoteRestService {

    @Nonnull
    final private AuthenticationCredentialsAccessor authenticationCredentialsAccessor;

    public VoucherServiceClient(@Nonnull MessageSource messageSource,
                               @Nonnull DiscoveryClient discoveryClient,
                               @Nonnull AnemoneRestTemplateFactory restTemplateFactory,
                               @Nonnull JwtTokenFactory jwtTokenFactory) {
        super(messageSource, discoveryClient, restTemplateFactory);
        this.authenticationCredentialsAccessor = new ForceAnemoneAuthenticationCredentialsAccessor(jwtTokenFactory);
    }

    @Override
    protected void configureRestTemplate(RestTemplate rest) {
        rest.getInterceptors().add(new AnemoneAuthenticationHeaderClientHttpRequestInterceptor(authenticationCredentialsAccessor));
    }

    public Voucher createVoucher(@Nonnull String searchId, @Nonnull String countryCode, @Nonnull UserId userId) {

        String endpoint = getEndpoint(AnemoneServices.VOUCHERS_SERVICE, "/v1/vouchers");

        CreateAnemoneVoucherRequestBody body = new CreateAnemoneVoucherRequestBody(searchId, countryCode, userId);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<?> entity = new HttpEntity<>(body, headers);

        try {
            return restTemplate().exchange(endpoint, HttpMethod.POST, entity, Voucher.class).getBody();
        } catch (Exception e) {
            log.info(
                    String.format("Voucher cannot be created for user: %s with search_id: %s and country_code: %s",
                            body.getUserId(),
                            body.getSearchId(),
                            body.getCountryCode()),
                    e);

            return null;
        }
    }
}

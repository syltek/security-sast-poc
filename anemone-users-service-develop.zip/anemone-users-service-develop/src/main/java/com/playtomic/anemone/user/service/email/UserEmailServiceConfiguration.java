package com.playtomic.anemone.user.service.email;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties("users.emails")
@Data
@NoArgsConstructor
public class UserEmailServiceConfiguration {

    private WelcomeEmail welcomeEmail;

    private EmailConfiguration resetPasswordManagerNewUserConfig;

    private EmailConfiguration managerRoleAddedConfig;

    private EmailConfiguration resetPasswordExistingUserConfig;

    private EmailConfiguration validateUserConfig;

    private EmailConfiguration customerSuggestionConfig;

    private EmailConfiguration tenantSuggestionConfig;

    @Getter
    @Setter
    //TODO refactor this email to use
    public static class WelcomeEmail {
        @Nonnull
        String templateId;

        @Nonnull
        String from = "Playtomic <hola@playtomic.io>";

    }

    @Getter
    @Setter
    public static class EmailConfiguration {

        @Nonnull
        private String templateId;

        @Nonnull
        private String from;

        @Nullable
        private String to;

        @Nonnull
        private String emailPropertiesPrefix;
    }
}

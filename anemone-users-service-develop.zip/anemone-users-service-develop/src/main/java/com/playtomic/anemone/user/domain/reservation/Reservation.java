package com.playtomic.anemone.user.domain.reservation;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.domain.user.UserId;
import com.playtomic.anemone.user.domain.tenant.ReservationTenant;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Data;

@Data
public class Reservation {

    @Nonnull
    private ReservationId reservationId;

    @Nonnull
    private String status;

    @Nonnull
    private UserId userId;

    @Nonnull
    private ReservationTenant tenant;

    @Nullable
    private MerchantUserId merchantUserId;

    @JsonCreator
    public Reservation(
        @JsonProperty(value = "reservation_id", required = true) @Nonnull ReservationId reservationId,
        @JsonProperty(value = "status", required = true) @Nonnull String status,
        @JsonProperty(value = "user_id", required = true) @Nonnull UserId userId,
        @JsonProperty(value = "tenant", required = true) @Nonnull ReservationTenant tenant,
        @JsonProperty(value = "merchant_user_id") @Nullable MerchantUserId merchantUserId) {
        this.reservationId = reservationId;
        this.status = status;
        this.userId = userId;
        this.tenant = tenant;
        this.merchantUserId = merchantUserId;
    }
}

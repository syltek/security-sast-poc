package com.playtomic.anemone.user.service.exception;

// sgmoratilla: i've removed all constructor because it is returning query params as part of the response
public class UserNotFoundException extends RuntimeException {
}

package com.playtomic.anemone.user.service.apple;

import com.playtomic.anemone.domain.generic.AbstractStringId;

/**
 *
 */
public class AppleId extends AbstractStringId {
    protected AppleId(String id) {
        super(id);
    }

    public static AppleId valueOf(String id) {
        return new AppleId(id);
    }

}

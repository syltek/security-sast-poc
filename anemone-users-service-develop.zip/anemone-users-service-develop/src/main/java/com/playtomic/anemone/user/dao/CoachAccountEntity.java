package com.playtomic.anemone.user.dao;

import com.playtomic.anemone.converter.StringSetConverter;
import com.playtomic.anemone.dao.BaseEntity;
import com.playtomic.anemone.user.domain.matches.SportId;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "coach_account")
@Access(AccessType.FIELD)
@Data
@NoArgsConstructor
public class CoachAccountEntity extends BaseEntity {
    public static final String SPORTS_SEPARATOR = ";";

    @Id
    @Column(name = "id")
    @Nonnull
    private String id;

    @ManyToOne
    @JoinColumn(name="user_id", nullable = false)
    @Nonnull
    private UserEntity user;

    @Column(name="tenant_id", nullable = false)
    @Nonnull
    private String tenantId;

    @Column(name = "sport_ids")
    @Convert(converter = StringSetConverter.class)
    @Nonnull
    private Set<String> sportIds;

    @Column(name = "experience")
    @Nullable
    private String experience;

    @Column(name = "ages")
    @Nullable
    private String ages;

    @Column(name = "description")
    @Nullable
    private String description;

    public CoachAccountEntity(
                               @Nonnull String id,
                               @Nonnull UserEntity user,
                               @Nonnull String tenantId,
                               @Nonnull List<SportId> sportIds,
                               @Nullable String experience,
                               @Nullable String ages,
                               @Nullable String description
        ) {
        this.id = id;
        this.user = user;
        this.tenantId = tenantId;
        setSportIds(sportIds);
        this.experience = experience;
        this.ages = ages;
        this.description = description;
    }

    public void setSportIds(@Nonnull List<SportId> sportIds) {
        this.sportIds = sportIds.stream()
            .map(s -> s.getValue())
            .collect(Collectors.toSet());
    }

    @Nonnull
    public List<SportId> getSportIds() {
        return sportIds
            .stream()
            .map(SportId::valueOf)
            .collect(Collectors.toList());
    }
}

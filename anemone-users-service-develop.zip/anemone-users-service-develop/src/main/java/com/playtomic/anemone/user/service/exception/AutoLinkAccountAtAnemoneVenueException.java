package com.playtomic.anemone.user.service.exception;

import javax.annotation.Nonnull;

public class AutoLinkAccountAtAnemoneVenueException extends RuntimeException {

    public AutoLinkAccountAtAnemoneVenueException(@Nonnull String e) {
        super(e);
    }

}

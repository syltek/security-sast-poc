package com.playtomic.anemone.user.service.exception;

import javax.annotation.Nonnull;

/**
 *
 */
public class CustomerProfileImageNotSaveException extends RuntimeException {
    public CustomerProfileImageNotSaveException(@Nonnull Exception e) {
        super(e);
    }
}

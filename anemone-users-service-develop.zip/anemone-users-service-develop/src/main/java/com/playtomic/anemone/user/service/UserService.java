package com.playtomic.anemone.user.service;

import com.google.api.client.util.Strings;
import com.playtomic.anemone.category.domain.BookingPrivilege;
import com.playtomic.anemone.category.domain.CancellationPolicyDuration;
import com.playtomic.anemone.category.domain.Category;
import com.playtomic.anemone.category.domain.CategoryId;
import com.playtomic.anemone.category.service.CategoryService;
import com.playtomic.anemone.category.service.exception.CategoryNotFoundException;
import com.playtomic.anemone.domain.Email;
import com.playtomic.anemone.domain.EmailValidator;
import com.playtomic.anemone.domain.generic.StringApiKey;
import com.playtomic.anemone.domain.user.UserId;
import com.playtomic.anemone.service.AbstractLocalizableService;
import com.playtomic.anemone.thirdparties.syltekcrm.PadelclickTenant;
import com.playtomic.anemone.thirdparties.syltekcrm.PadelclickTenantId;
import com.playtomic.anemone.user.dao.TenantTagEntity.Type;
import com.playtomic.anemone.user.dao.UserDocument;
import com.playtomic.anemone.user.dao.UserDocumentRepository;
import com.playtomic.anemone.user.dao.UserEntity;
import com.playtomic.anemone.user.dao.UserGamePreferencesField;
import com.playtomic.anemone.user.dao.UserRepository;
import com.playtomic.anemone.user.domain.PhoneValidator;
import com.playtomic.anemone.user.domain.UserProfile;
import com.playtomic.anemone.user.domain.tenant.Tenant;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import com.playtomic.anemone.user.domain.users.UserGamePreferences;
import com.playtomic.anemone.user.domain.users.UserLegacy;
import com.playtomic.anemone.user.domain.validation.annotation.Password;
import com.playtomic.anemone.user.model.CustomerAddress;
import com.playtomic.anemone.user.model.CustomerUserProfile;
import com.playtomic.anemone.user.model.ExtendedUserRole;
import com.playtomic.anemone.user.model.PrivacyProfile;
import com.playtomic.anemone.user.model.PublicUserProfile;
import com.playtomic.anemone.user.model.UserFilter;
import com.playtomic.anemone.user.model.UserGender;
import com.playtomic.anemone.user.model.role.PlaytomicUserRole;
import com.playtomic.anemone.user.service.UserServicePersistenceComponent.CustomerUpdateResult;
import com.playtomic.anemone.user.service.anemone.MatchesServiceClient;
import com.playtomic.anemone.user.service.anemone.PaymentsServiceClient;
import com.playtomic.anemone.user.service.apple.AppleUserData;
import com.playtomic.anemone.user.service.exception.CustomerProfileImageNotSaveException;
import com.playtomic.anemone.user.service.exception.InvalidPhoneException;
import com.playtomic.anemone.user.service.exception.PhoneAlreadyValidatedException;
import com.playtomic.anemone.user.service.exception.UserDeletionConflictException;
import com.playtomic.anemone.user.service.exception.UserNotFoundException;
import com.playtomic.anemone.user.service.facebook.FacebookUserData;
import com.playtomic.anemone.user.service.google.GoogleUserData;
import com.playtomic.anemone.user.service.messaging.MessagingBroker;
import com.playtomic.anemone.user.service.messaging.UserEvent;
import com.playtomic.anemone.user.service.messaging.UserEvent.UserEventType;
import com.playtomic.anemone.user.service.messaging.UserUpdateTenantTagEvent;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.validation.ClockProvider;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.context.MessageSource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;
import org.springframework.validation.annotation.Validated;

@Validated
@Service
@Slf4j
public class UserService extends AbstractLocalizableService {

    @Nonnull
    private final UserCredentialService userCredentialService;

    @Nonnull
    private final UserRepository userRepository;

    @Nonnull
    private final UserDocumentRepository userDocumentRepository;

    @Nonnull
    private final MessagingBroker messagingBroker;

    @Nonnull
    private final UserServicePersistenceComponent userServicePersistenceComponent;

    @Nonnull
    private final PaymentsServiceClient paymentsServiceClient;

    @Nonnull
    private final MatchesServiceClient matchesServiceClient;

    @Nonnull
    private final ClockProvider clockProvider;

    @Nonnull
    private final CategoryService categoryService;

    public UserService(@Nonnull MessageSource messageSource,
        @Nonnull DiscoveryClient discoveryClient,
        @Nonnull UserCredentialService userCredentialService,
        @Nonnull UserRepository userRepository,
        @Nonnull UserDocumentRepository userDocumentRepository,
        @Nonnull MessagingBroker messagingBroker,
        @Nonnull UserServicePersistenceComponent userServicePersistenceComponent,
        @Nonnull PaymentsServiceClient paymentsServiceClient,
        @Nonnull MatchesServiceClient matchesServiceClient,
        @Nonnull ClockProvider clockProvider,
        @Nonnull CategoryService categoryService) {
        super(messageSource, discoveryClient);
        this.userCredentialService = userCredentialService;
        this.userRepository = userRepository;
        this.userDocumentRepository = userDocumentRepository;
        this.messagingBroker = messagingBroker;
        this.userServicePersistenceComponent = userServicePersistenceComponent;
        this.paymentsServiceClient = paymentsServiceClient;
        this.matchesServiceClient = matchesServiceClient;
        this.clockProvider = clockProvider;
        this.categoryService = categoryService;
    }

    /**
     * Used to send an update event each time a user entity is updated.
     */
    private void sendUserUpdateEvent(@Nonnull UserProfile user) {
        messagingBroker.sendEvent(new UserEvent(UserEventType.UPDATED, user));
    }

    @Nonnull
    @Transactional(readOnly = true)
    public String getUsername(@Nonnull UserId userId) {
        Optional<UserEntity> entity = userRepository.findById(UserLegacy.asSafeLong(userId));
        return entity
            .map(UserEntity::getFullName)
            .orElseThrow(() -> new UsernameNotFoundException(String.format("User with id=%s was not found", userId)));
    }

    @Nonnull
    public PublicUserProfile getPublicUserById(@Nonnull UserId userId) {
        Optional<UserEntity> entity = userRepository.findById(UserLegacy.asSafeLong(userId));
        return entity
            .map(e -> userServicePersistenceComponent.mapUserEntityToPublicDomain(e, false, false, false))
            .orElseThrow(UserNotFoundException::new);
    }

    @Nonnull
    @Transactional
    public CustomerUserProfile getUserById(@Nonnull UserId userId) {
        Optional<UserEntity> opt = userRepository.findById(UserLegacy.asSafeLong(userId));

        CustomerUserProfile user = opt
            .map(userServicePersistenceComponent::mapUserEntityToDomain)
            .orElseThrow(UserNotFoundException::new);

        // calling to the async version to save 10ms of latency when adding the message to kafka
        UserUpdateTenantTagEvent event = UserUpdateTenantTagEvent.builder().userId(user.getId()).build();
        messagingBroker.asyncSendEvent(event);

        return user;
    }

    @Nonnull
    @Transactional
    public UserProfile getUserByEmailCheckingTags(@Nonnull Email email) {
        CustomerUserProfile user = userRepository.findUserByEmail(email.getEmail())
                                                 .map(userServicePersistenceComponent::mapUserEntityToDomain)
                                                 .orElseThrow(UserNotFoundException::new);

        // calling to the async version to save 10ms of latency when adding the message to kafka
        UserUpdateTenantTagEvent event = UserUpdateTenantTagEvent.builder().userId(user.getId()).build();
        messagingBroker.asyncSendEvent(event);

        return user;
    }

    @Nonnull
    @Transactional
    public CustomerUserProfile getUserByEmail(@Nonnull Email email) {
        return userRepository.findUserByEmail(email.getEmail())
            .map(userServicePersistenceComponent::mapUserEntityToDomain)
            .orElseThrow(UserNotFoundException::new);
    }

    public long existsAnyUserWithPhoneVerified(@Nonnull String phone) {
        return userRepository.countByPhoneAndPhoneVerified(phone, true);
    }

    @Nonnull
    @Transactional(readOnly = true)
    public Page<PublicUserProfile> searchPublicUsersByFilter(@Nonnull final UserFilter userFilter, @Nonnull final Pageable pageable, boolean accessAllContactData) {
        // we are allowing to see the email, the phone or facebook_id if the request included it.
        // I'm not transforming the email from the entity into Email because it is safer (Email instantiation validates the string).
        final Set<String> emails = userFilter.emails() == null ? Collections.emptySet() : new HashSet<>(userFilter.emails().stream().map(m -> m.getEmail()).collect(Collectors.toSet()));
        final Set<String> phones = userFilter.phones() == null ? Collections.emptySet() : new HashSet<>(userFilter.phones());
        final Set<String> facebookIds = userFilter.facebookIds() == null ? Collections.emptySet() : new HashSet<>(userFilter.facebookIds());

        return searchUserEntitiesByFilter(userFilter.buildSearchSpecifications(), pageable)
            .map(e -> {
                    boolean accessEmail = accessAllContactData || emails.contains(e.getEmail());
                    boolean accessPhone = accessAllContactData || phones.contains(e.getPhone());
                    boolean accessFacebookId = accessAllContactData || facebookIds.contains(e.getFacebookId());

                    return userServicePersistenceComponent.mapUserEntityToPublicDomain(e, accessEmail, accessPhone, accessFacebookId);
                }
            );
    }

    @Nonnull
    @Transactional(readOnly = true)
    public Page<CustomerUserProfile> searchUsersByFilter(@Nonnull UserFilter userFilter, @Nonnull Pageable pageable) {
        return searchUserEntitiesByFilter(userFilter.buildSearchSpecifications(), pageable).map(userServicePersistenceComponent::mapUserEntityToDomain);
    }

    @Nonnull
    protected Pageable getDefaultSort(@Nonnull Pageable pageable) {
        Assert.isTrue(pageable.isPaged(), "We can only set default sort for paged requests");

        Sort defaultSort = Sort.by(
                new Sort.Order(Sort.Direction.DESC, "emailVerified"),
                new Sort.Order(Sort.Direction.DESC, "phoneVerified"),
                new Sort.Order(Sort.Direction.DESC, "profilePhotoFilename").nullsLast(),
                new Sort.Order(Sort.Direction.DESC, "phone").nullsLast(),
                new Sort.Order(Sort.Direction.DESC, "facebookId").nullsLast(),
                new Sort.Order(Sort.Direction.ASC, "id")
        );

        return PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), defaultSort);
    }

    @Nonnull
    @Transactional(readOnly = true)
    protected Page<UserEntity> searchUserEntitiesByFilter(@Nonnull Specification<UserEntity> userDataSpecification, @Nonnull Pageable pageable) {

        // This condition assumes that whether the user has answered yes or the user has not answered yet,
        // we include it on the results
        Specification<UserEntity> gdprSpecification = (root, criteriaQuery, cb) ->
                cb.or(cb.isTrue(root.get("acceptsPrivacyPolicy")),
                        cb.isNull(root.get("acceptsPrivacyPolicy")));

        Specification<UserEntity> specification = Specification
                .where(userDataSpecification)
                .and(gdprSpecification);

        // Perform custom order if none provided to give more weight to validated users and with picture
        if (pageable.isPaged() && pageable.getSort().isUnsorted()) {
            pageable = getDefaultSort(pageable);
        }

        return userRepository.findAll(specification, pageable);
    }

    @Nonnull
    public UserProfile addUserRoles(@Nonnull final UserId userId, @Nonnull final Set<ExtendedUserRole> userRoles, boolean sendNotification) {

        // filtering to avoid storing ROLE_CUSTOMER in database. All users are customers right now.
        Collection<ExtendedUserRole> filteredUserRoles = new ArrayList<>(userRoles);
        filteredUserRoles.removeIf(r -> PlaytomicUserRole.ROLE_CUSTOMER.equals(r.getUserRole()));

        // Not very efficient because I'm iterating 3 times in total on userRoles,
        // but it is a clear way to remove unset tenant managers when they have a tenant assigned.
        boolean hasTenantManagerAssigned = filteredUserRoles
            .stream()
            .anyMatch(r -> r.getTenantId() != null && PlaytomicUserRole.ROLE_TENANT_MANAGER.equals(r.getUserRole()));

        if (hasTenantManagerAssigned) {
            filteredUserRoles.removeIf(r -> r.getTenantId() == null && PlaytomicUserRole.ROLE_TENANT_MANAGER.equals(r.getUserRole()));
        }

        // After all the filtering, it shouldn't contain ROLE_CUSTOMER and ROLE_TENANT_MANAGER without tenant_id if this user
        // is manager of some tenant.
        UserProfile saved = userServicePersistenceComponent.addUserRoles(userId, filteredUserRoles, sendNotification);
        sendUserUpdateEvent(saved);

        return saved;
    }

    @Nonnull
    public UserProfile removeUserRole(@Nonnull UserId userId, @Nonnull PlaytomicUserRole userRole, @Nullable List<TenantId> tenantIds) {
        UserProfile saved = userServicePersistenceComponent.removeUserRole(userId, userRole, tenantIds);
        sendUserUpdateEvent(saved);

        return saved;
    }

    public void updateCustomer(@Nonnull UserId userId,
                               @Nullable Email email,
                               @Nullable String emailToken,
                               @Nullable String fullName,
                               @Nullable String newPassword,
                               @Nullable String phone,
                               @Nullable String phoneToken,
                               @Nullable Boolean acceptsPrivacy,
                               @Nullable Boolean acceptsCommercial,
                               @Nullable UserGender gender,
                               @Nullable ZonedDateTime birthDate,
                               @Nullable String bio,
                               @Nullable String countryCode,
                               @Nullable Locale communicationsLanguage,
                               @Nullable Boolean isEmailVerified,
                               @Nullable Boolean isPhoneVerified,
                               @Nullable CustomerAddress address,
                               @Nullable PrivacyProfile privacyProfile) throws InterruptedException {

        CustomerUpdateResult updateResult = userServicePersistenceComponent.updateCustomer(userId, email, emailToken,
                fullName, newPassword, phone, phoneToken, acceptsPrivacy, acceptsCommercial, gender, birthDate, bio,
                countryCode, communicationsLanguage, isEmailVerified,
                isPhoneVerified, address, privacyProfile);

        CustomerUserProfile userProfile = updateResult.getUserProfile();
        sendUserUpdateEvent(userProfile);

        for (UserProfile collateral : updateResult.getOtherUserProfilesThatChanged()) {
            sendUserUpdateEvent(collateral);
        }

        if (updateResult.isEmailChanged() && !userProfile.isEmailVerified()) {
            String emailOptional = userProfile.getEmail();
            if (emailOptional != null) {
                userCredentialService.sendValidationEmail(new Email(emailOptional),
                        userProfile.getCommunicationsLanguage(), null);
            }
        }
    }

    public void updatePicture(@Nonnull UserId userId, @Nonnull String pictureBase64) {
        UserProfile userProfile = userServicePersistenceComponent.updatePicture(userId, pictureBase64);
        sendUserUpdateEvent(userProfile);
    }

    @Nonnull
    public UserProfile createUser(@Nonnull Email email,
        @Nonnull @Password String password,
        @Nonnull String name,
        @Nullable String phone,
        @Nonnull String countryCode,
        @Nullable Locale communicationsLanguage,
        @Nullable ZonedDateTime birthDate,
        @Nullable UserGender gender,
        @Nullable CustomerAddress address,
        @Nullable String pictureBase64,
        @Nullable String createdBy,
        @Nullable TenantId tenantId,
        @Nonnull Collection<ExtendedUserRole> userRoles) {

        UserProfile newUser = registerEmailUser(email, password, name, phone,    null, null, countryCode, address, false, communicationsLanguage,
            createdBy, tenantId, userRoles);

        // FIXME: From here, this method is not transactional but it's the best we have right now.
        // TODO: We should have a builder/class for updates
        try {
            updateCustomer(newUser.getId(), null, null, null, null, null, null, null, null, gender, birthDate, null, null,null, null, null, null, null);
        } catch (Exception e) {
            log.error("Error while updating user gender and birth date of user {}", newUser.getId(), e);
        }

        // We keep the creation of the image out in case the upload fails so that the user can be created correctly
        if (pictureBase64 != null) {
            try {
                updatePicture(newUser.getId(), pictureBase64);
            } catch (UserNotFoundException | CustomerProfileImageNotSaveException e) {
                log.error("Error while updating user profile picture {}", newUser.getId(), e);
            }
        }

        // refresh the newUser because there were a lot of changes
        try {
            return getUserById(newUser.getId());
        } catch (UserNotFoundException e) {
            throw new IllegalStateException("The user that was just created can not be found");
        }
    }

    @Nonnull
    public CustomerUserProfile registerEmailUser(@Nonnull Email email, @Nonnull @Password String password, @Nonnull String name,
        @Nullable String phone, @Nullable Boolean acceptsPrivacy,
        @Nullable Boolean acceptsCommercial, @Nonnull String countryCode,
        @Nullable CustomerAddress address,
        boolean withWelcomeVoucher, @Nullable Locale communicationsLanguage,
        @Nullable String createdBy, @Nullable TenantId tenantId,
        @Nonnull Collection<ExtendedUserRole> userRoles) {
        CustomerUserProfile user = userServicePersistenceComponent.registerEmailUser(email, password, name, phone, acceptsPrivacy,
            acceptsCommercial, countryCode, address, communicationsLanguage, withWelcomeVoucher, createdBy, tenantId, userRoles);

        sendUserUpdateEvent(user);

        return user;
    }

    @Nonnull
    @Transactional
    public CustomerUserProfile registerImportedEmailUser(@Nonnull Email email, @Nonnull @Password String password, @Nonnull String name,
        @Nullable String phone, @Nullable Boolean acceptsPrivacy,
        @Nullable Boolean acceptsCommercial, @Nonnull String countryCode,
        @Nullable CustomerAddress address, @Nullable Locale communicationsLanguage,
        @Nullable UserGender gender, @Nullable Instant birthdate,
        @Nonnull Tenant tenant, @Nullable String createdBy) {
        return userServicePersistenceComponent.registerImportedEmailUser(email, password, name, phone, acceptsPrivacy,
            acceptsCommercial, countryCode, address, gender, birthdate, communicationsLanguage, tenant,  createdBy);
    }

    @Nonnull
    public UserProfile registerFacebookUser(@Nonnull FacebookUserData facebookUserData, @Nullable String phone,
        @Nonnull String countryCode, @Nullable Boolean acceptsPrivacy,
        @Nullable Boolean acceptsCommercial, boolean withWelcomeVoucher, @Nullable String createdBy) {
        UserProfile user = userServicePersistenceComponent.registerFacebookUser(facebookUserData, phone, countryCode, acceptsPrivacy,
            acceptsCommercial, withWelcomeVoucher, createdBy);

        sendUserUpdateEvent(user);

        return user;
    }

    @Nonnull
    public UserProfile registerGoogleUser(@Nonnull GoogleUserData googleUserData, @Nullable String phone, @Nonnull String countryCode,
        @Nullable Boolean acceptsPrivacy,
        @Nullable Boolean acceptsCommercial, boolean withWelcomeVoucher, @Nullable String createdBy) {
        UserProfile user = userServicePersistenceComponent.registerGoogleUser(googleUserData, phone, countryCode, acceptsPrivacy,
            acceptsCommercial, withWelcomeVoucher, createdBy);

        sendUserUpdateEvent(user);

        return user;
    }

    @Nonnull
    public UserProfile registerAppleUser(@Nonnull AppleUserData appleUserData, @Nonnull String fullName, @Nullable String phone,
        @Nonnull String countryCode, @Nullable Boolean acceptsPrivacy, @Nullable Boolean acceptsCommercial,
        boolean withWelcomeVoucher, String createdBy) {
        UserProfile user = userServicePersistenceComponent.registerAppleUser(appleUserData, fullName, phone, countryCode,
            acceptsPrivacy, acceptsCommercial, withWelcomeVoucher, createdBy);

        sendUserUpdateEvent(user);

        return user;
    }

    public void removeUser(@Nonnull UserId userId) {
        userServicePersistenceComponent.removeUser(userId);
    }

    @Nonnull
    public UserGamePreferences getGamePreferences(@Nonnull UserId userId)  {
        Optional<UserDocument> userDoc = getUserDocument(userId);

        UserGamePreferencesField d = userDoc.isPresent() ? userDoc.get().getGamePreferencesField() : null;
        if (d == null) {
            return new UserGamePreferences(new ArrayList<>());
        }

        return new UserGamePreferences(d.getTimeranges());
    }

    @Nonnull
    protected static PadelclickTenant toPadelclick(@Nonnull Tenant tenant) {
        return new PadelclickTenant(
            PadelclickTenantId.valueOf(tenant.getTenantId().getValue()),
            tenant.getUrl(),
            Arrays.asList(),
            tenant.getCustomApiKey() != null ? new StringApiKey(tenant.getCustomApiKey()) : null,
            tenant.getDefaultCurrency());
    }

    @Nonnull
    public UserGamePreferences setGamePreferences(@Nonnull UserId userId, @Nonnull UserGamePreferences gamePreferences) {
        Optional<UserDocument> userOptional = getUserDocument(userId);

        UserDocument userDoc = userOptional
            .orElseGet(() -> new UserDocument(userId.getValue(), new UserGamePreferencesField()));

        UserGamePreferencesField prefs = userDoc.getGamePreferencesField();
        prefs.setTimeranges(gamePreferences.getTimeranges());

        userDocumentRepository.save(userDoc);

        return gamePreferences;
    }

    @Nonnull
    public CustomerUserProfile removeProfilePicture(@Nonnull UserId userId) {
        return userServicePersistenceComponent.updatePicture(userId, null);
    }

    @Nonnull
    public Page<CustomerUserProfile> searchAdmins(@Nonnull String filter, @Nonnull TenantId tenantId, @Nonnull Pageable pageable) {
        Page<UserEntity> admins = filter.isEmpty()
            ? userRepository.findAdmins(tenantId.getValue(), pageable)
            : userRepository.findAdminsByNameLike(tenantId.getValue(), "%" + filter + "%", pageable);
        return admins.map(userServicePersistenceComponent::mapUserEntityToDomain);
    }

    @Nonnull
    public Page<CustomerUserProfile> searchSuggestedPlayers(
        @Nonnull String filter,
        @Nullable String defaultUserPhoneCountryCode,
        @Nonnull TenantId tenantId,
        @Nonnull Pageable pageable) {

        //Step 1: With empty query just return linked accounts
        if (filter.isEmpty()) {
            return
                userRepository.findLinkedAccounts(tenantId.getValue(), pageable)
                    .map(userServicePersistenceComponent::mapUserEntityToDomain);
        }

        //Step 2: First search by exact phone or name.
        //This query is very fast since index is used.
        //Could be done in parallel.
        List<Email> filterEmail = null;
        List<String> filterPhone = null;
        if (EmailValidator.isValid(filter)) {
            filterEmail = Arrays.asList(new Email(filter));
        }

        Optional<String> phone = PhoneValidator.formattedPhone(filter, defaultUserPhoneCountryCode);
        if (phone.isPresent()) {
            filterPhone = Arrays.asList(phone.get());
        }

        if (filterEmail != null || filterPhone != null) {
            UserFilter userFilter = UserFilter.builder()
                .emails(filterEmail)
                .phones(filterPhone)
                .build();

            // use q

            Page<CustomerUserProfile> page = searchUserEntitiesByFilter(userFilter.buildSearchSpecifications(), pageable)
                .map(userServicePersistenceComponent::mapUserEntityToDomain);
            if (!page.isEmpty()) {
                return page;
            }
        }

        //Step3: use linked only accounts and search by name content.
        //This will be faster since the search is limited to linked accounts before using like
        //because a inner join is used.
        return
            userRepository.findLinkedAccountByNameLike(tenantId.getValue(), "%" + filter + "%", pageable)
                .map(userServicePersistenceComponent::mapUserEntityToDomain);
    }

    @Nonnull
    public CustomerUserProfile anonymizeUser(@Nonnull UserId userId) {
        userServicePersistenceComponent.anonymizeUser(userId);
        CustomerUserProfile user = removeProfilePicture(userId);
        sendUserUpdateEvent(user);
        return user;
    }

    public void anonymizeUserWithRestrictions(@Nonnull UserId userId) {
        // User has pending debts
        if (!paymentsServiceClient.findUserDebt(userId).isEmpty()) {
            throw UserDeletionConflictException.pendingDebts();
        }

        // User has to wait at least 3 hours from the last match (Ensure debt generation)
        Instant timeLimit = Instant.now(clockProvider.getClock()).minus(3, ChronoUnit.HOURS);
        if (!matchesServiceClient.findPendingMatches(userId, timeLimit).isEmpty()) {
            throw UserDeletionConflictException.pendingActivities();
        }

        anonymizeUser(userId);

        // TODO - Send email to delete user from mailing lists
    }

    @Nonnull
    public Page<CustomerUserProfile> searchCustomers(@Nonnull String filter, @Nonnull TenantId tenantId, @Nonnull Pageable pageable) {
        Page<UserEntity> customers;
        if (filter.isEmpty()) {
            customers = userRepository.findLinkedAccounts(tenantId.getValue(), pageable);
        } else {
            Specification<UserEntity> specification = (root, criteriaQuery, cb) -> {
                var acceptsPrivacyPolicy = cb.or(cb.isTrue(root.get("acceptsPrivacyPolicy")), cb.isNull(root.get("acceptsPrivacyPolicy")));
                var linkedAccounts = root.join("linkedAccounts", JoinType.INNER).get("tenantId").in(tenantId.getValue());
                return cb.and(linkedAccounts, acceptsPrivacyPolicy);
            };

            var phone = PhoneValidator.formattedPhone(filter, null);
            if (phone.isPresent()) {
                specification = specification.and((root, criteriaQuery, cb) -> cb.equal(root.get("phone"), phone.get()));
                customers = userRepository.findAll(specification, pageable);

            } else if (EmailValidator.isValid(filter)) {
                specification = specification.and((root, criteriaQuery, cb) -> cb.equal(root.get("email"), filter));
                customers = userRepository.findAll(specification, pageable);
            } else {
                customers = userRepository.findLinkedAccountByNameLike(tenantId.getValue(), "%" + filter + "%", pageable);
            }
        }

        return customers.map(userServicePersistenceComponent::mapUserEntityToDomain);
    }

    @Nonnull
    public Page<CustomerUserProfile> searchMembers(@Nonnull String filter,@Nonnull CategoryId categoryId, @Nonnull Pageable pageable) {
        Page<UserEntity> members;
        if (filter.isEmpty()) {
            members = userRepository.findByTenantTags_tagAndTenantTags_Type(categoryId.toString(), Type.ANEMONE_CATEGORY, pageable);
        } else {
            Specification<UserEntity> specification = (root, criteriaQuery, cb) -> {
                Join<Object, Object> tenantTags = root.join("tenantTags", JoinType.INNER);
                var tag = tenantTags.get("tag").in(categoryId.toString());
                var type = tenantTags.get("type").in( Type.ANEMONE_CATEGORY);
                return cb.and(tag, type);
            };
            var phone = PhoneValidator.formattedPhone(filter, null);
            if (phone.isPresent()) {
                specification = specification.and((root, criteriaQuery, cb) -> cb.equal(root.get("phone"), phone.get()));
                members = userRepository.findAll(specification, pageable);
            } else if (EmailValidator.isValid(filter)) {
                specification =  specification.and((root, criteriaQuery, cb) -> cb.equal(root.get("email"), filter));
                members = userRepository.findAll(specification, pageable);
            } else {
               members = userRepository.findByFullNameLikeAndTenantTags_tagAndTenantTags_Type("%" + filter + "%", categoryId.toString(), Type.ANEMONE_CATEGORY, pageable);
            }
        }
        return members.map(userServicePersistenceComponent::mapUserEntityToDomain);
    }

    @Nonnull
    public Optional<CancellationPolicyDuration> getCancellationPolicy(@Nonnull UserId userId, @Nonnull TenantId tenantId, @Nonnull Instant date) {
        return categoryService.getCategoryForUserActiveAt(userId, tenantId, date)
            .map(Category::getBookingPrivilege)
            .map(BookingPrivilege::getCancellationPolicy);
    }

    @Transactional
    @Nonnull
    public CustomerUserProfile syncUserCategory(@Nonnull CustomerUserProfile profile, @Nonnull Tenant tenant,
        @Nullable String categoryName, @Nullable Instant categoryExpiresAt) {
        var tenantId = tenant.getTenantId();
        var userId = UserLegacy.asSafeLong(profile.getId());
        var user = userRepository.findById(userId).orElseThrow(UserNotFoundException::new);
        Assert.isTrue(user.hasLinkedAccount(tenantId), "User must be linked to the tenant before sync categories");
        var currentCategoryTagOpt = user.getCategoryActiveAt(tenantId, clockProvider.getClock().instant());
        if (currentCategoryTagOpt.isEmpty() && Strings.isNullOrEmpty(categoryName)) {
            return profile;
        }

        if (currentCategoryTagOpt.isPresent()) {
            var currentCategoryTag = currentCategoryTagOpt.get();
            if (Strings.isNullOrEmpty(categoryName)) {
                user.removeTenantTag(currentCategoryTag);
                categoryService.removeMemberFromCategory(tenant, CategoryId.valueOf(currentCategoryTag.getTag()), userId);
            } else {
                var newCategory = categoryService.getCategory(tenantId, categoryName).orElseThrow(() -> new CategoryNotFoundException(categoryName));
                if (currentCategoryTag.isSameTag(newCategory.getId())) {
                    categoryService.updateMemberInCategory(tenant, newCategory, userId, categoryExpiresAt);
                } else {
                    user.removeTenantTag(currentCategoryTag);
                    categoryService.removeMemberFromCategory(tenant, CategoryId.valueOf(currentCategoryTag.getTag()), userId);
                    categoryService.addMemberToCategory(tenant, newCategory, userId, categoryExpiresAt);
                }
            }
        } else if (!Strings.isNullOrEmpty(categoryName)) {
            var category = categoryService.getCategory(tenantId, categoryName).orElseThrow(() -> new CategoryNotFoundException(categoryName));
            categoryService.addMemberToCategory(tenant, category, userId, categoryExpiresAt);
        }
        return getUserByEmail(Email.of(profile.getEmail()).get());
    }

    @Nullable
    @Transactional
    public String getDefaultUserPhoneCountryCode(@Nonnull UserId currentUserId) {
        try {
            var user = getUserById(currentUserId);
            return Optional.ofNullable(user.getPhone())
                .filter(p -> !p.isEmpty())
                .flatMap(PhoneValidator::getPhoneCountryCode)
                .orElse(null);
        } catch (Exception e) {
            log.warn("Can not get user profile for userId {}", currentUserId);
        }
        return null;
    }

    @Transactional
    public void validatePhone(@Nonnull UserId userId, @Nonnull String phone) {
        var formattedPhone = PhoneValidator.formattedPhone(phone, null)
            .orElseThrow(() -> new InvalidPhoneException(phone));
        var userProfile = getUserById(userId);

        if (userProfile.isPhoneVerified() && formattedPhone.equals(userProfile.getPhone())) {
            throw new PhoneAlreadyValidatedException("User already has its phone verified");
        }
        userCredentialService.sendValidationSms(userProfile, formattedPhone);
    }

    @Transactional
    public void setPremiumInfo(@Nonnull UserId userId, boolean isPremium, @Nullable Instant expiresAt) {
        CustomerUserProfile user = userServicePersistenceComponent.updatePremiumInfo(userId, isPremium, expiresAt);
        sendUserUpdateEvent(user);
    }

    @Nonnull
    private Optional<UserDocument> getUserDocument(@Nonnull UserId userId) {
        userRepository
            .findById(UserLegacy.asSafeLong(userId))
            .orElseThrow(UserNotFoundException::new);

        return userDocumentRepository.findById(userId.getValue());
    }
}

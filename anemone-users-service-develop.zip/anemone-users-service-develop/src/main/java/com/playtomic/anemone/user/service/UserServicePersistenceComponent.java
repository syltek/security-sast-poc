package com.playtomic.anemone.user.service;

import com.playtomic.anemone.Constants;
import com.playtomic.anemone.domain.Email;
import com.playtomic.anemone.domain.EmailValidator;
import com.playtomic.anemone.domain.user.UserId;
import com.playtomic.anemone.service.AbstractLocalizableService;
import com.playtomic.anemone.thirdparties.syltekcrm.PadelclickGenericException;
import com.playtomic.anemone.thirdparties.syltekcrm.PadelclickService;
import com.playtomic.anemone.thirdparties.syltekcrm.PadelclickTenant;
import com.playtomic.anemone.thirdparties.syltekcrm.PadelclickTenantAccountId;
import com.playtomic.anemone.thirdparties.syltekcrm.PadelclickUser;
import com.playtomic.anemone.thirdparties.syltekcrm.PadelclickUserAccount;
import com.playtomic.anemone.thirdparties.syltekcrm.impl.PadelclickFindCustomerException;
import com.playtomic.anemone.thirdparties.syltekcrm.impl.PadelclickRegisterCustomerException;
import com.playtomic.anemone.user.api.v2.request.LinkCoachAccountData;
import com.playtomic.anemone.user.config.RegistrationVoucherConfiguration;
import com.playtomic.anemone.user.dao.CoachAccountEntity;
import com.playtomic.anemone.user.dao.GdprAuditEntity;
import com.playtomic.anemone.user.dao.GdprAuditRepository;
import com.playtomic.anemone.user.dao.LinkedAccountEntity;
import com.playtomic.anemone.user.dao.PlaytomicUserType;
import com.playtomic.anemone.user.dao.TenantOwnerAccountEntity;
import com.playtomic.anemone.user.dao.TenantTagEntity;
import com.playtomic.anemone.user.dao.UserEntity;
import com.playtomic.anemone.user.dao.UserRepository;
import com.playtomic.anemone.user.dao.UserRoleEntity;
import com.playtomic.anemone.user.dao.UserStatus;
import com.playtomic.anemone.user.domain.LinkingType;
import com.playtomic.anemone.user.domain.PasswordGenerator;
import com.playtomic.anemone.user.domain.PasswordValidator;
import com.playtomic.anemone.user.domain.UserProfile;
import com.playtomic.anemone.user.domain.reservation.MerchantUserId;
import com.playtomic.anemone.user.domain.tenant.Tenant;
import com.playtomic.anemone.user.domain.tenant.TenantAccountId;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import com.playtomic.anemone.user.domain.users.UserLegacy;
import com.playtomic.anemone.user.domain.validation.annotation.Password;
import com.playtomic.anemone.user.domain.validation.constants.PasswordValidationMode;
import com.playtomic.anemone.user.model.CoachAccount;
import com.playtomic.anemone.user.model.CustomerAddress;
import com.playtomic.anemone.user.model.CustomerUserProfile;
import com.playtomic.anemone.user.model.ExtendedUserRole;
import com.playtomic.anemone.user.model.LinkedAccount;
import com.playtomic.anemone.user.model.PrivacyProfile;
import com.playtomic.anemone.user.model.PublicCustomerAddress;
import com.playtomic.anemone.user.model.PublicUserProfile;
import com.playtomic.anemone.user.model.TenantOwnerAccount;
import com.playtomic.anemone.user.model.TenantTag;
import com.playtomic.anemone.user.model.TenantTagDetails;
import com.playtomic.anemone.user.model.UserGender;
import com.playtomic.anemone.user.model.role.PlaytomicUserRole;
import com.playtomic.anemone.user.service.anemone.TenantServiceClient;
import com.playtomic.anemone.user.service.anemone.VoucherServiceClient;
import com.playtomic.anemone.user.service.apple.AppleUserData;
import com.playtomic.anemone.user.service.exception.AutoLinkAccountAtAnemoneVenueException;
import com.playtomic.anemone.user.service.exception.CustomerProfileImageNotSaveException;
import com.playtomic.anemone.user.service.exception.EmailNotAvailableException;
import com.playtomic.anemone.user.service.exception.InvalidPhoneTokenException;
import com.playtomic.anemone.user.service.exception.LinkAccountRegisterException;
import com.playtomic.anemone.user.service.exception.LinkAccountValidateException;
import com.playtomic.anemone.user.service.exception.PhoneNotAvailableException;
import com.playtomic.anemone.user.service.exception.TenantNotFoundException;
import com.playtomic.anemone.user.service.exception.UserNotFoundException;
import com.playtomic.anemone.user.service.facebook.FacebookUserData;
import com.playtomic.anemone.user.service.google.GoogleUserData;
import java.io.IOException;
import java.net.URL;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.validation.ClockProvider;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.LocaleUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.context.MessageSource;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.annotation.Validated;


@Service
@Validated
@Slf4j
@Transactional
public class UserServicePersistenceComponent extends AbstractLocalizableService {
    protected static final String SYLTEK_CUSTOMER_TYPE_PREFIX = "SYLTEK_CUSTOMER_TYPE_";
    private static final int MAX_WIDTH_BIO = 2048;

    @Nonnull
    private final UserRepository userRepository;

    @Nonnull
    private final CustomerProfileImageUrlGenerator customerProfileImageUrlGenerator;

    @Nonnull
    private final UserCredentialService userCredentialService;

    @Nonnull
    private final TenantTagsComponent tenantTagsComponent;

    @Nonnull
    private final GdprAuditRepository gdprAuditRepository;

    @Nonnull
    private final VoucherServiceClient voucherService;

    @Nonnull
    private final CloudinaryService cloudinaryService;

    @Nonnull
    private final PadelclickService padelclickService;

    @PersistenceContext
    @Nonnull
    private EntityManager entityManager;

    @Nonnull
    private final RegistrationVoucherConfiguration registrationVoucherConfiguration;

    @Nonnull
    private final TenantServiceClient tenantService;
    @Nonnull
    private final ClockProvider clockProvider;

    @Data
    @AllArgsConstructor
    private static class GdprSettingsKey {
        @Nullable
        private Boolean privacy;
        @Nullable
        private Boolean commercial;
    }


    @Nonnull
    private final Map<GdprSettingsKey, String> map = Map.of(
        new GdprSettingsKey(true, null), "Privacy policy accepted",
        new GdprSettingsKey(false, null), "Privacy policy refused",
        new GdprSettingsKey(null, true), "Commercial communications accepted",
        new GdprSettingsKey(null, false), "Commercial communications refused",
        new GdprSettingsKey(true, true), "Privacy policy and commercial communications accepted",
        new GdprSettingsKey(false, false), "Privacy policy and commercial communications refused",
        new GdprSettingsKey(true, false), "Privacy policy accepted and commercial communications refused",
        new GdprSettingsKey(false, true), "Privacy policy refused and commercial communications accepted");

    public UserServicePersistenceComponent(@Nonnull MessageSource messageSource,
        @Nonnull DiscoveryClient discoveryClient,
        @Nonnull CustomerProfileImageUrlGenerator customerProfileImageUrlGenerator,
        @Nonnull UserRepository userRepository,
        @Nonnull UserCredentialService userCredentialService,
        @Nonnull TenantTagsComponent tenantTagsComponent,
        @Nonnull GdprAuditRepository gdprAuditRepository,
        @Nonnull VoucherServiceClient voucherService,
        @Nonnull CloudinaryService cloudinaryService,
        @Nonnull RegistrationVoucherConfiguration registrationVoucherConfiguration,
        @Nonnull TenantServiceClient tenantService,
        @Nonnull PadelclickService padelclickService,
        @Nonnull ClockProvider clockProvider) {
        super(messageSource, discoveryClient);
        this.userRepository = userRepository;
        this.customerProfileImageUrlGenerator = customerProfileImageUrlGenerator;
        this.userCredentialService = userCredentialService;
        this.tenantTagsComponent = tenantTagsComponent;
        this.gdprAuditRepository = gdprAuditRepository;
        this.voucherService = voucherService;
        this.cloudinaryService = cloudinaryService;
        this.registrationVoucherConfiguration = registrationVoucherConfiguration;
        this.tenantService = tenantService;
        this.padelclickService = padelclickService;
        this.clockProvider = clockProvider;
    }

    @Nonnull
    public CustomerUserProfile persistOnRegister(@Nonnull Email email, @Nonnull @Password String password,
        @Nonnull String name, @Nullable String phone, @Nullable Boolean acceptsPrivacy,
        @Nullable Boolean acceptsCommercial, @Nonnull String countryCode,
        @Nullable Locale communicationsLanguage, @Nullable CustomerAddress address, @Nullable String createdBy,
        @Nullable TenantId createdByTenant, @Nonnull PlaytomicUserType userType) {
        return persistOnRegister(email, password, name, phone, acceptsPrivacy, acceptsCommercial, countryCode,
            communicationsLanguage, address, null, null, createdBy, createdByTenant,
            userType);

    }

    @Nonnull
    public CustomerUserProfile persistOnRegister(@Nonnull Email email, @Nonnull @Password String password,
        @Nonnull String name, @Nullable String phone, @Nullable Boolean acceptsPrivacy,
        @Nullable Boolean acceptsCommercial, @Nonnull String countryCode,
        @Nullable Locale communicationsLanguage, @Nullable CustomerAddress address,
        @Nullable UserGender gender, @Nullable Instant birthDate, @Nullable String createdBy,
        @Nullable TenantId createdByTenant, @Nonnull PlaytomicUserType userType) {
        var userByEmail = userRepository.findUserByEmail(email.getEmail());
        UserEntity userEntity;
        if (userByEmail.isEmpty()) {
            userEntity = createNewUser(email, password, name, phone, countryCode, communicationsLanguage,
                address, gender, birthDate, createdBy, createdByTenant, acceptsPrivacy, acceptsCommercial,
                userType);
        } else {
            var existingUser = userByEmail.get();
            if (existingUser.getType() != PlaytomicUserType.ONSITE) {
                throw new EmailNotAvailableException(email);
            }
            userEntity = updateExistingAccount(existingUser, password, name, phone, acceptsPrivacy, acceptsCommercial,
                countryCode, communicationsLanguage, address, gender, birthDate);
        }
        return mapUserEntityToDomain(userEntity);
    }

    /**
     *  This is and ad-hoc method for optimizing the process of bulk imports of users linked to an ANEMONE tenant
     *  it assumes that the account is owned by the tenant ant that the tenant is type ANEMONE
     *
     */
    @Nonnull
    @Transactional
    public CustomerUserProfile persistOnRegisterForAnemoneTenantImports(
        @Nonnull Email email, @Nonnull @Password String password, @Nonnull String name, @Nullable String phone,
        @Nullable Boolean acceptsPrivacy, @Nullable Boolean acceptsCommercial, @Nonnull String countryCode,
        @Nullable Locale communicationsLanguage, @Nullable CustomerAddress address, @Nullable UserGender gender,
        @Nullable Instant birthDate, @Nonnull Tenant tenant, @Nullable String createdBy) {

        Assert.isTrue(tenant.isAnemone(), "This method is only allowed for ANEMONE tenants");

        // Save user. They are onsite by default because these users are being added by mann
        UserEntity userEntity = createNewUser(email, password, name, phone, countryCode, communicationsLanguage,
            address, gender, birthDate, createdBy, tenant.getTenantId(), acceptsPrivacy,
            acceptsCommercial, PlaytomicUserType.ONSITE);

        // Create link account entity for the user
        LinkedAccountEntity linkAccount =
            new LinkedAccountEntity(userEntity,
                tenant.getTenantId().toString(),
                userEntity.getId().toString(),
                acceptsCommercial,
                LinkingType.AUTOLINK);
        userEntity.getLinkedAccounts().add(linkAccount);
        UserEntity saved = userRepository.save(userEntity);

        return mapUserEntityToDomain(saved);
    }

    @Nonnull
    public CustomerUserProfile mapUserEntityToDomain(@Nonnull UserEntity userEntity) {
        String email = userEntity.getEmail();
        // protecting against bad data in db
        if (StringUtils.isEmpty(email)) {
            email = null;
        }

        Set<LinkedAccount> linkedAccounts = new TreeSet<>(Comparator.comparing(LinkedAccount::getTenantId));
        linkedAccounts.addAll(
            userEntity.getLinkedAccounts()
                .stream()
                .map(this::mapLinkedAccountEntityToDomain)
                .collect(Collectors.toSet()));

        Set<CoachAccount> coachAccounts = new TreeSet<>(Comparator.comparing(CoachAccount::getTenantId));
        coachAccounts.addAll(
            userEntity.getCoachAccounts()
                .stream()
                .map(this::mapCoachAccountEntityToDomain)
                .collect(Collectors.toSet()));

        Set<TenantOwnerAccount> tenantOwnerAccounts = new TreeSet<>(Comparator.comparing(TenantOwnerAccount::getTenantId));
        tenantOwnerAccounts.addAll(
            userEntity.getTenantOwnerAccounts()
                .stream()
                .map(this::mapOwnerAccountEntityToDomain)
                .collect(Collectors.toSet()));

        List<ExtendedUserRole> userRoles = new ArrayList<>();
        // By now, every user has ROLE_CUSTOMER as default
        userRoles.add(new ExtendedUserRole(PlaytomicUserRole.ROLE_CUSTOMER, TenantId.valueOf("*")));

        if (!CollectionUtils.isEmpty(userEntity.getUserRoles())) {
            userRoles.addAll(
                userEntity.getUserRoles().stream()
                    .map(userRoleEntity ->
                        new ExtendedUserRole(userRoleEntity.getUserRole(),
                            userRoleEntity.getTenantId() == null ? null : TenantId.valueOf(userRoleEntity.getTenantId())))
                    .collect(Collectors.toList())
            );
        }

        Set<TenantTag> tenantTags = new TreeSet<>(Comparator.comparing(TenantTag::getTenantId));
        if (!CollectionUtils.isEmpty(userEntity.getTenantTags())) {
            var now = clockProvider.getClock().instant();
            // Group active tenantTags by tenantId
            Map<String, List<TenantTagEntity>> tenantTagsMap = userEntity.getTenantTags().stream()
                .filter(tt -> tt.isActiveAt(now))
                .collect(Collectors.groupingBy(TenantTagEntity::getTenantId));

            // Map to domain TenantTag
            tenantTagsMap.keySet().forEach(tenantId -> {
                Set<String> tagsForTenantId = tenantTagsMap.get(tenantId).stream()
                    .map(TenantTagEntity::getTag)
                    .collect(Collectors.toCollection(() -> new TreeSet<String>(Comparator.naturalOrder())));
                Set<TenantTagDetails> tagsInfoForTenantId = tenantTagsMap.get(tenantId).stream()
                    .map(tt -> new TenantTagDetails(tt.getTag(), tt.getType(), tt.getExpiresAt()))
                    .collect(Collectors.toSet());

                tenantTags.add(new TenantTag(tagsForTenantId, tagsInfoForTenantId, TenantId.valueOf(tenantId)));
            });
        }

        // sgmoratilla: I'm forcing to get PublicUser here because there are conventions
        // that I don't want to have duplicated in code (for example, is_verified and other shared variables)
        PublicUserProfile publicUser = mapUserEntityToPublicDomain(userEntity, true, true, false);

        CustomerAddress address = userEntity.addressToDomain();

        Instant now = Instant.now(clockProvider.getClock());
        boolean expiredPremium = userEntity.getPremiumExpiresAt() == null ? false : now.isAfter(userEntity.getPremiumExpiresAt());
        // TODO: Remove this elvis operator when is_premium is not null in db.
        boolean isPremium = userEntity.getIsPremium() == null ? false : userEntity.getIsPremium();

        isPremium = isPremium && !expiredPremium;

        return new CustomerUserProfile(
            publicUser.getId(),
            publicUser.getName(),
            email,
            publicUser.isValidated(),
            publicUser.isEmailVerified(),
            publicUser.getPicture(),
            userEntity.getPhone(),
            publicUser.isPhoneVerified(),
            userEntity.isDeleted(),
            userEntity.getAcceptsPrivacyPolicy(),
            userEntity.getAcceptsCommercialCommunications(),
            linkedAccounts,
            coachAccounts,
            tenantOwnerAccounts,
            userEntity.getBirthDate() != null ? ZonedDateTime.ofInstant(userEntity.getBirthDate(), Constants.UTC) : null,
            userEntity.getGender(),
            publicUser.getBio(),
            publicUser.getCountryCode(),
            LocaleUtils.toLocale(userEntity.getCommunicationsLanguage()),
            userRoles,
            tenantTags,
            address,
            null,
            userEntity.getCreatedBy(),
            userEntity.getCreatedByTenant(),
            publicUser.getPrivacyProfile(),
            userEntity.getType(),
            isPremium
        );
    }

    @Nonnull
    private LinkedAccount mapLinkedAccountEntityToDomain(@Nonnull LinkedAccountEntity linkedAccountEntity) {
        return new LinkedAccount(
            TenantId.valueOf(linkedAccountEntity.getTenantId()),
            TenantAccountId.valueOf(linkedAccountEntity.getMerchantUserId()),
            linkedAccountEntity.getAcceptsCommercialCommunications(),
            linkedAccountEntity.getLinkingType(),
            linkedAccountEntity.getCreatedAt()
        );
    }

    @Nonnull
    private TenantOwnerAccount mapOwnerAccountEntityToDomain(@Nonnull TenantOwnerAccountEntity entity) {
        return new TenantOwnerAccount(TenantId.valueOf(entity.getTenantId()),
                                      entity.getCreatedAt(),
                                      entity.isAcceptsMarketingCommunications(),
                                      entity.isAcceptsMarketingBehaviourAnalysis(),
                                      entity.isAcceptsCxQuestionnaires(),
                                      entity.isAcceptsCxWhatsappCommunications());
    }

    @Nonnull
    private CoachAccount mapCoachAccountEntityToDomain(@Nonnull CoachAccountEntity entity) {
        return new CoachAccount(
            TenantId.valueOf(entity.getTenantId()),
            entity.getCreatedAt(),
            entity.getSportIds(),
            entity.getExperience(),
            entity.getAges(),
            entity.getDescription()
        );
    }

    @Nonnull
    public PublicUserProfile mapUserEntityToPublicDomain(
        @Nonnull UserEntity userEntity,
        boolean includeEmail,
        boolean includePhone,
        boolean includeFacebookId) {

        UserId id = UserLegacy.valueOf(userEntity.getId());
        String name = userEntity.getFullName();

        URL picture = customerProfileImageUrlGenerator.generatePublicProfilePictureUrl(userEntity);
        boolean isPhoneVerified = userEntity.isPhoneVerified();
        boolean isEmailVerified = userEntity.isEmailVerified();

        // sgmoratilla. We are going to regret this in the future.
        boolean isValidated = isEmailVerified;
        String bio = userEntity.getBio();
        Locale communicationsLanguage = UserProfile.generateCommunicationsLanguage(userEntity.getCountryCode());
        String countryCode = userEntity.getCountryCode();

        String email = includeEmail ? userEntity.getEmail() : null;
        String phone = includePhone ? userEntity.getPhone() : null;
        String facebookId = includeFacebookId ? userEntity.getFacebookId() : null;
        final PublicCustomerAddress address = new PublicCustomerAddress(userEntity.addressToDomain());

        PrivacyProfile privacyProfile = userEntity.getPrivacyProfile();
        boolean isPremium = userEntity.getIsPremium() == null ? false : userEntity.getIsPremium();

        return new PublicUserProfile(id, name, picture, isValidated, isEmailVerified,
            isPhoneVerified, bio, communicationsLanguage, countryCode, email, phone, facebookId, address,
            privacyProfile, isPremium);
    }

    @Nonnull
    private UserProfile registerThirdPartyUser(@Nullable Email email, @Nonnull String fullName, boolean isEmailVerified,
        @Nullable String facebookId, @Nullable String googleId, @Nullable String appleId,
        @Nullable String phone, @Nonnull String countryCode,
        @Nullable Boolean acceptsPrivacy, @Nullable Boolean acceptsCommercial,
        @Nullable CustomerAddress address, @Nullable String createdBy)
        throws EmailNotAvailableException, PhoneNotAvailableException {

        UserEntity userEntity;

        if (email != null) {
            Optional<UserEntity> possibleUser = userRepository.findUserByEmail(email.getEmail());
            if (possibleUser.isPresent()) {
                // If the user already exists with that e-mail and it is verified in third party, we allow it,
                // since we understand it's the same person with access to that e-mail.
                // If it is not verified, we raise an EmailNotAvailableException, as it could be another person
                // trying to gain access to the account.
                if (!isEmailVerified) {
                    throw new EmailNotAvailableException(email);
                }

                userEntity = possibleUser.get();
                // The user already existed but since they didn't have their Facebook id, we should set it.
                if (facebookId != null) {
                    userEntity.setFacebookId(facebookId);
                }
                if (googleId != null) {
                    userEntity.setGoogleId(googleId);
                }
                if (appleId != null) {
                    userEntity.setAppleId(appleId);
                }
                userEntity.setEmailVerified(true);
            } else {
                if (phone != null && isPhoneInUse(phone)) {
                    throw new PhoneNotAvailableException(phone);
                }
                // Mail not registered, all good, so we register the Facebook guy.
                String strEmail = email.getEmail();
                userEntity =
                    new UserEntity(fullName,
                        userCredentialService.hashPassword(PasswordGenerator.generate()),
                        strEmail,
                        isEmailVerified,
                        phone,
                        false,
                        acceptsPrivacy,
                        acceptsCommercial,
                        facebookId,
                        googleId,
                        appleId,
                        countryCode,
                        address,
                        null,
                        PlaytomicUserType.ONLINE);

                if (!isEmailVerified) {
                    // FixMe - This is required until communications_language is persisted and not calculated from country_code
                    Locale userLocale = UserProfile.generateCommunicationsLanguage(userEntity.getCountryCode());
                    userCredentialService.sendValidationEmail(email, userLocale, null);
                }
            }
        } else {
            // If the third party user has no e-mail, we accept it with a null e-mail and a not verified status.
            // We accept it because the user can keep logging on with e-mail, and we have to support that
            // even if the third party user only has a phone number. Corner case though.
            // I'm not proud of this code and I acknowledge the overall subpar quality of this process.
            userEntity = new UserEntity(fullName, userCredentialService.hashPassword(PasswordGenerator.generate()),
                null, false,
                null, false,
                null, null,
                facebookId, googleId, appleId,
                countryCode, address, null,  PlaytomicUserType.ONLINE);
        }

        userEntity.setCreatedBy(createdBy);

        userEntity = userRepository.save(userEntity);

        log.info("User Entity" + userEntity);

        GdprAuditEntity
            gdprAuditEntity =
            new GdprAuditEntity(userEntity.getId(), null, null, "Account creation");
        gdprAuditRepository.save(gdprAuditEntity);

        return mapUserEntityToDomain(userEntity);
    }

    @Nonnull
    public UserProfile addUserRoles(@Nonnull UserId userId, @Nonnull Collection<ExtendedUserRole> userRoles, boolean sendNotification) {
        UserEntity userEntity = userRepository.findById(UserLegacy.asSafeLong(userId))
            .orElseThrow(UserNotFoundException::new);

        boolean existing = userRoles.stream()
            .anyMatch(
                extendedUserRole -> userEntity.getUserRoles().stream()
                    .anyMatch(userRoleEntity -> {
                        if (userRoleEntity.getUserRole().equals(extendedUserRole.getUserRole())) {
                            return extendedUserRole.getTenantId() == null ?
                                userRoleEntity.getTenantId() == null :
                                extendedUserRole.getTenantId().getValue()
                                    .equals(userRoleEntity.getTenantId());
                        }
                        return false;
                    })
            );

        if (existing) {
            log.trace("Role already present. Nothing to change.");
            return mapUserEntityToDomain(userEntity);
        } else {

            Set<String> tenantIds = new HashSet<>();

            userEntity.getUserRoles().addAll(userRoles.stream()
                .map(role -> new UserRoleEntity(userEntity,
                    role.getUserRole(),
                    role.getTenantId() == null ? null : role.getTenantId().getValue()))
                .peek(role -> tenantIds.add(role.getTenantId()))
                .collect(Collectors.toSet())
            );

            // If all the roles are for the same tenant and there is only a single tenant
            // send notifications otherwise don't.
            if (sendNotification && tenantIds.size() == 1) {
                boolean hasManagerRole = userRoles.stream()
                    .map(ExtendedUserRole::getUserRole)
                    .anyMatch(role -> role == PlaytomicUserRole.ROLE_ACTIVITY_MANAGER
                        || role == PlaytomicUserRole.ROLE_TENANT_MANAGER);
                //send email if all the new roles are for the same tenant and the newly added roles are of manager type.
                String tenantId = tenantIds.iterator().next();
                String allTenantManagerId = "*";
                if (hasManagerRole && !allTenantManagerId.equals(tenantId)) {
                    Tenant tenant = tenantService.getById(TenantId.valueOf(tenantId));
                    userCredentialService.sendManagerRoleAssignedEmail(userEntity.getEmail(),
                        userEntity.getCommunicationsLanguageLocale(), tenant);
                }
            }

            UserEntity saved = userRepository.save(userEntity);
            return mapUserEntityToDomain(saved);
        }
    }

    @Nonnull
    public UserProfile removeUserRole(@Nonnull UserId userId, @Nonnull PlaytomicUserRole userRole, @Nullable List<TenantId> tenantIds) {
        UserEntity userEntity = userRepository.findById(UserLegacy.asSafeLong(userId))
            .orElseThrow(UserNotFoundException::new);

        Set<UserRoleEntity> userRolesToRemove = userEntity.getUserRoles()
            .stream()
            .filter(role -> role.getTenantId() != null)
            .filter(role -> role.getUserRole().equals(userRole) )
            .filter(role -> tenantIds == null || tenantIds.contains(TenantId.valueOf(role.getTenantId())))
            .collect(Collectors.toSet());

        Set<UserRoleEntity> newUserRoles = new HashSet<>(userEntity.getUserRoles());
        newUserRoles.removeAll(userRolesToRemove);
        userEntity.setUserRoles(newUserRoles);

        userRolesToRemove.forEach(entityManager::remove);

        //Now we also remove tenant owner relation when manager relation is removed
        Iterator<TenantOwnerAccountEntity> ownerAccountsIterator = userEntity.getTenantOwnerAccounts().iterator();
        while (ownerAccountsIterator.hasNext()) {
            TenantOwnerAccountEntity account = ownerAccountsIterator.next();
            if (tenantIds == null || tenantIds.contains(TenantId.valueOf(account.getTenantId()))) {
                ownerAccountsIterator.remove();
                entityManager.remove(account);
            }
        }

        UserEntity saved = userRepository.save(userEntity);
        return mapUserEntityToDomain(saved);
    }

    private void changePhone(@Nonnull UserEntity userEntity, @Nonnull String phone)
        throws PhoneNotAvailableException {
        if (phone.equalsIgnoreCase(userEntity.getPhone())) {
            return;
        }
        if (isPhoneInUse(phone)) {
            log.info("Change phone failed because the phone {} is already in use and verified by other user", phone);
            throw new PhoneNotAvailableException(phone);
        }
        userEntity.setPhone(phone);
        userEntity.setPhoneVerified(false);
    }

    private void validateEmail(@Nonnull UserEntity userEntity, @Nonnull String emailToken) {
        log.info("Validating user {}:", userEntity.getEmail());
        Email email = userCredentialService.decodeEmail(emailToken);
        if (email.getEmail().equalsIgnoreCase(userEntity.getEmail())) {
            userEntity.setEmailVerified(true);
        }
    }

    @Nonnull
    /**
     * This method returns the list of colaterally updated users, note that users with same validates phone will lose validation
     */
    private List<CustomerUserProfile> validatePhone(@Nonnull UserEntity userEntity, @Nonnull String phoneToken)
            throws InvalidPhoneTokenException, InterruptedException {

        Thread.sleep(100); // Prevent brute-force attack

        if (!userCredentialService.isVerifiedPhone(userEntity.getPhone(), phoneToken)) {
            log.info("Validate phone failed because the provided token is not correct for {}", userEntity.getPhone());
            throw new InvalidPhoneTokenException();
        }
        userEntity.setPhoneVerified(true);

        // Nullify all other phones from users using the same. This is required because we allow multiple accounts to
        // add the same number, but only one can be verified. Once one gets verified, the rest must be removed
        List<UserEntity> allOtherUsersByPhone = userRepository.findAllForUpdateByPhone(userEntity.getPhone())
            .stream()
            .filter(user -> !user.getId().equals(userEntity.getId()))
            .collect(Collectors.toList());
        allOtherUsersByPhone.forEach(user -> user.setPhone(null));
        Iterable<UserEntity> savedEntities = userRepository.saveAll(allOtherUsersByPhone);

        return StreamSupport.stream(savedEntities.spliterator(), false)
            .map(e -> mapUserEntityToDomain(e))
            .collect(Collectors.toList());
    }

    @Nullable
    private UserProfile addLinkedAccount(@Nonnull UserEntity userEntity,
        @Nonnull TenantId tenantId,
        @Nonnull MerchantUserId merchantUserId,
        @Nullable Boolean acceptsCommercial,
        @Nonnull LinkingType linkingType) {

        Optional<LinkedAccountEntity> existing =
            userEntity.getLinkedAccounts()
                .stream()
                .filter(a -> a.getTenantId().equals(tenantId.getValue()))
                .findFirst();

        if (existing.isPresent()) {
            LinkedAccountEntity entity = existing.get();
            if (!entity.getMerchantUserId().equals(merchantUserId.getValue())) {
                log.info("Updating linked account (tenant_id {}, merchant_user_id {}) to user_id {}", tenantId,
                    merchantUserId, userEntity.getId());

                entity.setMerchantUserId(merchantUserId.getValue());
                UserEntity saved = userRepository.save(userEntity);
                return mapUserEntityToDomain(saved);
            } else {
                return null;
            }
        } else {
            log.info("Adding linked account (tenant_id {}, merchant_user_id {}) to user_id {}", tenantId,
                merchantUserId, userEntity.getId());

            LinkedAccountEntity linkAccount =
                new LinkedAccountEntity(userEntity,
                    tenantId.toString(),
                    merchantUserId.toString(),
                    acceptsCommercial,
                    linkingType);

            userEntity.getLinkedAccounts().add(linkAccount);
            UserEntity saved = userRepository.save(userEntity);
            return mapUserEntityToDomain(saved);
        }
    }

    private boolean changeEmail(@Nonnull UserEntity userEntity, @Nonnull Email email)
        throws EmailNotAvailableException {
        if (email.getEmail().equalsIgnoreCase(userEntity.getEmail())) {
            return false;
        }

        if (userRepository.findUserByEmail(email.getEmail()).isPresent()) {
            throw new EmailNotAvailableException(email);
        }

        userEntity.setEmail(email.getEmail());
        userEntity.setEmailVerified(false);

        return true;
    }

    @Nonnull
    public UserProfile registerFacebookUser(@Nonnull FacebookUserData facebookUserData, @Nullable String phone,
        @Nonnull String countryCode, @Nullable Boolean acceptsPrivacy,
        @Nullable Boolean acceptsCommercial, boolean withWelcomeVoucher, @Nullable String createdBy)
        throws EmailNotAvailableException, PhoneNotAvailableException {

        log.info("Sign-up from facebook login. email {}", facebookUserData.getEmail());

        Optional<UserEntity> userOpt = userRepository.findUserByFacebookId(facebookUserData.getFacebookId().getValue());

        UserProfile user;
        if (userOpt.isPresent()) {
            user = mapUserEntityToDomain(userOpt.get());
        } else {
            user = registerThirdPartyUser(
                facebookUserData.getEmail(),
                facebookUserData.getUsername(),
                facebookUserData.isVerified(),
                facebookUserData.getFacebookId().getValue(),
                null,
                null,
                phone,
                countryCode,
                acceptsPrivacy,
                acceptsCommercial,
                null, createdBy);

            if (withWelcomeVoucher) {
                voucherService.createVoucher(registrationVoucherConfiguration.getWelcomeSearchId(), user.getCountryCode(), user.getId());
            }
        }

        return user;
    }

    @Nonnull
    public UserProfile registerGoogleUser(GoogleUserData googleUserData, @Nullable String phone, @Nonnull String countryCode,
        @Nullable Boolean acceptsPrivacy,
        @Nullable Boolean acceptsCommercial, boolean withWelcomeVoucher, @Nullable String createdBy)
        throws EmailNotAvailableException, PhoneNotAvailableException {

        log.info("Sign-up from google login. email {}", googleUserData.getEmail());

        Optional<UserEntity> userOpt = userRepository.findUserByGoogleId(googleUserData.getGoogleId().getValue());

        UserProfile user;
        if (userOpt.isPresent()) {
            user = mapUserEntityToDomain(userOpt.get());
        } else {
            user = registerThirdPartyUser(
                googleUserData.getEmail(),
                googleUserData.getUsername(),
                googleUserData.isVerified(),
                null,
                googleUserData.getGoogleId().getValue(),
                null,
                phone,
                countryCode,
                acceptsPrivacy,
                acceptsCommercial,
                null, createdBy);

            if (withWelcomeVoucher) {
                voucherService.createVoucher(registrationVoucherConfiguration.getWelcomeSearchId(), user.getCountryCode(), user.getId());
            }
        }

        return user;
    }

    @Nonnull
    public UserProfile registerAppleUser(@Nonnull AppleUserData appleUserData,
        @NonNull String fullName, @Nullable String phone, @Nonnull String countryCode,
        @Nullable Boolean acceptsPrivacy, @Nullable Boolean acceptsCommercial, boolean withWelcomeVoucher, @Nullable String createdBy)
        throws EmailNotAvailableException, PhoneNotAvailableException {

        log.info("Sign-up from apple login. email {}", appleUserData.getEmail());

        Optional<UserEntity> userOpt = userRepository.findUserByAppleId(appleUserData.getAppleId().getValue());

        UserProfile user;
        if (userOpt.isPresent()) {
            user = mapUserEntityToDomain(userOpt.get());
        } else {
            user = registerThirdPartyUser(
                appleUserData.getEmail(),
                fullName,
                appleUserData.isVerified(),
                null,
                null,
                appleUserData.getAppleId().getValue(),
                phone,
                countryCode,
                acceptsPrivacy,
                acceptsCommercial,
                null, createdBy);

            if (withWelcomeVoucher) {
                voucherService.createVoucher(registrationVoucherConfiguration.getWelcomeSearchId(), user.getCountryCode(), user.getId());
            }
        }

        return user;
    }

    @Nonnull
    public CustomerUserProfile registerEmailUser(@Nonnull Email email, @Nonnull @Password String password, @Nonnull String name,
        @Nullable String phone, @Nullable Boolean acceptsPrivacy,
        @Nullable Boolean acceptsCommercial, @Nonnull String countryCode,
        @Nullable CustomerAddress address, @Nullable Locale communicationsLanguage,
        boolean withWelcomeVoucher, @Nullable String createdBy, @Nullable TenantId tenantId,
        @Nonnull Collection<ExtendedUserRole> userRoles) {
        log.info("Sign-up with email {}", email);
        CustomerUserProfile user =
            tenantId  == null ? registerSelfRegisteredUser(email, password, name, phone, acceptsPrivacy, acceptsCommercial, countryCode, address,
                communicationsLanguage, createdBy)
                : registerUserCreatedByTenant(email, password, name, phone, acceptsPrivacy, acceptsCommercial, countryCode, address,
                    communicationsLanguage, createdBy, tenantId, userRoles);

        if (withWelcomeVoucher) {
            voucherService.createVoucher(registrationVoucherConfiguration.getWelcomeSearchId(), user.getCountryCode(), user.getId());
        }

        return user;
    }

    @Nonnull
    private CustomerUserProfile registerSelfRegisteredUser(@Nonnull Email email, @Nonnull @Password  String password, @Nonnull String name, @Nullable String phone,
        @Nullable Boolean acceptsPrivacy, @Nullable Boolean acceptsCommercial, @Nonnull String countryCode, @Nullable CustomerAddress address,
        @Nullable Locale communicationsLanguage, @Nullable String createdBy) {

        PlaytomicUserType userType =
            createdBy != null ? PlaytomicUserType.ONSITE : PlaytomicUserType.ONLINE;

        CustomerUserProfile user = persistOnRegister(email, password, name, phone, acceptsPrivacy, acceptsCommercial, countryCode,
            communicationsLanguage, address, createdBy, null, userType);
        userCredentialService.sendWelcomeEmail(email, user.getCommunicationsLanguage());
        return user;
    }

    @Nonnull
    @Transactional
    public CustomerUserProfile registerImportedEmailUser(
        @Nonnull Email email, @Nonnull @Password String password, @Nonnull String name, @Nullable String phone,
        @Nullable Boolean acceptsPrivacy, @Nullable Boolean acceptsCommercial, @Nonnull String countryCode,
        @Nullable CustomerAddress address, @Nullable UserGender gender, @Nullable Instant birthdate,
        @Nullable Locale communicationsLanguage, @Nonnull Tenant tenant, @Nullable String createdBy) {
        log.debug("Import user with email {}", email);
        return persistOnRegisterForAnemoneTenantImports(email, password, name, phone, acceptsPrivacy, acceptsCommercial, countryCode,
            communicationsLanguage, address, gender, birthdate, tenant, createdBy);
    }

    @Data
    @AllArgsConstructor
    static class CustomerUpdateResult {
        @Nonnull
        CustomerUserProfile userProfile;

        boolean emailChanged;

        @Nonnull
        List<CustomerUserProfile> otherUserProfilesThatChanged;
    }

    @Nonnull
    public CustomerUpdateResult updateCustomer(@Nonnull UserId userId,
                                               @Nullable Email email,
                                               @Nullable String emailToken,
                                               @Nullable String fullName,
                                               @Nullable String newPassword,
                                               @Nullable String phone,
                                               @Nullable String phoneToken,
                                               @Nullable Boolean acceptsPrivacy,
                                               @Nullable Boolean acceptsCommercial,
                                               @Nullable UserGender gender,
                                               @Nullable ZonedDateTime birthDate,
                                               @Nullable String bio,
                                               @Nullable String countryCode,
                                               @Nullable Locale communicationsLanguage,
                                               @Nullable Boolean isEmailVerified,
                                               @Nullable Boolean isPhoneVerified,
                                               @Nullable CustomerAddress address,
                                               @Nullable PrivacyProfile privacyProfile) throws InterruptedException {
        log.info("Updating customer profile. user_id {}", userId);
        List<CustomerUserProfile> collateralChanges = Collections.emptyList();

        UserEntity userEntity =
            userRepository
                .findOneForUpdateById(UserLegacy.asSafeLong(userId))
                .orElseThrow(UserNotFoundException::new);
        entityManager.refresh(userEntity);

        boolean isEmailUpdated = false;
        if (email != null) {
            isEmailUpdated = changeEmail(userEntity, email);
        }

        if (emailToken != null) {
            validateEmail(userEntity, emailToken);
        }

        if (phone != null) {
            changePhone(userEntity, phone);
        }

        if (phoneToken != null) {
            collateralChanges = validatePhone(userEntity, phoneToken);
        }

        if (fullName != null) {
            userEntity.setFullName(fullName);
        }

        if (newPassword != null) {
            PasswordValidator.validate(newPassword, PasswordValidationMode.ALL);
            userEntity.setPasswordHash(userCredentialService.hashPassword(newPassword));
        }

        if (birthDate != null) {
            userEntity.setBirthDate(birthDate.toInstant());
        }

        if (gender != null) {
            userEntity.setGender(gender);
        }

        if (bio != null) {
            userEntity.setBio(StringUtils.abbreviate(bio, MAX_WIDTH_BIO));
        }

        if (countryCode != null) {
            userEntity.setCountryCode(countryCode);
        }

        if (communicationsLanguage != null) {
            userEntity.setCommunicationsLanguage(communicationsLanguage);
        }

        if (acceptsPrivacy != null) {
            userEntity.setAcceptsPrivacyPolicy(acceptsPrivacy);
        }

        if (acceptsCommercial != null) {
            userEntity.setAcceptsCommercialCommunications(acceptsCommercial);
        }

        if (acceptsPrivacy != null || acceptsCommercial != null) {
            GdprAuditEntity
                gdprAuditEntity =
                new GdprAuditEntity(
                    userEntity.getId(),
                    userEntity.getAcceptsPrivacyPolicy(),
                    userEntity.getAcceptsCommercialCommunications(),
                    map.get(new GdprSettingsKey(acceptsPrivacy, acceptsCommercial)));
            gdprAuditRepository.save(gdprAuditEntity);
        }

        if (isEmailVerified != null) {
            userEntity.setEmailVerified(isEmailVerified);
        }

        if (isPhoneVerified != null) {
            userEntity.setPhoneVerified(isPhoneVerified);
        }

        if (address != null) {
            userEntity.setAddressStreet(address.getStreet());
            userEntity.setAddressZipCode(address.getZipCode());
            userEntity.setAddressCity(address.getCity());
            userEntity.setAddressState(address.getState());
        }

        if (privacyProfile != null) {
            userEntity.setPrivacyProfile(privacyProfile);
        }

        userEntity = userRepository.save(userEntity);

        CustomerUserProfile domain = mapUserEntityToDomain(userEntity);
        return new CustomerUpdateResult(domain, isEmailUpdated, collateralChanges);
    }

    /**
     * @param pictureBase64 the base64 codification of the image, or null to remove it.
     */
    @Nonnull
    public CustomerUserProfile updatePicture(@Nonnull UserId userId, @Nullable String pictureBase64) {

        log.info("Updating customer profile photo. user_id {}", userId);

        // Change this method in 2038.
        // Cloudinary: don't use extension, because files are "agnostic" of the format when
        // uploaded to cloudinary. That is, you can request .jpg, or .png or whatever.
        final String PROFILE_FILENAME = String.valueOf(System.currentTimeMillis());
        UserEntity userEntity = userRepository
                .findById(UserLegacy.asSafeLong(userId))
                .orElseThrow(UserNotFoundException::new);

        String previousPhoto = userEntity.getProfilePhotoFilename();

        // First we create the new file (if required, if not, unset it), then we store the change in the entity.
        if (pictureBase64 != null) {
            try {
                cloudinaryService.uploadImages(PROFILE_FILENAME, pictureBase64, "users/" + userId.toString());
            } catch (IOException e) {
                throw new CustomerProfileImageNotSaveException(e);
            }
            userEntity.setProfilePhotoFilename(PROFILE_FILENAME);
        } else {
            userEntity.setProfilePhotoFilename(null);
        }
        userEntity = userRepository.save(userEntity);

        // After the new picture is set, delete the previous one, if any.
        if (!StringUtils.isEmpty(previousPhoto)) {
            removePicture(userId, previousPhoto);
        }

        return mapUserEntityToDomain(userEntity);
    }

    public void removePicture(@Nonnull UserId userId, @Nonnull String filename) {
        try {
            cloudinaryService.deleteImage(filename, "users/" + userId.toString());
        } catch (IOException e) {
            // don't break the uploading because we couldn't delete the previous image.
            log.error("Couldn't delete previous image for user {}", userId);
            throw new CustomerProfileImageNotSaveException(e);
        }
    }

    public void removeUser(@Nonnull UserId userId) {
        userRepository.deleteById(UserLegacy.asSafeLong(userId));
    }

    /**
     * This is equivalent to doing a login and then use the found user to create a link.
     * Only will work for syltek venues.
     */
    @Nullable
    public UserProfile linkTenantWithEmailAndPassword(@Nonnull UserId userId,
        @Nonnull TenantId tenantId,
        @Nonnull Email email,
        @Nonnull String password,
        @Nullable Boolean acceptsCommercial) {
        UserEntity userEntity =
            userRepository
                .findById(UserLegacy.asSafeLong(userId))
                .orElseThrow(UserNotFoundException::new);

        // We are not checking user.isValidate here because she is already specifying her credentials.

        PadelclickTenant padelclickTenant = toPadelclickTenant(tenantId);

        try {
            PadelclickUserAccount
                padelclickUserAccount =
                padelclickService.validateAccount(padelclickTenant, email, password);
            if (acceptsCommercial != null) {
                PadelclickTenantAccountId
                    tenantAccountId =
                    PadelclickTenantAccountId.valueOf(padelclickUserAccount.getSyltekUserId().toString());
                padelclickService.setCustomerCommunications(padelclickTenant, tenantAccountId, acceptsCommercial);
            }

            UserProfile result = addLinkedAccount(userEntity, tenantId, MerchantUserId.valueOf(padelclickUserAccount.getSyltekUserId()),
                acceptsCommercial,
                LinkingType.MANUAL_LINK);

            log.info("Linked tenant {} to customer user_id {}", tenantId, userId);
            return result;
        } catch (PadelclickGenericException | PadelclickRegisterCustomerException e) {
            log.info("Failed trying to link tenant {} to customer user_id {}", tenantId, userId);

            throw new LinkAccountValidateException(e.getMessage());
        }
    }

    @Nonnull
    public CoachAccount putCoachAccount(
        @Nonnull UserId userId,
        @Nonnull TenantId tenantId,
        @Nonnull LinkCoachAccountData data)
        throws UserNotFoundException {

        UserEntity userEntity =
            userRepository
                .findById(UserLegacy.asSafeLong(userId))
                .orElseThrow(UserNotFoundException::new);

        CoachAccountEntity account = userEntity.findCoachAccount(tenantId);
        if (account != null) {
            account.setSportIds(data.getSportIds());
            account.setAges(data.getAges());
            account.setDescription(data.getDescription());
            account.setExperience(data.getExperience());
        } else {
            account = new CoachAccountEntity(
                UUID.randomUUID().toString(),
                userEntity, tenantId.getValue(), data.getSportIds(),
                data.getExperience(), data.getAges(), data.getDescription());

            userEntity.getCoachAccounts().add(account);
        }

        UserEntity saved = userRepository.save(userEntity);

        log.info("Coach account added to tenant {} to customer user_id {}", tenantId, userId);
        return mapCoachAccountEntityToDomain(account);
    }

    @Nullable
    public UserProfile linkTenant(@Nonnull UserId userId, @Nonnull Tenant tenant, @Nonnull MerchantUserId merchantUserId, @Nullable Boolean acceptsCommercial) {
        UserEntity userEntity =
            userRepository
                .findById(UserLegacy.asSafeLong(userId))
                .orElseThrow(UserNotFoundException::new);

        // Not checking if the user is validated, because we know the merchantUserId here.
        return addLinkedAccount(userEntity, tenant.getTenantId(), merchantUserId, acceptsCommercial, LinkingType.AUTOLINK);
    }

    @Nonnull
    protected PadelclickTenant toPadelclickTenant(@Nonnull TenantId tenantId) {
        Tenant tenant = tenantService.getById(tenantId.toString());
        if (!tenant.isSyltekCrm()) {
            log.info("This tenant is not a SyltekCrm tenant, linking unsupported.");
            throw new TenantNotFoundException(tenantId);
        }

        PadelclickTenant padelclickTenant = UserService.toPadelclick(tenant);

        return padelclickTenant;
    }

    @Nonnull
    public UserProfile createTenantTags(@Nonnull UserId userId, @Nonnull TenantTag tenantTag) {
        UserEntity userEntity = userRepository
            .findOneForUpdateById(UserLegacy.asSafeLong(userId))
            .orElseThrow(UserNotFoundException::new);
        entityManager.refresh(userEntity);

        return createTenantTags(userEntity, tenantTag);
    }

    @Nonnull
    public UserProfile createTenantTags(@Nonnull UserEntity userEntity, @Nonnull TenantTag tenantTag) {
        UserEntity updatedEntity = tenantTagsComponent.createTenantTags(userEntity, tenantTag);
        return mapUserEntityToDomain(updatedEntity);
    }

    @Nonnull
    public UserProfile updateTenantTags(@Nonnull UserId userId, @Nonnull Set<TenantTag> tenantTags) {
        UserEntity updatedEntity = tenantTagsComponent.setTenantTags(userId, tenantTags);
        return mapUserEntityToDomain(updatedEntity);
    }

    @Nonnull
    public UserProfile updateTenantTagsForTenantId(@Nonnull UserId userId, @Nonnull TenantId tenantId, @Nonnull Set<String> tenantTags) {
        TenantTag tenantTag = new TenantTag(tenantTags, new HashSet<>(), tenantId);
        UserEntity updatedEntity = tenantTagsComponent.setTenantTagsForTenant(userId, tenantTag);
        return mapUserEntityToDomain(updatedEntity);
    }

    @Nonnull
    public UserProfile removeTenantTags(@Nonnull UserId userId, @Nullable Set<String> tenantTags, @Nonnull TenantId tenantId) {
        UserEntity updatedUser = tenantTagsComponent.removeTenantTags(userId, tenantTags, tenantId);
        return mapUserEntityToDomain(updatedUser);
    }


    /**
     * This operation internally calculates the user linking. Does not apply to anemone venues.
     */
    @Nullable
    public UserProfile autolinkTenant(@Nonnull UserId userId, @Nonnull Tenant tenant) {
        //Auto link only makes sense for syltek CRM venues that can locate related accounts
        if (tenant.isSyltekCrm()) {
            return autolinkTenantSyltekCrmInternal(userId, tenant);
        }

        //Autolink is never executed for other venues, only user registration in tenant
        //Just return profile
        throw new AutoLinkAccountAtAnemoneVenueException("Accounts can't be auto-linked in anemone venues");
    }

    @Nullable
    private UserProfile autolinkTenantSyltekCrmInternal(@Nonnull UserId userId, @Nonnull Tenant tenant) {
        Assert.isTrue(tenant.isSyltekCrm(), "This tenant must be syltek's to use this method");
        UserEntity userEntity = userRepository
                .findOneForUpdateById(UserLegacy.asSafeLong(userId))
                .orElseThrow(UserNotFoundException::new);

        entityManager.refresh(userEntity);

        PadelclickTenant padelclickTenant = UserService.toPadelclick(tenant);

        UserProfile user = mapUserEntityToDomain(userEntity);
        if (!user.isValidated()) {
            throw new LinkAccountValidateException("User is not validated");
        }

        if (user.getEmail() == null || !EmailValidator.isValid(user.getEmail())) {
            throw new LinkAccountValidateException("No email provided");
        }

        Email email = new Email(user.getEmail());

        try {
            PadelclickUser padelclickUser = padelclickService.findCustomer(padelclickTenant, email);
            UserProfile newUser = addLinkedAccount(userEntity, tenant.getTenantId(), MerchantUserId.valueOf(padelclickUser.getIdCustomer()),
                null, LinkingType.AUTOLINK);

            createTenantTags(userEntity, new TenantTag(
                Collections.singleton(SYLTEK_CUSTOMER_TYPE_PREFIX + padelclickUser.getDetail().getIdCustomerType()),
                Collections.singleton(new TenantTagDetails(SYLTEK_CUSTOMER_TYPE_PREFIX + padelclickUser.getDetail().getIdCustomerType(), null, null)),
                tenant.getTenantId()));

            log.info("Autolink: linked tenant {} to customer user_id {}", tenant.getTenantId(), userId);

            return newUser;
        } catch (PadelclickFindCustomerException | PadelclickGenericException e) {
            log.info("Autolink: failed trying to link tenant {} to customer user_id {}", tenant.getTenantId(), userId);

            throw new LinkAccountValidateException(e.getMessage());
        }
    }

    @Nullable
    public UserProfile registerUserInTenant(@Nonnull UserId userId, @Nonnull Tenant tenant) {
        if (tenant.isAnemone()) {
            //For anemone venues we directly create the link
            return linkTenant(userId, tenant, MerchantUserId.valueOf(userId.getValue()), null);
        } else {
            UserEntity userEntity = userRepository
                .findOneForUpdateById(UserLegacy.asSafeLong(userId))
                .orElseThrow(UserNotFoundException::new);
            entityManager.refresh(userEntity);

            PadelclickTenant padelclickTenant = toPadelclickTenant(tenant.getTenantId());

            UserProfile user = mapUserEntityToDomain(userEntity);
            if (!user.isValidated()) {
                throw new LinkAccountRegisterException("User is not validated");
            }

            if (user.getEmail() == null || !EmailValidator.isValid(user.getEmail())) {
                throw new LinkAccountRegisterException("No email provided");
            }

            try {
                Email email = new Email(user.getEmail());

                PadelclickUser padelclickUser = padelclickService.registerCustomer(padelclickTenant, email, user.getName());
                addLinkedAccount(userEntity, tenant.getTenantId(), MerchantUserId.valueOf(padelclickUser.getIdCustomer()), null,
                    LinkingType.AUTOREGISTER);

                UserProfile result = createTenantTags(userEntity, new TenantTag(
                    Collections.singleton(SYLTEK_CUSTOMER_TYPE_PREFIX + padelclickUser.getDetail().getIdCustomerType()),
                    Collections.singleton(new TenantTagDetails(SYLTEK_CUSTOMER_TYPE_PREFIX + padelclickUser.getDetail().getIdCustomerType(), null, null)),
                    tenant.getTenantId()));

                log.info("Autoregister: linked tenant {} to customer user_id {}", tenant.getTenantId(), userId);
                return result;
            } catch (PadelclickRegisterCustomerException | PadelclickGenericException e) {
                log.info("Autoregister: failed trying to link tenant {} to customer user_id {}: {}", tenant.getTenantId(), userId, e.getMessage());

                throw new LinkAccountRegisterException(e.getMessage());
            }
        }
    }

    @Transactional
    @Nonnull
    public UserProfile unlinkTenant(@Nonnull UserId userId, @Nonnull TenantId tenantId) {
        log.info("Un-linking tenant {} from customer user_id {}", tenantId, userId);

        UserEntity userEntity =
            userRepository
                .findById(UserLegacy.asSafeLong(userId))
                .orElseThrow(UserNotFoundException::new);

        Set<LinkedAccountEntity> accountsToRemove = userEntity.getLinkedAccounts()
            .stream()
            .filter(linkedAccount -> linkedAccount.getTenantId().equals(tenantId.toString()))
            .collect(Collectors.toSet());

        Set<LinkedAccountEntity> newAccounts = new HashSet<>(userEntity.getLinkedAccounts());
        newAccounts.removeAll(accountsToRemove);
        userEntity.setLinkedAccounts(newAccounts);

        accountsToRemove.forEach(entityManager::remove);
        userEntity = userRepository.save(userEntity);
        return mapUserEntityToDomain(userEntity);
    }

    @Transactional
    @Nonnull
    public UserProfile deleteCoachAccount(@Nonnull UserId userId, @Nonnull TenantId tenantId) {
        log.info("Deleting coach account for tenant {} from customer user_id {}", tenantId, userId);

        UserEntity userEntity =
            userRepository
                .findById(UserLegacy.asSafeLong(userId))
                .orElseThrow(UserNotFoundException::new);

        Set<CoachAccountEntity> accountsToRemove = userEntity.getCoachAccounts()
            .stream()
            .filter(linkedAccount -> linkedAccount.getTenantId().equals(tenantId.toString()))
            .collect(Collectors.toSet());

        Set<CoachAccountEntity> newAccounts = new HashSet<>(userEntity.getCoachAccounts());
        newAccounts.removeAll(accountsToRemove);
        userEntity.setCoachAccounts(newAccounts);

        accountsToRemove.forEach(entityManager::remove);
        userEntity = userRepository.save(userEntity);
        return mapUserEntityToDomain(userEntity);
    }

    @Nonnull
    public TenantOwnerAccount putTenantOwnerAccount(@Nonnull UserId userId, @Nonnull TenantId tenantId) {
        UserEntity userEntity =
            userRepository
                .findById(UserLegacy.asSafeLong(userId))
                .orElseThrow(UserNotFoundException::new);

        TenantOwnerAccountEntity account = userEntity.findOwnerAccount(tenantId);
        if (account == null) {
            account = new TenantOwnerAccountEntity(UUID.randomUUID().toString(), userEntity, tenantId.getValue(), false, false, false, false);
            userEntity.getTenantOwnerAccounts().add(account);
        }

        UserEntity saved = userRepository.save(userEntity);

        log.info("Tenant owner account added to tenant {} to customer user_id {}", tenantId, userId);
        return mapOwnerAccountEntityToDomain(account);
    }

    @Transactional
    @Nonnull
    public CustomerUserProfile updateTenantOwnerAccount(@Nonnull UserId userId,
                                                        @Nonnull TenantId tenantId,
                                                        @Nullable final Boolean acceptsMarketingCommunications,
                                                        @Nullable final Boolean acceptsMarketingBehaviourAnalysis,
                                                        @Nullable final Boolean acceptsCxQuestionnaires,
                                                        @Nullable final Boolean acceptsCxWhatsappCommunications) {
        UserEntity userEntity = userRepository.findById(UserLegacy.asSafeLong(userId))
                                              .orElseThrow(UserNotFoundException::new);

        // pedroserro: the permission check is here because the role tenant owner does not exist and tenant_manager does not fit the requirements.
        // If this check is done in another layer it would require two calls to the DB to get the user. Either that or inject UserRepository in the calling service.
        TenantOwnerAccountEntity account = Optional.ofNullable(userEntity.findOwnerAccount(tenantId)).orElseThrow(
            () -> new AccessDeniedException("User is not the owner of the account.")
        );

        if (acceptsMarketingCommunications != null) {
            account.setAcceptsMarketingCommunications(acceptsMarketingCommunications);
        }
        if (acceptsMarketingBehaviourAnalysis != null) {
            account.setAcceptsMarketingBehaviourAnalysis(acceptsMarketingBehaviourAnalysis);
        }
        if (acceptsCxQuestionnaires != null) {
            account.setAcceptsCxQuestionnaires(acceptsCxQuestionnaires);
        }
        if (acceptsCxWhatsappCommunications != null) {
            account.setAcceptsCxWhatsappCommunications(acceptsCxWhatsappCommunications);
        }

        UserEntity updatedUser = userRepository.save(userEntity);

        return mapUserEntityToDomain(updatedUser);
    }

    @Transactional
    @Nonnull
    public UserProfile deleteTenantOwnerAccount(@Nonnull UserId userId, @Nonnull TenantId tenantId) {
        log.info("Deleting tenant owner account for tenant {} from customer user_id {}", tenantId, userId);

        UserEntity userEntity =
            userRepository
                .findById(UserLegacy.asSafeLong(userId))
                .orElseThrow(UserNotFoundException::new);

        Set<TenantOwnerAccountEntity> accountsToRemove = userEntity.getTenantOwnerAccounts()
            .stream()
            .filter(linkedAccount -> linkedAccount.getTenantId().equals(tenantId.toString()))
            .collect(Collectors.toSet());

        Set<TenantOwnerAccountEntity> newAccounts = new HashSet<>(userEntity.getTenantOwnerAccounts());
        newAccounts.removeAll(accountsToRemove);
        userEntity.setTenantOwnerAccounts(newAccounts);

        accountsToRemove.forEach(entityManager::remove);
        userEntity = userRepository.save(userEntity);
        return mapUserEntityToDomain(userEntity);
    }


    @Transactional
    @Nonnull
    public UserProfile updateLinkedTenant(@Nonnull UserId userId, @Nonnull TenantId tenantId, boolean acceptsCommercial) {
        log.info("Updating tenant linked account {} from customer user_id {}", tenantId, userId);

        UserEntity userEntity =
            userRepository
                .findById(UserLegacy.asSafeLong(userId))
                .orElseThrow(UserNotFoundException::new);

        Tenant tenant = tenantService.getById(tenantId.toString());
        if (tenant.isAnemone()) {
            Optional<LinkedAccountEntity> linkedAccount = userEntity.getLinkedAccounts().stream()
                .filter(account -> account.getTenantId().equals(tenantId.toString())).findFirst();
            //In case is a tenant anemone, we can only link if the client has accepted commercial comms
            if (linkedAccount.isEmpty() && acceptsCommercial) {
                return linkTenant(userId, tenant, MerchantUserId.valueOf(userId.getValue()), acceptsCommercial);
            } else {
                linkedAccount.get().setAcceptsCommercialCommunications(acceptsCommercial);
            }
        } else {
            PadelclickTenant padelclickTenant = toPadelclickTenant(tenantId);

            try {
                for (LinkedAccountEntity a : userEntity.getLinkedAccounts()) {
                    if (a.getTenantId().equals(tenantId.toString())) {
                        safeUpdateSetAcceptsCommercialCommunicationsThirdParty(
                            MerchantUserId.valueOf(a.getMerchantUserId()), TenantId.valueOf(a.getTenantId()),
                            acceptsCommercial);
                        a.setAcceptsCommercialCommunications(acceptsCommercial);
                        PadelclickTenantAccountId merchantUserId = PadelclickTenantAccountId.valueOf(a.getMerchantUserId());
                        padelclickService.setCustomerCommunications(padelclickTenant, merchantUserId, acceptsCommercial);
                    }
                }
            } catch (PadelclickRegisterCustomerException | PadelclickGenericException e) {
                log.info(
                    "Updating tenant linked account failed trying to set accepts_commercial {} to tenant {} to customer user_id {}",
                    acceptsCommercial, tenantId, userId);
                throw new LinkAccountValidateException(e.getMessage());
            }
        }

        userEntity = userRepository.save(userEntity);
        return mapUserEntityToDomain(userEntity);
    }

    private void safeUpdateSetAcceptsCommercialCommunicationsThirdParty(@Nonnull MerchantUserId merchantUserId,
        @Nonnull TenantId tenantId,
        boolean acceptsCommercial) {
        try {
            PadelclickTenant padelclickTenant = toPadelclickTenant(tenantId);
            // TODO: once crm make their endpoint:
            // padelclickService.updateCustomer(padelclickTenant, merchantUserId , acceptsCommercial);
        } catch (Throwable e) {
            log.warn("Error while updating accepts commercial setting in tenant {} for merchantUserId {}", tenantId,
                merchantUserId);
        }
    }

    @Nonnull
    public CustomerUserProfile anonymizeUser(@Nonnull UserId userId) {
        log.info("Anonymize customer profile. user_id {}", userId);

        UserEntity userEntity = userRepository.findOneForUpdateById(UserLegacy.asSafeLong(userId))
                .orElseThrow(UserNotFoundException::new);
        entityManager.refresh(userEntity);

        changeEmail(userEntity, new Email("anonymous-" + userId + "@playtomic.io"));
        userEntity.setPhone(null);
        userEntity.setPhoneVerified(false);
        userEntity.setFullName("anonymous-" + userId);
        userEntity.setPasswordHash("");
        userEntity.setBirthDate(null);
        userEntity.setGender(null);
        userEntity.setBio(null);
        userEntity.setAcceptsPrivacyPolicy(false);
        userEntity.setAcceptsCommercialCommunications(false);

        GdprAuditEntity
            gdprAuditEntity =
            new GdprAuditEntity(
                userEntity.getId(),
                userEntity.getAcceptsPrivacyPolicy(),
                userEntity.getAcceptsCommercialCommunications(),
                map.get(new GdprSettingsKey(false, false)));
        gdprAuditRepository.save(gdprAuditEntity);

        userEntity.setAddressStreet(null);
        userEntity.setAddressZipCode(null);
        userEntity.setAddressCity(null);
        userEntity.setAddressState(null);

        userEntity.setDeleted(true);
        userEntity.setStatus(UserStatus.DISABLED);
        userEntity.setFacebookId(null);
        userEntity.setGoogleId(null);

        userEntity = userRepository.save(userEntity);

        return mapUserEntityToDomain(userEntity);
    }

    @Nonnull
    public CustomerUserProfile updatePremiumInfo(@Nonnull UserId userId, boolean isPremium, @Nullable Instant expiresAt) {
        UserEntity user = userRepository
            .findById(UserLegacy.asSafeLong(userId))
            .orElseThrow(UserNotFoundException::new);

        user.setIsPremium(isPremium);
        user.setPremiumExpiresAt(expiresAt);

        return mapUserEntityToDomain(userRepository.save(user));
    }

    @Nonnull
    private CustomerUserProfile registerUserCreatedByTenant(@Nonnull Email email, @Nonnull @Password String password, @Nonnull String name,
        @Nullable String phone, @Nullable Boolean acceptsPrivacy, @Nullable Boolean acceptsCommercial, @Nonnull String countryCode,
        @Nullable CustomerAddress address, @Nullable Locale communicationsLanguage, @Nullable String createdBy, @Nonnull TenantId tenantId,
        @Nonnull Collection<ExtendedUserRole> userRoles) {

        var tenant = tenantService.getById(tenantId.toString());
        var language = communicationsLanguage == null ? tenant.getCommunicationsLanguage() : communicationsLanguage;
        boolean hasManagerRole = userRoles.stream()
            .map(ExtendedUserRole::getUserRole)
            .anyMatch(role -> role == PlaytomicUserRole.ROLE_ACTIVITY_MANAGER || role == PlaytomicUserRole.ROLE_TENANT_MANAGER);

        PlaytomicUserType userType = hasManagerRole ? PlaytomicUserType.ONLINE : PlaytomicUserType.ONSITE;

        CustomerUserProfile customerUserProfile = persistOnRegister(email, password, name, phone,
            acceptsPrivacy, acceptsCommercial, countryCode, language, address, createdBy, tenantId,
            userType);

        if(!userRoles.isEmpty()){
            addUserRoles(customerUserProfile.getId(), userRoles, false);
            if(hasManagerRole){
                //send reset password notification
                userCredentialService.requestPasswordResetNewUserWithManagerRole(email, customerUserProfile.getCommunicationsLanguage());
            }
        }

        return customerUserProfile;
    }


    @Nonnull
    private UserEntity createNewUser(@Nonnull Email email, @Nonnull @Password String password,
        @Nonnull String name, @Nullable String phone,
        @Nonnull String countryCode, @Nullable Locale communicationsLanguage,
        @Nullable CustomerAddress address, @Nullable UserGender gender,
        @Nullable Instant birthDate, @Nullable String createdBy,
        @Nullable TenantId createdByTenant, @Nullable Boolean acceptsPrivacy,
        @Nullable Boolean acceptsCommercial, @Nonnull PlaytomicUserType userType) {
        if (phone != null && isPhoneInUse(phone)) {
            throw new PhoneNotAvailableException(phone);
        }
        var userEntity = new UserEntity(name, userCredentialService.hashPassword(password),
            email.getEmail(), false,
            phone, false,
            acceptsPrivacy, acceptsCommercial,
            null, null, null,
            countryCode, address, communicationsLanguage,
            gender, birthDate, createdByTenant, createdBy, userType);

        userEntity = userRepository.save(userEntity);
        var gdprAuditEntity =
            new GdprAuditEntity(userEntity.getId(), acceptsPrivacy, acceptsCommercial, "Account creation");
        gdprAuditRepository.save(gdprAuditEntity);
        return userEntity;
    }

    private UserEntity updateExistingAccount(@Nonnull UserEntity existingUser, @Nonnull @Password String password,
        @Nonnull String name, @Nullable String phone, @Nullable Boolean acceptsPrivacy,
        @Nullable Boolean acceptsCommercial, @Nonnull String countryCode, @Nullable Locale communicationsLanguage,
        @Nullable CustomerAddress address, @Nullable UserGender gender, @Nullable Instant birthDate) {
        if (phone != null && isPhoneInUse(phone)) {
            throw new PhoneNotAvailableException(phone);
        }
        existingUser.setPasswordHash(userCredentialService.hashPassword(password));
        existingUser.setFullName(name);
        existingUser.setPhone(phone);
        existingUser.setCountryCode(countryCode);
        existingUser.setCommunicationsLanguage(communicationsLanguage);
        existingUser.setGender(gender);
        existingUser.setBirthDate(birthDate);
        Optional.ofNullable(acceptsPrivacy).ifPresent(existingUser::setAcceptsPrivacyPolicy);
        Optional.ofNullable(acceptsCommercial).ifPresent(existingUser::setAcceptsCommercialCommunications);
        Optional.ofNullable(address).ifPresent(existingUser::setAddress);
        existingUser.setType(PlaytomicUserType.PENDING_VERIFICATION);
        var gdprAuditEntity = new GdprAuditEntity(existingUser.getId(), acceptsPrivacy, acceptsCommercial,
            "Account creation");
        gdprAuditRepository.save(gdprAuditEntity);
        return userRepository.save(existingUser);
    }


    private boolean isPhoneInUse(@Nonnull String phone) {
        return userRepository.findAllForUpdateByPhone(phone)
            .stream()
            .filter(UserEntity::isPhoneVerified)
            .anyMatch(user -> user.getAcceptsPrivacyPolicy() == null || user.getAcceptsPrivacyPolicy());
    }

}

package com.playtomic.anemone.category.domain;

import com.playtomic.anemone.domain.generic.AbstractUuidId;
import java.util.UUID;
import javax.annotation.Nonnull;

public class MembershipProductId extends AbstractUuidId {

    protected MembershipProductId(@Nonnull String id) {
        super(id);
    }

    protected MembershipProductId(@Nonnull UUID id) {
        super(id);
    }

    public static MembershipProductId valueOf(@Nonnull String id) {
        return new MembershipProductId(id);
    }

    public static MembershipProductId valueOf(@Nonnull UUID id) {
        return new MembershipProductId(id);
    }
}


package com.playtomic.anemone.user.dao;

import com.playtomic.anemone.user.domain.users.GameTimeRange;
import java.util.Collection;
import javax.annotation.Nonnull;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Data
@NoArgsConstructor
public class UserGamePreferencesField {
    /*

    @Field("only_content_i_can_play")
    @Nonnull
    private boolean onlyContentThatICanPlay;

    @Field("preferred_sport_id")
    private String sportId;

    @Field("preferred_tenant_id")
    @Nullable
    private String tenantId;

    @Field("preferred_coordinate")
    @Nullable
    private GeoJsonPoint coordinate;
    */

    @Nonnull
    @Field("time_ranges")
    private Collection<GameTimeRange> timeranges;

    public UserGamePreferencesField(
        @Nonnull Collection<GameTimeRange> timeranges) {
        setTimeranges(timeranges);
    }

    public void setTimeranges(
        @Nonnull Collection<GameTimeRange> timeranges) {
        this.timeranges = timeranges;
    }

    @Nonnull
    public Collection<GameTimeRange> getTimeranges() {
        return timeranges;
    }
}

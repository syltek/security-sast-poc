package com.playtomic.anemone.user.dao;

import com.playtomic.anemone.domain.user.UserId;
import com.playtomic.anemone.user.dao.permissions.PermissionDocument;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import javax.annotation.Nonnull;

@Repository
public interface PermissionRepository extends MongoRepository<PermissionDocument, String> {

    List<PermissionDocument> findByUserId(@Nonnull UserId userId);

    Optional<PermissionDocument> findByUserIdAndTenantId(@Nonnull UserId userId, @Nonnull TenantId tenantId);
}

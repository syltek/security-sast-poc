package com.playtomic.anemone.user.domain.reservation;

import com.playtomic.anemone.domain.generic.AbstractStringId;

/**
 *
 */
public class ReservationId extends AbstractStringId {
    protected ReservationId(String id) {
        super(id);
    }

    public static ReservationId valueOf(String id) {
        return new ReservationId(id);
    }
}

package com.playtomic.anemone.user.service.exception;

import javax.annotation.Nonnull;

public class UserRoleAlreadyDefinedException extends RuntimeException {

    public UserRoleAlreadyDefinedException(@Nonnull String message) {
        super(message);
    }

}

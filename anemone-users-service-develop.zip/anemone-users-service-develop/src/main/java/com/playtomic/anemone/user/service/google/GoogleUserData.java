package com.playtomic.anemone.user.service.google;

import com.playtomic.anemone.domain.Email;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Data;

@Data
public class GoogleUserData {
    @Nonnull
    private GoogleId googleId;

    @Nullable
    private String username;

    @Nullable
    private Email email;

    private boolean isVerified;

    public GoogleUserData(@Nonnull GoogleId googleId, @Nonnull String username, @Nullable Email email, boolean isVerified) {
        this.googleId = googleId;
        this.username = username;
        this.email = email;
        this.isVerified = isVerified;
    }

    @Nonnull
    public GoogleId getGoogleId() {
        return googleId;
    }

    @Nonnull
    public String getUsername() {
        return username;
    }

    @Nullable
    public Email getEmail() {
        return email;
    }

    public boolean isVerified() {
        return isVerified;
    }
}

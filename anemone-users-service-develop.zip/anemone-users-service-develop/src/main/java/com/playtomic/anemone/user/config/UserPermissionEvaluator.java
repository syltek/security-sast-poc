package com.playtomic.anemone.user.config;

import com.playtomic.anemone.category.domain.CategoryId;
import com.playtomic.anemone.domain.user.UserId;
import com.playtomic.anemone.user.domain.UserProfile;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import com.playtomic.anemone.user.domain.userimports.UserImportId;
import com.playtomic.anemone.user.model.CustomerUserProfile;
import com.playtomic.anemone.user.service.UserService;
import java.io.Serializable;
import java.util.Collection;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.access.PermissionEvaluator;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class UserPermissionEvaluator implements PermissionEvaluator {

    @Nonnull
    final private UserPermissionService permissionService;

    @Nonnull
    final private UserService userService;

    public UserPermissionEvaluator(@Nonnull UserPermissionService permissionService,
                                   @Nonnull UserService userService) {
        this.permissionService = permissionService;
        this.userService = userService;
    }

    @Override
    public boolean hasPermission(
        @Nonnull Authentication authentication,
        @Nullable Object targetDomainObject,
        @Nonnull Object permission) {

        if (targetDomainObject instanceof CustomerUserProfile) {
            CustomerUserProfile u = (CustomerUserProfile) targetDomainObject;
            return permissionService.isAllowed(u, permission.toString(), authentication);
        } else if (targetDomainObject instanceof UserProfile) {
            UserProfile u = (UserProfile)targetDomainObject;
            return permissionService.isAllowed(u.getId(), permission.toString(), authentication);
        } else if (targetDomainObject instanceof UserId) {
            UserId userId = (UserId)targetDomainObject;
            return permissionService.isAllowed(userId, permission.toString(), authentication);
        }  else if (targetDomainObject instanceof TenantId) {
            TenantId tenantId = (TenantId)targetDomainObject;
            return permissionService.isAllowed(tenantId, permission.toString(), authentication);
        } else if (targetDomainObject instanceof UserImportId) {
            UserImportId userImportId = (UserImportId)targetDomainObject;
            return permissionService.isAllowed(userImportId, permission.toString(), authentication);
        } else if (targetDomainObject instanceof CategoryId) {
            CategoryId categoryId = (CategoryId)targetDomainObject;
            return permissionService.isAllowed(categoryId, permission.toString(), authentication);
        }

        return false;
    }

    @Override
    public boolean hasPermission(
        @Nonnull Authentication authentication,
        @Nonnull Serializable targetId,
        @Nonnull String targetType,
        @Nonnull Object permission) {

        log.trace("Checking permission targetId {}. targetType {}, permission {}", targetId, targetType, permission);

        boolean hasPermission = false;
        if ("userId".equalsIgnoreCase(targetType)) {
            UserId userId = UserId.valueOf(targetId.toString());
            hasPermission = permissionService.isAllowed(userId, permission.toString(), authentication);
        } else if ("tenantIds".equalsIgnoreCase(targetType)) {
            // made <?> to be more flexible (it accepts Strings and TenantIds)
            Collection<?> tenantIds = (Collection)targetId;
            hasPermission =
                    tenantIds
                            .stream()
                            .allMatch(id -> permissionService.isAllowed(TenantId.valueOf(id.toString()), permission.toString(), authentication))
                    ;

        }

        log.trace("Permission for targetId {}. targetType {}, permission {} returned {}", targetId, targetType, permission, hasPermission);

        return hasPermission;
    }
}

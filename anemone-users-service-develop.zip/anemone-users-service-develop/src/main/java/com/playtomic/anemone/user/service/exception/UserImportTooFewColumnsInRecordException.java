package com.playtomic.anemone.user.service.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public class UserImportTooFewColumnsInRecordException extends RuntimeException {
    long recordNumber;
    int expectedColumns;
    int foundColumns;
}

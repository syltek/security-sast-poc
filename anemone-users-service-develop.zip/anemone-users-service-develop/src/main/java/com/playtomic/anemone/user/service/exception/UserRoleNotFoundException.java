package com.playtomic.anemone.user.service.exception;

import javax.annotation.Nonnull;

public class UserRoleNotFoundException extends RuntimeException {

    public UserRoleNotFoundException(@Nonnull String message) {
        super(message);
    }

}

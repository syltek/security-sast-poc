package com.playtomic.anemone.user.service.anemone;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;

import javax.annotation.Nonnull;

@Getter
public class SubscriptionModule {

    @Nonnull
    private final String moduleType;

    public SubscriptionModule(@JsonProperty("module_type") @Nonnull String moduleType) {
        this.moduleType = moduleType;
    }
}

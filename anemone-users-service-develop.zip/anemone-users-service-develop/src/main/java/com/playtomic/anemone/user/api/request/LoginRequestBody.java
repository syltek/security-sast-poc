package com.playtomic.anemone.user.api.request;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.domain.Email;
import javax.annotation.Nullable;

public class LoginRequestBody {
    @Nullable
    public Email email;

    @Nullable
    public String password;

    @Nullable
    public String facebookToken;

    @Nullable
    public String googleToken;

    @Nullable
    public String appleToken;

    public LoginRequestBody() {}

    @JsonCreator
    public LoginRequestBody(
        @JsonProperty(value = "email", required = false) @Nullable Email email,
        @JsonProperty(value = "password", required = false) @Nullable  String password,
        @JsonProperty(value = "facebook_token", required = false) @Nullable  String facebookToken,
        @JsonProperty(value = "google_token", required = false) @Nullable String googleToken,
        @JsonProperty(value = "apple_token", required = false) @Nullable String appleToken) {
        this.email = email;
        this.password = password;
        this.facebookToken = facebookToken;
        this.googleToken = googleToken;
        this.appleToken = appleToken;
    }
}

package com.playtomic.anemone.user.dao;

import com.playtomic.anemone.dao.BaseEntity;
import com.playtomic.anemone.domain.Email;
import javax.annotation.Nonnull;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "password_reset_request")
public class PasswordResetRequestEntity extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "email")
    private String email;

    @Column(name = "security_token")
    private String securityToken;

    protected PasswordResetRequestEntity() {
        // nothing here, jpa requirement
    }

    public PasswordResetRequestEntity(@Nonnull Email email, @Nonnull String token) {
        this.email = email.getEmail();
        this.securityToken = token;
    }

    @Nonnull
    public Email getEmail() {
        return new Email(this.email);
    }

    @Nonnull
    public String getToken() {
        return securityToken;
    }
}

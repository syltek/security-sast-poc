package com.playtomic.anemone.user.model.permissions;

import java.util.Map;

public class PremiumPermissionsToAuthorities extends PermissionsToAuthorities {

    private static final Map<PermissionLevel, String[]> authorities = Map.ofEntries(
            e(PermissionLevel.READ_ONLY),
            e(PermissionLevel.READ_WRITE)
    );

    public PremiumPermissionsToAuthorities() {
        super(authorities);
    }

}

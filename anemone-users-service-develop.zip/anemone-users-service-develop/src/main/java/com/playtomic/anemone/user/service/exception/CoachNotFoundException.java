package com.playtomic.anemone.user.service.exception;

public class CoachNotFoundException extends RuntimeException {
}

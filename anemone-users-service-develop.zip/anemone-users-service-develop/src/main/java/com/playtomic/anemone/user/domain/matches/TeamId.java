package com.playtomic.anemone.user.domain.matches;

import com.playtomic.anemone.domain.generic.AbstractStringId;

import javax.annotation.Nonnull;

public class TeamId extends AbstractStringId {

    protected TeamId(@Nonnull String id) {
        super(id);
    }

    @Nonnull
    public static TeamId valueOf(@Nonnull String id) {
        return new TeamId(id);
    }
}
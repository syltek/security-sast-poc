package com.playtomic.anemone.user.service.anemone;

import com.playtomic.anemone.jwt.JwtTokenFactory;
import com.playtomic.anemone.spring.ForceAnemoneAuthenticationCredentialsAccessor;
import com.playtomic.anemone.spring.config.AnemoneWebMvConfigurerAdapter;
import com.playtomic.anemone.spring.feign.AnemoneFeignFormatterRegistrar;
import com.playtomic.anemone.spring.feign.AuthenticationHeaderFeignInterceptor;
import com.playtomic.anemone.user.domain.wallet.Wallet;
import com.playtomic.anemone.user.domain.wallet.WalletType;
import feign.RequestInterceptor;
import java.util.List;
import javax.annotation.Nonnull;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.cloud.openfeign.FeignFormatterRegistrar;
import org.springframework.context.annotation.Bean;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(name = "wallet-service", configuration = WalletServiceClient.Configuration.class, url="${wallet-service.url}")
public interface WalletServiceClient {

    @GetMapping(value = "/v2/wallets", consumes = "application/json")
    List<Wallet> findByTenantId(@RequestParam("tenant_id") @Nonnull String tenantId, @RequestParam("type") @Nonnull WalletType walletType, @Nonnull Pageable pageable);

    class Configuration {
        @Bean
        public RequestInterceptor requestInterceptor(@Nonnull JwtTokenFactory jwtTokenFactory) {
            return new AuthenticationHeaderFeignInterceptor(new ForceAnemoneAuthenticationCredentialsAccessor(jwtTokenFactory));
        }

        @Bean
        public FeignFormatterRegistrar feignFormatterRegistrar(@Nonnull AnemoneWebMvConfigurerAdapter anemoneWebMvConfigurerAdapter) {
            return new AnemoneFeignFormatterRegistrar(anemoneWebMvConfigurerAdapter);
        }
    }
}


package com.playtomic.anemone.user.model.permissions;

import java.util.Map;

public class MatchPermissionsToAuthorities extends PermissionsToAuthorities {

    private static final Map<PermissionLevel, String[]> authorities = Map.ofEntries(
            e(PermissionLevel.READ_ONLY, "read_recurring_match_configurations"),
            e(PermissionLevel.READ_WRITE,  "create_matches", "write_matches", "delete_matches", "invite_players", "remove_players", "register_players", "register_players_payments", "cancel_matches", "admin_own_matches", "admin_own_reservations")
    );

    public MatchPermissionsToAuthorities() {
        super(authorities);
    }

}

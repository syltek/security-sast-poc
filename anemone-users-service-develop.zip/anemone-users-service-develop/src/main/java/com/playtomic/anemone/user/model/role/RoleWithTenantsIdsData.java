package com.playtomic.anemone.user.model.role;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.Set;
import javax.annotation.Nonnull;

@AllArgsConstructor
@Data
public class RoleWithTenantsIdsData {

    @Nonnull
    @JsonProperty("tenant_ids")
    private Set<String> tenantIds;

}

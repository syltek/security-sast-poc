package com.playtomic.anemone.category.api.v1.request;

import static com.playtomic.anemone.category.dao.CategoryDocument.Status;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.category.dao.CategoryDocument.PricingType;
import com.playtomic.anemone.category.domain.Visibility;
import javax.annotation.Nullable;
import javax.validation.Valid;
import lombok.Getter;

@Getter
public class PatchCategory {

    @Nullable
    @JsonProperty("pricing_type")
    private PricingType pricingType;

    @Nullable
    @JsonProperty("status")
    private Status status;

    @Nullable
    @JsonProperty("allow_single_payment_when_price_is_customized")
    private Boolean allowSinglePaymentWhenPriceIsCustomized;

    @Valid
    @Nullable
    @JsonProperty("membership_details")
    private PatchCategoryMembershipDetails membershipDetails;

    @Getter
    public static class PatchCategoryMembershipDetails {

        @Nullable
        @JsonProperty("visibility")
        private Visibility visibility;

        @Nullable
        @JsonProperty("description")
        private String description;

    }
}

package com.playtomic.anemone.category.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.time.Instant;
import javax.annotation.Nullable;
import javax.validation.constraints.Future;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public class UserIdAndCategoryExpiration {

    @NotNull
    @JsonProperty(value =  "user_id", required = true)
    private Long userId;
    @Nullable
    @Future
    @JsonProperty(value =  "expires_at", required = true)
    private Instant expiresAt;
}

package com.playtomic.anemone.category.service.exception;

import javax.annotation.ParametersAreNonnullByDefault;

@ParametersAreNonnullByDefault
public class CategoryUpdateRejectedException extends RuntimeException {

    public CategoryUpdateRejectedException(String message) {
        super(message);
    }


}

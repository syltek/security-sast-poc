package com.playtomic.anemone.user.service.messaging;

import com.playtomic.anemone.category.messaging.CategoryEvent;
import com.playtomic.anemone.user.config.MessagingConfiguration;
import com.playtomic.anemone.user.config.MessagingConfiguration.UserUpdateTenantTagsTopicOutput;
import javax.annotation.Nonnull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class MessagingBroker {

    @Nonnull
    private final MessagingConfiguration.UsersTopic usersTopic;

    @Nonnull
    private final MessagingConfiguration.UserImportsTopicOutput userImportsTopicOutput;

    @Nonnull
    private final MessagingConfiguration.CategoriesTopic categoriesTopic;

    @Nonnull
    private final MessagingConfiguration.UserUpdateTenantTagsTopicOutput updateTenantTagsTopic;

    public MessagingBroker(@Nonnull MessagingConfiguration.UsersTopic usersTopic,
                           @Nonnull MessagingConfiguration.UserImportsTopicOutput userImportsTopicOutput,
                           @Nonnull MessagingConfiguration.CategoriesTopic categoriesTopic,
                           @Nonnull MessagingConfiguration.UserUpdateTenantTagsTopicOutput updateTenantTagsTopic) {
        this.usersTopic = usersTopic;
        this.userImportsTopicOutput = userImportsTopicOutput;
        this.categoriesTopic = categoriesTopic;
        this.updateTenantTagsTopic = updateTenantTagsTopic;
    }

    public void sendEvent(@Nonnull UserEvent event) {
        try {
            log.debug("Sending user event to kafka. Event Id:" + event.getKey());
            usersTopic.output().send(MessageBuilder
                    .withPayload(event)
                    .setHeader(KafkaHeaders.MESSAGE_KEY, event.getKey()
                    ).build());
        } catch (Throwable e) {
            log.error("Error while sending user event to Kafka: Event Id:" + event.getKey(), e);
        }
    }

    public void sendEvent(@Nonnull UserImportEvent event) {
        try {
            log.debug("Sending user import event to kafka. Event Id:" + event.getKey());
            userImportsTopicOutput.output().send(MessageBuilder
                .withPayload(event)
                .setHeader(KafkaHeaders.MESSAGE_KEY, event.getKey()
            ).build());
        } catch (Throwable e) {
            log.error("Error while sending user event to Kafka: Event Id:" + event.getKey(), e);
        }
    }

    public void sendEvent(@Nonnull CategoryEvent event) {
        try {
            log.debug("Sending user category event to kafka. Event Id:" + event.getKey());
            categoriesTopic.output().send(MessageBuilder
                .withPayload(event)
                .setHeader(KafkaHeaders.MESSAGE_KEY, event.getKey()
            ).build());
        } catch (Throwable e) {
            log.error("Error while sending user category event to Kafka: Event Id:" + event.getKey(), e);
        }
    }

    @Async
    public void asyncSendEvent(@Nonnull UserUpdateTenantTagEvent event) {
        sendEvent(event);
    }

    public void sendEvent(@Nonnull UserUpdateTenantTagEvent event) {
        try {
            log.debug("Sending update tenant tags event to kafka. Event Id:" + event.getKey());
            updateTenantTagsTopic.output().send(MessageBuilder
                                              .withPayload(event)
                                              .setHeader(KafkaHeaders.MESSAGE_KEY, event.getKey()
                                              ).build());
        } catch (Throwable e) {
            log.error("Error while sending update tenant tags event to Kafka: Event Id:" + event.getKey(), e);
        }
    }
}

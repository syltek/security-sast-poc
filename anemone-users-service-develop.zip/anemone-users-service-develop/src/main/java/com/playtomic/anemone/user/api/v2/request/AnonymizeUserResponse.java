package com.playtomic.anemone.user.api.v2.request;

import com.playtomic.anemone.user.model.CustomerUserProfile;
import javax.annotation.Nonnull;
import com.fasterxml.jackson.annotation.JsonProperty;

public class AnonymizeUserResponse {

    @JsonProperty("commercial_notifications_warning")
    @Nonnull
    private String commercialNotificationsWarning = " ******* Remember that you have to remove this email account from commercial notification lists *******";

    @JsonProperty("user")
    @Nonnull
    private CustomerUserProfile user;

    public AnonymizeUserResponse(@Nonnull CustomerUserProfile user) {
        this.user = user;
    }

}

package com.playtomic.anemone.user.domain.csv;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class CsvWalletHeader {

    private final int namePosition;
    private final int balancePosition;
}

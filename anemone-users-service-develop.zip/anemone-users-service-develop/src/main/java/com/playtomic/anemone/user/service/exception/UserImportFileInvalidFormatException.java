package com.playtomic.anemone.user.service.exception;

public class UserImportFileInvalidFormatException extends RuntimeException {
}

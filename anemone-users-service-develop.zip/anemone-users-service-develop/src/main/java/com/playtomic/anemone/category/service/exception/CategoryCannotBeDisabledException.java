package com.playtomic.anemone.category.service.exception;

import com.playtomic.anemone.category.domain.CategoryId;
import javax.annotation.Nonnull;

public class CategoryCannotBeDisabledException extends RuntimeException {

    public CategoryCannotBeDisabledException(@Nonnull CategoryId categoryId) {
        super(String.format("Category %s cannot be disabled", categoryId));
    }
}

package com.playtomic.anemone.category.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.time.Duration;
import java.util.Optional;
import javax.annotation.Nullable;
import javax.validation.constraints.Min;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public class BookingPrivilege {

    @Min(0)
    @Nullable
    @JsonProperty("days_of_booking_ahead")
    private Integer daysOfBookingAhead;
    @Min(0)
    @Nullable
    @JsonProperty("max_number_of_active_bookings")
    private Integer maxNumberOfActiveBookings;
    @Min(0)
    @Nullable
    @JsonProperty("max_number_of_bookings_per_day")
    private Integer maxNumberOfBookingsPerDay;
    @Nullable
    @JsonProperty("cancellation_policy")
    private CancellationPolicyDuration cancellationPolicy;

    @Nullable
    @JsonIgnore
    public Duration getCancellationPolicyDuration() {
        return Optional.ofNullable(cancellationPolicy).map(CancellationPolicyDuration::getDuration).orElse(null);
    }
}

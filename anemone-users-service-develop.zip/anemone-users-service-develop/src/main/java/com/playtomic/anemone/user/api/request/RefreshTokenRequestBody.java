package com.playtomic.anemone.user.api.request;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.jwt.RawAccessJwtToken;
import javax.annotation.Nonnull;

public class RefreshTokenRequestBody {

    @Nonnull
    public RawAccessJwtToken refreshToken;

    public RefreshTokenRequestBody() {
    }

    @JsonCreator
    public RefreshTokenRequestBody(
        @JsonProperty(value = "refresh_token", required = true) @Nonnull RawAccessJwtToken refreshToken
    ) {
        this.refreshToken = refreshToken;
    }
}

package com.playtomic.anemone.user.service.apple.exception;

public class InvalidAppleTokenException extends RuntimeException {
    public InvalidAppleTokenException() {
        super();
    }

    public InvalidAppleTokenException(Exception e) {
        super(e);
    }
}

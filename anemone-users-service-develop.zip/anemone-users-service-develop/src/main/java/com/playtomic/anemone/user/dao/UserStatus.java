package com.playtomic.anemone.user.dao;

public enum UserStatus {
    ACTIVE,
    INACTIVE,
    DISABLED
}

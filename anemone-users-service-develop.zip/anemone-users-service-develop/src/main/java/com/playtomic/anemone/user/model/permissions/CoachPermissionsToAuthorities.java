package com.playtomic.anemone.user.model.permissions;

import java.util.Map;

public class CoachPermissionsToAuthorities extends PermissionsToAuthorities {

    private static final Map<PermissionLevel, String[]> authorities = Map.ofEntries(
            e(PermissionLevel.READ_ONLY, "read_coach_accounts", "read_coach_pricing_rules"),
            e(PermissionLevel.READ_WRITE, "write_coach_accounts", "write_coach_pricing_rules")
    );

    public CoachPermissionsToAuthorities() {
        super(authorities);
    }

}

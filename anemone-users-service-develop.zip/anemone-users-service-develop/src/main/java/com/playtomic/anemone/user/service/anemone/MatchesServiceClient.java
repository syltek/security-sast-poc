package com.playtomic.anemone.user.service.anemone;

import com.playtomic.anemone.domain.user.UserId;
import com.playtomic.anemone.jwt.JwtTokenFactory;
import com.playtomic.anemone.spring.ForceAnemoneAuthenticationCredentialsAccessor;
import com.playtomic.anemone.spring.feign.AnemoneFeignConfiguration;
import com.playtomic.anemone.spring.feign.AuthenticationHeaderFeignInterceptor;
import com.playtomic.anemone.user.domain.matches.Match;
import feign.RequestInterceptor;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.context.annotation.Bean;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.Instant;
import java.util.List;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;

@FeignClient(name = "matches-service", configuration = MatchesServiceClient.Configuration.class, url="${matches-service.url}")
public interface MatchesServiceClient {

    @GetMapping("/v1/matches?disable_price_calculation=true&match_status=PENDING,IN_PROGRESS,PLAYED&after_end_date={after_end_date}&player_user_id={user_id}&size=1")
    @Nonnull
    List<Match> findPendingMatches(@RequestParam(name = "user_id") @Nullable UserId userId, @RequestParam("after_end_date") @Nullable Instant from);

    @RequestMapping(path = "/v1/matches?disable_price_calculation=true&match_status=PENDING,IN_PROGRESS&is_playtomic_managed=true&after_end_date={after_end_date}&player_user_id={user_id}&size=1", method = RequestMethod.HEAD)
    ResponseEntity getNumberOfPendingMatches(@RequestParam(name = "user_id") @Nullable UserId userId, @RequestParam("after_end_date") @Nullable Instant from);


    class Configuration extends AnemoneFeignConfiguration {
        @Bean
        public RequestInterceptor requestInterceptor(@Nonnull JwtTokenFactory jwtTokenFactory) {
            return new AuthenticationHeaderFeignInterceptor(new ForceAnemoneAuthenticationCredentialsAccessor(jwtTokenFactory));
        }
    }
}

package com.playtomic.anemone.user.service.exception;

import com.playtomic.anemone.user.domain.tenant.TenantId;
import javax.annotation.Nonnull;

/**
 *
 */
public class TenantNotFoundException extends RuntimeException {
    public TenantId tenantId;

    public TenantNotFoundException(@Nonnull TenantId tenantId) {
        super(String.format("Tenant with id=%s not found", tenantId));
        this.tenantId = tenantId;
    }

    public TenantNotFoundException(@Nonnull String tenantId) {
        super(String.format("Tenant with id=%s not found", tenantId));
    }
}

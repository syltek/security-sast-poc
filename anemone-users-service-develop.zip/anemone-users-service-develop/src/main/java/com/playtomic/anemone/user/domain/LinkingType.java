package com.playtomic.anemone.user.domain;

public enum LinkingType {
    AUTOLINK,
    AUTOREGISTER,
    MANUAL_LINK
}

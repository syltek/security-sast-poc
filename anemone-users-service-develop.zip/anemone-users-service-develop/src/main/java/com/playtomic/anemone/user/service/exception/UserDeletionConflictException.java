package com.playtomic.anemone.user.service.exception;

import lombok.Getter;

import javax.annotation.Nonnull;

@Getter
public class UserDeletionConflictException extends RuntimeException {

    public enum Type {
        PENDING_DEBTS, PENDING_ACTIVITIES
    }

    @Nonnull
    private final Type reason;

    private UserDeletionConflictException(@Nonnull Type reason) {
        this.reason = reason;
    }

    @Nonnull
    public static UserDeletionConflictException pendingDebts() {
        return new UserDeletionConflictException(Type.PENDING_DEBTS);
    }

    @Nonnull
    public static UserDeletionConflictException pendingActivities() {
        return new UserDeletionConflictException(Type.PENDING_ACTIVITIES);
    }

}

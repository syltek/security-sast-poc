package com.playtomic.anemone.user.service.exception;

import com.playtomic.anemone.domain.Email;
import javax.annotation.Nonnull;

public class PasswordResetRequestNotFound extends RuntimeException {
    public PasswordResetRequestNotFound(@Nonnull Email email) {
        super(String.format("PasswordResetRequest with email=%s was not found", email));
    }
}

package com.playtomic.anemone.user.domain.userimports;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class UserImportResult {

    @JsonProperty("total")
    private long total;

    @JsonProperty("processed")
    private long processed;

    @JsonProperty("succeeded")
    private long success;

    @JsonProperty("failed")
    private long failed;

}

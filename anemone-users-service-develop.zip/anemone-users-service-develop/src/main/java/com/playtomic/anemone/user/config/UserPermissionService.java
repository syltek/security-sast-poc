package com.playtomic.anemone.user.config;

import com.playtomic.anemone.category.dao.CategoryRepository;
import com.playtomic.anemone.category.domain.CategoryId;
import com.playtomic.anemone.category.service.exception.CategoryNotFoundException;
import com.playtomic.anemone.domain.generic.AbstractStringId;
import com.playtomic.anemone.domain.user.UserId;
import com.playtomic.anemone.domain.user.UserRole;
import com.playtomic.anemone.spring.security.ByTokenBasedAuthPermissionChecker;
import com.playtomic.anemone.spring.security.TenantsFromJwtClaims;
import com.playtomic.anemone.spring.security.UserIdFromPrincipalScopesGetter;
import com.playtomic.anemone.user.dao.LinkedAccountsDao;
import com.playtomic.anemone.user.dao.userimports.UserImportRepository;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import com.playtomic.anemone.user.domain.userimports.UserImport;
import com.playtomic.anemone.user.domain.userimports.UserImportId;
import com.playtomic.anemone.user.model.CustomerUserProfile;
import io.jsonwebtoken.lang.Collections;
import java.util.Collection;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class UserPermissionService {

    @Nonnull
    private final ByTokenBasedAuthPermissionChecker<UserId, UserId> userIdPermissionChecker;

    @Nonnull
    private final ByTokenBasedAuthPermissionChecker<String, String> tenantIdPermissionChecker;

    @Nonnull
    private final UserImportRepository userImportRepository;

    @Nonnull
    private final CategoryRepository categoryRepository;

    @Nonnull
    private final LinkedAccountsDao linkedAccountsDao;

    public UserPermissionService(@Nonnull UserImportRepository userImportRepository,
        @Nonnull CategoryRepository categoryRepository,
        @Nonnull LinkedAccountsDao linkedAccountsDao) {
        this.userImportRepository = userImportRepository;
        this.categoryRepository = categoryRepository;

        this.linkedAccountsDao = linkedAccountsDao;

        this.userIdPermissionChecker = new ByTokenBasedAuthPermissionChecker("users",
            u -> u,
            new UserIdFromPrincipalScopesGetter(),
            true);

        this.tenantIdPermissionChecker = new ByTokenBasedAuthPermissionChecker("users",
            t -> t,
            new TenantsFromJwtClaims(),
            true);
    }


    public boolean isAllowed(@Nonnull String permission, @Nonnull Authentication authentication) {
        return userIdPermissionChecker.isAllowed(permission, authentication, null);
    }

    /*
     * It might be a bit misleading because this is not accessing the linked tenants and it probably should!
     */
    public boolean isAllowed(@Nullable UserId userId, @Nonnull String permission, @Nonnull Authentication auth) {
        if (userIdPermissionChecker.isAllowed(permission, auth, userId)) {
            return true;
        }

        Collection<TenantId> linkedAccounts = linkedAccountsDao.getLinkedAccountsIds(userId);
        return isAllowed(linkedAccounts, permission, auth, CheckMode.ANY);
    }

    public boolean isAllowed(@Nullable CustomerUserProfile user, @Nonnull String permission, @Nonnull Authentication auth) {
        return userIdPermissionChecker.isAllowed(permission, auth, user.getId())
                // Checking linked tenant ids (user is customer of tenant)
                || isAllowed(user.getLinkedTenantIds(), permission, auth, CheckMode.ANY)
                // Checking linked coach ids (user is coach of tenant)
                || isAllowed(user.getLinkedAsCoachTenantIds(), permission, auth, CheckMode.ANY)
                // Checking managed tenant ids (user is manager of tenant)
                || isAllowed(user.getManagedTenantIds(), permission, auth, CheckMode.ANY);
    }

    public boolean isAllowedUser(@Nullable UserId userId, @Nonnull String permission, @Nonnull Authentication auth) {
        return userIdPermissionChecker.isAllowed(permission, auth, userId);
    }

    public boolean isAllowed(@Nullable TenantId tenantId, @Nonnull String permission, @Nonnull Authentication auth) {
        return tenantIdPermissionChecker.isAllowed(permission, auth, tenantId.getValue());
    }

    public boolean isAllowed(@Nonnull UserImportId userImportId, @Nonnull String permission, @Nonnull Authentication auth){
        UserImport userImport = userImportRepository.findById(userImportId).orElse(null);
        if (userImport == null) {
            return false;
        }

        TenantId userImportTenantId = userImport.getTenantId();
        return tenantIdPermissionChecker.isAllowed(permission, auth, userImportTenantId.getValue());
    }

    public boolean isAllowed(@Nonnull CategoryId categoryId, @Nonnull String permission, @Nonnull Authentication auth) {
        var category = categoryRepository.findById(categoryId).orElseThrow(() -> new CategoryNotFoundException(categoryId));
        return tenantIdPermissionChecker.isAllowed(permission, auth, category.getTenantId().getValue());
    }

    public <T extends AbstractStringId> boolean isAllowed(@Nullable Collection<T> ids, @Nonnull String permission, @Nonnull Authentication auth) {
        return isAllowed(ids, permission, auth, CheckMode.ALL);
    }

    public boolean mightAccessPrivateData(@Nonnull UserId userId, @Nonnull Authentication authentication) {
        // If authentication is the same user, anemone or admin, I can read the private profile
        if (userIdPermissionChecker.isAllowed("read_private_profile", authentication, userId)) {
            return true;
        }

        return authentication.getAuthorities().contains(UserRolesToAuthorities.MIGHT_READ_OTHERS_PRIVATE_PROFILE);
    }

    public enum CheckMode {
        ALL,
        ANY
    }

    /**
     * When specified ALL, auth must be allowed for every id.
     * When specified ANY, auth have to be allowed at least in one id.
     */
    public <T extends AbstractStringId> boolean isAllowed(@Nullable Collection<T> ids, @Nonnull String permission, @Nonnull Authentication auth, @Nonnull CheckMode mode) {
        if (Collections.isEmpty(ids)) {
            return isAllowed(permission, auth);
        }

        for (T id : ids) {
            boolean isAllowed;
            if (id instanceof TenantId) {
                isAllowed = isAllowed((TenantId) id, permission, auth);
            } else if (id instanceof UserId) {
                isAllowed = isAllowed((UserId) id, permission, auth);
            } else {
                // unsupported data type, break the loop
                return false;
            }

            if (CheckMode.ALL == mode && !isAllowed) {
                return false;
            }

            if (CheckMode.ANY == mode && isAllowed) {
                return true;
            }
        }

        return CheckMode.ALL == mode ? true : false;
    }
}

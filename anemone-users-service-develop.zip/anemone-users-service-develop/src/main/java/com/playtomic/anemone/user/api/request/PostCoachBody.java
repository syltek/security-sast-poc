package com.playtomic.anemone.user.api.request;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.domain.user.UserId;
import com.playtomic.anemone.user.domain.matches.SportId;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import java.util.List;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Data;

@Data
public class PostCoachBody {

    @Nonnull
    private UserId userId;

    @Nullable
    private TenantId tenantId;

    @Nonnull
    private List<SportId> sportIds;

    @Nonnull
    private String experience;

    @Nonnull
    private String ages;

    @Nonnull
    private String description;

    @JsonCreator
    public PostCoachBody(
        @JsonProperty(value = "user_id", required = true) @Nonnull UserId userId,
        @JsonProperty(value = "tenant_id", required = false) @Nullable TenantId tenantId,
        @JsonProperty(value = "sport_ids", required = true) @Nonnull List<SportId> sportIds,
        @JsonProperty(value = "experience", required = true) @Nonnull String experience,
        @JsonProperty(value = "ages", required = true) @Nonnull String ages,
        @JsonProperty(value = "description", required = true) @Nonnull String description
        ) {
        this.userId = userId;
        this.tenantId =  tenantId;
        this.sportIds = sportIds;
        this.experience = experience;
        this.ages = ages;
        this.description = description;
    }
}

package com.playtomic.anemone.user.service.anemone;

import com.playtomic.anemone.domain.Email;
import javax.annotation.Nullable;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

@Component
public class EmailConverter implements Converter<String, Email> {

    @Nullable
    @Override
    public Email convert(String source) {
        if (source == null) {
            return null;
        }
        return new Email(source);
    }
}
package com.playtomic.anemone.category.messaging;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import javax.annotation.Nonnull;
import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

@ToString
@Getter
@Builder
public class MembershipEvent {

    @Nonnull
    @JsonProperty(value = "user_id", required = true)
    private String userId;

    @Nonnull
    @JsonProperty(value = "membership_product_id", required = true)
    private String membershipProductId;

    @Nonnull
    @JsonProperty(value = "event_type", required = true)
    private MembershipEventType eventType;

    @JsonCreator
    public MembershipEvent(@Nonnull @JsonProperty(value = "user_id", required = true) String userId,
        @Nonnull @JsonProperty(value = "membership_product_id", required = true) String membershipProductId,
        @Nonnull @JsonProperty(value = "event_type", required = true) MembershipEventType eventType){
        this.userId = userId;
        this.membershipProductId = membershipProductId;
        this.eventType = eventType;
    }


    public enum MembershipEventType {
      MEMBERSHIP_SUBSCRIPTION_ACTIVATED,
        MEMBERSHIP_SUBSCRIPTION_CANCELLED
    }

    @JsonIgnore
    @Nonnull
    public String getKey() {
        return membershipProductId;
    }
}

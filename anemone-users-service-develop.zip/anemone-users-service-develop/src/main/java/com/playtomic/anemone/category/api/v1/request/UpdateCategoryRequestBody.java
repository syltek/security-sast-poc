package com.playtomic.anemone.category.api.v1.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.category.domain.BookingPrivilege;
import com.playtomic.anemone.category.domain.CategoryExpiration;
import com.playtomic.anemone.category.domain.Visibility;
import java.math.BigDecimal;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import lombok.Getter;

@Getter
@ParametersAreNonnullByDefault
public class UpdateCategoryRequestBody {

    @NotNull
    @JsonProperty(value = "name")
    private String name;
    @Valid
    @Nullable
    @JsonProperty("expiration")
    private CategoryExpiration expiration;
    @Valid
    @Nullable
    @JsonProperty("booking_privilege")
    private BookingPrivilege bookingPrivilege;
    @NotNull
    @JsonProperty("allow_single_payment_when_price_is_customized")
    private Boolean allowSinglePaymentWhenPriceIsCustomized;
    @Min(0)
    @Max(1)
    @Nullable
    @JsonProperty(value = "vat_rate")
    private BigDecimal vatRate;

    @Valid
    @Nullable
    @JsonProperty("membership_details")
    private UpdateCategoryMembershipDetails membershipDetails;

    @Getter
    public static class UpdateCategoryMembershipDetails {

        @NotNull
        @JsonProperty("visibility")
        private Visibility visibility;

        @NotNull
        @JsonProperty("description")
        private String description;

    }
}

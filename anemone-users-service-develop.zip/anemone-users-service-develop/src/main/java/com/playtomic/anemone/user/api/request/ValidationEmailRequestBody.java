package com.playtomic.anemone.user.api.request;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;

import javax.annotation.Nullable;

@Getter
public class ValidationEmailRequestBody {

    @Nullable
    private String returnPath;

    @JsonCreator
    public ValidationEmailRequestBody(
            @JsonProperty(value = "return_path") @Nullable String returnPath) {
        this.returnPath = returnPath;
    }
}

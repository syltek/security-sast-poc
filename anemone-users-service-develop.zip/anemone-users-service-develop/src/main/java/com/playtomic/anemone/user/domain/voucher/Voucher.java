package com.playtomic.anemone.user.domain.voucher;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Voucher {
    @JsonProperty("voucher_id")
    private VoucherId voucherId;

    public VoucherId getVoucherId() {
        return voucherId;
    }
}

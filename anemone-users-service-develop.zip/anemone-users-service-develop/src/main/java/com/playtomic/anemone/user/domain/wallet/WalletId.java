package com.playtomic.anemone.user.domain.wallet;

import com.playtomic.anemone.domain.generic.AbstractStringId;
import javax.annotation.Nonnull;

public class WalletId extends AbstractStringId {

    protected WalletId(@Nonnull String id) {
        super(id);
    }

    @Nonnull
    public static WalletId valueOf(@Nonnull String id) {
        return new WalletId(id);
    }
}

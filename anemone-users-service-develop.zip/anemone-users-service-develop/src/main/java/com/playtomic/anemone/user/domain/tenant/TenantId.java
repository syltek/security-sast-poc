package com.playtomic.anemone.user.domain.tenant;

import com.playtomic.anemone.domain.generic.AbstractStringId;

public class TenantId extends AbstractStringId {

    protected TenantId(String id) {
        super(id);
    }

    public static TenantId valueOf(String id) {
        return new TenantId(id);
    }

}
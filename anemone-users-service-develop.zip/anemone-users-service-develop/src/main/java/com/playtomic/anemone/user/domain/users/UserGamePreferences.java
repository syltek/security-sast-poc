package com.playtomic.anemone.user.domain.users;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Collection;
import java.util.Comparator;
import java.util.Set;
import java.util.TreeSet;
import javax.annotation.Nonnull;
import lombok.Data;

@Data
public class UserGamePreferences {

    /*
    @JsonProperty("only_content_i_can_play")
    private boolean onlyContentThatICanPlay;

    @JsonProperty("preferred_sport_id")
    @Nullable
    private String sportId;

    @JsonProperty("preferred_location")
    @Nullable
    private GameLocation preferredLocation;
    */

    @JsonProperty("time_ranges")
    @Nonnull
    private Set<GameTimeRange> timeranges =
        new TreeSet<>(Comparator
            .comparing(GameTimeRange::getDayOfWeek)
            .thenComparing(GameTimeRange::getStart)
            .thenComparing(GameTimeRange::getEnd));

    @JsonCreator
    public UserGamePreferences(
        @JsonProperty(value = "time_ranges", required = true) @Nonnull Collection<GameTimeRange> timeranges) {
        this.timeranges.addAll(timeranges);
    }
}

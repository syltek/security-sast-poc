package com.playtomic.anemone.user.domain;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import org.apache.commons.lang3.RandomStringUtils;

public class PasswordGenerator {

    private PasswordGenerator(){}
    private static final int BASE_PASSWORD_CHAR_COUNT = 16;
    private static final String PASSWORD_PATTERN_COMPLIANT_CHARS = "5#gE";

    /**
     * Generate a password compliant with pattern used in {@link PasswordValidator}
     *
     * @return a string of the generated password chars.
     */
    public static String generate() {
      // pedroserro: This was the most efficient way I found to generate a password pattern compliant using the class RandomStringUtils.
      // The other option would have been to generate portions of the password using subsets of the UTF set of chars.
        List<Character> passwordChars = (RandomStringUtils.random(BASE_PASSWORD_CHAR_COUNT, true, true) + PASSWORD_PATTERN_COMPLIANT_CHARS)
            .chars()
            .mapToObj(c -> (char) c)
            .collect(Collectors.toList());

        Collections.shuffle(passwordChars);

        return passwordChars.stream().map(String::valueOf).collect(Collectors.joining());
    }
}
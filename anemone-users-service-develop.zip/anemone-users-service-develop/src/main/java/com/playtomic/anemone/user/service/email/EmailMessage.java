package com.playtomic.anemone.user.service.email;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@RequiredArgsConstructor
@Builder
@Getter
@Setter
public class EmailMessage {

    @JsonProperty("template_id")
    @Nonnull
    private final String templateId;

    @JsonProperty("from")
    @Nonnull
    private final String from;

    @JsonProperty("to")
    @Nonnull
    private final List<String> to;

    @JsonProperty("send_after_time")
    @Nullable
    private LocalTime sendAfterTime;

    @JsonProperty("send_before_time")
    @Nullable
    private LocalTime sendBeforeTime;

    @JsonProperty("send_time_zone_id")
    @Nullable
    private ZoneId sendTimeZoneId;

    @JsonProperty("dynamic_data")
    @Nonnull
    private final Map<String, Object> dynamicData;

    @JsonProperty("locale")
    @Nonnull
    private Locale locale;
}

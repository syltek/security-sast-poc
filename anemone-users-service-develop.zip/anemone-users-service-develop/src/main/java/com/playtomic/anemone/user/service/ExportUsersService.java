package com.playtomic.anemone.user.service;

import static java.util.stream.Collectors.collectingAndThen;
import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.toList;

import com.playtomic.anemone.category.domain.CategoryId;
import com.playtomic.anemone.category.service.CategoryService;
import com.playtomic.anemone.dao.BaseEntity;
import com.playtomic.anemone.domain.Email;
import com.playtomic.anemone.user.dao.TenantTagEntity;
import com.playtomic.anemone.user.dao.UserEntity;
import com.playtomic.anemone.user.dao.UserRepository;
import com.playtomic.anemone.user.domain.csv.CsvDataMoney;
import com.playtomic.anemone.user.domain.csv.CsvDataString;
import com.playtomic.anemone.user.domain.csv.CsvWalletHeader;
import com.playtomic.anemone.user.domain.csv.WalletCsvData;
import com.playtomic.anemone.user.domain.tenant.Tenant;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import com.playtomic.anemone.user.domain.wallet.Wallet;
import com.playtomic.anemone.user.domain.wallet.WalletType;
import com.playtomic.anemone.user.model.UserFilter;
import com.playtomic.anemone.user.service.anemone.TenantServiceClient;
import com.playtomic.anemone.user.service.anemone.WalletServiceClient;
import com.playtomic.anemone.user.service.exception.ExportCsvException;
import com.playtomic.anemone.user.service.userimports.ExportUserMapper;
import com.playtomic.anemone.user.utils.ListUtils;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.Instant;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.validation.ClockProvider;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.lang3.tuple.Pair;
import org.javamoney.moneta.Money;
import org.springframework.core.io.InputStreamResource;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service
@RequiredArgsConstructor
@ParametersAreNonnullByDefault
public class ExportUsersService {

    @Nonnull
    private final UserRepository userRepository;
    @Nonnull
    private final UserService userService;
    @Nonnull
    private final CategoryService categoryService;
    @Nonnull
    private final ClockProvider clockProvider;
    @Nonnull
    private final TenantServiceClient tenantServiceClient;
    @Nonnull
    private final WalletServiceClient walletServiceClient;

    @Transactional(readOnly = true)
    public InputStreamResource exportCustomers(TenantId tenantId) {
        var tenant = tenantServiceClient.getById(tenantId);
        var wallets = getWalletsByTenantId(tenantId);
        var csvCustomerHeader = Arrays.asList("name", "email", "commercial_communications", "category", "category_expiration", "birthday", "gender",
                                              "phone_number", "connected_date");
        var csvHeaders = new ArrayList<>(csvCustomerHeader);
        final var walletsByUserId = groupByUserIdAndAddWalletHeaders(wallets, csvHeaders);

        try (var out = new ByteArrayOutputStream(); var csvPrinter = getCsvPrinter(csvHeaders.toArray(String[]::new), out)) {
            exportCustomers(csvPrinter, tenant, Boolean.TRUE, "accepted", walletsByUserId, csvHeaders);
            exportCustomers(csvPrinter, tenant, Boolean.FALSE, "rejected", walletsByUserId, csvHeaders);
            exportCustomers(csvPrinter, tenant, null, "undefined", walletsByUserId, csvHeaders);
            csvPrinter.flush();
            return new InputStreamResource(new ByteArrayInputStream(out.toByteArray()));
        } catch (IOException e) {
            throw new ExportCsvException(e);
        }
    }

    private List<Wallet> getWalletsByTenantId(@Nonnull TenantId tenantId) {
        List<Wallet> wallets = new ArrayList<>();
        boolean hasGotAllWalletChunks = false;
        int page = 0;
        while (!hasGotAllWalletChunks) {
            var walletsChunk = walletServiceClient.findByTenantId(tenantId.getValue(), WalletType.MERCHANT,
                                                                  PageRequest.of(page, 1000, Sort.by("user_id")));
            wallets.addAll(walletsChunk);
            if (walletsChunk.size() == 0) {
                hasGotAllWalletChunks = true;
            }
            page++;
        }

        return wallets;
    }

    private Map<Long, List<WalletCsvData>> groupByUserIdAndAddWalletHeaders(@Nonnull List<Wallet> wallets, @Nonnull ArrayList<String> csvHeaders) {
        Map<String, CsvWalletHeader> headerPositions = new HashMap<>();
        var result = wallets.stream()
                            .collect(
                                groupingBy(Wallet::getUserId,
                                           collectingAndThen(toList(), walletList -> toWalletCsvDataList(walletList, headerPositions, csvHeaders))));
        if (!result.isEmpty()) {
            csvHeaders.add("sum_of_wallets");
            csvHeaders.add("currency");
        }
        return result;
    }

    private List<WalletCsvData> toWalletCsvDataList(@Nonnull List<Wallet>  walletList,@Nonnull Map<String, CsvWalletHeader> headerPositions, @Nonnull List<String> csvHeaders) {
        return walletList.stream()
                         .filter(Wallet::isActive)
                         .map(wallet -> ExportUserMapper.toWalletCsvData(wallet, headerPositions, csvHeaders))
                         .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public InputStreamResource exportUsers(List<Email> emails, Pageable pageable) {
        var userFilter = UserFilter.builder().emails(emails).build();
        var profiles = userService.searchUsersByFilter(userFilter, pageable);
        var csvHeader = new String[]{"email", "user_id"};
        var csvBody = profiles.stream()
                              .map(profile -> Arrays.asList(profile.getEmail(), profile.getId().toString()))
                              .collect(Collectors.toList());
        try (var out = new ByteArrayOutputStream(); var csvPrinter = getCsvPrinter(csvHeader, out)) {
            csvBody.forEach(line -> printRecord(csvPrinter, line));
            csvPrinter.flush();
            return new InputStreamResource(new ByteArrayInputStream(out.toByteArray()));
        } catch (IOException e) {
            throw new ExportCsvException(e);
        }
    }

    private CSVPrinter getCsvPrinter(String[] csvHeader, ByteArrayOutputStream out) throws IOException {
        return new CSVPrinter(new PrintWriter(out), CSVFormat.DEFAULT.withHeader(csvHeader));
    }

    private void exportCustomers(CSVPrinter csvPrinter, Tenant tenant,
                                 @Nullable Boolean acceptsCommercialCommunications,
                                 String commercialCommunicationsString,
                                 Map<Long, List<WalletCsvData>> walletsByUserId,
                                 List<String> headers) {
        userRepository.findByLinkedAccountAndAcceptsCommercialCommunications(tenant.getTenantId().getValue(), acceptsCommercialCommunications)
                      .map(user -> getCustomerData(tenant, commercialCommunicationsString, walletsByUserId, headers, user))
                      .forEachOrdered(line -> printRecord(csvPrinter, line));
    }

    @Nonnull
    private List<String> getCustomerData(Tenant tenant, String commercialCommunicationsString, Map<Long, List<WalletCsvData>> walletsByUserId,
                                         List<String> headers, UserEntity user) {
        var result = getCustomerData(tenant, commercialCommunicationsString, user);
        ListUtils.expandList(result, headers.size(), "");
        addWalletData(result, user, walletsByUserId);

        return result;
    }

    @Nonnull
    private List<String> getCustomerData(Tenant tenant, String commercialCommunicationsString, UserEntity user) {
        var zoneId = tenant.getTenantAddress().getZoneId();
        var categoryActiveAt = user.getCategoryActiveAt(tenant.getTenantId(), clockProvider.getClock().instant())
                                   .map(tt -> getCategoryInfo(tt, zoneId))
                                   .orElseGet(() -> Pair.of(null, null));
        var userLinkedToClubDate = user.getLinkedAccount(tenant.getTenantId()).map(BaseEntity::getCreatedAt)
                                       .map(d -> getDateAtZone(d, zoneId)).orElse(null);
        var result = new ArrayList<String>();
        result.add(user.getFullName());
        result.add(user.getEmail());
        result.add(commercialCommunicationsString);
        result.add(categoryActiveAt.getLeft());
        result.add(categoryActiveAt.getRight());
        result.add(getDateAtZone(user.getBirthDate(), zoneId));
        result.add(user.getGender() == null ? null : user.getGender().name());
        result.add(user.getPhone());
        result.add(userLinkedToClubDate);

        return result;
    }

    private void addWalletData(@Nonnull List<String> csvRow, @Nonnull UserEntity user,
                               @Nonnull Map<Long, List<WalletCsvData>> walletsCsvData) {
        var userWallets = walletsCsvData.get(user.getId());

        if (userWallets != null && !userWallets.isEmpty()) {
            var currency = userWallets.get(0).getBalance().getValue().getCurrency();
            Money totalAmount = Money.of(0, currency);

            for (WalletCsvData wallet : userWallets) {
                final CsvDataString walletName = wallet.getWalletName();
                csvRow.set(walletName.getPosition(), walletName.getValue());

                final CsvDataMoney walletBalance = wallet.getBalance();
                csvRow.set(walletBalance.getPosition(), String.valueOf(walletBalance.getValue().getNumber().doubleValueExact()));

                totalAmount = totalAmount.add(walletBalance.getValue());
            }

            csvRow.set(csvRow.size() - 2, String.valueOf(totalAmount.getNumber().doubleValueExact()));
            csvRow.set(csvRow.size() - 1, currency.toString());
        }
    }

    @Nonnull
    private Pair<String, String> getCategoryInfo(TenantTagEntity tt, ZoneId zoneId) {
        var expiresAt = tt.getExpiresAt();
        String expiresAtDate = getDateAtZone(expiresAt, zoneId);
        return Pair.of(categoryService.getCategory(CategoryId.valueOf(tt.getTag())).getName(), expiresAtDate);
    }

    @Nullable
    private String getDateAtZone(@Nullable Instant dateTime, ZoneId zoneId) {
        return dateTime == null ? null : dateTime.atZone(zoneId).toLocalDate().toString();
    }

    private void printRecord(CSVPrinter csvPrinter, List<String> line) {
        try {
            csvPrinter.printRecord(line);
        } catch (IOException e) {
            throw new ExportCsvException(e);
        }
    }

}

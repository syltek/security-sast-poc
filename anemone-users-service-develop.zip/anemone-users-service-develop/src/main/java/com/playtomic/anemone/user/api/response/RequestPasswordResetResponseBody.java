package com.playtomic.anemone.user.api.response;

import com.playtomic.anemone.http.response.GenericResponseBody;
import com.playtomic.anemone.user.api.response.RequestPasswordResetResponseBody.RequestPasswordResetResponseStatus;
import javax.annotation.Nonnull;

public class RequestPasswordResetResponseBody extends
    GenericResponseBody<RequestPasswordResetResponseStatus> {
    public enum RequestPasswordResetResponseStatus {
        SENT
    }

    public RequestPasswordResetResponseBody(@Nonnull RequestPasswordResetResponseStatus status,
                                            String localizedMessage) {
        super(status, localizedMessage);
    }
}
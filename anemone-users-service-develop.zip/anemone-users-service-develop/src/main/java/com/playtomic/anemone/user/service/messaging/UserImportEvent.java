package com.playtomic.anemone.user.service.messaging;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.user.domain.userimports.UserImportDataRow;
import lombok.Getter;
import lombok.ToString;
import org.springframework.util.Assert;

import javax.annotation.Nonnull;

@ToString
@Getter
public class UserImportEvent {

    public enum UserImportEventType {
        IMPORT
    }

    @JsonProperty(value = "event_type", required = true)
    @Nonnull
    private UserImportEventType eventType;

    @JsonProperty(value = "event_data", required = true)
    @Nonnull
    private UserImportDataRow userImportDataRow;

    @JsonCreator
    public UserImportEvent(@JsonProperty(value = "event_type", required = true) @Nonnull UserImportEventType eventType,
                           @JsonProperty(value = "event_data", required = true) @Nonnull UserImportDataRow userImportDataRow) {
        this.eventType = eventType;
        this.userImportDataRow = userImportDataRow;
    }

    @JsonIgnore
    @Nonnull
    public String getKey() {
        // Using tenantId as key involves that the events will be processed one by one even within tenant different imports,
        // no parallelization; which in this case seems to be interesting for us (avoid concurrency & saturation issues)
        Assert.notNull(userImportDataRow.getTenant(), "TenantId cannot be null when publishing a UserImportEvent as it is used as key");
        return userImportDataRow.getTenant().getTenantId().toString();
    }
}

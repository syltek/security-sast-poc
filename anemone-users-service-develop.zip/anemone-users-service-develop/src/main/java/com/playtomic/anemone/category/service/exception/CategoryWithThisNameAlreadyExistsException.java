package com.playtomic.anemone.category.service.exception;

import javax.annotation.Nonnull;

public class CategoryWithThisNameAlreadyExistsException extends RuntimeException {

    public CategoryWithThisNameAlreadyExistsException(@Nonnull String name) {
        super(String.format("Category with name %s already exists", name));
    }
}

package com.playtomic.anemone.category.service.exception;

import com.playtomic.anemone.category.domain.CategoryId;
import javax.annotation.Nonnull;

public class CategoryIsDisabledException extends RuntimeException {

    public CategoryIsDisabledException(@Nonnull CategoryId categoryId) {
        super(String.format("Category %s is disabled", categoryId));
    }
}

package com.playtomic.anemone.user.service.messaging;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.domain.user.UserId;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

@Getter
@Builder
@ToString
public class UserUpdateTenantTagEvent {
    // Currently not checking this value.

    @JsonProperty(value = "event_type")
    @Nullable
    private String eventType;

    @JsonProperty(value = "event_data")
    @Nonnull
    private UserId userId;

    @JsonCreator
    protected UserUpdateTenantTagEvent(
        @JsonProperty(value = "event_type") @Nullable String eventType,
        @JsonProperty(value = "event_data", required = true) @Nonnull UserId userId) {
        this.eventType = eventType;
        this.userId = userId;
    }

    @JsonIgnore
    @Nonnull
    public String getKey() {
        return userId.toString();
    }
}

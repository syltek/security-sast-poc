package com.playtomic.anemone.user.domain.matches;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import javax.annotation.Nonnull;

@Data
@NoArgsConstructor
public class Team {

    @Nonnull
    private TeamId teamId;

    @Nonnull
    private List<Player> players;

    @JsonCreator
    public Team(@JsonProperty("team_id") @Nonnull TeamId teamId,
                @JsonProperty("players") @Nonnull List<Player> players) {
        this.teamId = teamId;
        this.players = players;
    }
}

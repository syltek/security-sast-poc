package com.playtomic.anemone.user.api.request;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.user.model.ExtendedUserRole;

import lombok.Getter;

import java.util.Set;
import javax.annotation.Nonnull;

@Getter
public class CreateUserRoleRequestBody {

    @Nonnull
    private Set<ExtendedUserRole> userRoles;

    @JsonCreator
    public CreateUserRoleRequestBody(
            @JsonProperty(value = "user_roles", required = true) @Nonnull Set<ExtendedUserRole> userRoles) {
        this.userRoles = userRoles;
    }
}

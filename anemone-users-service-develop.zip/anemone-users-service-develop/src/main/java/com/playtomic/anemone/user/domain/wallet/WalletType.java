package com.playtomic.anemone.user.domain.wallet;

public enum WalletType {
    PLAYTOMIC,
    MERCHANT
}

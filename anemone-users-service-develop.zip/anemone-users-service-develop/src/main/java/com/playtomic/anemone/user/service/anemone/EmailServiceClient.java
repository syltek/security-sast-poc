package com.playtomic.anemone.user.service.anemone;

import com.playtomic.anemone.jwt.JwtTokenFactory;
import com.playtomic.anemone.spring.ForceAnemoneAuthenticationCredentialsAccessor;
import com.playtomic.anemone.spring.feign.AnemoneFeignConfiguration;
import com.playtomic.anemone.spring.feign.AuthenticationHeaderFeignInterceptor;
import com.playtomic.anemone.user.service.email.EmailMessage;
import feign.RequestInterceptor;
import java.util.List;
import javax.annotation.Nonnull;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "emails-service", configuration = EmailServiceClient.Configuration.class, url = "${emails-service.url}")
public interface EmailServiceClient {

    @PostMapping(value = "/v1/emails", consumes = "application/json")
    void sendEmail(@RequestBody @Nonnull EmailMessage email);

    @PostMapping(value = "/v1/emails_batch", consumes = "application/json")
    void sendEmailBatch(@RequestBody @Nonnull List<EmailMessage> emailList);

    class Configuration extends AnemoneFeignConfiguration {

        @Bean
        public RequestInterceptor requestInterceptor(@Nonnull JwtTokenFactory jwtTokenFactory) {
            return new AuthenticationHeaderFeignInterceptor(new ForceAnemoneAuthenticationCredentialsAccessor(jwtTokenFactory));
        }

    }
}

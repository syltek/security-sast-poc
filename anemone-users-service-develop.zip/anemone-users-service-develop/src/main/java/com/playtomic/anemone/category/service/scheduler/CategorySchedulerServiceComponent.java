package com.playtomic.anemone.category.service.scheduler;


import com.playtomic.anemone.category.config.CategoryTasksConfigurations;
import com.playtomic.anemone.category.config.CategoryTasksConfigurations.TaskConfiguration;
import com.playtomic.anemone.category.domain.Category;
import com.playtomic.anemone.category.domain.CategoryId;
import com.playtomic.anemone.category.domain.scheduler.MemberTaskDetails;
import com.playtomic.anemone.category.domain.scheduler.ScheduledTask;
import com.playtomic.anemone.user.dao.UserEntity;
import com.playtomic.anemone.user.domain.tenant.Tenant;
import com.playtomic.anemone.user.service.anemone.SchedulerServiceClient;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Map;
import javax.annotation.Nonnull;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.validation.ClockProvider;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.web.util.UriComponentsBuilder;

@Component
@ParametersAreNonnullByDefault
@RequiredArgsConstructor
@Slf4j
public class CategorySchedulerServiceComponent {

    @Nonnull
    private final CategoryTasksConfigurations categoryTasksConfigurations;
    @Nonnull
    private final SchedulerServiceClient schedulerClient;
    @Nonnull
    private final ClockProvider clockProvider;
    @Nonnull
    public static final Integer DAYS_BEFORE_SEND_REMINDER = 15;
    @Nonnull
    public static final Integer HOURS_TO_RETRY_TASK = 1;

    @Async
    public void scheduleMemberExpirationTasks(List<UserEntity> users, Map<Long, Instant> userIdAndExpiresAt, Category category,
        Tenant tenant) {
        Instant currentTime = clockProvider.getClock().instant();

        users.stream()
            .filter(user -> userIdAndExpiresAt.get(user.getId()) != null)
            .map(user -> toMemberTaskDetails(user, userIdAndExpiresAt, category, tenant))
            .map(memberTaskDetails -> {
                scheduleMemberDeletionTask(memberTaskDetails, category.getId());
                return memberTaskDetails;
            })
            .filter(memberTaskDetails -> currentTime.plus(DAYS_BEFORE_SEND_REMINDER, ChronoUnit.DAYS).isBefore(memberTaskDetails.getExpiresAt()))
            .forEach(memberTaskDetails -> scheduleMembershipExpirationReminderTask(memberTaskDetails, category.getId()));
    }

    @Async
    public void scheduleMemberDeletionTask(MemberTaskDetails memberTaskDetails, CategoryId categoryId) {
        TaskConfiguration taskConfiguration = categoryTasksConfigurations.getMemberDeleteExpired();
        scheduleMemberTask(
            taskConfiguration,
            memberTaskDetails.getExpiresAt().plus(taskConfiguration.getTriggerDelayMinutes(), ChronoUnit.MINUTES),
            memberTaskDetails,
            categoryId);
    }

    @Async
    public void scheduleMembershipExpirationReminderTask(MemberTaskDetails memberTaskDetails, CategoryId categoryId) {
        TaskConfiguration taskConfiguration = categoryTasksConfigurations.getMemberExpirationReminder();
        scheduleMemberTask(
            taskConfiguration,
            memberTaskDetails.getExpiresAt()
                .minus(DAYS_BEFORE_SEND_REMINDER, ChronoUnit.DAYS)
                .plus(taskConfiguration.getTriggerDelayMinutes(), ChronoUnit.MINUTES),
            memberTaskDetails,
            categoryId);
    }

    private void scheduleMemberTask(TaskConfiguration taskConfiguration, Instant startAt, MemberTaskDetails memberTaskDetails,
        CategoryId categoryId) {
        try {
            URL url = UriComponentsBuilder.newInstance()
                .scheme("http")
                .host(categoryTasksConfigurations.getCallBackHost())
                .port(categoryTasksConfigurations.getCallBackPort())
                .path(taskConfiguration.getTargetEndpoint().replace("{category_id}", categoryId.getValue().toString()))
                .build().toUri().toURL();
            scheduleTask(url, taskConfiguration, startAt, memberTaskDetails);
        } catch (MalformedURLException e) {
            log.error("Error building task URL, skipping task schedule", e);
        }
    }

    private void scheduleTask(URL url, TaskConfiguration taskConfiguration, Instant startAt, Object payload) {

        ScheduledTask task = ScheduledTask.builder()
            .groupId(taskConfiguration.getGroupId())
            .description(taskConfiguration.getDescription())
            .startAt(startAt)
            .endAt(startAt.plus(HOURS_TO_RETRY_TASK, ChronoUnit.HOURS))
            .isRecoverable(taskConfiguration.isRecoverable())
            .misfiredPolicy(taskConfiguration.getMisfiredPolicy())
            .payload(payload)
            .callbackUrl(url)
            .build();

        schedulerClient.scheduleTask(task);

    }

    @Nonnull
    private MemberTaskDetails toMemberTaskDetails(UserEntity user, Map<Long, Instant> userIdAndExpiresAt, Category category, Tenant tenant) {
        return MemberTaskDetails.builder()
            .userId(user.getId().toString())
            .expiresAt(userIdAndExpiresAt.get(user.getId()))
            .tenantId(tenant.getTenantId().getValue())
            .tenantName(tenant.getTenantName())
            .tenantZoneId(tenant.getTenantAddress().getZoneId())
            .categoryName(category.getName())
            .build();
    }
}

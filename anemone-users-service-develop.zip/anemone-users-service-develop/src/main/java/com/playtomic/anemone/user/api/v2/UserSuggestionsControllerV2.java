package com.playtomic.anemone.user.api.v2;

import com.playtomic.anemone.category.domain.CategoryId;
import com.playtomic.anemone.http.LinkHeader;
import com.playtomic.anemone.user.config.UserPermissionService;
import com.playtomic.anemone.user.domain.matches.SportId;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import com.playtomic.anemone.user.model.CustomerUserProfile;
import com.playtomic.anemone.user.service.CoachService;
import com.playtomic.anemone.user.service.PermissionService;
import com.playtomic.anemone.user.service.UserService;
import java.util.List;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.context.MessageSource;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping(path = "/v2/users/suggestions")
@ParametersAreNonnullByDefault
public class UserSuggestionsControllerV2 extends AbstractUserRestController {

    @Nonnull
    private final CoachService coachService;

    public UserSuggestionsControllerV2(MessageSource messageSource,
        DiscoveryClient discoveryClient, UserPermissionService userPermissionService,
        PermissionService permissionService, UserService userService, CoachService coachService) {
        super(messageSource, discoveryClient, userPermissionService, permissionService, userService);
        this.coachService = coachService;
    }

    /**
     * This endpoint is intended to internally find the best options for the provided filter.
     * The tenant is taken into account but not necessarily used depending on results:
     * 1 - If email or phone is found the user is returned, with independence of the tenant.
     * 2 - Else a search by name patter is performed (filter is contained) only on linked accounts
     */
    @Nonnull
    @GetMapping(path = {"", "/players"})
    @PreAuthorize("hasPermission(#tenantId, 'read_private_profile')")
    public ResponseEntity<List<CustomerUserProfile>> searchSuggestedPlayers(@RequestParam(name = "filter") String filter,
        @RequestParam(name = "tenant_id") TenantId tenantId, Pageable pageable) {
        var profiles = userService.searchSuggestedPlayers(filter, getDefaultUserPhoneCountryCode(), tenantId, pageable);
        sanitize(profiles, getAuthentication());
        return LinkHeader.toResponse(profiles);
    }

    @Nonnull
    @GetMapping(path = "/admins")
    @PreAuthorize("hasPermission(#tenantId, 'read_user_roles')")
    public ResponseEntity<List<CustomerUserProfile>> searchSuggestedAdmins(@RequestParam(name = "filter") String filter,
        @RequestParam(name = "tenant_id") TenantId tenantId, Pageable pageable) {
        var profiles = userService.searchAdmins(filter, tenantId, pageable);
        sanitize(profiles, getAuthentication());
        return LinkHeader.toResponse(profiles);
    }


    @Nonnull
    @GetMapping(path = "/coaches")
    @PreAuthorize("hasPermission(#tenantId, 'read_coach_accounts')")
    public ResponseEntity<List<CustomerUserProfile>> searchSuggestedCoaches(@RequestParam(name = "tenant_id") TenantId tenantId,
        @RequestParam(name = "sport_id") @Nullable SportId sportId, @RequestParam(name = "filter") @Nullable String filter, Pageable pageable) {
        var profiles = coachService.searchCoaches(tenantId, sportId, filter, pageable);
        sanitize(profiles, getAuthentication());
        return LinkHeader.toResponse(profiles);
    }

    /**
     * This endpoint is intended to search users who are customers of a specific tenant,
     * i.e., only customers linked to the tenantId provided will be returned.
     */
    @Nonnull
    @GetMapping(path = "/customers")
    @PreAuthorize("hasPermission(#tenantId, 'read_user_roles')")
    public ResponseEntity<List<CustomerUserProfile>> searchSuggestedCustomers(@RequestParam(name = "filter") String filter,
        @RequestParam(name = "tenant_id") TenantId tenantId, Pageable pageable) {
        var customers = userService.searchCustomers(filter, tenantId, pageable);
        sanitize(customers, getAuthentication());
        return LinkHeader.toResponse(customers);
    }

    @Nonnull
    @GetMapping(path = {"/members", "/category_members"})
    @PreAuthorize("hasPermission(#categoryId, 'read_user_roles')")
    public ResponseEntity<List<CustomerUserProfile>> searchSuggestedMembers(@RequestParam(name = "filter") String filter,
        @RequestParam(name = "category_id") CategoryId categoryId, Pageable pageable) {
        var members = userService.searchMembers(filter, categoryId, pageable);
        sanitize(members, getAuthentication());
        return LinkHeader.toResponse(members);
    }

}

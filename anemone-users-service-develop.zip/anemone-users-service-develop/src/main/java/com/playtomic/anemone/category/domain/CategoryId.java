package com.playtomic.anemone.category.domain;

import com.playtomic.anemone.domain.generic.AbstractUuidId;
import java.util.UUID;
import javax.annotation.Nonnull;

public class CategoryId extends AbstractUuidId {

    protected CategoryId(@Nonnull String id) {
        super(id);
    }

    protected CategoryId(@Nonnull UUID id) {
        super(id);
    }

    public static CategoryId valueOf(@Nonnull String id) {
        return new CategoryId(id);
    }

    public static CategoryId valueOf(@Nonnull UUID id) {
        return new CategoryId(id);
    }
}

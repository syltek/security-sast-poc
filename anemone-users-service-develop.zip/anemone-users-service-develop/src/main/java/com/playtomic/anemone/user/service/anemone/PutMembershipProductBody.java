package com.playtomic.anemone.user.service.anemone;

import com.fasterxml.jackson.annotation.JsonProperty;
import javax.annotation.Nonnull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;


@AllArgsConstructor
@Builder
@NoArgsConstructor
public class PutMembershipProductBody {

    @Nonnull
    @JsonProperty("description")
    private String description;

}
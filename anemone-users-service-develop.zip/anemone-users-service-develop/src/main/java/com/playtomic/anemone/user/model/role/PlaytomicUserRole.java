package com.playtomic.anemone.user.model.role;

import com.playtomic.anemone.domain.user.UserRole;
import lombok.AllArgsConstructor;
import lombok.Getter;

import javax.annotation.Nonnull;

/**
 * This class is a limited version of UserRole for users-service.
 * Giving access in users-service to all variety of UserRoles is a bit reckless: there is no control
 * about what roles can be given.
 *
 * At this moment, only ROLE_CUSTOMER, TENANT_MANAGER, ACTIVITY_MANAGER are safe roles to give to a regular user.
 */
@AllArgsConstructor
public enum PlaytomicUserRole {
    ROLE_CUSTOMER(UserRole.ROLE_CUSTOMER),
    ROLE_TENANT_MANAGER(UserRole.ROLE_TENANT_MANAGER),
    ROLE_ACTIVITY_MANAGER(UserRole.ROLE_ACTIVITY_MANAGER)
    ;

    @Getter
    @Nonnull
    private UserRole anemoneRole;
}

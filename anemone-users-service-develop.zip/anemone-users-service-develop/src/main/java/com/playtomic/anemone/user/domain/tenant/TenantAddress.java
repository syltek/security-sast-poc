package com.playtomic.anemone.user.domain.tenant;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.domain.generic.Address;
import com.playtomic.anemone.domain.location.Location;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import java.time.ZoneId;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;

@EqualsAndHashCode(callSuper = true)
@Getter
@Setter
public class TenantAddress extends Address {
    @Nullable
    @JsonProperty("country_code")
    private String countryCode;

    @Nonnull
    @JsonProperty("coordinate")
    private Location coordinate;

    @Nonnull
    @JsonProperty("timezone")
    private ZoneId zoneId;

    @JsonCreator
    public TenantAddress(@JsonProperty(value = "street", required = true) String street,
                         @JsonProperty(value = "postal_code") String postalCode,
                         @JsonProperty(value = "city") String city,
                         @JsonProperty(value = "sub_administrative_area") String subAdministrativeArea,
                         @JsonProperty(value = "administrative_area") String administrativeArea,
                         @JsonProperty(value = "country") String country,
                         @JsonProperty(value = "country_code") String countryCode,
                         @JsonProperty(value = "coordinate", required = true) Location coordinate,
                         @JsonProperty(value = "timezone", required = true) ZoneId zoneId) {
        super(street, postalCode, city, subAdministrativeArea, administrativeArea, country);
        this.countryCode = countryCode;
        this.coordinate = coordinate;
        this.zoneId = zoneId;
    }

}

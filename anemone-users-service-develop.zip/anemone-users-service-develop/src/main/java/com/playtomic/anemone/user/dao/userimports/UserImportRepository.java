package com.playtomic.anemone.user.dao.userimports;

import com.playtomic.anemone.user.domain.tenant.TenantId;
import com.playtomic.anemone.user.domain.userimports.UserImport;
import com.playtomic.anemone.user.domain.userimports.UserImportId;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;

import javax.annotation.Nonnull;

public interface UserImportRepository extends MongoRepository<UserImport, UserImportId> {

    Page<UserImport> findUserImportByTenantId(@Nonnull TenantId tenantId, @Nonnull Pageable pageable);

}

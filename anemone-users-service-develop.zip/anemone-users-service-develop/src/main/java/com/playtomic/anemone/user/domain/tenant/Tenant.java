package com.playtomic.anemone.user.domain.tenant;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.playtomic.anemone.converter.CurrencyUnitDeserializer;
import com.playtomic.anemone.converter.CurrencyUnitSerializer;
import java.net.URL;
import java.util.Locale;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.money.CurrencyUnit;
import lombok.Data;

@Data
public class Tenant {

    public final static String SYLTEKCRM_TENANT_TYPE = "SYLTEKCRM";
    public final static String ANEMONE_TENANT_TYPE = "ANEMONE";
    public final static String ACTIVE_PLAYTOMIC_STATUS = "ACTIVE";
    public final static String INACTIVE_PLAYTOMIC_STATUS = "INACTIVE";

    @JsonProperty(value = "tenant_id")
    @Nonnull
    private TenantId tenantId;

    @JsonProperty(value = "url")
    @Nonnull
    private URL url;

    @JsonProperty(value = "tenant_name")
    @Nonnull
    private String tenantName;

    @JsonProperty(value = "tenant_type")
    @Nonnull
    private String tenantType;

    @JsonProperty(value = "address")
    @Nonnull
    private TenantAddress tenantAddress;

    @JsonProperty(value = "playtomic_status")
    @Nonnull
    private String playtomicStatus;

    @JsonProperty(value = "custom_syltekcrm_apikey")
    @Nullable
    private String customApiKey;

    @JsonProperty("onboarding_status")
    @Nullable
    private String onboardingStatus;

    @JsonProperty("communications_language")
    @Nonnull
    private Locale communicationsLanguage;

    @JsonProperty("default_currency")
    @JsonSerialize(using = CurrencyUnitSerializer.class)
    @Nonnull
    private CurrencyUnit defaultCurrency;

    @JsonCreator
    public Tenant(
        @JsonProperty(value = "tenant_id", required = true) @Nonnull TenantId tenantId,
        @JsonProperty(value = "url", required = true) @Nonnull URL url,
        @JsonProperty(value = "tenant_name", required = true) @Nonnull String tenantName,
        @JsonProperty(value = "tenant_type", required = true) @Nonnull String tenantType,
        @JsonProperty(value = "address", required = true) @Nonnull TenantAddress tenantAddress,
        @JsonProperty(value = "playtomic_status", required = true) @Nonnull String playtomicStatus,
        @JsonProperty(value = "custom_syltekcrm_apikey") @Nullable String customApiKey,
        @JsonProperty(value = "onboarding_status") @Nullable String onboardingStatus,
        @JsonProperty("communications_language")  @Nonnull Locale communicationsLanguage,
        @JsonProperty(value = "default_currency", required = true) @Nonnull @JsonDeserialize(using = CurrencyUnitDeserializer.class) CurrencyUnit defaultCurrency
        ) {
        this.tenantId = tenantId;
        this.tenantName = tenantName;
        this.url = url;
        this.tenantType = tenantType;
        this.tenantAddress = tenantAddress;
        this.playtomicStatus = playtomicStatus;
        this.customApiKey = customApiKey;
        this.onboardingStatus = onboardingStatus;
        this.communicationsLanguage = communicationsLanguage;
        this.defaultCurrency = defaultCurrency;
    }


    public boolean isSyltekCrm() {
        return SYLTEKCRM_TENANT_TYPE.equalsIgnoreCase(tenantType);
    }

    public boolean isAnemone() {
        return ANEMONE_TENANT_TYPE.equalsIgnoreCase(tenantType);
    }

    public boolean isActive() {
        return ACTIVE_PLAYTOMIC_STATUS.equalsIgnoreCase(playtomicStatus);
    }

    // Note that playtomic status has a third option called UNBOOKEABLE, that's why we cannot simply use the negation of "isActive" method
    public boolean isInactive() {
        return INACTIVE_PLAYTOMIC_STATUS.equalsIgnoreCase(playtomicStatus);
    }
}

package com.playtomic.anemone.user.dao;

import com.playtomic.anemone.category.dao.CategoryDocument;
import com.playtomic.anemone.category.domain.Category;
import com.playtomic.anemone.category.service.exception.UserIsAlreadyAssignedToCategoryInTenantException;
import com.playtomic.anemone.dao.BaseEntity;
import com.playtomic.anemone.user.dao.TenantTagEntity.Type;
import com.playtomic.anemone.user.domain.UserProfile;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import com.playtomic.anemone.user.model.CustomerAddress;
import com.playtomic.anemone.user.model.PrivacyProfile;
import com.playtomic.anemone.user.model.UserGender;
import java.time.Instant;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.LocaleUtils;
import org.springframework.security.access.AccessDeniedException;

@Entity
@Table(name = "user")
@Access(AccessType.FIELD)
@Getter
@Setter
public class UserEntity extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id")
    private Long id;

    @Column(name = "name")
    private String fullName;

    @Column(name = "password")
    private String passwordHash;

    @Column(name = "email")
    private String email;

    @Column(name = "email_verified")
    private boolean emailVerified;

    @Column(name = "phone")
    private String phone;

    @Column(name = "phone_verified")
    private boolean phoneVerified;

    @Column(name = "status")
    private UserStatus status;

    @Column(name = "is_deleted")
    private boolean isDeleted;

    @Column(name = "facebook_id")
    private String facebookId;

    @Column(name = "google_id")
    private String googleId;

    @Column(name = "apple_id")
    private String appleId;

    @Column(name = "photo")
    @Nullable
    private String profilePhotoFilename;

    @Column(name = "accepts_privacy_policy")
    @Nullable
    private Boolean acceptsPrivacyPolicy;

    @Column(name = "privacy_last_modified")
    @Nullable
    private Instant privacyLastModified;

    @Column(name = "accepts_commercial_communications")
    @Nullable
    private Boolean acceptsCommercialCommunications;

    @Column(name = "commercial_last_modified")
    @Nullable
    private Instant commercialLastModified;

    @Nonnull
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "user", fetch = FetchType.LAZY)
    private Set<LinkedAccountEntity> linkedAccounts = new HashSet<>();

    @Nonnull
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "user", fetch = FetchType.LAZY)
    private Set<CoachAccountEntity> coachAccounts = new HashSet<>();

    @Nonnull
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "user", fetch = FetchType.LAZY)
    private Set<TenantOwnerAccountEntity> tenantOwnerAccounts = new HashSet<>();

    @Column(name = "birth_date")
    @Nullable
    private Instant birthDate;

    @Column(name = "gender")
    @Enumerated(EnumType.STRING)
    @Nullable
    private UserGender gender;

    @Column(name = "bio")
    @Nullable
    private String bio;

    @Column(name = "country_code")
    @Nonnull
    private String countryCode;

    @Column(name = "address_street")
    @Nullable
    private String addressStreet;

    @Column(name = "address_zip_code")
    @Nullable
    private String addressZipCode;

    @Column(name = "address_city")
    @Nullable
    private String addressCity;

    @Column(name = "address_state")
    @Nullable
    private String addressState;

    @Column(name = "badges")
    @Nullable
    private String badges;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "user", fetch = FetchType.LAZY)
    @Nonnull
    private Set<UserRoleEntity> userRoles = new HashSet<>();

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "user", fetch = FetchType.LAZY)
    @Nonnull
    private Set<TenantTagEntity> tenantTags = new HashSet<>();

    @Column(name = "communications_language")
    @Nonnull
    private String communicationsLanguage;

    @Column(name = "created_by")
    @Nullable
    private String createdBy;

    @Column(name = "created_by_tenant")
    @Nullable
    private String createdByTenant;

    @Column(name = "privacy_profile")
    @Enumerated(EnumType.STRING)
    @Nonnull
    private PrivacyProfile privacyProfile;

    @Column(name = "type")
    @Enumerated(EnumType.STRING)
    @Nonnull
    private PlaytomicUserType type;
    
    @Column(name = "is_premium")
    @Nonnull
    private Boolean isPremium;

    @Column(name = "premium_expires_at")
    @Nullable
    private Instant premiumExpiresAt;

    public UserEntity() {
    }

    public UserEntity(@Nonnull String fullName, @Nonnull String passwordHash,
        @Nullable String email, boolean emailVerified,
        @Nullable String phone, boolean phoneVerified,
        @Nullable Boolean acceptsPrivacyPolicy, @Nullable Boolean acceptsCommercialCommunications,
        @Nullable String facebookId, @Nullable String googleId, @Nullable String appleId,
        @Nonnull String countryCode, @Nullable CustomerAddress address,
        @Nullable Locale communicationsLanguage, @Nullable UserGender gender, @Nullable Instant birthDate,
        @Nullable TenantId tenantId, @Nullable String createdBy, @Nonnull PlaytomicUserType userType) {
        this(fullName, passwordHash, email, emailVerified, phone, phoneVerified, acceptsPrivacyPolicy,
            acceptsCommercialCommunications, facebookId, googleId, appleId, countryCode, address,
            communicationsLanguage, gender, birthDate, userType);
        this.createdBy = createdBy;
        this.createdByTenant = tenantId == null ? null : tenantId.getValue();
    }

    public UserEntity(@Nonnull String fullName, @Nonnull String passwordHash,
        @Nullable String email, boolean emailVerified,
        @Nullable String phone, boolean phoneVerified,
        @Nullable Boolean acceptsPrivacyPolicy, @Nullable Boolean acceptsCommercialCommunications,
        @Nonnull String countryCode, @Nonnull PlaytomicUserType type) {
        this(fullName, passwordHash, email, emailVerified, phone, phoneVerified, acceptsPrivacyPolicy, acceptsCommercialCommunications,
            null, null, null, countryCode, null, null, type);
    }

    public UserEntity(@Nonnull String fullName, @Nonnull String passwordHash,
        @Nullable String email, boolean emailVerified,
        @Nullable String phone, boolean phoneVerified,
        @Nullable Boolean acceptsPrivacyPolicy, @Nullable Boolean acceptsCommercialCommunications,
        @Nullable String facebookId, @Nullable String googleId, @Nullable String appleId,
        @Nonnull String countryCode,
        @Nullable CustomerAddress address,
        @Nullable Locale communicationsLanguage,
        @Nonnull PlaytomicUserType type) {
        this(fullName, passwordHash, email, emailVerified, phone, phoneVerified, acceptsPrivacyPolicy, acceptsCommercialCommunications, facebookId,
            googleId, appleId, countryCode, address, communicationsLanguage, null, null, type);
    }

    public UserEntity(@Nonnull String fullName, @Nonnull String passwordHash,
        @Nullable String email, boolean emailVerified,
        @Nullable String phone, boolean phoneVerified,
        @Nullable Boolean acceptsPrivacyPolicy, @Nullable Boolean acceptsCommercialCommunications,
        @Nullable String facebookId, @Nullable String googleId, @Nullable String appleId,
        @Nonnull String countryCode, @Nullable CustomerAddress address,
        @Nullable Locale communicationsLanguage, @Nullable UserGender gender, @Nullable Instant birthDate,
        @Nonnull PlaytomicUserType type) {
        this.fullName = fullName;
        this.passwordHash = passwordHash;
        this.email = email;
        this.emailVerified = emailVerified;
        this.phone = phone;
        this.phoneVerified = phoneVerified;
        this.status = UserStatus.ACTIVE;
        this.isDeleted = false;
        this.facebookId = facebookId;
        this.googleId = googleId;
        this.appleId = appleId;
        if (acceptsPrivacyPolicy != null) {
            this.setAcceptsPrivacyPolicy(acceptsPrivacyPolicy);
        }
        if (acceptsCommercialCommunications != null) {
            this.setAcceptsCommercialCommunications(acceptsCommercialCommunications);
        }
        this.countryCode = countryCode;

        if (address != null) {
            this.addressStreet = address.getStreet();
            this.addressZipCode = address.getZipCode();
            this.addressCity = address.getCity();
            this.addressState = address.getState();
        }
        setCommunicationsLanguage(communicationsLanguage);
        this.gender = gender;
        this.birthDate = birthDate;
        this.privacyProfile = PrivacyProfile.PUBLIC;
        this.type = type;
        this.isPremium = false; // on creation no user can be premium.
        this.premiumExpiresAt = null;
    }

    public void setAcceptsPrivacyPolicy(@Nonnull Boolean acceptsPrivacyPolicy) {
        this.acceptsPrivacyPolicy = acceptsPrivacyPolicy;
        this.privacyLastModified = Instant.now();
    }

    public void setAcceptsCommercialCommunications(@Nonnull Boolean acceptsCommercialCommunications) {
        this.acceptsCommercialCommunications = acceptsCommercialCommunications;
        this.commercialLastModified = Instant.now();
    }

    public void setCommunicationsLanguage(@Nullable Locale communicationsLanguage) {
        this.communicationsLanguage = communicationsLanguage == null ? UserProfile
            .generateCommunicationsLanguage(countryCode).toString() :
            communicationsLanguage.toString();
    }

    public void setAddress(@Nonnull CustomerAddress address) {
        this.setAddressStreet(address.getStreet());
        this.setAddressZipCode(address.getZipCode());
        this.setAddressCity(address.getCity());
        this.setAddressState(address.getState());
    }

    @Nonnull
    public CustomerAddress addressToDomain() {
        return new CustomerAddress(addressStreet, addressZipCode, addressCity, addressState, countryCode);
    }

    @Nullable
    public CoachAccountEntity findCoachAccount(@Nonnull TenantId tenantId) {
        return coachAccounts.stream()
            .filter(c -> tenantId.getValue().equals(c.getTenantId()))
            .findFirst()
            .orElse(null);
    }

    @Nullable
    public TenantOwnerAccountEntity findOwnerAccount(@Nonnull TenantId tenantId) {
        return tenantOwnerAccounts.stream()
            .filter(c -> tenantId.getValue().equals(c.getTenantId()))
            .findFirst()
            .orElse(null);
    }

    public void addCategory(@Nonnull Category category, @Nullable Instant expiresAt) {
        var categoryTag = new TenantTagEntity(
            this,
            category.getId().getValue().toString(),
            category.getTenantId(),
            Type.ANEMONE_CATEGORY,
            expiresAt);
        tenantTags.add(categoryTag);
    }

    // todo remove this from tests and use addCategory(@Nonnull Category category, @Nullable Instant expiresAt)
    public void addCategory(@Nonnull CategoryDocument categoryDocument, @Nullable Instant expiresAt) {
        var category = new TenantTagEntity(
            this,
            categoryDocument.getId().getValue().toString(),
            categoryDocument.getTenantId().getValue(),
            Type.ANEMONE_CATEGORY,
            expiresAt);
        tenantTags.add(category);
    }

    @Nonnull
    public Optional<TenantTagEntity> getCategoryActiveAt(@Nonnull TenantId tenantId, @Nonnull Instant date) {
        return tenantTags.stream()
            .filter(tt -> tt.getTenantId().equals(tenantId.getValue()))
            .filter(TenantTagEntity::isAnemoneCategory)
            .filter(tt -> tt.isActiveAt(date))
            .findAny();
    }

    @Nonnull
    public List<TenantTagEntity> getCategoryActiveAt(@Nonnull Instant date) {
        return tenantTags.stream()
            .filter(TenantTagEntity::isAnemoneCategory)
            .filter(tt -> tt.isActiveAt(date))
            .collect(Collectors.toList());
    }

    @Nonnull
    public Set<TenantTagEntity> getTenantTags(@Nonnull TenantId tenantId, boolean withCategory) {
        return tenantTags.stream()
            .filter(tt -> tt.isForTenant(tenantId))
            .filter(tt -> withCategory || !tt.isAnemoneCategory())
            .collect(Collectors.toSet());
    }

    public void checkIfCategoryCanBeAddedForTenant(@Nonnull TenantId tenantId, @Nonnull Instant date) {
        if (!this.hasLinkedAccount(tenantId)) {
            throw new AccessDeniedException(String.format("Tenant %s don't have access to the user %s", tenantId.getValue(), this.getId()));
        }
        if (this.getCategoryActiveAt(tenantId, date).isPresent()) {
            throw new UserIsAlreadyAssignedToCategoryInTenantException(
                String.format("User %s already has category in the tenant %s", this.getId(), tenantId));
        }
    }

    public boolean hasLinkedAccount(@Nonnull TenantId tenantId) {
        return this.linkedAccounts.stream().anyMatch(la -> la.getTenantId().equals(tenantId.getValue()));
    }

    public Optional<LinkedAccountEntity> getLinkedAccount(@Nonnull TenantId tenantId) {
        return this.linkedAccounts.stream().filter(la -> la.getTenantId().equals(tenantId.getValue())).findAny();
    }

    @Nonnull
    public Locale getCommunicationsLanguageLocale() {
        return LocaleUtils.toLocale(communicationsLanguage);
    }

    public void removeTenantTag(@Nonnull TenantTagEntity tagEntity) {
        this.getTenantTags().remove(tagEntity);
    }

    public void removeTenantTags(@Nonnull Collection<TenantTagEntity> tagEntities) {
        this.getTenantTags().removeAll(tagEntities);
    }

    public void removeAllTenantTag() {
        this.getTenantTags().clear();
    }

    public void addTenantTag(@Nonnull TenantTagEntity tagEntity) {
        this.getTenantTags().add(tagEntity);
    }

    public void addTenantTags(@Nonnull Collection<TenantTagEntity> tagEntities) {
        this.getTenantTags().addAll(tagEntities);
    }

    public boolean isPlaytomicOnline() {
        return PlaytomicUserType.ONLINE == type;
    }

    public boolean isPlaytomicOnsite() {
        return PlaytomicUserType.ONSITE == type;
    }

    public void setEmailVerified(boolean emailVerified) {
        this.emailVerified = emailVerified;
        if (emailVerified && !this.isPlaytomicOnline()) {
            this.type = PlaytomicUserType.ONLINE;
        }
    }

}

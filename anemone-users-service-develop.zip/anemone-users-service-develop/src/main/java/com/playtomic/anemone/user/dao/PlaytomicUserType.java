package com.playtomic.anemone.user.dao;

public enum PlaytomicUserType {
  ONLINE,
  ONSITE,
  PENDING_VERIFICATION
}

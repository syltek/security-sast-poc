package com.playtomic.anemone.user.api.request;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import lombok.Getter;

import javax.annotation.Nonnull;

@Getter
public class CreateUserImportRequestBody {

    @Nonnull
    private final String name;

    @Nonnull
    private final TenantId tenantId;

    @JsonCreator
    public CreateUserImportRequestBody(
        @JsonProperty(value = "name", required = true) @Nonnull String name,
        @JsonProperty(value = "tenant_id", required = true) @Nonnull TenantId tenantId) {
        this.name = name;
        this.tenantId = tenantId;
    }

}

package com.playtomic.anemone.user.service.exception;

import com.playtomic.anemone.user.domain.wallet.WalletId;
import javax.annotation.Nonnull;

public class WalletNotFoundException extends RuntimeException {
    public WalletId walletId;

    public WalletNotFoundException(@Nonnull WalletId walletId) {
        super(String.format("Wallet with id=%s not found", walletId));
        this.walletId = walletId;
    }

    public WalletNotFoundException(@Nonnull String walletId) {
        super(String.format("Tenant with id=%s not found", walletId));
    }
}

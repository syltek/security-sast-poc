package com.playtomic.anemone.user.domain.csv;

public class CsvDataString extends CsvDataBase<String> {
    public CsvDataString(int position, String value) {
        super(position, value);
    }
}

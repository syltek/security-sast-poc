package com.playtomic.anemone.user.service;

import com.playtomic.anemone.domain.user.UserId;
import com.playtomic.anemone.user.service.anemone.MatchesServiceClient;
import javax.annotation.Nonnull;
import javax.validation.ClockProvider;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@RequiredArgsConstructor
public class UserMatchesService {

  public static final String NO_TOTAL_ERROR_MESSAGE = "We were not able to obtain 'total' header from /v1/matches. We cannot process this order.";
  @Nonnull
  private final MatchesServiceClient matchesServiceClient;

  @Nonnull
  private final ClockProvider clockProvider;

  public boolean hasPendingPublicMatches(@Nonnull UserId userId) {
    HttpHeaders headers = matchesServiceClient.getNumberOfPendingMatches(userId,
        clockProvider.getClock().instant()).getHeaders();

    long pendingMatches = extractTotalHeader(headers);

    return pendingMatches > 0;
  }

  private long extractTotalHeader(@Nonnull HttpHeaders headers) {
    try {
      return headers.getOrEmpty("total").stream()
          .findFirst()
          .map(Long::parseLong)
          .filter(value -> value >= 0)
          .orElseThrow(() -> new IllegalStateException(NO_TOTAL_ERROR_MESSAGE));
    } catch (IllegalArgumentException e) {
      throw new IllegalStateException(NO_TOTAL_ERROR_MESSAGE, e);
    }
  }
}

package com.playtomic.anemone.user.dao;

import com.playtomic.anemone.dao.BaseStringUuidEntity;
import com.playtomic.anemone.user.model.role.PlaytomicUserRole;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "user_role")
@Access(AccessType.FIELD)
@Getter
@Setter
@NoArgsConstructor
public class UserRoleEntity extends BaseStringUuidEntity {

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    @Nonnull
    private UserEntity user;

    @Column(name = "user_role", nullable = false)
    @Enumerated(EnumType.STRING)
    @Nonnull
    private PlaytomicUserRole userRole;

    @Column(name = "tenant_id")
    @Nullable
    private String tenantId;

    public UserRoleEntity(@Nonnull UserEntity user,
                          @Nonnull PlaytomicUserRole userRole,
                          @Nullable String tenantId) {
        this.user = user;
        this.userRole = userRole;
        this.tenantId = tenantId;
    }
}

package com.playtomic.anemone.user.service.exception;

public class UserImportNotFoundException extends RuntimeException {
}

package com.playtomic.anemone.user.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

/**
 * In profile we need to show city and country if available so we use this subclass to ensure that we only show
 * what we need to show.
 */
@Data
public class PublicCustomerAddress {

    @JsonProperty("city")
    @Nullable
    private String city;

    @JsonProperty("country_code")
    @Nullable
    private String countryCode;

    public PublicCustomerAddress(@Nonnull CustomerAddress customerAddress) {
        this.city = customerAddress.getCity();
        this.countryCode = customerAddress.getCountryCode();
    }
}

package com.playtomic.anemone.category.domain.scheduler;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.time.Instant;
import java.time.ZoneId;
import javax.annotation.Nonnull;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;

@Getter
@Builder
@NoArgsConstructor
@RequiredArgsConstructor
public class MemberTaskDetails {

    @JsonProperty(value =  "user_id", required = true)
    @Nonnull
    private String userId;

    @JsonProperty(value =  "tenant_id", required = true)
    @Nonnull
    private String tenantId;

    @JsonProperty(value =  "tenant_name", required = true)
    @Nonnull
    private String tenantName;

    @JsonProperty(value =  "tenant_time_zone", required = true)
    @Nonnull
    private ZoneId tenantZoneId;

    @JsonProperty(value =  "category_name", required = true)
    @Nonnull
    private String categoryName;

    @JsonProperty(value =  "expires_at", required = true)
    @Nonnull
    private Instant expiresAt;
}

package com.playtomic.anemone.category.domain;

import java.time.temporal.ChronoUnit;
import javax.annotation.Nonnull;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ExpirationUnit {
    DAYS(ChronoUnit.DAYS),
    MONTHS(ChronoUnit.MONTHS),
    YEARS(ChronoUnit.YEARS);

    @Nonnull
    private final ChronoUnit chronoUnit;
}

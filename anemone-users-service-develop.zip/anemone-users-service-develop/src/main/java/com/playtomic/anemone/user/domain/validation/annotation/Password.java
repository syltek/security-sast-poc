package com.playtomic.anemone.user.domain.validation.annotation;

import com.playtomic.anemone.user.domain.validation.constants.PasswordValidationMode;
import com.playtomic.anemone.user.domain.validation.validator.PasswordConstraintValidator;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import javax.validation.Constraint;
import javax.validation.Payload;

/**
 * This annotation is intended for password validation. See {@link PasswordConstraintValidator}.
 */
@Target({ElementType.ANNOTATION_TYPE, ElementType.FIELD, ElementType.METHOD, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = {PasswordConstraintValidator.class})
public @interface Password {

  String message() default "invalid password";

  Class<?>[] groups() default {};

  Class<? extends Payload>[] payload() default {};

  PasswordValidationMode mode() default PasswordValidationMode.ALL;

}

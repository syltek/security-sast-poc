package com.playtomic.anemone.user.utils;

import java.util.Collections;
import java.util.List;
import javax.annotation.Nonnull;

public class ListUtils {

    private ListUtils() {
    }

    public static void expandList(@Nonnull List<String> list, @Nonnull int size, @Nonnull String withValue) {
        int diff = Math.abs(list.size() - size);
        if (diff > 0) {
            var fill = Collections.nCopies(diff, withValue);
            list.addAll(fill);
        }
    }
}

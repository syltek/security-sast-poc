package com.playtomic.anemone.user.service.messaging;

import com.playtomic.anemone.domain.user.UserId;
import com.playtomic.anemone.user.config.MessagingConfiguration;
import com.playtomic.anemone.user.dao.LinkedAccountRepository;
import com.playtomic.anemone.user.domain.matches.Match;
import com.playtomic.anemone.user.domain.matches.MatchTenant;
import com.playtomic.anemone.user.domain.matches.Player;
import com.playtomic.anemone.user.domain.matches.Team;
import com.playtomic.anemone.user.domain.reservation.MerchantUserId;
import com.playtomic.anemone.user.domain.tenant.Tenant;
import com.playtomic.anemone.user.service.UserLinkingTenantService;
import com.playtomic.anemone.user.service.anemone.TenantServiceClient;
import com.playtomic.anemone.user.service.exception.AutoLinkAccountAtAnemoneVenueException;
import com.playtomic.anemone.user.service.exception.LinkAccountValidateException;
import com.playtomic.anemone.user.service.exception.TenantNotFoundException;
import com.playtomic.anemone.user.service.exception.UserNotFoundException;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class MatchesProcessor {
    public static final String INTERNAL_USER_ID = "0";

    @Nonnull
    private final TenantServiceClient tenantServiceClient;

    @Nonnull
    private final UserLinkingTenantService userLinkingTenantService;

    @Nonnull
    private final LinkedAccountRepository linkedAccountsRepository;

    public MatchesProcessor(@Nonnull TenantServiceClient tenantServiceClient,
                            @Nonnull UserLinkingTenantService userLinkingTenantService,
                            @Nonnull LinkedAccountRepository linkedAccountsRepository) {
        this.tenantServiceClient = tenantServiceClient;
        this.userLinkingTenantService = userLinkingTenantService;
        this.linkedAccountsRepository = linkedAccountsRepository;
    }

    @StreamListener(MessagingConfiguration.MatchesTopic.INPUT)
    public void handle(@Nonnull Message<MatchEvent> matchMessage) {
        log.info("Received Match Event: {}", matchMessage);
        try {
            internalHandle(matchMessage);
        } catch (Exception e) {
            log.error("Unhandled error when processing this message. Discarding", e);
        }
    }

    private void internalHandle(@Nonnull Message<MatchEvent> matchMessage) {
        Match match = matchMessage.getPayload().getMatch();

        autolink(match);
    }

    private void autolink(@Nonnull Match match) {
        MatchTenant tenantFromMatch = match.getTenant();
        if (tenantFromMatch == null) {
            log.trace("Match {} with no tenant. Ignoring it.", match.getMatchId());
            return;
        }

        Tenant tenant;
        try {
            tenant = tenantServiceClient.getById(tenantFromMatch.getTenantId().getValue());
        } catch (TenantNotFoundException e) {
            log.info("Tenant with id {} not found. Discarding event", tenantFromMatch.getTenantId());
            return;
        }

        for (Team t : match.getTeams()) {
            for (Player p : t.getPlayers()) {
                UserId userId = p.getUserId();
                if (userId != null) {
                    autolink(userId, p.getMerchantPlayerId(), tenant);
                }
            }
        }
    }

    private void autolink(@Nonnull UserId userId, @Nullable MerchantUserId merchantUserId, @Nonnull Tenant tenant) {
        //Skip user if already linked
        if (linkedAccountsRepository.countByTenantIdAndUserId(tenant.getTenantId().getValue(), Long.valueOf(userId.getValue())) > 0) {
            log.info("Autolink skipped for user {} (already linked account)", userId);
            return;
        }


        try {
            if (merchantUserId != null) {
                userLinkingTenantService.linkTenant(userId, tenant, merchantUserId, null);
            } else {
                userLinkingTenantService.autolinkTenant(userId, tenant);
            }
        } catch (UserNotFoundException e) {
            log.warn("User {} not found", userId);
        } catch (LinkAccountValidateException e) {
            log.info("Account not linked because the user_id {} is not validated", userId);
        } catch (AutoLinkAccountAtAnemoneVenueException e) {
            log.info("Account not linked because tenant of anemone type");
        }
    }
}

package com.playtomic.anemone.user.api.v2.request;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.user.model.TenantTag;
import lombok.Data;


import java.util.Set;
import javax.annotation.Nonnull;

@Data
public class PutTenantTagsBody {

    @Nonnull
    private Set<TenantTag> tenantTags;

    @JsonCreator
    public PutTenantTagsBody(@JsonProperty(value = "tenant_tags", required = true) @Nonnull Set<TenantTag> tenantTags) {
        this.tenantTags = tenantTags;
    }

}

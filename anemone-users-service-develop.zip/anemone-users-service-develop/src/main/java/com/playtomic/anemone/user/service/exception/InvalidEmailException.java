package com.playtomic.anemone.user.service.exception;

public class InvalidEmailException extends RuntimeException {
}

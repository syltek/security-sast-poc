package com.playtomic.anemone.user.service.facebook;

import com.playtomic.anemone.domain.generic.AbstractStringId;

/**
 *
 */
public class FacebookId extends AbstractStringId {
    protected FacebookId(String id) {
        super(id);
    }

    public static FacebookId valueOf(String id) {
        return new FacebookId(id);
    }

}

package com.playtomic.anemone.user.service.userimports;

import com.playtomic.anemone.user.domain.csv.CsvDataMoney;
import com.playtomic.anemone.user.domain.csv.CsvDataString;
import com.playtomic.anemone.user.domain.csv.CsvWalletHeader;
import com.playtomic.anemone.user.domain.csv.WalletCsvData;
import com.playtomic.anemone.user.domain.wallet.Wallet;
import java.util.List;
import java.util.Map;
import javax.annotation.Nonnull;

public class ExportUserMapper {

    private ExportUserMapper()  {
    }

    public static WalletCsvData toWalletCsvData(@Nonnull Wallet wallet,@Nonnull Map<String, CsvWalletHeader> headerPositions, @Nonnull List<String> csvHeaders) {
        final int headerCount = headerPositions.keySet().size() + 1;
        final String count = headerCount == 1 ? "" : "_" + headerCount;
        final String nameHeader = "wallet_name" + count;
        final String balanceHeader = "balance" + count;
        final String walletName = wallet.getName();

        var header = headerPositions.get(walletName);
        if (header == null) {
            csvHeaders.add(nameHeader);
            csvHeaders.add(balanceHeader);
            var csvWalletHeader = new CsvWalletHeader(csvHeaders.indexOf(nameHeader),
                                                      csvHeaders.indexOf(balanceHeader));
            headerPositions.put(walletName, csvWalletHeader);
        }

        var walletNameCell = new CsvDataString(headerPositions.get(walletName).getNamePosition(), walletName);
        var balanceCell = new CsvDataMoney(headerPositions.get(walletName).getBalancePosition(),
                                           wallet.getBalance());
        return new WalletCsvData(wallet.getUserId(), walletNameCell, balanceCell);
    }
}

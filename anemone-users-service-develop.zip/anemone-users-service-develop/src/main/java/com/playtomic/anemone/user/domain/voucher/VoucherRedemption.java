package com.playtomic.anemone.user.domain.voucher;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.domain.user.UserId;
import com.playtomic.anemone.user.domain.reservation.ReservationId;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;

public class VoucherRedemption {
    @JsonProperty("redemption_id")
    private VoucherRedemptionId redemptionId;

    @JsonProperty("consumer_id")
    private UserId consumerId;

    @JsonProperty(value = "reservation_id")
    private ReservationId reservationId;

    protected VoucherRedemption() {
    }

    public VoucherRedemption(@Nonnull UserId consumerId, @Nonnull ReservationId reservationId) {
        this.consumerId = consumerId;
        this.reservationId = reservationId;
    }

    @Nonnull
    public UserId getConsumerId() {
        return consumerId;
    }

    @Nonnull
    public ReservationId getReservationId() {
        return reservationId;
    }

    @Nullable
    public VoucherRedemptionId getRedemptionId() {
        return redemptionId;
    }
}

package com.playtomic.anemone.user.api.request;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;

import javax.annotation.Nonnull;

@Getter
public class PhoneTokenRequestBody {

    @Nonnull
    private String phone;

    @JsonCreator
    public PhoneTokenRequestBody(@JsonProperty(value = "phone", required = true) @Nonnull String phone) {
        this.phone = phone;
    }
}

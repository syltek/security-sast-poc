package com.playtomic.anemone.user.api.v2.request;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;

import javax.annotation.Nonnull;

@Getter
public class ValidationPhoneRequestBody {

    @Nonnull
    private String phone;

    @JsonCreator
    public ValidationPhoneRequestBody(@JsonProperty(value = "phone", required = true) @Nonnull String phone) {
        this.phone = phone;
    }

}

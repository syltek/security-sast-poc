package com.playtomic.anemone.user.api.v1;

import com.playtomic.anemone.http.LinkHeader;
import com.playtomic.anemone.service.AbstractRestController;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import com.playtomic.anemone.user.domain.userimports.UserImport;
import com.playtomic.anemone.user.domain.userimports.UserImportId;
import com.playtomic.anemone.user.service.exception.TenantNotFoundException;
import com.playtomic.anemone.user.service.userimports.UserImportService;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.context.MessageSource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;

@RequestMapping("/v1/user_imports")
@RestController
public class UserImportControllerV1 extends AbstractRestController {

    @Nonnull
    private final UserImportService userImportService;

    public UserImportControllerV1(@Nonnull MessageSource messageSource,
                                  @Nonnull DiscoveryClient discoveryClient,
                                  @Nonnull UserImportService userImportService) {
        super(messageSource, discoveryClient);
        this.userImportService = userImportService;
    }

    @Nonnull
    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @PreAuthorize("hasPermission(#tenantId, 'write_user_imports')")
    protected ResponseEntity importUsers(
        @RequestParam(value = "name") @Nonnull String name,
        @RequestParam(value = "tenant_id") @Nonnull TenantId tenantId,
        @RequestParam(value = "mismatch", required = false) @Nullable String mismatchMapping,
        @RequestParam(value = "file") @Nonnull MultipartFile file
    ) throws IOException, TenantNotFoundException {
        UserImport userImport = userImportService.createUserImport(name, tenantId, file, processMismatchMapping(mismatchMapping));
        return ResponseEntity.ok(userImport);
    }

    @Nonnull
    @GetMapping("/{user_import_id}")
    @PreAuthorize("hasPermission(#userImportId, 'read_user_imports')")
    protected ResponseEntity<UserImport> getImportUsersById(
        @PathVariable(value = "user_import_id") @Nonnull UserImportId userImportId,
        @RequestParam(value = "include_errors", required = false, defaultValue = "false") boolean includeErrors
    ) {
        UserImport userImport = userImportService.getUserImportById(userImportId);
        if (!includeErrors) {
            userImport.getErrorDetails().clear();
        }
        return ResponseEntity.ok(userImport);
    }

    @Nonnull
    @GetMapping
    @PreAuthorize("hasPermission(#tenantId, 'read_user_imports')")
    protected ResponseEntity<List<UserImport>> searchImportUsers(
        @RequestParam(value = "tenant_id", required = false) @Nullable TenantId tenantId,
        @RequestParam(value = "include_errors", required = false, defaultValue = "false") boolean includeErrors,
        @Nonnull Pageable pageable
    ) {
        Page<UserImport> userImports = userImportService.searchUserImports(tenantId, pageable);
        if (!includeErrors) {
            userImports.forEach(ui -> ui.getErrorDetails().clear());
        }
        return LinkHeader.toResponse(userImports);
    }

    @Nonnull
    @GetMapping(path = "/{user_import_id}/errors.csv", produces = "text/csv")
    @PreAuthorize("hasPermission(#userImportId, 'read_user_imports')")
    protected ResponseEntity<byte[]> getErrorsCsv(@PathVariable("user_import_id") @Nonnull UserImportId userImportId) {
        byte[] contents = userImportService.generateErrorsCSV(userImportId);
        return getResponseCSVAttachment(contents);
    }

    @Nonnull
    @PostMapping("/{user_import_id}/stop")
    @PreAuthorize("hasPermission(#userImportId, 'write_user_imports')")
    protected ResponseEntity<UserImport> stopImport(@PathVariable(value = "user_import_id") @Nonnull UserImportId userImportId) {
        UserImport userImport = userImportService.stopImport(userImportId);
        return ResponseEntity.ok(userImport);
    }

    @Nonnull
    private ResponseEntity<byte[]> getResponseCSVAttachment(@Nonnull byte[] contents) {
        HttpHeaders header = new HttpHeaders();
        header.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=errors.csv");
        header.add("Cache-Control", "no-cache, no-store, must-revalidate");
        header.add("Pragma", "no-cache");
        header.add("Expires", "0");

        return ResponseEntity.ok()
            .headers(header)
            .contentLength(contents.length)
            .contentType(MediaType.parseMediaType("text/csv"))
            .body(contents);
    }

    @Nullable
    private Map<String, String> processMismatchMapping(@Nullable String mapping) {
        if (mapping == null) {
            return null;
        }

        String[] mapArray = mapping.split(",");
        return Arrays.stream(mapArray).collect(Collectors.toMap(k ->k.split(":")[0], v -> v.split(":")[1]));
    }

}

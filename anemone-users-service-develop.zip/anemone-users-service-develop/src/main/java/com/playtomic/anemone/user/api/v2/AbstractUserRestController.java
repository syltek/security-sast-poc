package com.playtomic.anemone.user.api.v2;

import com.playtomic.anemone.domain.user.UserId;
import com.playtomic.anemone.service.AbstractRestController;
import com.playtomic.anemone.user.config.UserPermissionService;
import com.playtomic.anemone.user.model.CustomerUserProfile;
import com.playtomic.anemone.user.service.PermissionService;
import com.playtomic.anemone.user.service.UserService;
import java.util.Optional;
import javax.annotation.Nonnull;
import javax.annotation.ParametersAreNonnullByDefault;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.context.MessageSource;
import org.springframework.data.domain.Page;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.Authentication;

@ParametersAreNonnullByDefault
public class AbstractUserRestController extends AbstractRestController {

    protected static final UserId ANEMONE_USER_AS_ZERO = UserId.valueOf("0");
    protected static final UserId ANEMONE_USER_AS_ANEMONE = UserId.valueOf("ANEMONE");

    @Nonnull
    protected final UserPermissionService userPermissionService;
    @Nonnull
    protected final PermissionService permissionService;
    @Nonnull
    protected final UserService userService;

    public AbstractUserRestController(MessageSource messageSource,
        DiscoveryClient discoveryClient, UserPermissionService userPermissionService,
        PermissionService permissionService, UserService userService) {
        super(messageSource, discoveryClient);
        this.userPermissionService = userPermissionService;
        this.permissionService = permissionService;
        this.userService = userService;
    }

    protected void sanitize(CustomerUserProfile user, Authentication authentication) {
        if (!userPermissionService.isAllowed(user.getId(), "read_linked_accounts", authentication)) {
            user.getLinkedTenantsAccounts().
                removeIf(l -> !userPermissionService.isAllowed(l.getTenantId(), "read_linked_accounts", authentication));
        }

        user.getUserRoles().
            removeIf(r -> r.getTenantId() != null && !userPermissionService.isAllowed(r.getTenantId(), "read_user_roles", authentication));
        user.getTenantTags().
            removeIf(t -> !userPermissionService.isAllowed(t.getTenantId(), "read_user_roles", authentication));
    }

    protected void sanitize(Page<CustomerUserProfile> users, Authentication authentication) {
        users.forEach(u -> sanitize(u, authentication));
    }

    protected String getDefaultUserPhoneCountryCode() {
        // Anonymous and Anemone users are skipped.
        return isAnonymous() ? null :
            Optional.of(getCurrentUser().getId())
            .filter(id -> !isAnemoneUser(id))
            .map(userService::getDefaultUserPhoneCountryCode)
            .orElse(null);
    }

    protected void assertAllowed(boolean allowed) {
        if (!allowed) {
            throw new AccessDeniedException("You don't have permission to do this operation");
        }
    }

    private boolean isAnemoneUser(UserId currentUserId) {
        return currentUserId.equals(ANEMONE_USER_AS_ZERO) || currentUserId.equals(ANEMONE_USER_AS_ANEMONE);
    }
}

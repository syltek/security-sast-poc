package com.playtomic.anemone.user.api.request;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.domain.user.UserId;

import lombok.Data;

import javax.annotation.Nonnull;

@Data
public class ImpersonateRequestBody {

    @Nonnull
    private UserId userId;

    @JsonCreator
    public ImpersonateRequestBody(@JsonProperty(value = "user_id", required = true) @Nonnull UserId userId) {
        this.userId = userId;
    }
}

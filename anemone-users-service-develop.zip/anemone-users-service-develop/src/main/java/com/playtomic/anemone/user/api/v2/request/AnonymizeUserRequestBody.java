package com.playtomic.anemone.user.api.v2.request;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Data;

@Data
public class AnonymizeUserRequestBody {
    @JsonProperty(value = "confirmation")
    @Nullable
    public String confirmation;

    @JsonCreator
    public AnonymizeUserRequestBody(@JsonProperty(value = "confirmation", required = true) @Nonnull String confirmation) {
        this.confirmation = confirmation;
    }
}

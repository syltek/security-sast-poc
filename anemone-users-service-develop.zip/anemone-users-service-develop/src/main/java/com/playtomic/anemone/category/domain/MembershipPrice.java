package com.playtomic.anemone.category.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.playtomic.anemone.converter.MoneySerializer;
import javax.annotation.Nonnull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.javamoney.moneta.Money;

@AllArgsConstructor
@NoArgsConstructor
@Getter
public class MembershipPrice {

    @Nonnull
    @JsonProperty("amount")
    @JsonSerialize(using = MoneySerializer.class)
    private Money amount;

    @Nonnull
    @JsonProperty("interval")
    private Interval interval;

    @JsonProperty("interval_count")
    private int intervalCount;

    public MembershipPrice(@JsonProperty("amount") @Nonnull Money amount){
        this.amount = amount;
        // For now we only have prices which to be charged monthly but this will change in the future.
        this.interval = Interval.MONTH;
        this.intervalCount = 1;
    }

    public enum Interval {
        DAY("day"),
        MONTH("month"),
        WEEK("week"),
        YEAR("year");

        private final String value;

        Interval(String value) {
            this.value = value;
        }

        public String getValue() {
            return this.value;
        }
    }
}


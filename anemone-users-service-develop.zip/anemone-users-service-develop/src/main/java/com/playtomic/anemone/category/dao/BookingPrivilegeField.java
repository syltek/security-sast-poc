package com.playtomic.anemone.category.dao;

import com.playtomic.anemone.category.domain.CancellationPolicyDuration;
import java.time.Duration;
import java.util.Optional;
import javax.annotation.Nullable;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.springframework.data.mongodb.core.mapping.Field;

@Getter
@AllArgsConstructor
public class BookingPrivilegeField {

    @Nullable
    @Field("days_of_booking_ahead")
    private  final Integer daysOfBookingAhead;
    @Nullable
    @Field("max_number_of_active_bookings")
    private final Integer maxNumberOfActiveBookings;
    @Nullable
    @Field("max_number_of_bookings_per_day")
    private final Integer maxNumberOfBookingsPerDay;
    @Nullable
    @Field("cancellation_policy_duration")
    private final Duration cancellationPolicyDuration;

    @Nullable
    public CancellationPolicyDuration getCancellationPolicy() {
        return Optional.ofNullable(cancellationPolicyDuration).map(CancellationPolicyDuration::new).orElse(null);
    }
}

package com.playtomic.anemone.user.service.exception;

import javax.annotation.Nonnull;

public class PhoneNotAvailableException extends RuntimeException {
    public PhoneNotAvailableException(@Nonnull String phone) {
        super(String.format("Phone %s is already in use", phone));
    }

}

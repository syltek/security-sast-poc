package com.playtomic.anemone.user.service.exception;

import com.playtomic.anemone.domain.Email;
import javax.annotation.Nonnull;

public class EmailNotAvailableException extends RuntimeException {
    public EmailNotAvailableException(@Nonnull Email email) {
        super(String.format("Email %s is already in use", email.getEmail()));
    }

}

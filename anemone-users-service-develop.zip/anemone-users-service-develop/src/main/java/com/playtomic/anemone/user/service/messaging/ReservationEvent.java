package com.playtomic.anemone.user.service.messaging;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.user.domain.reservation.Reservation;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@ToString
@Getter
@Builder
@NoArgsConstructor
public class ReservationEvent {

    public enum ReservationEventType {
        RESERVATION_CONFIRMED,
        RESERVATION_UPDATED,
        RESERVATION_PRERESERVED,
        RESERVATION_CANCELED
    }

    @JsonProperty(value = "event_type")
    @Nullable
    private ReservationEventType eventType;

    @Nullable
    private Reservation reservation;

    @JsonCreator
    protected ReservationEvent(
        @JsonProperty(value = "event_type") @Nullable ReservationEventType eventType,
        @JsonProperty(value = "reservation", required = true) @Nonnull Reservation reservation) {
        this.eventType = eventType;
        this.reservation = reservation;
    }
}

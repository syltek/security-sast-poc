package com.playtomic.anemone.category.domain;

public enum Visibility {
    APP, HIDDEN
}

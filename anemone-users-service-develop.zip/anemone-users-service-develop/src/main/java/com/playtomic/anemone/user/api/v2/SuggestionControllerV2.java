package com.playtomic.anemone.user.api.v2;

import com.playtomic.anemone.Constants;
import com.playtomic.anemone.domain.user.User;
import com.playtomic.anemone.http.response.ErrorResponseBody;
import com.playtomic.anemone.http.response.StatusResponseBody;
import com.playtomic.anemone.service.AbstractRestController;
import com.playtomic.anemone.user.api.v2.request.SuggestionImprovementRequestBody;
import com.playtomic.anemone.user.api.v2.request.SuggestionTenantRequestBody;
import com.playtomic.anemone.user.service.UserService;
import com.playtomic.anemone.user.service.email.UserEmailService;
import java.util.HashMap;
import java.util.Map;
import javax.annotation.Nonnull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping(path = "/v2")
@Controller
public class SuggestionControllerV2 extends AbstractRestController {

    @Nonnull
    private final UserEmailService userEmailService;

    @Nonnull
    private final UserService userService;

    public SuggestionControllerV2(@Nonnull MessageSource messageSource,
                                  @Nonnull DiscoveryClient discoveryClient,
                                  @Nonnull UserEmailService userEmailService,
                                  @Nonnull UserService userService) {
        super(messageSource, discoveryClient);
        this.userEmailService = userEmailService;
        this.userService = userService;
    }

    @RequestMapping(path = "/suggestion/tenant", method = RequestMethod.POST, consumes = Constants.CONSUMES_JSON)
    public ResponseEntity<StatusResponseBody> tenant(@RequestBody SuggestionTenantRequestBody body) {
        HttpStatus status = HttpStatus.BAD_REQUEST;
        StatusResponseBody response = new ErrorResponseBody(ErrorResponseBody.Status.MISSING_PARAMETERS, getMessage("Suggestion.NoParameters"));

        if (!body.type.equals("customer") && !body.type.equals("tenant")) {
            response = new ErrorResponseBody(ErrorResponseBody.Status.MISSING_PARAMETERS, getMessage("Suggestion.InvalidType"));
        }

        if (body.type.equals("customer")) {
            try {
                userEmailService.sendCustomerSuggestionEmail(body, getCurrentUser(), getCurrentUsername(), LocaleContextHolder.getLocale());
                status = HttpStatus.OK;
                response = new StatusResponseBody("OK", getMessage("Suggestion.CustomerSent"));
            } catch (Exception e) {
                log.error("Unable to send customer suggestion email {}", e);
                status = HttpStatus.INTERNAL_SERVER_ERROR;
                response = new ErrorResponseBody(ErrorResponseBody.Status.INTERNAL, getMessage("Suggestion.UnableToSend"));
            }
        }

        if (body.type.equals("tenant")) {
            try {
                userEmailService.sendTenantSuggestionEmail(body, getCurrentUser(), getCurrentUsername(), LocaleContextHolder.getLocale());
                status = HttpStatus.OK;
                response = new StatusResponseBody("OK", getMessage("Suggestion.TenantSent"));
            } catch (Exception e) {
                log.error("Unable to send tenant suggestion email {}", e);
                status = HttpStatus.INTERNAL_SERVER_ERROR;
                response = new ErrorResponseBody(ErrorResponseBody.Status.INTERNAL, getMessage("Suggestion.UnableToSend"));
            }
        }

        return new ResponseEntity<>(response, status);
    }

    @RequestMapping(path = "/suggestion/improvement", method = RequestMethod.POST, consumes = Constants.CONSUMES_JSON)
    public ResponseEntity<StatusResponseBody> improvement(@RequestBody SuggestionImprovementRequestBody body) {

        HttpStatus status = HttpStatus.BAD_REQUEST;
        StatusResponseBody response;

        if (body.comments.length() > 1024) {
            response = new ErrorResponseBody(ErrorResponseBody.Status.INCORRECT_PARAMETERS, getMessage("Feedback.MessageTooLarge"));
        } else {
            try {
                userEmailService.sendFeedbackEmail(body.comments, getCurrentUser(), getCurrentUsername(), LocaleContextHolder.getLocale());
                status = HttpStatus.OK;
                response = new StatusResponseBody("OK", getMessage("Feedback.Sent"));
            } catch (Exception e) {
                log.error("Unable to send Feedback suggestion email {}", e);
                status = HttpStatus.INTERNAL_SERVER_ERROR;
                response =
                        new ErrorResponseBody(ErrorResponseBody.Status.INTERNAL,
                                getMessage("Feedback.UnableToSend"));
            }
        }

        return new ResponseEntity<>(response, status);
    }

    @Nonnull
    private String getCurrentUsername() {
        try {
            User currentUser = getCurrentUser();
            return userService.getUsername(currentUser.getId());
        } catch (Exception e) {
            // not found, don't care. This is only for the suggestion email.
            return "";
        }
    }

    @Deprecated
    @RequestMapping(path = "/suggestion/improvement", method = RequestMethod.POST, consumes = Constants.CONSUMES_X_WWW_FORM)
    public ResponseEntity<StatusResponseBody> improvement(@RequestParam("comments") String comments) {
        return improvement(new SuggestionImprovementRequestBody(comments));
    }

    private @Nonnull Map<String, Object> instanceDefaultUserModel(@Nonnull User user, @Nonnull String username) {
        Map<String, Object> model = new HashMap<>();
        model.put("userId", user.getId());
        model.put("userName", username);
        model.put("userEmail", user.getEmail());

        return model;
    }
}

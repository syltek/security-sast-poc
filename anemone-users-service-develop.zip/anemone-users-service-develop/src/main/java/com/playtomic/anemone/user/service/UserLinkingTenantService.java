package com.playtomic.anemone.user.service;

import com.playtomic.anemone.domain.Email;
import com.playtomic.anemone.domain.user.UserId;
import com.playtomic.anemone.user.domain.UserProfile;
import com.playtomic.anemone.user.domain.reservation.MerchantUserId;
import com.playtomic.anemone.user.domain.tenant.Tenant;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import com.playtomic.anemone.user.model.CustomerUserProfile;
import com.playtomic.anemone.user.model.ExtendedUserRole;
import com.playtomic.anemone.user.model.TenantOwnerAccount;
import com.playtomic.anemone.user.model.permissions.PermissionLevel;
import com.playtomic.anemone.user.model.permissions.PermissionName;
import com.playtomic.anemone.user.model.role.PlaytomicUserRole;
import com.playtomic.anemone.user.service.anemone.TenantServiceClient;
import com.playtomic.anemone.user.service.exception.UserNotFoundException;
import com.playtomic.anemone.user.service.messaging.MessagingBroker;
import com.playtomic.anemone.user.service.messaging.UserEvent;
import com.playtomic.anemone.user.service.messaging.UserEvent.UserEventType;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service
@RequiredArgsConstructor
@ParametersAreNonnullByDefault
public class UserLinkingTenantService {

    @Nonnull
    private final TenantServiceClient tenantService;
    @Nonnull
    private final UserService userService;
    @Nonnull
    private final UserServicePersistenceComponent userServicePersistenceComponent;
    @Nonnull
    private final UserTenantTagService userTenantTagService;
    @Nonnull
    private final MessagingBroker messagingBroker;
    @Nonnull
    private final PermissionService permissionService;

    public CustomerUserProfile registerAsVenueCustomer(UserId userId, TenantId tenantId) {
        CustomerUserProfile user = userService.getUserById(userId);
        if (user.isLinkedTo(tenantId)) {
            return user;
        }

        Tenant tenant = tenantService.getById(tenantId.getValue());
        if (!tenant.isAnemone()) {
            autolinkTenant(userId, tenant);
            user = userService.getUserById(userId);
            if (user.isLinkedTo(tenantId)) {
                return user;
            }
        }
        registerUserInTenant(userId, tenant);
        return user;
    }

    public void registerOrLinkUserInTenant(UserId userId, TenantId tenantId, boolean autoregister) {
        Tenant tenant = tenantService.getById(tenantId.toString());
        if (autoregister) {
            registerUserInTenant(userId, tenant);
        } else {
            autolinkTenant(userId, tenant);
        }
    }

    public void autolinkTenant(UserId userId, Tenant tenant) {
        UserProfile user = userServicePersistenceComponent.autolinkTenant(userId, tenant);
        Optional.ofNullable(user).ifPresent(this::sendUserUpdateEvent);
    }

    public void registerUserInTenant(UserId userId, Tenant tenant) {
        UserProfile user = userServicePersistenceComponent.registerUserInTenant(userId, tenant);
        Optional.ofNullable(user).ifPresent(this::sendUserUpdateEvent);
    }

    public void linkTenant(UserId userId, Tenant tenant, MerchantUserId merchantUserId, @Nullable Boolean acceptsCommercial) {
        UserProfile userProfile = userServicePersistenceComponent.linkTenant(userId, tenant, merchantUserId, acceptsCommercial);
        Optional.ofNullable(userProfile).ifPresent(this::sendUserUpdateEvent);
    }

    public void linkTenantWithEmailAndPassword(UserId userId, TenantId tenantId, Email email, String password, @Nullable Boolean acceptsCommercial) {
        UserProfile userProfile = userServicePersistenceComponent.linkTenantWithEmailAndPassword(userId, tenantId, email, password,
            acceptsCommercial);
        Optional.ofNullable(userProfile).ifPresent(this::sendUserUpdateEvent);
    }

    @Nonnull
    public CustomerUserProfile updateLinkedTenant(UserId userId, TenantId tenantId, boolean acceptsCommercial) {
        UserProfile user = userServicePersistenceComponent.updateLinkedTenant(userId, tenantId, acceptsCommercial);
        sendUserUpdateEvent(user);
        return userService.getUserById(userId);
    }

    @Nonnull
    public CustomerUserProfile unlinkTenant(UserId userId, TenantId tenantId) {
        UserProfile userProfile = userServicePersistenceComponent.unlinkTenant(userId, tenantId);
        sendUserUpdateEvent(userProfile);
        // When we unlink an account of a user from a club, we have to remove all the benefits linked to him
        userTenantTagService.removeTenantTags(userId, null, tenantId);
        return userService.getUserById(userId);
    }

    @Nonnull
    public CustomerUserProfile deleteTenantOwnerAccount(UserId userId, TenantId tenantId) {
        UserProfile userProfile = userServicePersistenceComponent.deleteTenantOwnerAccount(userId, tenantId);
        sendUserUpdateEvent(userProfile);

        return userService.getUserById(userId);
    }

    @Nonnull
    public CustomerUserProfile putTenantOwnerAccount(UserId userId, TenantId tenantId) {
        TenantOwnerAccount account = userServicePersistenceComponent.putTenantOwnerAccount(userId, tenantId);
        //When user is a owner of a tenant, it also needs to have ROLE_TENANT_MANAGER and a set of default permissions.
        ExtendedUserRole tenantManager = new ExtendedUserRole(PlaytomicUserRole.ROLE_TENANT_MANAGER, account.getTenantId());
        log.trace("Trying to give role {} and create permissions in tenant {} to user {}", tenantManager.getUserRole(), tenantId, userId);
        Set<ExtendedUserRole> roles = Set.of(tenantManager);
        EnumMap<PermissionName, PermissionLevel> permissions = getAllAssignablePermissions();
        userService.addUserRoles(userId, roles, false);
        permissionService.setPermissionsInTenant(userId, tenantId, permissions);

        return userService.getUserById(userId);
    }

    @Nonnull
    public TenantOwnerAccount patchTenantOwnerAccount(@Nonnull final UserId userId,
                                                      @Nonnull final TenantId tenantId,
                                                      @Nullable final Boolean acceptsMarketingCommunications,
                                                      @Nullable final Boolean acceptsMarketingBehaviourAnalysis,
                                                      @Nullable final Boolean acceptsCxQuestionnaires,
                                                      @Nullable final Boolean acceptsCxWhatsappCommunications) {

        CustomerUserProfile user = userServicePersistenceComponent
            .updateTenantOwnerAccount(userId, tenantId, acceptsMarketingCommunications,
                                      acceptsMarketingBehaviourAnalysis, acceptsCxQuestionnaires,
                                      acceptsCxWhatsappCommunications);

        TenantOwnerAccount tenantOwnerAccount = user.getTenantOwnerAccounts().stream()
                                                    .filter(account -> account.getTenantId().getValue().equals(tenantId.getValue()))
                                                    .findFirst()
                                                    .orElseThrow(UserNotFoundException::new);
        sendUserUpdateEvent(user);

        return tenantOwnerAccount;
    }

    @Nonnull
    private EnumMap<PermissionName, PermissionLevel> getAllAssignablePermissions() {
        // PREMIUM_PERMISSION is only set by subscription
        return Arrays.stream(PermissionName.values())
            .filter(p -> !PermissionName.PREMIUM_PERMISSION.equals(p))
            .collect(Collectors.toMap(p -> p, p -> PermissionLevel.READ_WRITE, (p1, p2) -> p1, () -> new EnumMap<>(PermissionName.class)));
    }

    /**
     * Used to send an update event each time a user entity is updated.
     */
    private void sendUserUpdateEvent(UserProfile user) {
        messagingBroker.sendEvent(new UserEvent(UserEventType.UPDATED, user));
    }
}

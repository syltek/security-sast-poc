package com.playtomic.anemone.user.api.v2.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.domain.Email;
import lombok.Getter;

@Getter
public class SuggestionTenantRequestBody {
    @JsonProperty(value = "type", required = true)
    public String type;
    @JsonProperty(value = "tenant_name", required = true)
    public String tenantName;
    @JsonProperty(value = "tenant_email", required = false)
    public Email tenantEmail;
    @JsonProperty(value = "tenant_phone", required = false)
    public String tenantPhone;
    @JsonProperty(value = "tenant_address", required = false)
    public String tenantAddress;
    @JsonProperty(value = "comments", required = false)
    public String comments;

    public SuggestionTenantRequestBody() {
    }

    public SuggestionTenantRequestBody(String type, String tenantName, Email tenantEmail, String tenantPhone, String tenantAddress, String comments) {
        this.type = type;
        this.tenantName = tenantName;
        this.tenantEmail = tenantEmail;
        this.tenantPhone = tenantPhone;
        this.tenantAddress = tenantAddress;
        this.comments = comments;
    }
}

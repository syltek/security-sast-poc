package com.playtomic.anemone.user.api.v2.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.user.model.CustomerAddress;
import com.playtomic.anemone.user.model.PrivacyProfile;
import com.playtomic.anemone.user.model.UserGender;
import lombok.NoArgsConstructor;

import java.time.ZonedDateTime;
import java.util.Locale;
import javax.annotation.Nullable;

@NoArgsConstructor
public class UserUpdateRequestBody {
    @JsonProperty(value = "email")
    @Nullable
    public String email;

    @JsonProperty(value = "email_token")
    @Nullable
    public String emailToken;

    @JsonProperty(value = "full_name")
    @Nullable
    public String fullName;

    @JsonProperty(value = "password")
    @Nullable
    public String password;

    @JsonProperty(value = "picture")
    @Nullable
    public String pictureBase64;

    @JsonProperty(value = "phone")
    @Nullable
    public String phone;

    @JsonProperty(value = "phone_token")
    @Nullable
    public String phoneToken;

    @JsonProperty(value = "accepts_privacy")
    @Nullable
    public Boolean acceptsPrivacy;

    @JsonProperty(value = "accepts_commercial")
    @Nullable
    public Boolean acceptsCommercial;

    @JsonProperty(value = "birth_date")
    @Nullable
    public ZonedDateTime birthDate;

    @JsonProperty(value = "gender")
    @Nullable
    public UserGender gender;

    @JsonProperty(value = "bio")
    @Nullable
    public String bio;

    @JsonProperty(value = "country_code")
    @Nullable
    public String countryCode;

    @JsonProperty(value = "communications_language")
    @Nullable
    public Locale communicationsLanguage;

    @JsonProperty(value = "is_email_verified")
    @Nullable
    public Boolean isEmailVerified;

    @JsonProperty(value = "is_phone_verified")
    @Nullable
    public Boolean isPhoneVerified;

    @JsonProperty(value = "address")
    @Nullable
    public CustomerAddress address;

    @JsonProperty("privacy_profile")
    @Nullable
    public PrivacyProfile privacyProfile;

    // sgmoratilla: We left these methods here because when adding new fields these methods might be affected.
    public boolean modifiesPublicProfile() {
        return email != null || phone != null || fullName != null;
    }

    public boolean modifiesPrivateProfile() {
        return emailToken != null || password != null || pictureBase64 != null || phoneToken != null || birthDate != null || gender != null || bio != null || countryCode != null || address != null || privacyProfile != null;
    }

    public boolean modifiesVerificationData() {
        return isEmailVerified != null || isPhoneVerified != null;
    }
}

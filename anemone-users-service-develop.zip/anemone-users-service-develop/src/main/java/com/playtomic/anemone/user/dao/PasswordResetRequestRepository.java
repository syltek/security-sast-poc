package com.playtomic.anemone.user.dao;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;

import javax.transaction.Transactional;

public interface PasswordResetRequestRepository extends PagingAndSortingRepository<PasswordResetRequestEntity, Long> {
    PasswordResetRequestEntity findByEmailIgnoreCase(@Param("email") String email);
    PasswordResetRequestEntity findByEmailIgnoreCaseAndSecurityToken(@Param("email") String email, @Param("security_token") String token);

    @Transactional
    void deleteByEmail(@Param("email") String email);
}
package com.playtomic.anemone.user.service.anemone;

import com.playtomic.anemone.Constants;
import com.playtomic.anemone.category.domain.scheduler.ScheduledTask;
import com.playtomic.anemone.jwt.JwtTokenFactory;
import com.playtomic.anemone.spring.ForceAnemoneAuthenticationCredentialsAccessor;
import com.playtomic.anemone.spring.config.AnemoneWebMvConfigurerAdapter;
import com.playtomic.anemone.spring.feign.AnemoneFeignFormatterRegistrar;
import com.playtomic.anemone.spring.feign.AuthenticationHeaderFeignInterceptor;
import feign.RequestInterceptor;
import javax.annotation.Nonnull;
import javax.annotation.ParametersAreNonnullByDefault;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.cloud.openfeign.FeignFormatterRegistrar;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@ParametersAreNonnullByDefault
@FeignClient(name = "scheduler-service", configuration = SchedulerServiceClient.Configuration.class, url="${scheduler-service.url}")
public interface SchedulerServiceClient {

    @PostMapping(path = "/v1/scheduler/tasks", consumes = Constants.CONSUMES_JSON)
    void scheduleTask(@RequestBody ScheduledTask task);

    class Configuration {

        @Bean
        @Nonnull
        public RequestInterceptor requestInterceptor(JwtTokenFactory jwtTokenFactory) {
            return new AuthenticationHeaderFeignInterceptor(
                new ForceAnemoneAuthenticationCredentialsAccessor(jwtTokenFactory));
        }

        @Bean
        @Nonnull
        public FeignFormatterRegistrar feignFormatterRegistrar(AnemoneWebMvConfigurerAdapter anemoneWebMvConfigurerAdapter) {
            return new AnemoneFeignFormatterRegistrar(anemoneWebMvConfigurerAdapter);
        }
    }
}

package com.playtomic.anemone.category.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.category.dao.CategoryDocument.PricingType;
import com.playtomic.anemone.category.dao.CategoryDocument.Status;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import java.math.BigDecimal;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class Category {

    @Nonnull
    @JsonProperty("category_id")
    private final CategoryId id;
    @Nonnull
    @JsonProperty("tenant_id")
    private final TenantId tenantId;
    @Nonnull
    @JsonProperty("name")
    private String name;
    @Nonnull
    @JsonProperty("status")
    private Status status;
    @Nullable
    @JsonProperty("expiration")
    private CategoryExpiration expiration;
    @Nullable
    @JsonProperty("booking_privilege")
    private BookingPrivilege bookingPrivilege;
    @JsonProperty("customers")
    private long customers;
    @Nullable
    @JsonProperty("pricing_type")
    private PricingType pricingType;
    @JsonProperty("allow_single_payment_when_price_is_customized")
    private final boolean allowSinglePaymentWhenPriceIsCustomized;
    @Nullable
    @JsonProperty("vat_rate")
    private final BigDecimal vatRate;

    @Nullable
    @JsonProperty("category_type")
    private CategoryType categoryType;

    @Nullable
    @JsonProperty("membership_details")
    private MembershipDetails membershipDetails;

    public boolean isDisabled() {
        return Status.DISABLED == this.status;
    }

    public boolean isMembership() {
        return CategoryType.MEMBERSHIP == this.categoryType;
    }

}

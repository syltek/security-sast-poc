package com.playtomic.anemone.user.api.v2.request;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.Set;
import javax.annotation.Nonnull;

@Data
public class PatchTenantTagsBody {

    @Nonnull
    private Set<String> tenantTagValues;

    @JsonCreator
    public PatchTenantTagsBody(
            @JsonProperty(value = "tags", required = true) @Nonnull Set<String> tenantTagValues) {
        this.tenantTagValues = tenantTagValues;
    }

}

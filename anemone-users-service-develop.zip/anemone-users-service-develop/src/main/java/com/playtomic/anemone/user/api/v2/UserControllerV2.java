package com.playtomic.anemone.user.api.v2;

import com.google.api.client.util.Strings;
import com.playtomic.anemone.Constants;
import com.playtomic.anemone.category.domain.CancellationPolicyDuration;
import com.playtomic.anemone.converter.CurrentUserIdConverter;
import com.playtomic.anemone.domain.Email;
import com.playtomic.anemone.domain.EmailValidator;
import com.playtomic.anemone.domain.user.User;
import com.playtomic.anemone.domain.user.UserId;
import com.playtomic.anemone.http.BadRequestException;
import com.playtomic.anemone.http.LinkHeader;
import com.playtomic.anemone.http.response.StatusResponseBody;
import com.playtomic.anemone.user.api.request.CreateUserRoleRequestBody;
import com.playtomic.anemone.user.api.request.PremiumInfoBody;
import com.playtomic.anemone.user.api.request.ValidationEmailRequestBody;
import com.playtomic.anemone.user.api.v2.request.AnonymizeUserRequestBody;
import com.playtomic.anemone.user.api.v2.request.AnonymizeUserResponse;
import com.playtomic.anemone.user.api.v2.request.LinkCoachAccountData;
import com.playtomic.anemone.user.api.v2.request.PatchLinkedAccountRequestBody;
import com.playtomic.anemone.user.api.v2.request.PatchTenantOwnerAccount;
import com.playtomic.anemone.user.api.v2.request.PostUserBody;
import com.playtomic.anemone.user.api.v2.request.PutPermissionBody;
import com.playtomic.anemone.user.api.v2.request.UserLinkAccountRequestBody;
import com.playtomic.anemone.user.api.v2.request.UserUpdateRequestBody;
import com.playtomic.anemone.user.api.v2.request.ValidationPhoneRequestBody;
import com.playtomic.anemone.user.config.UserPermissionService;
import com.playtomic.anemone.user.dao.PlaytomicUserType;
import com.playtomic.anemone.user.domain.CountryCodeValidator;
import com.playtomic.anemone.user.domain.PasswordGenerator;
import com.playtomic.anemone.user.domain.PhoneValidator;
import com.playtomic.anemone.user.domain.UserProfile;
import com.playtomic.anemone.user.domain.permissions.Permission;
import com.playtomic.anemone.user.domain.reservation.MerchantUserId;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import com.playtomic.anemone.user.domain.users.AnemoneUserProfile;
import com.playtomic.anemone.user.domain.users.UserGamePreferences;
import com.playtomic.anemone.user.model.CustomerUserProfile;
import com.playtomic.anemone.user.model.ExtendedUserRole;
import com.playtomic.anemone.user.model.PrivacyProfile;
import com.playtomic.anemone.user.model.PublicUserProfile;
import com.playtomic.anemone.user.model.TenantOwnerAccount;
import com.playtomic.anemone.user.model.UserFilter;
import com.playtomic.anemone.user.model.permissions.PermissionName;
import com.playtomic.anemone.user.model.role.PlaytomicUserRole;
import com.playtomic.anemone.user.service.CoachService;
import com.playtomic.anemone.user.service.ExportUsersService;
import com.playtomic.anemone.user.service.IllegalEmailUpdateForOnsiteUserException;
import com.playtomic.anemone.user.service.PermissionService;
import com.playtomic.anemone.user.service.UserCredentialService;
import com.playtomic.anemone.user.service.UserLinkingTenantService;
import com.playtomic.anemone.user.service.UserMatchesService;
import com.playtomic.anemone.user.service.UserService;
import com.playtomic.anemone.user.service.exception.InvalidBirthDateException;
import com.playtomic.anemone.user.service.exception.InvalidCountryCodeException;
import com.playtomic.anemone.user.service.exception.InvalidEmailException;
import com.playtomic.anemone.user.service.exception.InvalidPhoneException;
import com.playtomic.anemone.user.service.exception.InvalidSearchParametersException;
import com.playtomic.anemone.user.service.exception.UserNotFoundException;
import com.playtomic.anemone.user.service.exception.UserPrivacyProfileConflictException;
import io.jsonwebtoken.lang.Collections;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.context.MessageSource;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Validated
@Slf4j
@RestController
@RequestMapping(path = "/v2")
public class UserControllerV2 extends AbstractUserRestController {

    enum ErrorCodes {
        SENT,
        EMAIL_NOT_SENT,
        MISSING_REQUIRED_PARAMETERS,
        ILLEGAL_EMAIL_UPDATE
    }

    private static final int MIN_SEARCH_QUERY_LENGTH = 3;

    private static final CurrentUserIdConverter userIdConverter = new CurrentUserIdConverter();

    @Nonnull
    private final UserCredentialService userCredentialService;
    @Nonnull
    private final UserLinkingTenantService userLinkingTenantService;
    @Nonnull
    private final ExportUsersService exportUsersService;
    @Nonnull
    private final CoachService coachService;
    @Nonnull
    private final UserMatchesService userMatchesService;

    public UserControllerV2(@Nonnull MessageSource messageSource,
        @Nonnull DiscoveryClient discoveryClient,
        @Nonnull UserService userService,
        @Nonnull UserCredentialService userCredentialService,
        @Nonnull UserPermissionService userPermissionService,
        @Nonnull PermissionService permissionService,
        @Nonnull UserLinkingTenantService userLinkingTenantService,
        @Nonnull ExportUsersService exportUsersService,
        @Nonnull CoachService coachService,
        @Nonnull UserMatchesService userMatchesService) {
        super(messageSource, discoveryClient, userPermissionService, permissionService,
            userService);
        this.userCredentialService = userCredentialService;
        this.userLinkingTenantService = userLinkingTenantService;
        this.exportUsersService = exportUsersService;
        this.coachService = coachService;
        this.userMatchesService = userMatchesService;
    }

    @Nonnull
    @PreAuthorize("hasPermission(#userId, 'read_private_profile')")
    @PostMapping(path = "/users/{user_id}/validation_email", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<StatusResponseBody> resendValidationEmail(
        @PathVariable(name = "user_id") UserId userId,
        @RequestBody(required = false) @Nullable ValidationEmailRequestBody validationEmailRequestBody) {
        // Updates user from db, because email can be changed.
        UserProfile user = userService.getUserById(userId);

        if (user.getEmail() == null) {
            return getErrorResponse(ErrorCodes.EMAIL_NOT_SENT,
                "UserService.ValidationEmail.NotEmailSet",
                HttpStatus.BAD_REQUEST);
        }

        // carlosgarcia:
        // This ASTONISHING work of art is because it seems to be fashionable to execute POST requests with {} in the body
        // Web clients -> Have changed their requests so when they have nothing to send in the body, don't send anything.
        // App -> Due to the library they use for rest requests. They send {} when they have nothing to send.
        var hasReturnPath =
            validationEmailRequestBody != null
                && validationEmailRequestBody.getReturnPath() != null;
        var returnPath = hasReturnPath ? validationEmailRequestBody.getReturnPath() : null;

        userCredentialService.sendValidationEmail(new Email(user.getEmail()),
            user.getCommunicationsLanguage(), returnPath);

        return ResponseEntity.ok(new StatusResponseBody("SENT",
            getMessage("UserService.ValidationEmail.Success", user.getEmail())));
    }

    @Nonnull
    @PostMapping(path = "/users")
    @PreAuthorize("hasAnyAuthority('admin_users', 'create_customers')")
    public ResponseEntity<UserProfile> createUser(@RequestBody @Nonnull PostUserBody body) {
        if (!PhoneValidator.isValid(body.getPhone())) {
            throw new InvalidPhoneException(body.getPhone());
        }
        String authenticatedUserId = isAnonymous() ? null : getCurrentUser().getId().getValue();
        UserProfile newUser = userService.createUser(
            body.getEmail(),
            body.getPassword() == null ? PasswordGenerator.generate() : body.getPassword().value(),
            body.getFullName(),
            body.getPhone(),
            body.getCountryCode(),
            body.getCommunicationsLanguage(),
            body.getBirthDate(),
            body.getGender(),
            body.getAddress(),
            body.getPictureBase64(),
            authenticatedUserId,
            body.getTenantId(),
            body.getRoles());

        return ResponseEntity.ok(newUser);
    }

    @Nonnull
    @PreAuthorize("hasPermission(#tenantId, 'export_customer_data')")
    @GetMapping(path = "/users/customers/csv", produces = "text/csv")
    public ResponseEntity<Resource> exportCustomers(
        @RequestParam(name = "tenant_id") @Nonnull TenantId tenantId) {
        var content = exportUsersService.exportCustomers(tenantId);
        var fileName = "customers-" + LocalDate.now() + ".csv";
        var headers = new HttpHeaders();
        headers.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + fileName);
        headers.set(HttpHeaders.CONTENT_TYPE, "text/csv");

        return new ResponseEntity<>(content, headers, HttpStatus.OK);
    }

    @Nonnull
    @PreAuthorize("hasAnyAuthority('admin_users')")
    @GetMapping(path = "/users/csv_export", produces = "text/csv")
    public ResponseEntity<Resource> exportUsers(
        @RequestParam(name = "email") @Nonnull List<Email> emails, @Nonnull Pageable pageable) {
        var content = exportUsersService.exportUsers(emails, pageable);
        var csvFileName = "users" + Instant.now().toString() + ".csv";
        var headers = new HttpHeaders();
        headers.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + csvFileName);
        headers.set(HttpHeaders.CONTENT_TYPE, "text/csv");

        return new ResponseEntity<>(content, headers, HttpStatus.OK);
    }

    @Nonnull
    @GetMapping(path = "/users")
    public ResponseEntity searchUsers(
        @RequestParam(name = "q", required = false) @Nullable String q,
        @RequestParam(name = "name", required = false) @Nullable String nameLike,
        @RequestParam(name = "user_id", required = false) @Nullable List<String> userStringIds,
        @RequestParam(name = "email", required = false) @Nullable List<Email> emails,
        @RequestParam(name = "phone", required = false) @Nullable List<String> phones,
        @RequestParam(name = "facebook_id", required = false) @Nullable List<String> facebookIds,
        @RequestParam(name = "user_role", required = false) @Nullable List<PlaytomicUserRole> userRoles,
        @RequestParam(name = "tenant_id", required = false) @Nullable List<TenantId> tenantIds,
        @RequestParam(name = "merchant_user_id", required = false) @Nullable List<MerchantUserId> merchantUserIds,
        @RequestParam(name = "is_email_verified", required = false) @Nullable Boolean emailVerified,
        @RequestParam(name = "has_linked_account", required = false) @Nullable Boolean hasLinkedAccount,
        @RequestParam(name = "has_coach_account", required = false) @Nullable Boolean hasCoachAccount,
        @Nonnull Pageable pageable) {

        // tenant_id is a 'weak' parameter, it must be used alongside user roles or merchant user id for filtering
        if (tenantIds != null && userRoles == null && merchantUserIds == null && nameLike == null
            && hasLinkedAccount == null && hasCoachAccount == null) {
            throw new BadRequestException(
                "If tenant_id is specified, you must specify one of user_role, merchant_user_id, name, has_linked_account, hasCoachAccount");
        }

        final Authentication auth = getAuthentication();

        // This creates a restriction to search user by user_role at tenants or merchant_user_id at tenant
        // mdelmoral: Before only admin_user could search by tenant_id and user_role but now we need tenant managers to be able to list their own users.
        if (tenantIds != null && userRoles != null && !userPermissionService.isAllowed(tenantIds,
            "read_user_roles", auth)) {
            throw new AccessDeniedException(
                "You don't have permission to use this parameters: user_role, tenant_id, merchant_user_id, has_linked_account");
        }

        if (tenantIds != null && hasLinkedAccount != null) {
            if (!userPermissionService.isAllowed(tenantIds, "read_linked_accounts", auth)) {
                throw new AccessDeniedException(
                    "You don't have permission to use this parameters: user_role, tenant_id, merchant_user_id, has_linked_account");
            }

            if (!hasLinkedAccount) {
                throw new BadRequestException(
                    "has_linked_account must be true or not specified. We don't support has_linked_account=false");
            }
        }

        if (tenantIds != null && hasCoachAccount != null) {
            if (!userPermissionService.isAllowed(tenantIds, "read_coach_accounts", auth)) {
                throw new AccessDeniedException(
                    "You don't have permission to use this parameters: tenant_id, has_coach_account");
            }

            if (!hasCoachAccount) {
                throw new BadRequestException(
                    "has_coach_account must be true or not specified. We don't support has_linked_account=false");
            }
        }

        // This creates a restriction to search user by linked_accounts
        if (tenantIds != null && merchantUserIds != null && !userPermissionService.isAllowed(
            tenantIds,
            "read_linked_accounts", auth)) {
            throw new AccessDeniedException(
                "You don't have permission to use this parameters: user_role, tenant_id, merchant_user_id, has_linked_account");
        }

        // name is a special parameter, because it is a potential way of searching every user in the database.
        // So that, only users with "search_by_name" auth are allowed to do a global search...
        if (nameLike != null && !userPermissionService.isAllowed("search_by_name", auth)) {
            // ... otherwise you have to specify tenantsIs parameter and have access to that.
            assertAllowed(userPermissionService.isAllowed(tenantIds, "search_by_name", auth));
        }

        if (emailVerified != null && emails == null) {
            throw new BadRequestException(
                "If is_email_verified is specified, you must specify emails");
        }

        if (Strings.isNullOrEmpty(q) &&
            Strings.isNullOrEmpty(nameLike) &&
            CollectionUtils.isEmpty(userStringIds) &&
            CollectionUtils.isEmpty(emails) &&
            CollectionUtils.isEmpty(phones) &&
            CollectionUtils.isEmpty(facebookIds) &&
            CollectionUtils.isEmpty(userRoles) &&
            CollectionUtils.isEmpty(merchantUserIds) &&
            hasLinkedAccount == null &&
            hasCoachAccount == null) {

            throw new InvalidSearchParametersException();
        }

        // Do not return results when less than 3 chars
        if (q != null && q.length() < MIN_SEARCH_QUERY_LENGTH) {
            return ResponseEntity.ok(List.of());
        }

        // We are only setting default userPhoneCountryCode if q or phones parameters are set.
        var searchByPhone = !Strings.isNullOrEmpty(q) || !CollectionUtils.isEmpty(phones);
        var defaultUserPhoneCountryCode = searchByPhone ? getDefaultUserPhoneCountryCode() : null;

        if (phones != null) {
            phones = phones.stream()
                .map(s -> PhoneValidator.formattedPhone(s, defaultUserPhoneCountryCode)
                    .orElseThrow(() -> new InvalidPhoneException(s)))
                .collect(Collectors.toList());
        }

        var userIds = Collections.isEmpty(userStringIds) ? null
            : userStringIds.stream().map(this::toUserIdOrNull).collect(Collectors.toList());

        // optimization: By now every user has ROLE_CUSTOMER and it is not stored in db.
        if (!CollectionUtils.isEmpty(userRoles)) {
            userRoles.remove(PlaytomicUserRole.ROLE_CUSTOMER);
        }

        // Non protected filters are here. Notice that defaultUserPhoneCountry code might be null if q or phones are unused
        // or if request is anonymous or requestUser is Anemone
        UserFilter.UserFilterBuilder userFilterBuilder = UserFilter.builder()
            .userIds(userIds)
            .query(q)
            .emails(emails)
            .phones(phones)
            .facebookIds(facebookIds)
            .defaultPhoneCountryCode(defaultUserPhoneCountryCode)
            .nameLike(nameLike)
            .tenantIds(tenantIds)
            .hasLinkedAccount(hasLinkedAccount)
            .hasCoachAccount(hasCoachAccount);

        if (userPermissionService.isAllowed(userIds, "read_private_profile", auth) ||
            userPermissionService.isAllowed(tenantIds, "read_private_profile", auth)) {
            // And admin filters are here
            UserFilter userFilter = userFilterBuilder
                .userRoles(userRoles)
                .merchantUserIds(merchantUserIds)
                .emailVerified(emailVerified)
                .build();

            Page<CustomerUserProfile> privateProfiles = userService.searchUsersByFilter(userFilter,
                pageable);

            sanitize(privateProfiles, getAuthentication());

            return LinkHeader.toResponse(privateProfiles);
        }

        final UserFilter userFilter = userFilterBuilder.build();
        boolean accessAllContactData = userPermissionService.isAllowed(userFilter.tenantIds(),
            "read_contact_data", auth);
        Page<PublicUserProfile> publicProfiles = userService.searchPublicUsersByFilter(userFilter,
            pageable, accessAllContactData);

        return LinkHeader.toResponse(publicProfiles);
    }

    /**
     * This method was added as dirty hack to support "anemone" owner in reservations, because
     * user_id is nonnull. Future changes to support user_id nullable in reservations are planned,
     * but in the meanwhile we need this mapping:
     */
    @Nonnull
    @GetMapping(path = {"/users/anemone", "/users/0", "/users/ANEMONE"})
    public ResponseEntity<AnemoneUserProfile> getAnemoneUser() {
        return ResponseEntity.ok(new AnemoneUserProfile());
    }

    @Nonnull
    @GetMapping(path = "/users/{user_id}")
    public UserProfile getUserProfile(@PathVariable(name = "user_id") @Nullable UserId userId,
        @RequestParam(name = "with_active_permissions", required = false) @Nullable Boolean withActivePermissions) {
        // Nullable due to "me": it returns null when no user is logged if "me" was specified.
        if (userId == null) {
            throw new UserNotFoundException();
        }

        // optimization: This endpoint is the second most used endpoint in anemone.
        // most of the traffic comes from the app, were the rest of the users have no right to read private info.
        // This will avoid reading the whole entity from database in those cases.
        if (!userPermissionService.mightAccessPrivateData(userId, getAuthentication())) {
            return userService.getPublicUserById(userId);
        }

        CustomerUserProfile user = userService.getUserById(userId);
        if (!userPermissionService.isAllowed(user, "read_private_profile", getAuthentication())) {
            boolean hasContactDataAccess = userPermissionService.isAllowed(user.getLinkedTenantIds(), "read_contact_data", getAuthentication());
            return new PublicUserProfile(user, hasContactDataAccess);
        }

        if (BooleanUtils.isTrue(withActivePermissions) &&
            userPermissionService.isAllowedUser(userId, "read_user_permissions", getAuthentication())) {
                user.setActivePermissions(permissionService.getActivePermissions(userId));
        }

        sanitize(user, getAuthentication());
        return user;
    }

    @Nonnull
    @GetMapping(path = "/users/{user_id}/cancellation-policies")
    public ResponseEntity<CancellationPolicyDuration> getUserCancellationPolicy(
        @PathVariable(name = "user_id") @Nonnull UserId userId,
        @RequestParam(name = "tenant_id") @Nonnull TenantId tenantId,
        @RequestParam(name = "date") @Nonnull Instant date) {
        return userService.getCancellationPolicy(userId, tenantId, date)
            .map(ResponseEntity::ok)
            .orElseGet(() -> ResponseEntity.noContent().build());
    }

    @Nonnull
    @PostMapping(path = "/users/{user_id}/user_roles")
    public ResponseEntity<UserProfile> addUserRoles(
        @PathVariable(name = "user_id") @Nonnull UserId userId,
        @RequestBody @Nonnull CreateUserRoleRequestBody body) {
        List<TenantId> tenantIds = body.getUserRoles().stream()
            .map(ExtendedUserRole::getTenantId)
            .filter(Objects::nonNull)
            .collect(Collectors.toList());

        assertAllowed(
            userPermissionService.isAllowed(tenantIds, "write_user_roles", getAuthentication()));

        UserProfile user = userService.addUserRoles(userId, body.getUserRoles(), true);

        return ResponseEntity.ok(user);
    }

    @Nonnull
    @DeleteMapping(path = "/users/{user_id}/user_roles/{role_id}")
    public ResponseEntity<UserProfile> removeUserRole(
        @PathVariable(name = "user_id") @Nonnull UserId userId,
        @PathVariable(name = "role_id") @Nonnull PlaytomicUserRole userRole,
        @RequestParam(name = "tenant_id", required = false) @Nullable List<TenantId> tenantIds) {
        if (Collections.isEmpty(tenantIds)) {
            // Only ADMINs should be able to remove all roles in any tenant
            assertAllowed(userPermissionService.isAllowed("admin_users", getAuthentication()));
        } else {
            // We check access to tenants
            assertAllowed(
                userPermissionService.isAllowed(tenantIds, "write_user_roles",
                    getAuthentication()));
        }

        UserProfile user = userService.removeUserRole(userId, userRole, tenantIds);

        return ResponseEntity.ok(user);
    }


    @Nonnull
    @PostMapping(path = "/users/{user_id}/anonymize")
    @PreAuthorize("hasAnyAuthority('admin_users')")
    public AnonymizeUserResponse anonymizeUserWithoutRestrictions(
        @PathVariable(name = "user_id") @Nonnull UserId userId,
        @RequestBody @Nonnull AnonymizeUserRequestBody body) {
        //This is a check intended to prevent accidental deletion. We could also ask for the email to match.
        String expectedConfirmation = "I have proof of consent to anonymize user " + userId;
        if (!expectedConfirmation.equalsIgnoreCase(body.confirmation)) {
            throw new BadRequestException("Confirmation content is wrong");
        }

        CustomerUserProfile updatedUser = userService.anonymizeUser(userId);
        return new AnonymizeUserResponse(updatedUser);
    }

    @Nonnull
    @DeleteMapping("/users/{user_id}/anonymize")
    public ResponseEntity<Void> anonymizeUser(
        @PathVariable(name = "user_id") @Nonnull UserId userId) {
        assertAllowed(
            userPermissionService.isAllowedUser(userId, "delete_private_profile",
                getAuthentication()));

        userService.anonymizeUserWithRestrictions(userId);
        return ResponseEntity.noContent().build();
    }

    @Nonnull
    @PatchMapping(path = "/users/{user_id}")
    public CustomerUserProfile updateProfile(@PathVariable(name = "user_id") @Nonnull UserId userId,
        @RequestBody @Nonnull UserUpdateRequestBody body)
        throws InterruptedException {
        final Authentication auth = getAuthentication();

        // A user cannot change to private profile if there are pending public matches
        if (body.privacyProfile == PrivacyProfile.PRIVATE
            && userMatchesService.hasPendingPublicMatches(userId)) {
            throw new UserPrivacyProfileConflictException();
        }

        if (body.modifiesPrivateProfile() || body.modifiesPublicProfile()) {
            CustomerUserProfile user = userService.getUserById(userId);

            if (body.modifiesPrivateProfile() || body.fullName != null) {
                assertCanModifyPrivateProfile(userId, auth, user);
            }

            if (body.modifiesPublicProfile()) {
                assertCanModifyPublicProfile(body.email, body.fullName, auth, user);
            }

            if (body.email != null) {
                assertCanModifyEmail(body.email, getCurrentUser(), user);
            }
        }

        if (body.modifiesVerificationData()) {
            assertAllowed(userPermissionService.isAllowed(userId, "write_verification_data", auth));
        }

        if (body.email != null && !EmailValidator.isValid(body.email)) {
            throw new InvalidEmailException();
        }

        if (body.phone != null) {
            body.phone = PhoneValidator.formattedPhone(body.phone, null)
                .orElseThrow(() -> new InvalidPhoneException(body.phone));
        }

        if (body.birthDate != null && body.birthDate.isAfter(ZonedDateTime.now())) {
            throw new InvalidBirthDateException();
        }

        if (body.countryCode != null && !CountryCodeValidator.isValid(body.countryCode)) {
            throw new InvalidCountryCodeException();
        }

        userService.updateCustomer(userId,
            body.email != null ? new Email(body.email) : null,
            body.emailToken,
            body.fullName,
            body.password,
            body.phone,
            body.phoneToken,
            body.acceptsPrivacy,
            body.acceptsCommercial,
            body.gender,
            body.birthDate,
            body.bio,
            body.countryCode,
            body.communicationsLanguage,
            body.isEmailVerified,
            body.isPhoneVerified,
            body.address,
            body.privacyProfile
        );

        if (body.pictureBase64 != null) {
            userService.updatePicture(userId, body.pictureBase64);
        }

        return userService.getUserById(userId);
    }

    // mdelmoral: Only for testing purpose
    @Nonnull
    @DeleteMapping(path = "/users/{user_id}")
    @PreAuthorize("hasAnyAuthority('admin_users')")
    public ResponseEntity<Void> removeUser(@PathVariable(name = "user_id") @Nonnull UserId userId) {
        userService.removeUser(userId);
        return ResponseEntity.noContent().build();
    }

    @Nonnull
    @DeleteMapping(path = "/users/{user_id}/picture")
    @PreAuthorize("hasPermission(#userId, 'write_private_profile')")
    public CustomerUserProfile removeProfilePicture(
        @PathVariable(name = "user_id") @Nonnull UserId userId) {
        return userService.removeProfilePicture(userId);
    }

    /**
     * NOTE: for new anemone venues consider using register_as_venue_customer endpoint that is much more clear.
     * This endpoint is used from different places for different purposes. Depending on the tenant type some of the usages will be ignored.
     *   * Standard account linking using password: only makes sense for syltek-crm venues
     *   * Autoregister: this creates an account on the venue.
     *      * For CRM this will create a new account with the values copied from anemone account
     *      * For anemone this will link the account, causing the anemone user to appear as a user in venues database.
     *   * Autolink:
     *      * For CRM, the account will be linked if account already exists on the venue
     *      * For anemone, operation is ignored, since there is no specific list to check if user is already registered on the venue.
     */
    @Nonnull
    @PostMapping(path = "/users/{user_id}/linked_accounts")
    @PreAuthorize("hasPermission(#userId, 'write_linked_accounts') || hasPermission(#body.tenantId, 'write_linked_accounts')")
    public ResponseEntity<CustomerUserProfile> linkAccount(
        @PathVariable(name = "user_id") UserId userId,
        @RequestBody UserLinkAccountRequestBody body) {
        if (!Objects.isNull(body.email) && !Strings.isNullOrEmpty(body.password)) {
            // Standard account linking using password
            userLinkingTenantService.linkTenantWithEmailAndPassword(userId, body.tenantId,
                body.email,
                body.password, body.acceptsCommercial);
        } else {
            userLinkingTenantService.registerOrLinkUserInTenant(userId, body.tenantId, body.autoregister);
        }
        return ResponseEntity.ok(userService.getUserById(userId));
    }

    /**
     * This endpoint is used when a service wants to register some user as a venue customer so it appears on venues database.
     * This operation is idempotent, if user already is a customer in venue this just does nothing.
     *
     * NOTE: this is a replacement for the legacy concept of autoregister/autolink on CRM venues.
     **/
    @Nonnull
    @PostMapping(path = "/users/{user_id}/register_as_venue_customer/{tenant_id}")
    @PreAuthorize("hasPermission(#userId, 'write_linked_accounts') || hasPermission(#tenantId, 'write_linked_accounts')")
    public ResponseEntity<CustomerUserProfile> registerAsVenueCustomer(
        @PathVariable(name = "user_id") @Nonnull UserId userId,
        @PathVariable(name = "tenant_id") @Nonnull TenantId tenantId) {
        var user = userLinkingTenantService.registerAsVenueCustomer(userId, tenantId);
        return ResponseEntity.ok(user);
    }

    /**
     * Updates accepts_commercial flag on linked accounts. Depending on venue type:
     *  * For syltek-crm: the flag is updated on existing link
     *  * For anemone: the link is created if it didn't exist before. This was requested by product team since
     *      they define the approval of accepts_commercial a case where user intends to be in the venues customers list.
     */
    @Nonnull
    @PreAuthorize("hasPermission(#userId, 'write_linked_accounts') || hasPermission(#body.tenantId, 'write_linked_accounts')")
    @PatchMapping(path = "/users/{user_id}/linked_accounts/{tenant_id}")
    public CustomerUserProfile patchAccount(@PathVariable(name = "user_id") UserId userId,
        @PathVariable(value = "tenant_id") TenantId tenantId,
        @RequestBody PatchLinkedAccountRequestBody body) {
        return userLinkingTenantService.updateLinkedTenant(userId, tenantId, body.acceptsCommercial);
    }

    @Nonnull
    @DeleteMapping(path = "/users/{user_id}/linked_accounts")
    @PreAuthorize("hasPermission(#userId, 'write_linked_accounts') || hasPermission(#body.tenantId, 'write_linked_accounts')")
    public CustomerUserProfile unlinkAccount(@PathVariable(name = "user_id") UserId userId,
        @RequestParam(value = "tenant_id") TenantId tenantId) {
        return userLinkingTenantService.unlinkTenant(userId, tenantId);
    }

    @Nonnull
    @GetMapping(path = "/users/{user_id}/game_preferences")
    @PreAuthorize("hasPermission(#userId, 'write_private_profile')")
    public ResponseEntity<UserGamePreferences> getGamePreferences(
        @PathVariable(name = "user_id") UserId userId) {
        return ResponseEntity.ok(userService.getGamePreferences(userId));
    }

    @Nonnull
    @PreAuthorize("hasPermission(#userId, 'write_private_profile')")
    @PutMapping(path = "/users/{user_id}/game_preferences")
    public ResponseEntity<UserGamePreferences> setGamePreferences(
        @PathVariable(name = "user_id") @Nonnull UserId userId,
        @RequestBody @Nonnull UserGamePreferences gamePreferences) {
        return ResponseEntity.ok(userService.setGamePreferences(userId, gamePreferences));
    }

    @Nonnull
    @PreAuthorize("hasPermission(#userId, 'write_private_profile')")
    @PostMapping(path = "/users/{user_id}/validation_sms", consumes = Constants.CONSUMES_JSON)
    public ResponseEntity<Void> validatePhone(
        @PathVariable(name = "user_id") @Nonnull UserId userId,
        @RequestBody @Nonnull ValidationPhoneRequestBody body) {
        userService.validatePhone(userId, body.getPhone());
        return ResponseEntity.ok().build();
    }

    @Nonnull
    @PreAuthorize("hasPermission(#tenantId, 'read_user_permissions')")
    @GetMapping("/users/{user_id}/permissions")
    public ResponseEntity<Permission> getPermissions(
        @PathVariable("user_id") @Nonnull UserId userId,
        @RequestParam("tenant_id") @Nonnull TenantId tenantId) {
        return ResponseEntity.ok(permissionService.getPermissionsInTenant(userId, tenantId));
    }

    @Nonnull
    @PreAuthorize("hasPermission(#body.tenantId, 'write_user_permissions')")
    @PutMapping("/users/{user_id}/permissions")
    public ResponseEntity<Permission> putPermissions(
        @PathVariable("user_id") @Nonnull UserId userId,
        @RequestBody @Nonnull Permission body) {
        return ResponseEntity.ok(
            permissionService.setPermissionsInTenant(userId, body.getTenantId(),
                body.getPermissions()));
    }

    @Nonnull
    @PreAuthorize("hasPermission(#tenantId, 'write_user_permissions')")
    @DeleteMapping("/users/{user_id}/permissions")
    public ResponseEntity<Void> deletePermissions(@PathVariable("user_id") @Nonnull UserId userId,
        @RequestParam("tenant_id") @Nonnull TenantId tenantId) {
        permissionService.deletePermissionsInTenant(userId, tenantId);
        return ResponseEntity.noContent().build();
    }

    @Nonnull
    @PreAuthorize("hasPermission(#body.tenantId, 'write_user_permissions')")
    @PutMapping("/users/{user_id}/permissions/{permission_name}")
    public ResponseEntity<Permission> putPermissions(
        @PathVariable("user_id") @Nonnull UserId userId,
        @PathVariable("permission_name") @Nonnull PermissionName permissionName,
        @RequestBody @Nonnull PutPermissionBody body) {
        return ResponseEntity.ok(
            permissionService.updatePermissionInTenant(userId, body.getTenantId(), permissionName,
                body.getLevel()));
    }

    @Nonnull
    @PreAuthorize("hasAnyAuthority('admin_users')")
    @PostMapping("/users/permissions/migrateTenantManagersWithoutPermissions")
    public ResponseEntity<Integer> migrateTenantManagersWithoutPermissions() {
        return ResponseEntity.ok(permissionService.migrateTenantManagersWithoutPermissions());
    }

    @Nonnull
    @PreAuthorize("hasPermission(#tenantId, 'write_coach_accounts')")
    @PutMapping(path = "/users/{user_id}/coach_accounts/{tenant_id}")
    public ResponseEntity<CustomerUserProfile> putCoachAccount(
        @PathVariable(name = "user_id") @Nonnull UserId userId,
        @PathVariable(name = "tenant_id") @Nonnull TenantId tenantId,
        @Nonnull @RequestBody LinkCoachAccountData body) {
        return ResponseEntity.ok(coachService.putCoachAccount(userId, tenantId, body));
    }

    @Nonnull
    @PreAuthorize("hasPermission(#tenantId, 'write_coach_accounts')")
    @DeleteMapping(path = "/users/{user_id}/coach_accounts/{tenant_id}")
    public CustomerUserProfile deleteCoachAccount(
        @PathVariable(name = "user_id") @Nonnull UserId userId,
        @PathVariable(value = "tenant_id") @Nonnull TenantId tenantId) {
        return coachService.deleteCoachAccount(userId, tenantId);
    }

    @Nonnull
    @PreAuthorize("hasPermission(#tenantId, 'write_tenant_owner_accounts')")
    @PutMapping(path = "/users/{user_id}/tenant_owner_accounts/{tenant_id}")
    public ResponseEntity<CustomerUserProfile> putTenantOwnerAccount(
        @PathVariable(name = "user_id") @Nonnull UserId userId,
        @PathVariable(name = "tenant_id") @Nonnull TenantId tenantId) {
        return ResponseEntity.ok(userLinkingTenantService.putTenantOwnerAccount(userId, tenantId));
    }

    @Nonnull
    @PreAuthorize("hasPermission(#tenantId, 'write_tenant_owner_accounts')")
    @DeleteMapping(path = "/users/{user_id}/tenant_owner_accounts/{tenant_id}")
    public CustomerUserProfile deleteTenantOwnerAccount(
        @PathVariable(name = "user_id") @Nonnull UserId userId,
        @PathVariable(value = "tenant_id") @Nonnull TenantId tenantId) {
        return userLinkingTenantService.deleteTenantOwnerAccount(userId, tenantId);
    }

    @Nonnull
    @PatchMapping(path = "/users/{user_id}/tenant_owner_accounts/{tenant_id}")
    public TenantOwnerAccount patchTenantOwnerAccount(
        @PathVariable(name = "user_id") @NotNull UserId userId,
        @PathVariable(value = "tenant_id") @NotNull TenantId tenantId,
        @RequestBody @Valid PatchTenantOwnerAccount body) {

        if(!getCurrentUser().getId().getValue().equals(userId.getValue())){
            throw new AccessDeniedException("Owner account can only be update by the user itself");
        }

        return userLinkingTenantService.patchTenantOwnerAccount(userId, tenantId,
                                                         body.getAcceptsMarketingCommunications(),
                                                         body.getAcceptsMarketingBehaviourAnalysis(),
                                                         body.getAcceptsCxQuestionnaires(),
                                                         body.getAcceptsCxWhatsappCommunications());
    }

    @PreAuthorize("hasAnyAuthority('admin_users')")
    @PutMapping(path = "/users/{user_id}/premium")
    public void setPremiumInfo(@PathVariable(name = "user_id") @Nonnull UserId userId, @Nonnull @RequestBody PremiumInfoBody body) {
        userService.setPremiumInfo(userId, body.isPremium(), body.getExpiresAt());
    }

    private void assertCanModifyPublicProfile(@Nullable String email, @Nullable String fullName,
        @Nonnull Authentication auth, @Nonnull CustomerUserProfile user) {
        // Checking if the user is a customer, coach or manager of the same tenant as the user who makes the request.
        final boolean isAllowed = userPermissionService.isAllowed(user, "write_contact_data", auth);

        if (!isAllowed) {
            // managers from the tenant where the user was created can update the user's data
            assertAllowed(isProfileCreatedInManagedTenant(auth, user));

            // The email is verified, so only the phone can be modified.
            if (user.isEmailVerified() && (email != null || fullName != null)) {
                assertAllowed(false);
            }

            // The phone is verified, so nothing can be updated from a manager.
            assertAllowed(!user.isPhoneVerified());

            // The rest of fields are controlled in the assertCanModifyPrivateProfile if needed.
        }
    }

    @Nonnull
    private Boolean isProfileCreatedInManagedTenant(@Nonnull Authentication auth,
        @Nonnull CustomerUserProfile user) {
        boolean isCustomer = user.getLinkedTenantsAccounts().stream()
            .filter(
                la -> userPermissionService.isAllowed(la.getTenantId(), "role_tenant_manager",
                    auth))
            .anyMatch(la -> user.isCreatedByTenant(la.getTenantId()));

        boolean isCoach = user.getCoachAccounts().stream()
                .filter(
                        ca -> userPermissionService.isAllowed(ca.getTenantId(), "role_tenant_manager",
                                auth))
                .anyMatch(ca -> user.isCreatedByTenant(ca.getTenantId()));
        return isCustomer || isCoach;
    }

    private void assertCanModifyPrivateProfile(@Nonnull UserId userId, @Nonnull Authentication auth,
        @Nonnull CustomerUserProfile user) {
        final boolean isAllowed = userPermissionService.isAllowed(userId, "write_private_profile",
            auth);
        if (!isAllowed) {
            assertAllowed((isProfileCreatedInManagedTenant(auth, user) && !user.isEmailVerified()));
        }
    }

    private void assertCanModifyEmail(@Nonnull String email, @Nonnull User currentUser,
        @Nonnull CustomerUserProfile user) {
        var emailChanged = !email.equalsIgnoreCase(user.getEmail());
        var accountOwner = user.getId().equals(currentUser.getId());
        // not ONLINE users cannot update their email if it was not verified yet, only managers can
        if (emailChanged && accountOwner && user.getType() != PlaytomicUserType.ONLINE) {
            throw new IllegalEmailUpdateForOnsiteUserException();
        }
    }

    @Nullable
    private UserId toUserIdOrNull(@Nonnull String userId) {
        try {
            return userIdConverter.convert(userId);
        } catch (NumberFormatException e) {
            return null;
        }
    }
}

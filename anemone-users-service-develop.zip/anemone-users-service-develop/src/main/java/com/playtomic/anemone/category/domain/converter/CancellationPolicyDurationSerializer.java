package com.playtomic.anemone.category.domain.converter;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.playtomic.anemone.category.domain.CancellationPolicyDuration;
import java.io.IOException;
import java.time.temporal.ChronoUnit;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.NoArgsConstructor;

@NoArgsConstructor
public class CancellationPolicyDurationSerializer extends JsonSerializer<CancellationPolicyDuration> {

    public void serialize(@Nullable CancellationPolicyDuration value, @Nonnull JsonGenerator jgen, @Nonnull SerializerProvider provider)
        throws IOException {
        if (value != null) {
            long hours = value.getDuration().toHours();
            jgen.writeStartObject();
            jgen.writeNumberField("amount", hours);
            jgen.writeStringField("unit", ChronoUnit.HOURS.name());
            jgen.writeEndObject();
        }
    }
}

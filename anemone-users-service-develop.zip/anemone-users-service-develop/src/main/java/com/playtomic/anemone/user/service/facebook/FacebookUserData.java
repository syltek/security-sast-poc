package com.playtomic.anemone.user.service.facebook;

import com.playtomic.anemone.domain.Email;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Data;

@Data
public class FacebookUserData {
    @Nonnull
    private FacebookId facebookId;

    @Nonnull
    private String username;

    @Nullable
    private Email email;

    private boolean isVerified;

    public FacebookUserData(@Nonnull FacebookId facebookId,
                            @Nonnull String username,
                            @Nullable Email email,
                            boolean isVerified) {
        this.facebookId = facebookId;
        this.username = username;
        this.email = email;
        this.isVerified = isVerified;
    }
}

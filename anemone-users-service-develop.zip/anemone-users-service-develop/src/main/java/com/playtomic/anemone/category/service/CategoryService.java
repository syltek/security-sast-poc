package com.playtomic.anemone.category.service;

import com.google.common.collect.Lists;
import com.playtomic.anemone.category.api.v1.request.PatchCategory;
import com.playtomic.anemone.category.dao.BookingPrivilegeField;
import com.playtomic.anemone.category.dao.CategoryDocument;
import com.playtomic.anemone.category.dao.CategoryDocument.Status;
import com.playtomic.anemone.category.dao.CategoryExpirationField;
import com.playtomic.anemone.category.dao.CategoryRepository;
import com.playtomic.anemone.category.dao.MembershipDetailsField;
import com.playtomic.anemone.category.domain.BookingPrivilege;
import com.playtomic.anemone.category.domain.Category;
import com.playtomic.anemone.category.domain.CategoryExpiration;
import com.playtomic.anemone.category.domain.CategoryId;
import com.playtomic.anemone.category.domain.CategoryType;
import com.playtomic.anemone.category.domain.MembershipDetails;
import com.playtomic.anemone.category.domain.MembershipPrice;
import com.playtomic.anemone.category.domain.MembershipProductId;
import com.playtomic.anemone.category.domain.UserIdAndCategoryExpiration;
import com.playtomic.anemone.category.domain.Visibility;
import com.playtomic.anemone.category.domain.scheduler.MemberTaskDetails;
import com.playtomic.anemone.category.messaging.CategoryEvent;
import com.playtomic.anemone.category.messaging.CategoryEvent.CategoryEventType;
import com.playtomic.anemone.category.service.email.CategoryEmailsServiceComponent;
import com.playtomic.anemone.category.service.email.MembershipEmailsServiceComponent;
import com.playtomic.anemone.category.service.exception.CategoryCannotBeDisabledException;
import com.playtomic.anemone.category.service.exception.CategoryIsDisabledException;
import com.playtomic.anemone.category.service.exception.CategoryMembersUpdateRejectedException;
import com.playtomic.anemone.category.service.exception.CategoryNotFoundException;
import com.playtomic.anemone.category.service.exception.CategoryUpdateRejectedException;
import com.playtomic.anemone.category.service.exception.CategoryWithThisNameAlreadyExistsException;
import com.playtomic.anemone.category.service.scheduler.CategorySchedulerServiceComponent;
import com.playtomic.anemone.dao.OptimisticLockingRetryableExecutor;
import com.playtomic.anemone.domain.user.UserId;
import com.playtomic.anemone.user.dao.TenantTagEntity;
import com.playtomic.anemone.user.dao.TenantTagEntity.Type;
import com.playtomic.anemone.user.dao.TenantTagRepository;
import com.playtomic.anemone.user.dao.UserRepository;
import com.playtomic.anemone.user.domain.reservation.MerchantUserId;
import com.playtomic.anemone.user.domain.tenant.Tenant;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import com.playtomic.anemone.user.domain.users.UserLegacy;
import com.playtomic.anemone.user.service.UserServicePersistenceComponent;
import com.playtomic.anemone.user.service.anemone.TenantServiceClient;
import com.playtomic.anemone.user.service.exception.TenantNotFoundException;
import com.playtomic.anemone.user.service.exception.UserNotFoundException;
import com.playtomic.anemone.user.service.messaging.MessagingBroker;
import io.jsonwebtoken.lang.Assert;
import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.validation.ClockProvider;
import javax.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service
@ParametersAreNonnullByDefault
@RequiredArgsConstructor
public class CategoryService {

    private static final int PAGE_SIZE = 20;

    @Nonnull
    private final CategoryRepository categoryRepository;
    @Nonnull
    private final UserRepository userRepository;
    @Nonnull
    private final TenantTagRepository tenantTagRepository;
    @Nonnull
    private final TenantServiceClient tenantServiceClient;
    @Nonnull
    private final UserServicePersistenceComponent userServicePersistenceComponent;
    @Nonnull
    private final CategorySchedulerServiceComponent categorySchedulerServiceComponent;
    @Nonnull
    private final CategoryEmailsServiceComponent categoryEmailsServiceComponent;
    @Nonnull
    private final MembershipEmailsServiceComponent membershipEmailsServiceComponent;
    @Nonnull
    private final ClockProvider clockProvider;
    @Nonnull
    private final MessagingBroker messagingBroker;
    @Nonnull
    private final MembershipService membershipService;

    @Nonnull
    public Category createCategory(TenantId tenantId, String name,
        @Nullable CategoryExpiration expiration,
        @Nullable BookingPrivilege bookingPrivilege,
        @Nullable Boolean allowSinglePaymentWhenPriceIsCustomized,
        @Nullable BigDecimal vatRate,
        @Nullable CategoryType categoryType,
        @Nullable Visibility visibility,
        @Nullable List<MembershipPrice> membershipPrices,
        @Nullable String description) {

        var tenant = tenantServiceClient.getById(tenantId.getValue());
        categoryRepository.findByTenantIdAndNameIgnoreCase(tenantId, name)
            .ifPresent(c -> {
                throw new CategoryWithThisNameAlreadyExistsException(name);
            });
        var bookingPrivilegeField = toField(bookingPrivilege);
        var expirationField = toField(expiration);

        CategoryDocument document =
            new CategoryDocument(CategoryId.valueOf(UUID.randomUUID().toString()),
                tenant.getTenantId(), name,
                expirationField, bookingPrivilegeField,
                allowSinglePaymentWhenPriceIsCustomized != null && allowSinglePaymentWhenPriceIsCustomized,
                vatRate, categoryType, null);

        document = categoryType == CategoryType.MEMBERSHIP ?
            createMembershipCategory(tenant, name, visibility, membershipPrices, description, document)
            : categoryRepository.save(document);

        Category category = toDomain(document);
        publishCategoryEvent(category, CategoryEventType.CATEGORY_CREATED);

        return category;
    }


    @Nonnull
    private CategoryDocument createMembershipCategory(Tenant tenant, String categoryName,
        @Nullable Visibility visibility, @Nullable List<MembershipPrice> membershipPrices, @Nullable String description,
        CategoryDocument document) {

        Assert.notNull(visibility, "Visibility must be defined for membership categories");
        Assert.notEmpty(membershipPrices, "Prices must be defined for membership categories");
        Assert.hasText(description, "Description must be defined for membership categories");

        MembershipProductId membershipProductId =
            MembershipProductId.valueOf(
                membershipService.createStripeProduct(tenant.getTenantId(), categoryName, description,
                    membershipPrices, tenant.getTenantName()));

        MembershipDetails membershipDetails = MembershipDetails.builder()
            .membershipProductId(membershipProductId)
            .visibility(visibility)
            .membershipPrices(membershipPrices)
            .description(description).build();

        document.setMembershipDetails(toField(membershipDetails));
        document.setCategoryType(CategoryType.MEMBERSHIP);

        try {
            return categoryRepository.save(document);
        } catch (Exception e) {
            //TODO evaluate if this should publish a kafka event instead of a synch http call
            membershipService.deleteMembershipProduct(membershipProductId);
            throw e;
        }
    }

    @Nonnull
    public Category updateCategory(CategoryId categoryId, String name, @Nullable CategoryExpiration expiration,
        @Nullable BookingPrivilege bookingPrivilege, Boolean allowSinglePaymentWhenPriceIsCustomized,
        @Nullable BigDecimal vatRate,  @Nullable Visibility visibility, @Nullable String description) {

        Category category = executeWithLock(
            () -> update(categoryId, name, expiration, bookingPrivilege, allowSinglePaymentWhenPriceIsCustomized, vatRate, visibility, description));
        publishCategoryEvent(category, CategoryEventType.CATEGORY_UPDATED);
        return category;
    }

    @Nonnull
    public Category getCategory(@Nonnull CategoryId categoryId) {
        return categoryRepository.findById(categoryId).map(this::toDomain).orElseThrow(() -> new CategoryNotFoundException(categoryId));
    }

    @Nonnull
    public Optional<Category> getCategory(TenantId tenantId, String categoryName) {
        return categoryRepository.findByTenantIdAndNameIgnoreCase(tenantId, categoryName).map(this::toDomain);
    }

    @Nonnull
    public Page<Category> findCategories(TenantId tenantId, @Nullable List<CategoryId> categoryIds,
        @Nullable String name, @Nullable CategoryType categoryType, @Nullable Visibility visibility, Pageable pageable) {
        Page<CategoryDocument> categories;
        if (name != null) {
            categories = categoryRepository.findByTenantIdAndNameLikeIgnoreCase(tenantId, name, pageable);
        } else if (categoryIds != null) {
            categories = categoryRepository.findByIdInAndTenantId(categoryIds, tenantId, pageable);
        } else if (categoryType != null) {
            categories = categoryRepository.findByCategoryTypeAndTenantId(categoryType, tenantId, pageable);
        } else if (visibility != null) {
           categories = categoryRepository.findByVisibilityAndTenantId(visibility, tenantId, pageable);
        } else {
            categories = categoryRepository.findByTenantId(tenantId, pageable);
        }
        return categories.map(this::toDomain);
    }


    @Nonnull
    public Page<Category> findActiveCategoriesForUser(@Nonnull UserId userId, @Nullable TenantId tenantId, Pageable pageable) {

        var user = userRepository.findById(UserLegacy.asSafeLong(userId)).orElseThrow(UserNotFoundException::new);
        var now = clockProvider.getClock().instant();

        List<TenantTagEntity> tagList =  tenantId == null ?
            user.getCategoryActiveAt(now) :
            user.getCategoryActiveAt(tenantId, now)
                .map(List::of)
                .orElse(Collections.emptyList());

        List<CategoryId> activeCategories = tagList
            .stream()
            .map(TenantTagEntity::getTag)
            .map(CategoryId::valueOf)
            .collect(Collectors.toList());

        return categoryRepository.findByIdIn(activeCategories, pageable).map(this::toDomain);

    }

    @Nonnull
    public List<Category> findCategoriesForUserActiveAt(@Nonnull UserId userId, @Nonnull TenantId tenantId, @Nonnull Instant date) {
        return getCategoryForUserActiveAt(userId, tenantId, date).map(List::of).orElse(Collections.emptyList());
    }

    @Nonnull
    public Optional<Category> getCategoryForUserActiveAt(@Nonnull UserId userId, @Nonnull TenantId tenantId, @Nonnull Instant date) {
        var user = userRepository.findById(UserLegacy.asSafeLong(userId)).orElseThrow(UserNotFoundException::new);
        return user.getCategoryActiveAt(tenantId, date).map(TenantTagEntity::getTag)
            .map(CategoryId::valueOf)
            .flatMap(categoryRepository::findById)
            .filter(CategoryDocument::isEnabled)
            .map(this::toDomain);
    }

    @Transactional
    public void addMemberToCategory(Tenant tenant, Category category, Long userId, @Nullable Instant expiresAt) {
        addMembersToCategory(category, List.of(new UserIdAndCategoryExpiration(userId, expiresAt)), () -> tenant);
    }

    @Transactional
    public void addMembersToCategory(CategoryId categoryId, @NotNull List<UserIdAndCategoryExpiration> membersAndExpirations) {
        var category = toDomain(getCategoryDocument(categoryId));
        if (category.isMembership()){
            throw new CategoryMembersUpdateRejectedException("Members can only be added to memberships when a user pays for it.");
        }
        addMembersToCategory(category, membersAndExpirations, () -> tenantServiceClient.getById(category.getTenantId().getValue()));
    }

    @Transactional
    public void updateMemberInCategory(Tenant tenant, Category category, Long userId, @Nullable Instant expiresAt) {
        var map = new HashMap<Long, Instant>();
        map.put(userId, expiresAt);
        verifyUserIdAndCategoryExpiration(category, List.of(new UserIdAndCategoryExpiration(userId, expiresAt)));
        updateMembersInCategory(category, map, () -> tenant);
    }

    @Transactional
    public void updateMembersInCategory(CategoryId categoryId, @NotNull List<UserIdAndCategoryExpiration> membersAndExpirations)
        throws TenantNotFoundException {
        var userIdAndExpiresAt = toUserIdExpiresAtMap(membersAndExpirations);
        var category = getCategoryDocument(categoryId);
        verifyUserIdAndCategoryExpiration((toDomain(category)), membersAndExpirations);
        updateMembersInCategory(toDomain(category), userIdAndExpiresAt, () -> tenantServiceClient.getById(category.getTenantId().getValue()));
    }

    private void updateMembersInCategory(Category category, Map<Long, Instant> userIdAndExpiresAt, Supplier<Tenant> function) {
        var users = userRepository.findAllById(userIdAndExpiresAt.keySet());
        var now = clockProvider.getClock().instant();
        var tenant = function.get();
        ZoneId zoneId = tenant.getTenantAddress().getZoneId();

        StreamSupport.stream(users.spliterator(), false)
                     .map(userEntity -> userEntity.getCategoryActiveAt(category.getTenantId(), now))
                     .filter(Optional::isPresent)
                     .map(Optional::get)
                     .forEach(c -> {
                         Instant adjustedExpiresAt = toInstantAtEndOfLocalDay(userIdAndExpiresAt.get(c.getUser().getId()), zoneId);
                         c.setExpiresAt(adjustedExpiresAt);
                         //pedroserro replace the value of expiresAt by adjusted one for later user in scheduleMemberExpirationTasks
                         userIdAndExpiresAt.put(c.getUser().getId(), adjustedExpiresAt);
                     });

        categorySchedulerServiceComponent.scheduleMemberExpirationTasks(Lists.newArrayList(users), userIdAndExpiresAt, category, tenant);
    }

    @Transactional
    public void removeMemberFromCategory(Tenant tenant, CategoryId categoryId, long userId) {
        var categoryDocument = getCategoryDocument(categoryId);
        removeMembersFromCategory(categoryDocument, List.of(userId), () -> tenant);
    }

    @Transactional
    public void removeMembersFromCategory(CategoryId categoryId, @Nullable List<Long> userIds) {
        var categoryDocument = getCategoryDocument(categoryId);
        if(categoryDocument.isMembership()){
            if(userIds == null || userIds.size() != 1){
                throw new CategoryMembersUpdateRejectedException("We only allow to remove a membership for one customer at a time.");
            }
            membershipService.cancelMembershipSubscriptions(userIds.get(0), categoryDocument.getMembershipDetails().getMembershipProductId());
            // To remove a user from a membership category the subscription from stripe must be
            // cancelled first so we wait for the MEMBERSHIP_SUBSCRIPTION_CANCELLED to remove the
            // user from the category.
            return;
        }

        removeMembersFromCategory(categoryDocument, userIds, () -> tenantServiceClient.getById(categoryDocument.getTenantId().getValue()));
    }

    private void removeMembersFromCategory(CategoryDocument categoryDocument, @Nullable List<Long> userIds, Supplier<Tenant> tenantSupplier) {
        var tenant = tenantSupplier.get();
        var categoryName = categoryDocument.getName();
        if (userIds == null) {
            var tag = categoryDocument.getId().toString();
            var membersCount = membersCount(categoryDocument.getId());
            var pages = (int) membersCount / PAGE_SIZE + 1;

            // Here we do not check if category is membership because it is not expected to be - if that changes, we need to send different emails
            Stream.iterate(0, i -> i + 1)
                .limit(pages)
                .map(pageNumber -> PageRequest.of(pageNumber, PAGE_SIZE))
                .map(request -> tenantTagRepository.deleteAllByTagAndType(tag, Type.ANEMONE_CATEGORY, request))
                .forEach(tagEntities -> categoryEmailsServiceComponent.sendCategoryRemovedEmails(tagEntities, categoryName, tenant));
        } else if (!userIds.isEmpty()) {
            removeMembersFromCategory(userIds, tenant, categoryName, categoryDocument.getId(), categoryDocument.isMembership());
        }
    }

    private void removeMembersFromCategory(List<Long> userIds, Tenant tenant, String categoryName, CategoryId categoryId, boolean categoryIsMembership) {
        var tenantTagEntities = tenantTagRepository.deleteAllByTagAndTypeAndUserIdIn(categoryId.toString(), Type.ANEMONE_CATEGORY, userIds);

        if (categoryIsMembership) {
            membershipEmailsServiceComponent.sendMembershipRemovedEmails(tenantTagEntities, categoryName, tenant);
        } else {
            categoryEmailsServiceComponent.sendCategoryRemovedEmails(tenantTagEntities, categoryName, tenant);
        }
    }

    @Nonnull
    public Category updateCategory(CategoryId categoryId, PatchCategory patchCategory) {
        Category category = executeWithLock(() -> update(getCategoryDocument(categoryId), patchCategory));
        publishCategoryEvent(category, CategoryEventType.CATEGORY_UPDATED);
        return category;
    }

    @Nonnull
    private CategoryDocument update(CategoryDocument categoryDocument, PatchCategory patchCategory) {

        if (patchCategory.getStatus() != null) {
            changeStatus(categoryDocument, patchCategory.getStatus());
        }

        if (patchCategory.getPricingType() != null && categoryDocument.getPricingType() == null) {
            categoryDocument.setPricingType(patchCategory.getPricingType());
        }

        if (patchCategory.getAllowSinglePaymentWhenPriceIsCustomized() != null) {
            categoryDocument.setAllowSinglePaymentWhenPriceIsCustomized(patchCategory.getAllowSinglePaymentWhenPriceIsCustomized());
        }

        if(patchCategory.getMembershipDetails() != null){
            Visibility newVisibility = patchCategory.getMembershipDetails().getVisibility();
            String newDescription = patchCategory.getMembershipDetails().getDescription();

            if (newVisibility != null) {
                changeMembershipVisibility(categoryDocument, newVisibility);
            }
            if (newDescription != null) {
                changeMembershipDescription(categoryDocument, newDescription);
            }
        }

        return categoryRepository.save(categoryDocument);
    }

    public void sendExpirationReminders(CategoryId categoryId, MemberTaskDetails task) throws TenantNotFoundException {
        var tenant = tenantServiceClient.getById(task.getTenantId());
        tenantTagRepository
            .findByTenantIdAndUserIdAndTag(task.getTenantId(), Long.valueOf(task.getUserId()), categoryId.getValue().toString())
            // pedroserro: this is a safeguard to prevent reminder being sent in case the expire date has changed in the meantime between the creation of the task and it's execution
            .filter(tag -> tag.getExpiresAt() != null)
            .filter(tag -> tag.getExpiresAt().truncatedTo(ChronoUnit.SECONDS).equals(task.getExpiresAt().truncatedTo(ChronoUnit.SECONDS)))
            .ifPresent(tag -> categoryEmailsServiceComponent
                .sendExpirationReminderEmail(tag.getUser(), task.getCategoryName(), task.getExpiresAt(), tenant));
    }

    public void deleteExpiredMembers(CategoryId categoryId, MemberTaskDetails task) throws TenantNotFoundException {
        var tenant = tenantServiceClient.getById(task.getTenantId());
        tenantTagRepository
            .findByTenantIdAndUserIdAndTag(task.getTenantId(), Long.valueOf(task.getUserId()), categoryId.getValue().toString())
            // pedroserro: this is a safeguard to prevent deletion in case expire date has changed in the meantime between the creation of the task and it's execution
            .filter(tag -> tag.getExpiresAt() != null)
            //pedroserro: The shortest duration of a member in a category is one day. Only need to check if it is the same day.
            .filter(tag -> tag.getExpiresAt().truncatedTo(ChronoUnit.DAYS).equals(task.getExpiresAt().truncatedTo(ChronoUnit.DAYS)))
            .filter(tag -> !tag.isActiveAt(clockProvider.getClock().instant()))
            .ifPresent(tag -> {
                tenantTagRepository.deleteById(tag.getId());
                // Here we do not check if category is membership because it is not expected to be - if that changes, we need to send different emails
                categoryEmailsServiceComponent.sendCategoryRemovedEmails(List.of(tag), task.getCategoryName(), tenant);
            });
    }

    @Nonnull
    public Category getCategoryByMembershipProductId(MembershipProductId membershipProductId) {
        return categoryRepository.findByMembershipProductId(membershipProductId).map(this::toDomain)
            .orElseThrow(() -> new CategoryNotFoundException(membershipProductId));
    }

    @Transactional
    public void addMemberToMembership(@Nonnull String userId, @Nonnull String membershipProductId) {
        var category = getCategoryByMembershipProductId(MembershipProductId.valueOf(membershipProductId));
        var tenant = tenantServiceClient.getById(category.getTenantId().getValue());

        addMemberToCategory(tenant, category, UserLegacy.asSafeLong(UserId.valueOf(userId)), null);
    }

    @Transactional
    public void removeMemberFromMembership(@Nonnull String userId, @Nonnull String membershipProductId) {
        var category = getCategoryByMembershipProductId(MembershipProductId.valueOf(membershipProductId));
        var tenant = tenantServiceClient.getById(category.getTenantId().getValue());

        removeMemberFromCategory(tenant, category.getId(), UserLegacy.asSafeLong(UserId.valueOf(userId)));
    }

    private boolean hasMembers(CategoryId categoryId) {
        return membersCount(categoryId) != 0;
    }

    private long membersCount(CategoryId categoryId) {
        return tenantTagRepository.countByTagAndType(categoryId.getValue().toString(), Type.ANEMONE_CATEGORY);
    }

    private void changeStatus(CategoryDocument categoryDocument, Status status) {
        if (categoryDocument.isMembership()) {
            throw new CategoryUpdateRejectedException("Status cannot be changed for membership categories");
        }

        if (Status.DISABLED == status && hasMembers(categoryDocument.getId())) {
            throw new CategoryCannotBeDisabledException(categoryDocument.getId());
        }
        categoryDocument.setStatus(status);
    }

    @Nonnull
    private CategoryDocument getCategoryDocument(CategoryId categoryId) {
        return categoryRepository.findById(categoryId).orElseThrow(() -> new CategoryNotFoundException(categoryId));
    }

    @Nonnull
    private HashMap<Long, Instant> toUserIdExpiresAtMap(@Nonnull List<UserIdAndCategoryExpiration> membersAndExpirations) {
        var userIdsAndExpiresAt = new HashMap<Long, Instant>();
        membersAndExpirations.forEach(u -> userIdsAndExpiresAt.put(u.getUserId(), u.getExpiresAt()));
        return userIdsAndExpiresAt;
    }

    @Nullable
    private CategoryExpirationField toField(@Nullable CategoryExpiration expiration) {
        return Optional.ofNullable(expiration)
            .map(e -> new CategoryExpirationField(e.getUnit(), e.getValue())).orElse(null);
    }

    @Nullable
    private BookingPrivilegeField toField(@Nullable BookingPrivilege privilege) {
        return Optional.ofNullable(privilege)
            .map(p -> new BookingPrivilegeField(p.getDaysOfBookingAhead(), p.getMaxNumberOfActiveBookings(), p.getMaxNumberOfBookingsPerDay(),
                p.getCancellationPolicyDuration()))
            .orElse(null);
    }

    @Nullable
    private MembershipDetailsField toField(@Nullable MembershipDetails privilege) {
        return Optional.ofNullable(privilege)
            .map(membershipDetails -> new MembershipDetailsField(
                membershipDetails.getMembershipProductId(), membershipDetails.getVisibility(),
                membershipDetails.getDescription(), membershipDetails.getMembershipPrices()))
            .orElse(null);
    }


    @Nonnull
    private Category toDomain(CategoryDocument doc) {
        var customers = membersCount(doc.getId());
        var expiration = toDomain(doc.getExpiration());
        var bookingPrivilege = toDomain(doc.getBookingPrivilege());
        return new Category(doc.getId(), doc.getTenantId(), doc.getName(), doc.getStatus(), expiration, bookingPrivilege, customers,
            doc.getPricingType(), doc.isAllowSinglePaymentWhenPriceIsCustomized(), doc.getVatRate(), doc.getCategoryType(),
            toDomain(doc.getMembershipDetails()));
    }

    @Nullable
    private BookingPrivilege toDomain(@Nullable BookingPrivilegeField field) {
        return Optional.ofNullable(field)
            .map(p -> new BookingPrivilege(p.getDaysOfBookingAhead(), p.getMaxNumberOfActiveBookings(), p.getMaxNumberOfBookingsPerDay(),
                p.getCancellationPolicy()))
            .orElse(null);
    }

    @Nullable
    private CategoryExpiration toDomain(@Nullable CategoryExpirationField field) {
        return Optional.ofNullable(field)
            .map(e -> new CategoryExpiration(e.getUnit(), e.getValue()))
            .orElse(null);
    }

    @Nullable
    private MembershipDetails toDomain(@Nullable MembershipDetailsField field) {
        return Optional.ofNullable(field)
            .map(membershipDetailsField -> new MembershipDetails(
                membershipDetailsField.getMembershipProductId(),
                membershipDetailsField.getVisibility(), membershipDetailsField.getDescription(),
                membershipDetailsField.getMembershipPrices()))
            .orElse(null);
    }

    @Nonnull
    private CategoryDocument update(CategoryId categoryId, String name, @Nullable CategoryExpiration expiration,
        @Nullable BookingPrivilege bookingPrivilege, Boolean allowSinglePaymentWhenPriceIsCustomized,
        @Nullable BigDecimal vatRate, @Nullable Visibility visibility,  @Nullable String description) {

        var document = getCategoryDocument(categoryId);

        categoryRepository.findByTenantIdAndNameIgnoreCase(document.getTenantId(), name)
            .filter(c -> !c.getId().equals(categoryId))
            .ifPresent(c -> {
                throw new CategoryWithThisNameAlreadyExistsException(name);
            });
        var bookingPrivilegeField = toField(bookingPrivilege);
        var expirationField = toField(expiration);

        validateExpirationUpdate(document, expirationField);
        changeMembershipVisibility(document, visibility);
        changeMembershipDescription(document, description);

        document.update(name, expirationField, bookingPrivilegeField, allowSinglePaymentWhenPriceIsCustomized, vatRate);

        return categoryRepository.save(document);
    }

    private void validateExpirationUpdate(CategoryDocument categoryDocument, @Nullable CategoryExpirationField expirationField) {
        if(categoryDocument.isMembership() && expirationField != null){
            throw new CategoryUpdateRejectedException("Category expiration default cannot be update for membership categories");
        }
    }

    private void changeMembershipVisibility(CategoryDocument categoryDocument, @Nullable Visibility visibility) {
        if(categoryDocument.isSimple() && visibility != null){
            throw new CategoryUpdateRejectedException("Visibility cannot be set or updated in simple categories");
        }

        if(categoryDocument.isMembership()) {
            if (visibility == null) {
                throw new CategoryUpdateRejectedException(
                    "Visibility cannot be null for membership categories");
            }

            if (categoryDocument.getMembershipDetails() == null) {
                throw new CategoryUpdateRejectedException(
                    "Categories of type membership must have non null membership details");
            }
            categoryDocument.getMembershipDetails().setVisibility(visibility);
        }
    }

    private void changeMembershipDescription(CategoryDocument categoryDocument, @Nullable String description) {
        if(categoryDocument.isSimple() && description != null){
            throw new CategoryUpdateRejectedException("Description cannot be set or updated in simple categories");
        }
        if (categoryDocument.isMembership()) {
            if (description == null || description.isEmpty()) {
                throw new CategoryUpdateRejectedException(
                    "Description cannot be null or empty for membership categories");
            }

            if (categoryDocument.getMembershipDetails() == null) {
                throw new CategoryUpdateRejectedException(
                    "Categories of type membership must have non null membership details");
            }
            categoryDocument.getMembershipDetails().setDescription(description);

            membershipService.updateMembershipProduct(categoryDocument.getMembershipDetails().getMembershipProductId(), description);
        }
    }

    @Nonnull
    private Category executeWithLock(OptimisticLockingRetryableExecutor.OptimisticLockingRetryableAction<CategoryDocument> action) {
        var executor = new OptimisticLockingRetryableExecutor<>(action, 5);
        return toDomain(executor.execute());
    }

    private void addMembersToCategory(Category category, List<UserIdAndCategoryExpiration> membersAndExpirations, Supplier<Tenant> tenantSupplier) {

        verifyUserIdAndCategoryExpiration(category, membersAndExpirations);

        var userIdAndExpiresAt = toUserIdExpiresAtMap(membersAndExpirations);
        if (category.isDisabled()) {
            throw new CategoryIsDisabledException(category.getId());
        }
        var users = userRepository.findAllById(userIdAndExpiresAt.keySet());
        var tenant = tenantSupplier.get();
        ZoneId zoneId = tenant.getTenantAddress().getZoneId();

        users.forEach(user -> {
            var now = clockProvider.getClock().instant();
            if (category.isMembership() && !user.hasLinkedAccount(category.getTenantId())) {
                UserId userId = UserId.valueOf(user.getId().toString());
                userServicePersistenceComponent.linkTenant(userId, tenant, MerchantUserId.valueOf(userId.getValue()), null);
            }
            user.checkIfCategoryCanBeAddedForTenant(category.getTenantId(), now);

            Instant adjustedExpiresAt = toInstantAtEndOfLocalDay(userIdAndExpiresAt.get(user.getId()), zoneId);
            user.addCategory(category, adjustedExpiresAt);
            //pedroserro replace the value of expiresAt by adjusted one for later user in scheduleMemberExpirationTasks
            userIdAndExpiresAt.put(user.getId(), adjustedExpiresAt);
            }
        );

        if (category.isMembership()) {
            membershipEmailsServiceComponent.sendNewMemberEmail(Lists.newArrayList(users), category.getName(), tenant);
        } else {
            categoryEmailsServiceComponent.sendNewMemberEmail(Lists.newArrayList(users), category.getName(), tenant);
        }

        categorySchedulerServiceComponent.scheduleMemberExpirationTasks(Lists.newArrayList(users), userIdAndExpiresAt, category, tenant);
    }

    private void verifyUserIdAndCategoryExpiration(Category category, List<UserIdAndCategoryExpiration> membersAndExpirations){
        if(category.isMembership()){
            membersAndExpirations.stream()
                .map(UserIdAndCategoryExpiration::getExpiresAt)
                .filter(Objects::nonNull)
                .findAny()
                .ifPresent(instant -> {throw new CategoryMembersUpdateRejectedException("Expiration date cannot be set for members of category of type MEMBERSHIP");});
        }
    }

    private void publishCategoryEvent(Category category, CategoryEventType eventType) {
        messagingBroker.sendEvent(CategoryEvent.builder()
            .eventType(eventType)
            .category(category)
            .build());
    }

    @Transactional
    public void deleteAllExpiredMembers() {
        tenantTagRepository.deleteAllByExpiresAtIsBefore(clockProvider.getClock().instant());
    }

    @Nullable
    private Instant toInstantAtEndOfLocalDay(@Nullable Instant categoryExpiresAt, @Nonnull ZoneId zoneId) {
        if(categoryExpiresAt == null){
            return null;
        }

        var date = categoryExpiresAt.atZone(zoneId).toLocalDate();
        var endOfTheDay = LocalDateTime.of(date, LocalTime.MAX);
        return endOfTheDay.atZone(zoneId).toInstant().truncatedTo(ChronoUnit.SECONDS);
    }
}

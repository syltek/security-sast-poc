package com.playtomic.anemone.user.domain.userimports;

import com.playtomic.anemone.domain.generic.AbstractUuidId;

import java.util.UUID;
import javax.annotation.Nonnull;

public class UserImportId extends AbstractUuidId {

    protected UserImportId(@Nonnull String id) {
        super(id);
    }

    protected UserImportId(@Nonnull UUID id) {
        super(id);
    }

    public static UserImportId valueOf(String id) {
        return new UserImportId(id);
    }

    public static UserImportId valueOf(UUID id) {
        return new UserImportId(id);
    }

}

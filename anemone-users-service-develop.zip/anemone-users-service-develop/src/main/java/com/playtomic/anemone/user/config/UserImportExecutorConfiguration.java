package com.playtomic.anemone.user.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "anemone.user-imports.executor")
public class UserImportExecutorConfiguration {

    @Getter
    @Setter
    private int threads = 2;

}

package com.playtomic.anemone.user.config;

import com.google.common.collect.ImmutableMap;
import java.util.Map;
import javax.annotation.Nonnull;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Data
@Configuration
@ConfigurationProperties(prefix = "anemone.cloudinary")
public class CloudinaryConfiguration {

    private String cloudName;
    private String apiKey;
    private String apiSecret;
    private String rootFolder;

    public void setRootFolder(@Nonnull String rootFolder) {
        this.rootFolder = folderForCloudinary(rootFolder);
    }

    @Nonnull
    public Map toMap() {
        return ImmutableMap.of("cloud_name", cloudName, "api_key", apiKey, "api_secret", apiSecret, "secure", "true");
    }

    @Nonnull
    public static String folderForCloudinary(@Nonnull String folder) {
        return folder.replaceFirst("^/", "").replaceFirst("/$", "");
    }
}


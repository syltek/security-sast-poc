package com.playtomic.anemone.category.service;

import com.playtomic.anemone.category.domain.MembershipPrice;
import com.playtomic.anemone.category.domain.MembershipProductId;
import com.playtomic.anemone.category.service.exception.StripeProductCreationFailedException;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import com.playtomic.anemone.user.service.anemone.CreateProductBody;
import com.playtomic.anemone.user.service.anemone.DeleteMembershipSubscriptionBody;
import com.playtomic.anemone.user.service.anemone.PutMembershipProductBody;
import com.playtomic.anemone.user.service.anemone.SubscriptionsServiceClient;
import java.util.List;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class MembershipService {

    @Nonnull
    private final SubscriptionsServiceClient subscriptionsServiceClient;

    @Nonnull
    public String createStripeProduct(@Nonnull TenantId tenantId, @Nonnull String name, @Nullable String description,
        @Nonnull List<MembershipPrice> membershipPrices, @Nonnull String tenantName) {
        String membershipProductId;
        CreateProductBody body = new CreateProductBody(name, description, tenantId.toString(), tenantName,
            membershipPrices);

        try {
            membershipProductId = subscriptionsServiceClient.createMembershipProduct(body);
        } catch (Exception e) {
            log.error("Stripe product creation in subscriptions service failed", e);
            throw new StripeProductCreationFailedException(name);
        }
        return membershipProductId;
    }

    public void deleteMembershipProduct(@Nonnull MembershipProductId membershipProductId) {
        subscriptionsServiceClient.deleteMembershipProduct(membershipProductId.toString());
    }

    public void cancelMembershipSubscriptions(@Nonnull Long userId, @Nonnull MembershipProductId membershipProductId) {
        subscriptionsServiceClient.deleteMembershipSubscription(new DeleteMembershipSubscriptionBody(String.valueOf(userId),
                membershipProductId.toString()));
    }

    public void updateMembershipProduct(@Nonnull MembershipProductId membershipProductId, @Nonnull String description) {
        subscriptionsServiceClient.updateMembershipProduct(membershipProductId.toString(),
            PutMembershipProductBody.builder().description(description).build());
    }
}

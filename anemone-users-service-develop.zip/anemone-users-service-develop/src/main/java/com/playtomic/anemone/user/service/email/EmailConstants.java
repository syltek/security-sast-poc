package com.playtomic.anemone.user.service.email;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class EmailConstants {

    public static final String LOCALE_KEY = "locale";
    public static final String SUBJECT_KEY = "subject";
    public static final String TITLE_KEY = "title";
    public static final String MESSAGE_KEY = "message";
    public static final String BUTTON_LABEL_KEY = "buttonLabel";
    public static final String BUTTON_URL = "buttonUrl";


}

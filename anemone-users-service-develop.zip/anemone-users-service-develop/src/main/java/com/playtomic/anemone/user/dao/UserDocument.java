package com.playtomic.anemone.user.dao;

import com.playtomic.anemone.dao.BaseDocument;
import javax.annotation.Nonnull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection = "users")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserDocument extends BaseDocument {

    @Id
    @Field("user_id")
    private String userId;

    @Field("game_preferences")
    @Nonnull
    private UserGamePreferencesField gamePreferencesField;
}

package com.playtomic.anemone.user.domain.wallet;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.javamoney.moneta.Money;

@Data
@ToString
@NoArgsConstructor
public class Wallet {

    @JsonProperty(value = "wallet_id")
    @Nonnull
    private WalletId walletId;

    @JsonProperty(value = "user_id")
    @Nonnull
    private Long userId;

    @JsonProperty(value = "name")
    @Nullable
    private String name;

    @JsonProperty(value = "balance")
    @Nonnull
    private Money balance;

    @JsonProperty(value = "active")
    private boolean active;

    @JsonCreator
    public Wallet(
        @JsonProperty(value = "wallet_id", required = true) @Nonnull WalletId walletId,
        @JsonProperty(value = "user_id", required = true) @Nonnull Long userId,
        @JsonProperty(value = "name") @Nullable String name,
        @JsonProperty(value = "balance", required = true) @Nonnull Money balance,
        @JsonProperty(value = "active", required = true) boolean active) {
        this.walletId = walletId;
        this.name = name;
        this.balance = balance;
        this.active = active;
        this.userId = userId;
    }
}

package com.playtomic.anemone.user.domain.validation.validator;

import com.playtomic.anemone.user.domain.PasswordValidator;
import com.playtomic.anemone.user.domain.validation.annotation.Password;
import com.playtomic.anemone.user.domain.validation.constants.PasswordValidationMode;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

@ParametersAreNonnullByDefault
public class PasswordConstraintValidator implements ConstraintValidator<Password, String> {

  @Nullable
  private PasswordValidationMode mode;

  @Override
  public void initialize(Password constraintAnnotation) {
    mode = constraintAnnotation.mode();
  }

  @Override
  public boolean isValid(@Nullable String password, ConstraintValidatorContext context) {
    PasswordValidator.validate(password, mode);
    return true;
  }
}

package com.playtomic.anemone.user.domain;

import java.util.Optional;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import org.apache.commons.lang3.StringUtils;

/**
 * A class to validate phones
 */
public class PhoneValidator {
    private static final String REGEX_SPACE = "(\\s|\\u00a0)";
    private static final String REGEX_PREFIX = "^\\+([0-9]+)" + REGEX_SPACE;
    private static final String REGEX_PHONE_WITH_PREFIX = REGEX_PREFIX + "([0-9]+)$";
    private static final String REGEX_NUMBERS = "^[0-9]+$";

    private PhoneValidator() {
    }

    public static boolean isValid(@Nullable String phone) {
        if (phone == null) {
            return true;
        }
        return phone.matches(REGEX_PHONE_WITH_PREFIX + "|" + REGEX_NUMBERS + "|^$");
    }

    public static boolean checkInternationalPrefix(@Nonnull String phone) {
        return phone.matches(REGEX_PREFIX + ".*");
    }

    public static Optional<String> formattedPhone(@Nonnull String phone, @Nullable String defaultPhoneCountryCode) {
        // Replace common symbols by spaces
        phone = phone.replace("-", " ")
                .replace("(", " ")
                .replace(")", " ");

        // Replace phone starting with 00 by +
        if (phone.startsWith("00")) {
            phone = phone.replaceFirst("00", "+");
        }

        String prefix = getPhoneCountryCode(phone).orElse(defaultPhoneCountryCode);
        if (prefix == null) {
            return Optional.empty();
        }

        // Remove the prefix and all white spaces
        phone = phone.replace(prefix, "").replaceAll(REGEX_SPACE, "");

        if (!isValid(phone)) {
            return Optional.empty();
        }

        if (StringUtils.isNoneEmpty(phone)) {
            phone = prefix + " " + phone;
        }
        return Optional.of(phone);
    }

    public static Optional<String> getPhoneCountryCode(@Nonnull String phone) {
        return checkInternationalPrefix(phone) ? Optional.of(phone.split(REGEX_SPACE)[0]) : Optional.empty();
    }
}

package com.playtomic.anemone.user.dao;

import com.playtomic.anemone.category.domain.CategoryId;
import com.playtomic.anemone.dao.BaseStringUuidEntity;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "tenant_tag")
@Access(AccessType.FIELD)
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class TenantTagEntity extends BaseStringUuidEntity {

    public TenantTagEntity(@Nonnull UserEntity userEntity, @Nonnull String tag, @Nonnull TenantId tenantId, @Nullable Type type,
        @Nullable Instant expiresAt) {
        this(userEntity, tag, tenantId.getValue(), type, truncateInstantToSeconds(expiresAt));
    }
    public TenantTagEntity(@Nonnull UserEntity userEntity, @Nonnull String tag, @Nonnull TenantId tenantId) {
        this(userEntity, tag, tenantId, null, null);
    }

    public enum Type {
        ANEMONE_CATEGORY
    }

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    @Nonnull
    private UserEntity user;

    @Column(name = "tag", nullable = false)
    @Nonnull
    private String tag;

    @Column(name = "tenant_id", nullable = false)
    @Nonnull
    private String tenantId;

    @Column(name = "type")
    @Nullable
    private Type type;

    @Column(name = "expires_at")
    @Nullable
    private Instant expiresAt;

    public void setExpiresAt(@Nullable Instant date) {
        this.expiresAt = truncateInstantToSeconds(date);
    }

    public boolean isActiveAt(@Nonnull Instant date) {
        return this.expiresAt == null || this.expiresAt.isAfter(date);
    }

    public boolean isAnemoneCategory() {
        return Type.ANEMONE_CATEGORY == this.type;
    }

    public boolean isSameTag(@Nonnull CategoryId categoryId){
       return this.getTag().equals(categoryId.toString());
    }

    public boolean isForTenant(@Nonnull TenantId tenantId){
        return this.getTenantId().equals(tenantId.toString());
    }

    @Nullable
    private static Instant truncateInstantToSeconds(@Nullable Instant instant){
        //pedroserro: the DB is rounding to seconds keep the precision in seconds
        return instant != null ? instant.truncatedTo(ChronoUnit.SECONDS) : null;
    }
}

package com.playtomic.anemone.user.domain.permissions;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import com.playtomic.anemone.user.model.permissions.PermissionLevel;
import com.playtomic.anemone.user.model.permissions.PermissionName;

import lombok.Getter;

import java.util.EnumMap;
import javax.annotation.Nonnull;

@Getter
public class Permission {

    @Nonnull
    @JsonProperty("tenant_id")
    private final TenantId tenantId;

    @Nonnull
    @JsonProperty("permissions")
    private final EnumMap<PermissionName, PermissionLevel> permissions;

    @JsonCreator
    public Permission(@JsonProperty(value = "tenant_id", required = true) @Nonnull TenantId tenantId,
                      @JsonProperty(value = "permissions", required = true) @Nonnull EnumMap<PermissionName, PermissionLevel> permissions) {
        this.tenantId = tenantId;
        this.permissions = permissions;
    }

}

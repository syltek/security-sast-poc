package com.playtomic.anemone.user.service.anemone;

import com.playtomic.anemone.http.AnemoneRestTemplateFactory;
import com.playtomic.anemone.jwt.JwtTokenFactory;
import com.playtomic.anemone.service.AbstractRemoteRestService;
import com.playtomic.anemone.spring.AnemoneAuthenticationCredentialsAccessor;
import com.playtomic.anemone.spring.AnemoneAuthenticationHeaderClientHttpRequestInterceptor;
import com.playtomic.anemone.spring.AuthenticationCredentialsAccessor;
import com.playtomic.anemone.user.domain.tenant.Tenant;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import com.playtomic.anemone.user.service.exception.TenantNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import javax.annotation.Nonnull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@Service
@Slf4j
public class TenantServiceClient extends AbstractRemoteRestService {

    @Nonnull
    private AuthenticationCredentialsAccessor authenticationCredentialsAccessor;

    public TenantServiceClient(@Nonnull MessageSource messageSource,
                          @Nonnull DiscoveryClient discoveryClient,
                          @Nonnull AnemoneRestTemplateFactory restTemplateFactory,
                          @Nonnull JwtTokenFactory jwtTokenFactory) {
        super(messageSource, discoveryClient, restTemplateFactory);
        this.authenticationCredentialsAccessor = new AnemoneAuthenticationCredentialsAccessor(jwtTokenFactory);
    }

    @Override
    protected void configureRestTemplate(RestTemplate rest) {
        rest.getInterceptors().add(new AnemoneAuthenticationHeaderClientHttpRequestInterceptor(authenticationCredentialsAccessor));
    }

    @Nonnull
    public Tenant getById(@Nonnull TenantId tenantId) {
        return getById(tenantId.getValue());
    }

    @Nonnull
    public Tenant getById(@Nonnull String tenantId) throws TenantNotFoundException, RestClientException {

        String endpoint = getEndpoint(AnemoneServices.TENANTS_SERVICE, "/v1/tenants");

        try {
            return restTemplate().getForObject(endpoint + "/" + tenantId, Tenant.class);
        } catch (HttpStatusCodeException e) {
            if (e.getStatusCode() == HttpStatus.NOT_FOUND) {
                log.warn("Tenant not found in anemone-tenants: ", tenantId);
                throw new TenantNotFoundException(tenantId);
            }
            throw new RestClientException("Error reading tenant", e);
        }
    }

    public Optional<TenantCommunicationSettings> getTenantCommunicationSettings(@Nonnull TenantId tenantId) {
        String endpoint = getEndpoint(AnemoneServices.TENANTS_SERVICE, "/v1/tenants");
        try {
            TenantCommunicationSettings response = restTemplate()
                .getForObject(endpoint + "/" + tenantId + "/communications", TenantCommunicationSettings.class);
            return Optional.ofNullable(response);
        } catch (HttpStatusCodeException e) {
            throw new RestClientException("Error reading tenant", e);
        }
    }

    @Nonnull
    public List<Tenant> getByIds(@Nonnull List<String> tenantIds) {
        String endpoint = getEndpoint(AnemoneServices.TENANTS_SERVICE, "/v1/tenants");

        try {
            Tenant[] tenants = restTemplate().getForObject(endpoint + "?tenant_id=" + String.join(", ",tenantIds) , Tenant[].class);
            return tenants != null ? new ArrayList<>(Arrays.asList(tenants)) : new ArrayList<>();

        } catch (HttpStatusCodeException e) {
            throw new RestClientException("Error reading tenants", e);
        }
    }
}

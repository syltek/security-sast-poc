package com.playtomic.anemone.user.service.messaging;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.user.domain.UserProfile;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

import javax.annotation.Nonnull;

@ToString
@Getter
@AllArgsConstructor
public class UserEvent {

    public enum UserEventType {
        UPDATED
    }

    @JsonProperty(value = "event_type", required = true)
    @Nonnull
    private UserEventType eventType;

    @JsonProperty(value = "event_data", required = true)
    @Nonnull
    private UserProfile data;

    @JsonIgnore
    @Nonnull
    public String getKey() {
        return data.getId().toString();
    }
}

package com.playtomic.anemone.user.domain.tenant;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import javax.annotation.Nonnull;
import lombok.Data;

@Data
public class ReservationTenant {

    @JsonProperty(value = "tenant_id")
    @Nonnull
    private TenantId tenantId;

    @JsonCreator
    public ReservationTenant(
        @JsonProperty(value = "tenant_id", required = true) @Nonnull TenantId tenantId
        ) {
        this.tenantId = tenantId;
    }

}

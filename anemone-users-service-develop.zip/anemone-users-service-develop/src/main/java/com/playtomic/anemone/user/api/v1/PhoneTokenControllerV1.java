package com.playtomic.anemone.user.api.v1;

import com.playtomic.anemone.Constants;
import com.playtomic.anemone.user.api.request.PhoneTokenRequestBody;
import com.playtomic.anemone.user.api.response.PhoneTokenResponseBody;
import com.playtomic.anemone.user.config.SecurityConfig;
import com.playtomic.anemone.user.domain.PhoneValidator;
import com.playtomic.anemone.user.service.UserCredentialService;
import com.playtomic.anemone.user.service.exception.InvalidPhoneException;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Nonnull;

/**
 * Authentication is performed via Filters and Spring Security modules. <p> This controller is intended to check whether
 * the user is authorized or not, which roles are assigned, when the session expires...
 * @see SecurityConfig
 */
@RestController
@RequestMapping(path = "/v1/phone_tokens")
public class PhoneTokenControllerV1 {

    @Nonnull
    private UserCredentialService userCredentialService;

    public PhoneTokenControllerV1(@Nonnull UserCredentialService userCredentialService) {
        this.userCredentialService = userCredentialService;
    }

    @PreAuthorize("hasAnyAuthority('admin_users')")
    @RequestMapping(method = RequestMethod.POST, consumes = Constants.CONSUMES_JSON)
    public ResponseEntity createPhoneToken(@RequestBody PhoneTokenRequestBody body) {
        String phone = PhoneValidator.formattedPhone(body.getPhone(), null)
                .orElseThrow(() -> new InvalidPhoneException(body.getPhone()));
        String token = userCredentialService.hashPhone(phone);
        return ResponseEntity.ok(new PhoneTokenResponseBody(token));
    }

}

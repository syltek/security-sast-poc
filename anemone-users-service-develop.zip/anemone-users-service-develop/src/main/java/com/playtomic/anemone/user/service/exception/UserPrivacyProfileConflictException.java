package com.playtomic.anemone.user.service.exception;

public class UserPrivacyProfileConflictException extends RuntimeException {

}

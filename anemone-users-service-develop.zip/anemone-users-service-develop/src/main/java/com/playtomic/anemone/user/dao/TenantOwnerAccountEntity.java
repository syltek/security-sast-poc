package com.playtomic.anemone.user.dao;

import com.playtomic.anemone.dao.BaseEntity;
import javax.annotation.Nonnull;
import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "tenant_owner_account")
@Access(AccessType.FIELD)
@Data
@NoArgsConstructor
public class TenantOwnerAccountEntity extends BaseEntity {
    @Id
    @Column(name = "id")
    @Nonnull
    private String id;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    @Nonnull
    private UserEntity user;

    @Column(name = "tenant_id", nullable = false)
    @Nonnull
    private String tenantId;

    @Column(name = "accepts_marketing_communications")
    private boolean acceptsMarketingCommunications;

    @Column(name = "accepts_marketing_behaviour_analysis")
    private boolean acceptsMarketingBehaviourAnalysis;

    @Column(name = "accepts_cx_questionnaires")
    private boolean acceptsCxQuestionnaires;

    @Column(name = "accepts_cx_whatsapp_communications")
    private boolean acceptsCxWhatsappCommunications;

    public TenantOwnerAccountEntity(@Nonnull String id,
                                    @Nonnull UserEntity user,
                                    @Nonnull String tenantId,
                                    boolean acceptsMarketingCommunications,
                                    boolean acceptsMarketingBehaviourAnalysis,
                                    boolean acceptsCxQuestionnaires,
                                    boolean acceptsCxWhatsappCommunications) {
        this.id = id;
        this.user = user;
        this.tenantId = tenantId;
        this.acceptsMarketingCommunications = acceptsMarketingCommunications;
        this.acceptsMarketingBehaviourAnalysis = acceptsMarketingBehaviourAnalysis;
        this.acceptsCxQuestionnaires = acceptsCxQuestionnaires;
        this.acceptsCxWhatsappCommunications = acceptsCxWhatsappCommunications;
    }

}

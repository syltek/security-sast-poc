package com.playtomic.anemone.user.service.anemone;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.playtomic.anemone.domain.user.UserId;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class CreateAnemoneVoucherRequestBody {

    @JsonProperty(value = "search_id")
    private String searchId;

    @JsonProperty(value = "country_code")
    private String countryCode;

    @JsonProperty(value = "user_id")
    private UserId userId;

}

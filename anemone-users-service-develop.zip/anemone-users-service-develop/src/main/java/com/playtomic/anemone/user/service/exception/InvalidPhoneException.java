package com.playtomic.anemone.user.service.exception;

import javax.annotation.Nonnull;

public class InvalidPhoneException extends RuntimeException {
    @Nonnull
    private String phone;
    public InvalidPhoneException(@Nonnull String phone) {
        this.phone = phone;
    }

    public String getPhone() {
        return phone;
    }
}

package com.playtomic.anemone.user.service.exception;

import javax.annotation.Nonnull;

public class PhoneAlreadyValidatedException extends RuntimeException {
    public PhoneAlreadyValidatedException(@Nonnull String message) {
        super(message);
    }
}

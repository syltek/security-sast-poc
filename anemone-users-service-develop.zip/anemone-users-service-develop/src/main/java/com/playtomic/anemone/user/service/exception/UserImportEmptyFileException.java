package com.playtomic.anemone.user.service.exception;

public class UserImportEmptyFileException extends RuntimeException {
}

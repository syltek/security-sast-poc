package com.playtomic.anemone.user.api.v2;

import static io.restassured.RestAssured.given;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.anything;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockserver.model.HttpRequest.request;
import static org.mockserver.model.HttpResponse.response;

import com.playtomic.anemone.UserApplication;
import com.playtomic.anemone.domain.Email;
import com.playtomic.anemone.domain.user.UserId;
import com.playtomic.anemone.domain.user.UserRole;
import com.playtomic.anemone.jwt.AccessJwtToken;
import com.playtomic.anemone.jwt.JwtTokenFactory;
import com.playtomic.anemone.test.TestCredentialsService;
import com.playtomic.anemone.test.WithMockUser;
import com.playtomic.anemone.user.api.v2.request.UserUpdateRequestBody;
import com.playtomic.anemone.user.config.AbstractTestContainersSupport;
import com.playtomic.anemone.user.dao.GdprAuditRepository;
import com.playtomic.anemone.user.dao.LinkedAccountEntity;
import com.playtomic.anemone.user.dao.PlaytomicUserType;
import com.playtomic.anemone.user.dao.UserDocumentRepository;
import com.playtomic.anemone.user.dao.UserEntity;
import com.playtomic.anemone.user.dao.UserRepository;
import com.playtomic.anemone.user.domain.LinkingType;
import com.playtomic.anemone.user.domain.users.UserLegacy;
import com.playtomic.anemone.user.model.CustomerUserProfile;
import com.playtomic.anemone.user.model.UserGender;
import com.playtomic.anemone.user.service.CloudinaryService;
import com.playtomic.anemone.user.service.UserCredentialService;
import com.playtomic.anemone.user.service.UserService;
import com.playtomic.anemone.user.service.anemone.EmailServiceClient;
import com.playtomic.anemone.user.service.exception.UserNotFoundException;
import io.restassured.http.ContentType;
import java.net.URL;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import org.apache.commons.codec.binary.Base64;
import org.apache.http.HttpStatus;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockserver.model.Header;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.core.io.Resource;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.util.Assert;
import org.springframework.util.FileCopyUtils;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = UserApplication.class)
@ExtendWith(SpringExtension.class)
public class UserUpdateControllerV2IT extends AbstractTestContainersSupport {
    private static final String USERS_API_V2 = "/v2/users";
    private static int MOCK_TENANTS_PORT = 10000;
    private final static int MOCK_CRM_SERVER_PORT = 5123;

    @Autowired
    private UserService userService;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private UserDocumentRepository userDocumentRepository;

    @Autowired
    private GdprAuditRepository gdprAuditRepository;

    @SpyBean
    private CloudinaryService cloudinaryService;

    @Autowired
    private JwtTokenFactory jwtTokenFactory;

    @Autowired
    private UserCredentialService userCredentialService;

    @Autowired
    private TestCredentialsService testCredentialsService;

    @MockBean
    private EmailServiceClient emailServiceClient;

    @AfterEach
    public void cleanReposAfterEach() {
        userRepository.deleteAll();
        userDocumentRepository.deleteAll();
    }


    @Test
    public void testFetchProfilePictureURLs() {
        UserEntity user = createUser("A name", "email@email.com", "+34 600000000", null);

        // No picture
        given()
                .get(USERS_API_V2 + "/" + user.getId())
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_OK)
                .body("picture", nullValue());

        // Facebook picture
        user.setFacebookId("10211318455263425");
        userRepository.save(user);
        given()
                .get(USERS_API_V2 + "/" + user.getId())
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_OK)
                .body("picture", is("https://res.cloudinary.com/playtomic/image/facebook/c_limit,w_1280/10211318455263425"));

        // Playtomic picture
        user.setProfilePhotoFilename("12345");
        userRepository.save(user);

        given()
                .get(USERS_API_V2 + "/" + user.getId())
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_OK)
                .body("picture", containsString(
                        "https://res.cloudinary.com/playtomic/image/upload/c_limit,w_1280/v1/test/users/"+user.getId())
                );
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_CUSTOMER)
    void testUpdateProfile() {
        UserEntity user = createUser("A name", "email@email.com", "+34 600000000", "picture");
        user.setPhoneVerified(true);
        userRepository.save(user);

        // Update regular data
        UserUpdateRequestBody body = new UserUpdateRequestBody();
        body.fullName = "New name";
        body.phone = "+34 666112233";
        given()
                .header("Authorization", createAuthHeader())
                .contentType("application/json")
                .body(body)
                .patch(USERS_API_V2 + "/" + user.getId())
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_OK)
                .body("user_id", is(user.getId() + ""))
                .body("email", is(user.getEmail()))
                .body("full_name", is("New name"))
                .body("is_validated", is(true))
                .body("picture", containsString(
                        "https://res.cloudinary.com/playtomic/image/upload/c_limit,w_1280/v1/test/users/"))
                .body("linked_accounts", hasSize(0))
                .body("phone", is("+34 666112233"))
                .body("is_phone_verified", is(false));

        // Update non formatted phone
        body.phone = "+34 123 45 67 89";
        given()
                .header("Authorization", createAuthHeader())
                .contentType("application/json")
                .body(body)
                .patch(USERS_API_V2 + "/" + user.getId())
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_OK)
                .body("phone", is("+34 123456789"))
                .body("is_phone_verified", is(false));

        // Update phone with token
        body.phone = "+34 698 76 54 32";
        body.phoneToken = userCredentialService.hashPhone("+34 698765432");
        given()
                .header("Authorization", createAuthHeader())
                .contentType("application/json")
                .body(body)
                .patch(USERS_API_V2 + "/" + user.getId())
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_OK)
                .body("phone", is("+34 698765432"))
                .body("is_phone_verified", is(true));

        // Update email should mark not validated
        body = new UserUpdateRequestBody();
        body.email = "new@email.com";
        given()
                .header("Authorization", createAuthHeader())
                .contentType("application/json")
                .body(body)
                .patch(USERS_API_V2 + "/" + user.getId())
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("user_id", is(user.getId() + ""))
                .body("email", is("new@email.com"))
                .body("is_validated", is(false));

        // Update email should mark validated if token provided
        body = new UserUpdateRequestBody();
        body.email = "valid@email.com";
        body.emailToken = userCredentialService.encodeEmail(Email.of("valid@email.com").get());
        given()
                .header("Authorization", createAuthHeader())
                .contentType("application/json")
                .body(body)
                .patch(USERS_API_V2 + "/" + user.getId())
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("user_id", is(user.getId() + ""))
                .body("email", is("valid@email.com"))
                .body("is_validated", is(true));

        // Update password
        body = new UserUpdateRequestBody();
        body.password = "Correct Password 1337";
        given()
                .header("Authorization", createAuthHeader())
                .contentType("application/json")
                .body(body)
                .patch(USERS_API_V2 + "/" + user.getId())
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("user_id", is(user.getId() + ""));

        UserEntity newUserEntity =
            userRepository
                .findById(user.getId())
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
        Assert.isTrue(new BCryptPasswordEncoder().matches("Correct Password 1337", newUserEntity.getPasswordHash()),
                "Password should be updated");

        // Update gender
        body = new UserUpdateRequestBody();
        body.gender = UserGender.FEMALE;
        given()
                .header("Authorization", createAuthHeader())
                .contentType("application/json")
                .body(body)
                .patch(USERS_API_V2 + "/" + user.getId())
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("user_id", is(user.getId() + ""))
                .body("gender", is("FEMALE"));

        // Update birthdate
        given()
                .header("Authorization", createAuthHeader())
                .contentType("application/json")
                .body("{\"birth_date\": \"1984-12-17T00:00:00\"}")
                .log().all()
                .patch(USERS_API_V2 + "/" + user.getId())
                .then()
                .log().all()
                .statusCode(HttpStatus.SC_OK)
                .body("user_id", is(user.getId() + ""))
                .body("birth_date", is("1984-12-17T00:00:00"));

        // Update bio
        given()
                .header("Authorization", createAuthHeader())
                .contentType("application/json")
                .body("{\"bio\": \"This is my sport profile biography\"}")
                .log().all()
                .patch(USERS_API_V2 + "/" + user.getId())
                .then()
                .log().all()
                .statusCode(HttpStatus.SC_OK)
                .body("user_id", is(user.getId() + ""))
                .body("bio", is("This is my sport profile biography"));

        // Check wrong email format
        body = new UserUpdateRequestBody();
        body.email = "wrong email.com";
        given()
                .header("Authorization", createAuthHeader())
                .contentType("application/json")
                .body(body)
                .patch(USERS_API_V2 + "/" + user.getId())
                .then()
                .statusCode(HttpStatus.SC_BAD_REQUEST)
                .body("status", is("INVALID_EMAIL"));

        // Check email in use
        UserEntity otherUser = createUser("Another user", "inuse@email.com");
        otherUser.setPhoneVerified(true);
        userRepository.save(otherUser);

        body = new UserUpdateRequestBody();
        body.email = "inuse@email.com";
        given()
                .header("Authorization", createAuthHeader())
                .contentType("application/json")
                .body(body)
                .patch(USERS_API_V2 + "/" + user.getId())
                .then()
                .statusCode(HttpStatus.SC_BAD_REQUEST)
                .body("status", is("INVALID_EMAIL"));

        // Check wrong email token
        body = new UserUpdateRequestBody();
        body.email = "wrongtoken@email.com";
        body.emailToken = "wrong token";
        given()
                .header("Authorization", createAuthHeader())
                .contentType("application/json")
                .body(body)
                .patch(USERS_API_V2 + "/" + user.getId())
                .then()
                .statusCode(HttpStatus.SC_BAD_REQUEST)
                .body("status", is("INVALID_EMAIL_TOKEN"));

        // Check wrong password format
        body = new UserUpdateRequestBody();
        body.password = "bad password";
        given()
                .header("Authorization", createAuthHeader())
                .contentType("application/json")
                .body(body)
                .patch(USERS_API_V2 + "/" + user.getId())
                .then()
                .statusCode(HttpStatus.SC_BAD_REQUEST)
                .body("status", is("INVALID_PASSWORD"));

        // Check wrong phone format
        body = new UserUpdateRequestBody();
        body.phone = "+32432345235223";
        given()
                .header("Authorization", createAuthHeader())
                .contentType("application/json")
                .body(body)
                .patch(USERS_API_V2 + "/" + user.getId())
                .then()
                .statusCode(HttpStatus.SC_BAD_REQUEST)
                .body("status", is("INVALID_PHONE"));

        // Check phone in use
        body = new UserUpdateRequestBody();
        body.phone = otherUser.getPhone();
        given()
                .header("Authorization", createAuthHeader())
                .contentType("application/json")
                .body(body)
                .patch(USERS_API_V2 + "/" + user.getId())
                .then()
                .statusCode(HttpStatus.SC_UNPROCESSABLE_ENTITY)
                .body("status", is("PHONE_ALREADY_IN_USE"));

        // Check invalid phone token
        body = new UserUpdateRequestBody();
        body.phone = "+34 98760000";
        body.phoneToken = "wrong token";
        given()
                .header("Authorization", createAuthHeader())
                .contentType("application/json")
                .body(body)
                .patch(USERS_API_V2 + "/" + user.getId())
                .then()
                .statusCode(HttpStatus.SC_BAD_REQUEST)
                .body("status", is("INVALID_PHONE_TOKEN"));

        // Check future birth date
        given()
                .header("Authorization", createAuthHeader())
                .contentType("application/json")
                .body("{\"birth_date\": \"2024-12-17T00:00:00\"}")
                .patch(USERS_API_V2 + "/" + user.getId())
                .then()
                .statusCode(HttpStatus.SC_BAD_REQUEST)
                .body("status", is("INVALID_BIRTH_DATE"));

        // Check updating not owned user
        body = new UserUpdateRequestBody();
        body.fullName = "A new name";
        given()
                .header("Authorization", createAuthHeader())
                .contentType("application/json")
                .body(body)
                .patch(USERS_API_V2 + "/" + otherUser.getId())
                .then()
                .statusCode(HttpStatus.SC_FORBIDDEN);

        // Check updating verfied not allowed user
        body = new UserUpdateRequestBody();
        body.isEmailVerified = true;
        given()
                .header("Authorization", createAuthHeader())
                .contentType("application/json")
                .body(body)
                .patch(USERS_API_V2 + "/" + otherUser.getId())
                .then()
                .statusCode(HttpStatus.SC_FORBIDDEN);


        user.setType(PlaytomicUserType.PENDING_VERIFICATION);
        userRepository.save(user);

        // Check updating email is not allowed for PENDING_VERIFICATION user type
        body = new UserUpdateRequestBody();
        body.email = "updated_email@gmail.com";
        given()
            .header("Authorization", createAuthHeader())
            .contentType("application/json")
            .body(body)
            .patch(USERS_API_V2 + "/" + user.getId())
            .then().log().all()
            .statusCode(HttpStatus.SC_BAD_REQUEST)
            .body("localized_message", is("You have to validate your email before changing it"));

        user.setType(PlaytomicUserType.ONSITE);
        userRepository.save(user);
        // Check updating email is not allowed for ONSITE user type
        body = new UserUpdateRequestBody();
        body.email = "updated_email@gmail.com";
        given()
            .header("Authorization", createAuthHeader())
            .contentType("application/json")
            .body(body)
            .patch(USERS_API_V2 + "/" + user.getId())
            .then().log().all()
            .statusCode(HttpStatus.SC_BAD_REQUEST)
            .body("localized_message", is("You have to validate your email before changing it"));;
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_ADMIN)
    void testUpdateProfileVerified() {
        UserEntity user = createUser("A name", "email@email.com", "+34 600000000", "picture");
        user.setPhoneVerified(true);
        userRepository.save(user);

        // Update regular data
        UserUpdateRequestBody body = new UserUpdateRequestBody();
        body.fullName = "New name";
        body.phone = "+34 666112233";
        body.isPhoneVerified = true;
        given()
                .header("Authorization", createAuthHeader())
                .contentType("application/json")
                .body(body)
                .patch(USERS_API_V2 + "/" + user.getId())
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_OK)
                .body("user_id", is(user.getId() + ""))
                .body("email", is(user.getEmail()))
                .body("full_name", is("New name"))
                .body("is_validated", is(true))
                .body("picture", containsString(
                        "https://res.cloudinary.com/playtomic/image/upload/c_limit,w_1280/v1/test/users/"))
                .body("linked_accounts", hasSize(0))
                .body("phone", is("+34 666112233"))
                .body("is_phone_verified", is(true));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void testUpdateProfile_by_manager() {
        mockTenantResponse("tenant_id",null);
        UserEntity manager = createUser("manager", "manager@email.com", "+34 600000001", "picture");

        UserEntity user = createUser("A name", "email@email.com", "+34 600000000", "picture");
        LinkedAccountEntity linkedAccountEntity = new LinkedAccountEntity(user, "tenant_id", "1", null, LinkingType.AUTOLINK);
        user.setLinkedAccounts(Collections.singleton(linkedAccountEntity));
        user.setCreatedByTenant("tenant_id");
        user.setEmailVerified(false);
        user.setType(PlaytomicUserType.PENDING_VERIFICATION);
        userRepository.save(user);
        Map<String, Object> claims = Map.of(UserRole.ROLE_TENANT_MANAGER.getGa().getAuthority(),
            Map.of("tenant_ids", Collections.singletonList("tenant_id")));

        // Check updating email is not allowed for PENDING_VERIFICATION user type
        UserUpdateRequestBody body = new UserUpdateRequestBody();
        body.email = "updated_email@gmail.com";
        given()
            .header("Authorization", createAuthHeader(claims, manager))
            .contentType("application/json")
            .body(body)
            .patch(USERS_API_V2 + "/" + user.getId())
            .then()
            .statusCode(HttpStatus.SC_OK)
            .body("email", is("updated_email@gmail.com"));

        user.setType(PlaytomicUserType.ONSITE);
        userRepository.save(user);

        // Check updating email is not allowed for ONSITE user type
        body = new UserUpdateRequestBody();
        body.email = "updated_email@gmail.com";
        given()
            .header("Authorization", createAuthHeader(claims, manager))
            .contentType("application/json")
            .body(body)
            .patch(USERS_API_V2 + "/" + user.getId())
            .then()
            .statusCode(HttpStatus.SC_OK)
            .body("email", is("updated_email@gmail.com"));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    public void test_should_not_allow_edition_of_user_not_created_by_tenant() {
        mockTenantResponse("tenant_id",null);
        UserEntity user = createUser("A name", "email@email.com", "+34 600000000", "picture");
        user.setEmailVerified(false);
        final LinkedAccountEntity linkedAccountEntity = new LinkedAccountEntity(user, "tenant_id", "1", null, LinkingType.AUTOLINK);
        user.setLinkedAccounts(Collections.singleton(linkedAccountEntity));
        userRepository.save(user);

        Map<String, Object> claims = Map.of(UserRole.ROLE_TENANT_MANAGER.getGa().getAuthority(),
            Map.of("tenant_ids", Collections.singletonList("tenant_id2")));

        // Update regular data
        UserUpdateRequestBody updateRequestBody = new UserUpdateRequestBody();
        updateRequestBody.fullName = "New name";
        updateRequestBody.phone = "+34 666112233";

        given()
            .header("Authorization", createAuthHeader(claims))
            .contentType("application/json")
            .body(updateRequestBody)
            .patch(USERS_API_V2 + "/" + user.getId())
            .then()
            .log().body()
            .statusCode(HttpStatus.SC_FORBIDDEN);
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    public void test_should_allow_edition_of_user_created_by_tenant() {
        mockTenantResponse("tenant_id",null);
        UserEntity user = createUser("A name", "email@email.com", "+34 600000000", "picture");
        user.setEmailVerified(false);
        final LinkedAccountEntity linkedAccountEntity = new LinkedAccountEntity(user, "tenant_id", "1", null, LinkingType.AUTOLINK);
        user.setLinkedAccounts(Collections.singleton(linkedAccountEntity));
        user.setCreatedByTenant("tenant_id");
        userRepository.save(user);

        Map<String, Object> claims = Map.of(UserRole.ROLE_TENANT_MANAGER.getGa().getAuthority(),
            Map.of("tenant_ids", Collections.singletonList("tenant_id")));

        // Update regular data
        UserUpdateRequestBody updateRequestBody = new UserUpdateRequestBody();
        updateRequestBody.fullName = "New name";
        updateRequestBody.phone = "+34 666112233";

        given()
            .header("Authorization", createAuthHeader(claims))
            .contentType("application/json")
            .body(updateRequestBody)
            .patch(USERS_API_V2 + "/" + user.getId())
            .then()
            .log().body()
            .statusCode(HttpStatus.SC_OK)
            .body("user_id", is(user.getId() + ""))
            .body("email", is(user.getEmail()))
            .body("full_name", is("New name"))
            .body("is_validated", is(false))
            .body("picture", containsString(
                "https://res.cloudinary.com/playtomic/image/upload/c_limit,w_1280/v1/test/users/"))
            .body("linked_accounts", hasSize(1))
            .body("phone", is("+34 666112233"))
            .body("is_phone_verified", is(false));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    public void test_should_allow_edition_of_only_phone_when_user_with_email_verified_created_by_tenant() {
        mockTenantResponse("tenant_id",null);
        UserEntity user = createUser("A name", "email@email.com", "+34 600000000", "picture");
        final LinkedAccountEntity linkedAccountEntity = new LinkedAccountEntity(user, "tenant_id", "1", null, LinkingType.AUTOLINK);
        user.setLinkedAccounts(Collections.singleton(linkedAccountEntity));
        user.setCreatedByTenant("tenant_id");
        userRepository.save(user);

        Map<String, Object> claims = Map.of(UserRole.ROLE_TENANT_MANAGER.getGa().getAuthority(),
            Map.of("tenant_ids", Collections.singletonList("tenant_id")));

        // Update name should fail as the email is verified
        UserUpdateRequestBody updateRequestBody = new UserUpdateRequestBody();
        updateRequestBody.fullName = "New name";

        given()
            .header("Authorization", createAuthHeader(claims))
            .contentType("application/json")
            .body(updateRequestBody)
            .patch(USERS_API_V2 + "/" + user.getId())
            .then()
            .log().body()
            .statusCode(HttpStatus.SC_FORBIDDEN);

        // Update phone should fail as the phone is not verified
        updateRequestBody = new UserUpdateRequestBody();
        updateRequestBody.phone = "+34 666112233";

        given()
            .header("Authorization", createAuthHeader(claims))
            .contentType("application/json")
            .body(updateRequestBody)
            .patch(USERS_API_V2 + "/" + user.getId())
            .then()
            .log().body()
            .statusCode(HttpStatus.SC_OK)
            .body("user_id", is(user.getId() + ""))
            .body("email", is(user.getEmail()))
            .body("full_name", is("A name"))
            .body("is_validated", is(true))
            .body("picture", containsString(
                "https://res.cloudinary.com/playtomic/image/upload/c_limit,w_1280/v1/test/users/"))
            .body("linked_accounts", hasSize(1))
            .body("phone", is("+34 666112233"))
            .body("is_phone_verified", is(false));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    public void test_should_not_allow_edition_of_phone_when_user_with_phone_verified_owned_by_tenant() {
        mockTenantResponse("tenant_id",null);
        UserEntity user = createUser("A name", "email@email.com", "+34 600000000", "picture");
        final LinkedAccountEntity linkedAccountEntity = new LinkedAccountEntity(user, "tenant_id", "1", null, LinkingType.AUTOLINK);
        user.setLinkedAccounts(Collections.singleton(linkedAccountEntity));
        user.setPhoneVerified(true);
        userRepository.save(user);

        Map<String, Object> claims = Map.of(UserRole.ROLE_TENANT_MANAGER.getGa().getAuthority(),
            Map.of("tenant_ids", Collections.singletonList("tenant_id")));

        // Update phone should fail as the phone is verified
        UserUpdateRequestBody updateRequestBody = new UserUpdateRequestBody();
        updateRequestBody.phone = "+34 666112233";

        given()
            .header("Authorization", createAuthHeader(claims))
            .contentType("application/json")
            .body(updateRequestBody)
            .patch(USERS_API_V2 + "/" + user.getId())
            .then()
            .log().body()
            .statusCode(HttpStatus.SC_FORBIDDEN);
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_CUSTOMER)
    public void testUpdateImageProfile() throws Exception {
        UserEntity user = createUser("A user", "email@email.com");
        Base64 base64 = new Base64();

        Resource imageOne = loadResource(getCurrentPackageAsClasspath() + "/upload_profile_image.png");
        final byte[] constByte = FileCopyUtils.copyToByteArray(imageOne.getInputStream());
        byte[] imageBase64 = base64.encode(constByte);

        doReturn(new URL("http://mock.com/profile.jpg")).when(cloudinaryService).getURL(any(), any(), any());
        doReturn(new CloudinaryService.Content(new URL("http://mock.com/profile.jpg"), "profile.jpg"))
                .when(cloudinaryService).uploadImages(any(), any(), any());

        UserUpdateRequestBody body = new UserUpdateRequestBody();
        body.pictureBase64 = new String(imageBase64);
        given()
                .header("Authorization", createAuthHeader())
                .contentType("application/json")
                .body(body)
                .patch(USERS_API_V2 + "/" + user.getId())
                .then()
                .statusCode(HttpStatus.SC_OK);

        user = userRepository
            .findById(user.getId())
            .orElseThrow(() -> new IllegalArgumentException("User not found"));
        assertThat(user.getProfilePhotoFilename()).isNotBlank();

        verify(cloudinaryService, times(2)).getURL(any(), any(),any());
        verify(cloudinaryService, times(1)).uploadImages(any(), any(), any());
        verify(cloudinaryService, times(0)).deleteImage(any(), any());

        String previousPhoto = user.getProfilePhotoFilename();

        Resource imageTwo = loadResource(getCurrentPackageAsClasspath() + "/upload_profile_image_2.png");
        final byte[] constByteTwo = FileCopyUtils.copyToByteArray(imageTwo.getInputStream());
        imageBase64 = base64.encode(constByteTwo);

        doReturn(new URL("http://mock.com/profile.jpg")).when(cloudinaryService).getURL(any(), any(), any());
        doReturn(new CloudinaryService.Content(new URL("http://mock.com/profile.jpg"), "profile.jpg"))
                .when(cloudinaryService).uploadImages(any(), any(), any());
        doNothing().when(cloudinaryService).deleteImage(any(), any());

        body = new UserUpdateRequestBody();
        body.pictureBase64 = new String(imageBase64);
        given()
                .header("Authorization", createAuthHeader())
                .contentType("application/json")
                .body(body)
                .patch(USERS_API_V2 + "/" + user.getId())
                .then()
                .statusCode(HttpStatus.SC_OK);

        user = userRepository
            .findById(user.getId())
            .orElseThrow(() -> new IllegalArgumentException("User not found"));
        assertThat(user.getProfilePhotoFilename()).isNotBlank();
        assertThat(user.getProfilePhotoFilename()).isNotEqualTo(previousPhoto);

        // sgmoratilla: why 5? seems such a random number...
        // nachogonzalez: now it's 6 because we get the user to see if it is allowed to perform the changes
        verify(cloudinaryService, times(6)).getURL(any(), any(), any());
        verify(cloudinaryService, times(2)).uploadImages(any(), any(), any());
        verify(cloudinaryService, times(1)).deleteImage(any(), any());
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_CUSTOMER)
    public void testUpdateGDPRSettings() {
        UserEntity user = createUser("A user", "email@email.com");
        long userId = user.getId();
        int sizeGdprAuditEntities = gdprAuditRepository.findAll().size();

        UserUpdateRequestBody body = new UserUpdateRequestBody();
        body.acceptsPrivacy = true;
        body.acceptsCommercial = true;
        given()
                .header("Authorization", createAuthHeader())
                .contentType("application/json")
                .body(body)
                .patch(USERS_API_V2 + "/" + user.getId())
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("user_id", is(userId + ""))
                .body("email", is(user.getEmail()))
                .body("full_name", is(user.getFullName()))
                .body("is_validated", is(true))
                .body("picture", anything())
                .body("linked_accounts", hasSize(0))
                .body("accepts_privacy", is(true))
                .body("accepts_commercial", is(true));

        Assert.isTrue(gdprAuditRepository.findAll().size() == sizeGdprAuditEntities + 1,
                "GdprAudit entry has not been created");

        sizeGdprAuditEntities = gdprAuditRepository.findAll().size();

        body = new UserUpdateRequestBody();
        body.acceptsPrivacy = false;
        body.acceptsCommercial = false;
        given()
                .header("Authorization", createAuthHeader())
                .contentType("application/json")
                .body(body)
                .patch(USERS_API_V2 + "/" + user.getId())
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("accepts_privacy", is(false))
                .body("accepts_commercial", is(false));

        Assert.isTrue(gdprAuditRepository.findAll().size() == sizeGdprAuditEntities + 1,
                "GdprAudit entry has not been created");

        sizeGdprAuditEntities = gdprAuditRepository.findAll().size();

        body = new UserUpdateRequestBody();
        body.acceptsCommercial = true;
        given()
                .header("Authorization", createAuthHeader())
                .contentType("application/json")
                .body(body)
                .patch(USERS_API_V2 + "/" + user.getId())
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("accepts_privacy", is(false))
                .body("accepts_commercial", is(true));

        Assert.isTrue(gdprAuditRepository.findAll().size() == sizeGdprAuditEntities + 1,
                "GdprAudit entry has not been created");

        sizeGdprAuditEntities = gdprAuditRepository.findAll().size();

        body = new UserUpdateRequestBody();
        body.acceptsPrivacy = true;
        given()
                .header("Authorization", createAuthHeader())
                .contentType("application/json")
                .body(body)
                .patch(USERS_API_V2 + "/" + user.getId())
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("accepts_privacy", is(true))
                .body("accepts_commercial", is(true));

        Assert.isTrue(gdprAuditRepository.findAll().size() == sizeGdprAuditEntities + 1,
                "GdprAudit entry has not been created");

        sizeGdprAuditEntities = gdprAuditRepository.findAll().size();

        body = new UserUpdateRequestBody();
        body.acceptsCommercial = false;
        given()
                .header("Authorization", createAuthHeader())
                .contentType("application/json")
                .body(body)
                .patch(USERS_API_V2 + "/" + user.getId())
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("accepts_privacy", is(true))
                .body("accepts_commercial", is(false));

        Assert.isTrue(gdprAuditRepository.findAll().size() == sizeGdprAuditEntities + 1,
                "GdprAudit entry has not been created");

        sizeGdprAuditEntities = gdprAuditRepository.findAll().size();

        body = new UserUpdateRequestBody();
        body.acceptsPrivacy = false;
        given()
                .header("Authorization", createAuthHeader())
                .contentType("application/json")
                .body(body)
                .patch(USERS_API_V2 + "/" + user.getId())
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("accepts_privacy", is(false))
                .body("accepts_commercial", is(false));

        Assert.isTrue(gdprAuditRepository.findAll().size() == sizeGdprAuditEntities + 1,
                "GdprAudit entry has not been created");

    }

    @Test
    @WithMockUser(role = UserRole.ROLE_CUSTOMER)
    public void tesUpdateLinkedAccount() {
        UserEntity userMe = createUser("User Test", "ok@email.com");
        LinkedAccountEntity linkedAccountEntity = new LinkedAccountEntity(userMe, "tenant-id", "1", null, null);
        userMe.setLinkedAccounts(Collections.singleton(linkedAccountEntity));
        userRepository.save(userMe);

        mockTenantResponse("tenant-id", null);
        mockCRMSetCustomerCommunicationsResponse(200, "{}");

        given()
            .header("Authorization", createAuthHeader())
            .contentType(ContentType.JSON)
            .body("{\"accepts_commercial\": true}")
            .patch(USERS_API_V2 + "/me/linked_accounts/tenant-id")
            .then()
            .log().body()
            .statusCode(HttpStatus.SC_OK)
            .body("linked_accounts", hasSize(1))
            .body("linked_accounts[0].tenant_id", is(linkedAccountEntity.getTenantId()))
            .body("linked_accounts[0].merchant_user_id", is(linkedAccountEntity.getMerchantUserId()))
            .body("linked_accounts[0].accepts_commercial", is(true))
            .body("linked_accounts[0].linking_type", is(nullValue()))
        ;

        given()
            .header("Authorization", createAuthHeader())
            .contentType(ContentType.JSON)
            .body("{\"accepts_commercial\": false}")
            .patch(USERS_API_V2 + "/me/linked_accounts/tenant-id")
            .then()
            .log().body()
            .statusCode(HttpStatus.SC_OK)
            .body("linked_accounts", hasSize(1))
            .body("linked_accounts[0].tenant_id", is(linkedAccountEntity.getTenantId()))
            .body("linked_accounts[0].merchant_user_id", is(linkedAccountEntity.getMerchantUserId()))
            .body("linked_accounts[0].accepts_commercial", is(false))
            .body("linked_accounts[0].linking_type", is(nullValue()))
        ;
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_CUSTOMER)
    public void testLinkTenantAccount() throws UserNotFoundException {
        UserEntity user = createUser("A user", "email@email.com");
        Map<String, String> body = new HashMap<>();

        // Fail because of invalid tenant
        getMockServer(MOCK_TENANTS_PORT).reset();
        body.put("tenant_id", "mytenant_other");
        body.put("email", "mock@email.com");
        body.put("tenant_password", "1234");

        mockTenantResponse("tenant-id", "mytenant_other");

        given()
                .header("Authorization", createAuthHeader())
                .contentType("application/json")
                .body(body)
                .post(USERS_API_V2 + "/me/linked_accounts")
                .then()
                .statusCode(HttpStatus.SC_NOT_FOUND)
                .body("status", is("TENANT_NOT_FOUND"));

        // Fail linking for invalid account
        body.put("tenant_id", "tenant-id");
        mockCRMValidateAccountResponse(400, "");
        given()
                .header("Authorization", createAuthHeader())
                .contentType("application/json")
                .body(body)
                .post(USERS_API_V2 + "/me/linked_accounts")
                .then()
                .statusCode(HttpStatus.SC_UNPROCESSABLE_ENTITY)
                .body("status", is("INVALID_LINK_CREDENTIALS"));

        // Link tenant properly
        mockCRMValidateAccountResponse(200, "{\"idCustomer\": 50}");
        given()
                .header("Authorization", createAuthHeader())
                .contentType("application/json")
                .body(body)
                .post(USERS_API_V2 + "/me/linked_accounts")
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("user_id", is(user.getId() + ""))
                .body("email", is(user.getEmail()))
                .body("linked_accounts", hasSize(1))
                .body("linked_accounts[0].tenant_id", is("tenant-id"))
                .body("linked_accounts[0].merchant_user_id", is("50"))
                .body("linked_accounts[0].linking_type", is("MANUAL_LINK"));

        assertThat(userService.getUserById(UserLegacy.valueOf(user.getId())).getLinkedTenantsAccounts()).hasSize(1);
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_CUSTOMER)
    public void testUnLinkTenantAccount() throws UserNotFoundException {
        mockTenantResponse("tenant-id", null);

        UserEntity user = createUser("A user", "email@email.com");
        LinkedAccountEntity linkedAccountEntity = new LinkedAccountEntity(user, "tenant-id", "1", null, null);
        user.setLinkedAccounts(Collections.singleton(linkedAccountEntity));
        userRepository.save(user);

        // Unlink tenant properly
        given()
                .header("Authorization", createAuthHeader())
                .param("tenant_id", "tenant-id")
                .delete(USERS_API_V2 + "/me/linked_accounts")
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("user_id", is(user.getId() + ""))
                .body("linked_accounts", hasSize(0));

        assertThat(userService.getUserById(UserLegacy.valueOf(user.getId())).getLinkedTenantsAccounts()).hasSize(0);


        // Unlink tenant again returns OK
        given()
                .header("Authorization", createAuthHeader())
                .param("tenant_id", "tenant-id")
                .delete(USERS_API_V2 + "/me/linked_accounts")
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("user_id", is(user.getId() + ""))
                .body("linked_accounts", hasSize(0));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_CUSTOMER)
    public void testAutolink() throws UserNotFoundException {
        UserEntity user = createUser("A user", "email@email.com");
        mockTenantResponse("tenant-id", "mytenant_other");
        Map<String, String> body = new HashMap<>();

        // Fail because of invalid tenant
        body.put("tenant_id", "mytenant_other");
        given()
                .header("Authorization", createAuthHeader())
                .contentType("application/json")
                .body(body)
                .post(USERS_API_V2 + "/me/linked_accounts")
                .then()
                .statusCode(HttpStatus.SC_NOT_FOUND)
                .body("status", is("TENANT_NOT_FOUND"))
                .body("localized_message", anything());


        // Fail linking for invalid account
        user.setEmailVerified(true);
        userRepository.save(user);

        body.put("tenant_id", "tenant-id");
        mockCRMFindCustomerResponse(400, "");
        given()
                .header("Authorization", createAuthHeader())
                .contentType("application/json")
                .body(body)
                .post(USERS_API_V2 + "/me/linked_accounts")
                .then()
                .statusCode(HttpStatus.SC_UNPROCESSABLE_ENTITY)
                .body("status", is("INVALID_LINK_CREDENTIALS"))
                .body("localized_message", anything());

        // Link tenant properly
        mockCRMFindCustomerResponse(200, "{\"idCustomer\": 60, \"entity\": {\"idCustomerType\": \"147\"}}");
        given()
                .header("Authorization", createAuthHeader())
                .contentType("application/json")
                .body(body)
                .post(USERS_API_V2 + "/me/linked_accounts")
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("user_id", is(user.getId() + ""))
                .body("linked_accounts", hasSize(1))
                .body("linked_accounts[0].tenant_id", is("tenant-id"))
                .body("linked_accounts[0].merchant_user_id", is("60"))
                .body("linked_accounts[0].linking_type", is("AUTOLINK"))
                .body("tenant_tags", hasSize(1))
                .body("tenant_tags[0].tags[0]", is("SYLTEK_CUSTOMER_TYPE_147"));

        assertThat(userService.getUserById(UserLegacy.valueOf(user.getId())).getLinkedTenantsAccounts()).hasSize(1);

        // Second link should do nothing
        given()
                .header("Authorization", createAuthHeader())
                .contentType("application/json")
                .body(body)
                .post(USERS_API_V2 + "/me/linked_accounts")
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("user_id", is(user.getId() + ""))
                .body("linked_accounts", hasSize(1));

        assertThat(userService.getUserById(UserLegacy.valueOf(user.getId())).getLinkedTenantsAccounts()).hasSize(1);
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_CUSTOMER)
    public void testAutoregister() throws UserNotFoundException {
        UserEntity user = createUser("A user", "email@email.com");
        mockTenantResponse("tenant-id", "mytenant_other");
        Map<String, String> body = new HashMap<>();
        body.put("autoregister", "true");

        // Fail because of invalid tenant
        body.put("tenant_id", "mytenant_other");
        given()
                .header("Authorization", createAuthHeader())
                .contentType("application/json")
                .body(body)
                .post(USERS_API_V2 + "/me/linked_accounts")
                .then()
                .statusCode(HttpStatus.SC_NOT_FOUND)
                .body("status", is("TENANT_NOT_FOUND"))
                .body("localized_message", anything());

        // Fail linking for already registered account
        user.setEmailVerified(true);
        userRepository.save(user);
        mockCRMRegisterCustomerResponse(400, "");
        body.put("tenant_id", "tenant-id");
        given()
                .header("Authorization", createAuthHeader())
                .contentType("application/json")
                .body(body)
                .post(USERS_API_V2 + "/me/linked_accounts")
                .then()
                .statusCode(HttpStatus.SC_UNPROCESSABLE_ENTITY)
                .body("status", is("EXISTING_ACCOUNT"))
                .body("localized_message", anything());

        // Link tenant properly
        mockCRMRegisterCustomerResponse(200, "{\"idCustomer\": 70, \"entity\": {\"idCustomerType\": \"147\"}}");
        given()
                .header("Authorization", createAuthHeader())
                .contentType("application/json")
                .body(body)
                .post(USERS_API_V2 + "/me/linked_accounts")
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("user_id", is(user.getId() + ""))
                .body("linked_accounts", hasSize(1))
                .body("linked_accounts[0].tenant_id", is("tenant-id"))
                .body("linked_accounts[0].merchant_user_id", is("70"))
                .body("linked_accounts[0].linking_type", is("AUTOREGISTER"))
                .body("tenant_tags", hasSize(1))
                .body("tenant_tags[0].tags[0]", is("SYLTEK_CUSTOMER_TYPE_147"));

        assertThat(userService.getUserById(UserLegacy.valueOf(user.getId())).getLinkedTenantsAccounts()).hasSize(1);
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_ADMIN)
    public void testAddRole() {

        mockAnemoneTenantResponse("tenant-1", "tenant-2");

        UserEntity user = createUser("A user", "email@email.com");
        String body = "{\"user_roles\":"+
                "[ "
                + "{"
                    + "\"user_role\": \"ROLE_TENANT_MANAGER\", "
                    + "\"tenant_id\": \"tenant-1\" "
                + "}"
                + "]}";

        given()
                .header("Authorization", createAuthHeader())
                .contentType("application/json")
                .body(body)
                .post(USERS_API_V2 + "/" + user.getId() + "/user_roles")
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("user_roles", hasSize(2))
                .body("user_roles[0].user_role", is("ROLE_CUSTOMER"))
                .body("user_roles[1].user_role", is("ROLE_TENANT_MANAGER"))
                .body("user_roles[1].tenant_id", is("tenant-1"));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    public void test_add_role_tenant_manager() {
        mockAnemoneTenantResponse("new-tenant-data", "tenant-2");

        UserEntity user = createUser("Another user", "another-email@email.com");
        String body = "{\"user_roles\":"+
                "[ "
                + "{"
                + "\"user_role\": \"ROLE_TENANT_MANAGER\", "
                + "\"tenant_id\": \"new-tenant-data\""
                + "}"
                + "]}";

        Map<String, List<String>> claimData = UserControllerV2IT.tenantsIdsClaimData("new-tenant-data");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);

        given()
                .header("Authorization", createAuthHeader(extraClaims))
                .contentType("application/json")
                .body(body)
                .post(USERS_API_V2 + "/" + user.getId() + "/user_roles")
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("user_roles", hasSize(2))
                .body("user_roles[0].user_role", is("ROLE_CUSTOMER"))
                .body("user_roles[1].user_role", is("ROLE_TENANT_MANAGER"))
                .body("user_roles[1].tenant_id", is("new-tenant-data"));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_CUSTOMER)
    public void testAddRole_forbidden() {
        UserEntity user = createUser("A user", "email@email.com");
        // This is a bad parameters as well:
        String body = "{\"user_roles\":"+
                "[ "
                + "{"
                + "\"user_role\": \"ROLE_TENANT_MANAGER\","
                + "\"tenant_id\": \"tenant-id\" "
                + "}"
                + "]}";

        given()
                .header("Authorization", createAuthHeader())
                .contentType("application/json")
                .body(body)
                .post(USERS_API_V2 + "/" + user.getId() + "/user_roles")
                .then()
                .statusCode(HttpStatus.SC_FORBIDDEN);
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_ADMIN)
    public void testDeleteRoleByRoleId() {
        mockAnemoneTenantResponse("tenant-1", "tenant-2");

        UserEntity user = createUser("A user", "email@email.com");
        String body = "{\"user_roles\":"+
                "[ "
                + "{"
                + "\"user_role\": \"ROLE_TENANT_MANAGER\", "
                + "\"tenant_id\": \"tenant-1\" "
                + "}"
                + "]}";

        given()
                .header("Authorization", createAuthHeader())
                .contentType("application/json")
                .body(body)
                .post(USERS_API_V2 + "/" + user.getId() + "/user_roles")
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("user_roles", hasSize(2))
                .body("user_roles[0].user_role", is("ROLE_CUSTOMER"))
                .body("user_roles[1].user_role", is("ROLE_TENANT_MANAGER"))
                .body("user_roles[1].tenant_id", is("tenant-1"));

        given()
                .header("Authorization", createAuthHeader())
                .contentType("application/json")
                .body(body)
                .delete(USERS_API_V2 + "/" + user.getId() + "/user_roles/ROLE_TENANT_MANAGER")
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("user_roles", hasSize(1))
                .body("user_roles[0].user_role", is("ROLE_CUSTOMER"));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_ADMIN)
    public void testDeleteRoleByRoleIdAndTenantId() throws UserNotFoundException {
        UserEntity user = createUser("A user", "email@email.com");
        String body = "{\"user_roles\":"+
                "[ "
                + "{"
                + "\"user_role\": \"ROLE_TENANT_MANAGER\", "
                + "\"tenant_id\": \"tenant-1\" "
                + "},"
                + "{"
                + "\"user_role\": \"ROLE_TENANT_MANAGER\", "
                + "\"tenant_id\": \"tenant-2\" "
                + "}"
                + "]}";

        given()
                .header("Authorization", createAuthHeader())
                .contentType("application/json")
                .body(body)
                .post(USERS_API_V2 + "/" + user.getId() + "/user_roles")
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("user_roles", hasSize(3))
                .body("user_roles[0].user_role", is("ROLE_CUSTOMER"))
                .body("user_roles[1].user_role", is("ROLE_TENANT_MANAGER"))
                .body("user_roles[2].user_role", is("ROLE_TENANT_MANAGER"));

        //Add tenant owner relations
        given()
            .header("Authorization", createAuthHeader())
            .contentType("application/json")
            .body(body)
            .put(USERS_API_V2 + "/" + user.getId() + "/tenant_owner_accounts/tenant-1")
            .then()
            .statusCode(HttpStatus.SC_OK);

        given()
            .header("Authorization", createAuthHeader())
            .contentType("application/json")
            .body(body)
            .put(USERS_API_V2 + "/" + user.getId() + "/tenant_owner_accounts/tenant-2")
            .then()
            .statusCode(HttpStatus.SC_OK);

        CustomerUserProfile dbUser = userService.getUserById(UserId.valueOf("" + user.getId()));
        assertThat(dbUser.getUserRoles()).hasSize(3);
        assertThat(dbUser.getTenantOwnerAccounts().stream().map(o -> o.getTenantId().getValue()).collect(Collectors.toList())).contains("tenant-1", "tenant-2");

        //Deleting manager account will also delete the existing owner relation
        given()
                .header("Authorization", createAuthHeader())
                .contentType("application/json")
                .param("tenant_id", "tenant-1")
                .delete(USERS_API_V2 + "/" + user.getId() + "/user_roles/ROLE_TENANT_MANAGER")
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("user_roles", hasSize(2))
                .body("user_roles[0].user_role", is("ROLE_CUSTOMER"))
                .body("user_roles[1].user_role", is("ROLE_TENANT_MANAGER"))
                .body("user_roles[1].tenant_id", is("tenant-2"));

        dbUser = userService.getUserById(UserId.valueOf("" + user.getId()));
        assertThat(dbUser.getUserRoles()).hasSize(2);
        assertThat(dbUser.getTenantOwnerAccounts().stream().map(o -> o.getTenantId().getValue()).collect(Collectors.toList())).contains("tenant-2");

        //Deleting all manager accounts will delete all owner accounts
        given()
            .header("Authorization", createAuthHeader())
            .contentType("application/json")
            .delete(USERS_API_V2 + "/" + user.getId() + "/user_roles/ROLE_TENANT_MANAGER")
            .then()
            .statusCode(HttpStatus.SC_OK)
            .body("user_roles", hasSize(1));

        dbUser = userService.getUserById(UserId.valueOf("" + user.getId()));
        assertThat(dbUser.getUserRoles()).hasSize(1);
        assertThat(dbUser.getTenantOwnerAccounts()).hasSize(0);
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_CUSTOMER)
    public void tesUpdateGamePreferences() {
        // This user is necessary for the createAuthHeader to work
        UserEntity userMe = createUser("User Test", "ok@email.com");

        given()
            .header("Authorization", createAuthHeader())
            .contentType(ContentType.JSON)
            .get(USERS_API_V2 + "/me/game_preferences")
            .then()
            .log().body()
            .statusCode(HttpStatus.SC_OK)
            .body("time_ranges", hasSize(0))
        ;

        // unordered, several formats.
        JSONArray time_ranges = new JSONArray();
        {
            JSONObject o = new JSONObject();
            o.put("day_of_week", "MONDAY");
            o.put("start", "16:00:00");
            o.put("end", "19:00:00");
            time_ranges.put(o);
        }
        {
            JSONObject o = new JSONObject();
            o.put("day_of_week", "MONDAY");
            o.put("start", "06:00");
            o.put("end", "14:00");
            time_ranges.put(o);
        }

        JSONObject body = new JSONObject();
        body.put("time_ranges", time_ranges);

        given()
            .header("Authorization", createAuthHeader())
            .contentType(ContentType.JSON)
            .body(body.toString())
            .put(USERS_API_V2 + "/me/game_preferences")
            .then()
            .log().body()
            .statusCode(HttpStatus.SC_OK)
            .body("time_ranges", hasSize(2))
            .body("time_ranges[0].day_of_week", is("MONDAY"))
            .body("time_ranges[0].start", is("06:00:00"))
            .body("time_ranges[0].end", is("14:00:00"))
            .body("time_ranges[1].day_of_week", is("MONDAY"))
            .body("time_ranges[1].start", is("16:00:00"))
            .body("time_ranges[1].end", is("19:00:00"))
        ;

        given()
            .header("Authorization", createAuthHeader())
            .contentType(ContentType.JSON)
            .get(USERS_API_V2 + "/me/game_preferences")
            .then()
            .log().body()
            .statusCode(HttpStatus.SC_OK)
            .body("time_ranges", hasSize(2))
            .body("time_ranges[0].day_of_week", is("MONDAY"))
            .body("time_ranges[0].start", is("06:00:00"))
            .body("time_ranges[0].end", is("14:00:00"))
            .body("time_ranges[1].day_of_week", is("MONDAY"))
            .body("time_ranges[1].start", is("16:00:00"))
            .body("time_ranges[1].end", is("19:00:00"))
        ;
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_CUSTOMER)
    public void tesValidatePhoneNullifiesDuplicates() {
        UserEntity userMe = createUser("User Test", "ok@email.com", "+34 612345678", null);
        List<UserEntity> otherUsers = Arrays.asList(
                createUser("User 1", "email1@email.com", "+34 612345678", null),
                createUser("User 2", "email2@email.com", "+34 612345678", null),
                createUser("User 3", "email3@email.com", "+34 612345678", null)
        );
        UserUpdateRequestBody body = new UserUpdateRequestBody();
        body.phoneToken = userCredentialService.hashPhone("+34 612345678");
        given()
                .header("Authorization", createAuthHeader())
                .contentType("application/json")
                .body(body)
                .patch(USERS_API_V2 + "/" + userMe.getId())
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_OK)
                .body("phone", is("+34 612345678"))
                .body("is_phone_verified", is(true));

        Assert.isNull(userRepository.findById(otherUsers.get(0).getId()).get().getPhone(), "[Assertion failed] - the object argument must be null");
        Assert.isNull(userRepository.findById(otherUsers.get(1).getId()).get().getPhone(), "[Assertion failed] - the object argument must be null");
        Assert.isNull(userRepository.findById(otherUsers.get(2).getId()).get().getPhone(), "[Assertion failed] - the object argument must be null");
        Assert.notNull(userRepository.findById(userMe.getId()).get().getPhone(), "[Assertion failed] - this argument is required; it must not be null");
    }

    @Nonnull
    private UserEntity createUser(String name, String email) {
        return createUser(name, email, "+34 123456789", null);
    }

    @Nonnull
    private UserEntity createUser(String name, String email, String phone, String picture) {
        String hashPassword = new BCryptPasswordEncoder().encode("password");
        UserEntity userEntity = new UserEntity(name, hashPassword, email, true, phone, false, null,null, "GB", PlaytomicUserType.ONLINE);
        userEntity.setProfilePhotoFilename(picture);
        userEntity.setCommunicationsLanguage(Locale.ENGLISH);
        return userRepository.save(userEntity);
    }

    @Nonnull
    private String createAuthHeader(@Nullable Map<String, Object> extraClaims) {
        return createAuthHeader(extraClaims, userRepository.findAll().iterator().next());
    }

    @Nonnull
    private String createAuthHeader(@Nullable Map<String, Object> extraClaims, @Nonnull UserEntity user) {
        Collection<GrantedAuthority> authorities = testCredentialsService.getTestPrincipal().getUser().getOriginalAuthorities();
        AccessJwtToken token = extraClaims == null ?
            jwtTokenFactory.createAccessJwtToken(user.getId().toString(), null, authorities) :
            jwtTokenFactory.createAccessJwtTokenWithCustomClaims(user.getId().toString(), null, authorities, extraClaims);

        return "Bearer " + token.getToken();
    }

    @Nonnull
    private String createAuthHeader() {
        return createAuthHeader(null);
    }

    private void mockTenantResponse(@Nonnull String id, @Nullable String notFoundId) {
        String publicSingle = readAsText(getCurrentPackageAsClasspath() + "/mock_anemone_single_tenant_public.json");
        getMockServer(MOCK_TENANTS_PORT).
                when(request().
                        withPath("/v1/tenants/" + id)).
                respond(response().
                        withHeaders(new Header("Content-Type", "application/json; charset=utf-8")).
                        withStatusCode(200).
                        withBody(publicSingle));

        getMockServer(MOCK_TENANTS_PORT).
                when(request().
                        withPath("/v1/tenants")
                        .withQueryStringParameter("tenant_id", id)).
                respond(response().
                        withHeaders(new Header("Content-Type", "application/json; charset=utf-8")).
                        withStatusCode(200).
                        withBody("[" + publicSingle + "]"));

        getMockServer(MOCK_TENANTS_PORT).
                when(request().
                        withPath("/v1/tenants")
                        .withQueryStringParameter("tenant_id", notFoundId)).
                respond(response().
                        withHeaders(new Header("Content-Type", "application/json; charset=utf-8")).
                        withStatusCode(200).
                        withBody("[]"));
    }

    private void mockAnemoneTenantResponse(@Nonnull String id, @Nullable String notFoundId) {
        String publicSingle = readAsText(getCurrentPackageAsClasspath() + "/mock_anemone_single_tenant_anemone.json");
        getMockServer(MOCK_TENANTS_PORT).
                when(request().
                        withPath("/v1/tenants/" + id)).
                respond(response().
                        withHeaders(new Header("Content-Type", "application/json; charset=utf-8")).
                        withStatusCode(200).
                        withBody(publicSingle));

        getMockServer(MOCK_TENANTS_PORT).
                when(request().
                        withPath("/v1/tenants")
                        .withQueryStringParameter("tenant_id", id)).
                respond(response().
                        withHeaders(new Header("Content-Type", "application/json; charset=utf-8")).
                        withStatusCode(200).
                        withBody("[" + publicSingle + "]"));

        getMockServer(MOCK_TENANTS_PORT).
                when(request().
                        withPath("/v1/tenants")
                        .withQueryStringParameter("tenant_id", notFoundId)).
                respond(response().
                        withHeaders(new Header("Content-Type", "application/json; charset=utf-8")).
                        withStatusCode(200).
                        withBody("[]"));
    }

    private void mockCRMValidateAccountResponse(int code, String body) {
        getMockServer(MOCK_CRM_SERVER_PORT).reset().
                when(request().
                        withPath("/api2/validateaccount")).
                respond(response().
                        withHeaders(new Header("Content-Type", "application/json; charset=utf-8")).
                        withStatusCode(code).withBody(body));
    }

    private void mockCRMFindCustomerResponse(int code, String body) {
        getMockServer(MOCK_CRM_SERVER_PORT).reset().
                when(request().
                        withPath("/api2/findcustomer")).
                respond(response().
                        withHeaders(new Header("Content-Type", "application/json; charset=utf-8")).
                        withStatusCode(code).withBody(body));
    }

    private void mockCRMRegisterCustomerResponse(int code, String body) {
        getMockServer(MOCK_CRM_SERVER_PORT).reset().
                when(request().
                        withPath("/api3/registercustomer")).
                respond(response().
                        withHeaders(new Header("Content-Type", "application/json; charset=utf-8")).
                        withStatusCode(code).withBody(body));
    }

    private void mockCRMSetCustomerCommunicationsResponse(int code, String body) {
        getMockServer(MOCK_CRM_SERVER_PORT).reset().
            when(request().
                withPath("/api3/customerCommunications")).
            respond(response().
                withHeaders(new Header("Content-Type", "application/json; charset=utf-8")).
                withStatusCode(code).withBody(body));
    }
}

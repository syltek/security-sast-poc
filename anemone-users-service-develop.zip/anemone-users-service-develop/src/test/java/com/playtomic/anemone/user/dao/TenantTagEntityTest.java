package com.playtomic.anemone.user.dao;

import com.playtomic.anemone.user.dao.TenantTagEntity.Type;
import java.time.Clock;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import static org.assertj.core.api.Assertions.assertThat;
import org.junit.jupiter.api.Test;

class TenantTagEntityTest {

    @Test
    void test_isActiveAt() {
        var tag = new TenantTagEntity(new UserEntity(), "category-id", "tenant-id", Type.ANEMONE_CATEGORY, null);
        var clock = Clock.systemDefaultZone();
        assertThat(tag.isActiveAt(Instant.now(clock))).isTrue();

        tag = new TenantTagEntity(new UserEntity(), "category-id", "tenant-id", Type.ANEMONE_CATEGORY, Instant.now(clock).plus(5, ChronoUnit.DAYS));
        assertThat(tag.isActiveAt(Instant.now(clock))).isTrue();

        tag = new TenantTagEntity(new UserEntity(), "category-id", "tenant-id", Type.ANEMONE_CATEGORY, Instant.now(clock).minus(5, ChronoUnit.DAYS));
        assertThat(tag.isActiveAt(Instant.now(clock))).isFalse();
    }

}

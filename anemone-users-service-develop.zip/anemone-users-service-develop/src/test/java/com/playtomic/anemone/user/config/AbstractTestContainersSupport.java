package com.playtomic.anemone.user.config;

import com.playtomic.anemone.test.AbstractSpringContextAndMockServerTestSupport;
import javax.annotation.Nonnull;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.containers.JdbcDatabaseContainer;
import org.testcontainers.containers.MongoDBContainer;
import org.testcontainers.containers.MySQLContainer;
import org.testcontainers.utility.DockerImageName;

public abstract class AbstractTestContainersSupport extends AbstractSpringContextAndMockServerTestSupport {

    @Nonnull
    static final MongoDBContainer mongoDb = new MongoDBContainer(DockerImageName.parse("mongo:4.4")).withReuse(true);
    @Nonnull
    static final JdbcDatabaseContainer mySql = new MySQLContainer(DockerImageName.parse("mysql/mysql-server:5.7").asCompatibleSubstituteFor("mysql"))
        .withDatabaseName("anemone_users_service")
        .withUrlParam("sessionVariables", "sql_mode='STRICT_ALL_TABLES,NO_ENGINE_SUBSTITUTION,PIPES_AS_CONCAT'")
        .withUrlParam("connectionCollation", "utf8mb4_unicode_ci")
        .withUrlParam("characterSetResults", "UTF-8")
        .withUrlParam("characterEncoding", "UTF-8")
        .withUrlParam("serverTimezone", "UTC");

    static {
        mySql.withReuse(false);
        mySql.start();
        mongoDb.start();
    }

    @DynamicPropertySource
    static void properties(DynamicPropertyRegistry registry) {
        registry.add("spring.data.mongodb.uri", mongoDb::getReplicaSetUrl);
        registry.add("spring.datasource.url", mySql::getJdbcUrl);
        registry.add("spring.datasource.password", mySql::getPassword);
        registry.add("spring.datasource.username", mySql::getUsername);
    }

}

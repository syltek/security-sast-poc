package com.playtomic.anemone.user.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.playtomic.anemone.category.domain.BookingPrivilege;
import com.playtomic.anemone.category.domain.CancellationPolicyDuration;
import com.playtomic.anemone.category.domain.Category;
import com.playtomic.anemone.category.service.CategoryService;
import com.playtomic.anemone.domain.user.UserId;
import com.playtomic.anemone.user.dao.UserDocumentRepository;
import com.playtomic.anemone.user.dao.UserRepository;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import com.playtomic.anemone.user.service.anemone.MatchesServiceClient;
import com.playtomic.anemone.user.service.anemone.PaymentsServiceClient;
import com.playtomic.anemone.user.service.exception.UserNotFoundException;
import com.playtomic.anemone.user.service.messaging.MessagingBroker;
import java.time.Clock;
import java.time.Duration;
import java.time.temporal.ChronoUnit;
import java.util.Optional;
import javax.annotation.Nonnull;
import javax.validation.ClockProvider;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.context.MessageSource;

@ExtendWith(MockitoExtension.class)
class UserServiceTest {

    @Mock
    @Nonnull
    MessageSource messageSource;
    @Mock
    @Nonnull
    DiscoveryClient discoveryClient;
    @Mock
    @Nonnull
    private UserCredentialService userCredentialService;
    @Mock
    @Nonnull
    private UserRepository userRepository;
    @Mock
    @Nonnull
    private UserDocumentRepository userDocumentRepository;
    @Mock
    @Nonnull
    private MessagingBroker messagingBroker;
    @Mock
    @Nonnull
    private UserServicePersistenceComponent userServicePersistenceComponent;
    @Mock
    @Nonnull
    private PermissionService permissionService;
    @Mock
    @Nonnull
    private PaymentsServiceClient paymentsServiceClient;
    @Mock
    @Nonnull
    private MatchesServiceClient matchesServiceClient;
    @Mock
    @Nonnull
    private ClockProvider clockProvider;
    @Mock
    @Nonnull
    private CategoryService categoryService;

    @Nonnull
    private UserService userService;

    @BeforeEach
    void setUp() {
        when(clockProvider.getClock()).thenReturn(Clock.systemDefaultZone());
        this.userService = new UserService(messageSource, discoveryClient, userCredentialService, userRepository, userDocumentRepository,
            messagingBroker, userServicePersistenceComponent, paymentsServiceClient, matchesServiceClient, clockProvider,
            categoryService);
    }

    @Test
    void getCancellationPolicy_whenCancellationIsSet_cancellationPolicy() throws UserNotFoundException {
        var category = mock(Category.class);
        var bookingPrivilege = mock(BookingPrivilege.class);
        var expectedCancellationPolicy = new CancellationPolicyDuration(Duration.of(1, ChronoUnit.HOURS));
        when(bookingPrivilege.getCancellationPolicy()).thenReturn(expectedCancellationPolicy);
        when(category.getBookingPrivilege()).thenReturn(bookingPrivilege);
        var userId = UserId.valueOf("1");
        var tenantId = TenantId.valueOf("tenant-id");
        var date = clockProvider.getClock().instant();
        when(categoryService.getCategoryForUserActiveAt(userId, tenantId, date)).thenReturn(Optional.of(category));
        var actual = userService.getCancellationPolicy(userId, tenantId, date);
        assertThat(actual).contains(expectedCancellationPolicy);
    }

    @Test
    void getCancellationPolicy_noActiveCategory_empty() throws UserNotFoundException {
        var userId = UserId.valueOf("1");
        var tenantId = TenantId.valueOf("tenant-id");
        var date = clockProvider.getClock().instant();
        when(categoryService.getCategoryForUserActiveAt(userId, tenantId, date)).thenReturn(Optional.empty());
        var actual = userService.getCancellationPolicy(userId, tenantId, date);
        assertThat(actual).isEmpty();
    }

    @Test
    void getCancellationPolicy_invalidUserId_error() throws UserNotFoundException {
        var userId = UserId.valueOf("1");
        var tenantId = TenantId.valueOf("tenant-id");
        var date = clockProvider.getClock().instant();
        when(categoryService.getCategoryForUserActiveAt(userId, tenantId, date)).thenThrow(new UserNotFoundException());
        assertThatThrownBy(
            () -> userService.getCancellationPolicy(userId, tenantId, date))
            .isInstanceOf(UserNotFoundException.class);
    }
}

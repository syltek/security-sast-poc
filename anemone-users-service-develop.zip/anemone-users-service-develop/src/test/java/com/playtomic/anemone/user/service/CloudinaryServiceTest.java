package com.playtomic.anemone.user.service;

import com.playtomic.anemone.user.config.CloudinaryConfiguration;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;

import java.net.URL;


public class CloudinaryServiceTest {

    @Test
    public void test_url_generation_with_overlay() {
        CloudinaryConfiguration conf = new CloudinaryConfiguration();
        conf.setRootFolder("root");
        conf.setCloudName("cloud");
        conf.setApiKey("api");
        conf.setApiSecret("secret");
        CloudinaryService service = new CloudinaryService(conf);
        URL url = service.getURL("file1", "folder1", " gamer");

        System.out.println(url);

        Assertions.assertThat(url.getPath()).containsOnlyOnce("grayscale");
    }
}

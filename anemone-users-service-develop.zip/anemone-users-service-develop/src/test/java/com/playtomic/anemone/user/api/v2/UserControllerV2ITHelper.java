package com.playtomic.anemone.user.api.v2;

import static java.time.ZoneOffset.UTC;
import static org.mockserver.model.HttpRequest.request;
import static org.mockserver.model.HttpResponse.response;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.playtomic.anemone.converter.CustomMappingJackson2HttpMessageConverter;
import com.playtomic.anemone.user.config.AbstractTestContainersSupport;
import com.playtomic.anemone.user.dao.UserEntity;
import com.playtomic.anemone.user.domain.wallet.Wallet;
import com.playtomic.anemone.user.domain.wallet.WalletId;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.annotation.Nonnull;
import org.javamoney.moneta.Money;
import org.json.JSONArray;
import org.mockserver.model.Header;

public class UserControllerV2ITHelper extends AbstractTestContainersSupport {

    private final String WALLET_ENDPOINT = "/v2/wallets";
    private static final int MOCK_WALLETS_PORT = 10002;

    private final static Instant NOW = ZonedDateTime.of(2021, 1, 1, 12, 0, 0, 0, UTC).toInstant();


    public static void mockWalletResponse(CustomMappingJackson2HttpMessageConverter converter,
                                          @Nonnull Map<String, Long> userWallet)
        throws JsonProcessingException {
        var result = new ArrayList<Wallet>();

        if (userWallet.size() != 0) {
            for (var entry: userWallet.entrySet()) {
                String walletName = entry.getKey();
                var userId = userWallet.get(walletName);

                Wallet wallet = new Wallet();
                wallet.setWalletId(WalletId.valueOf("WALLET_ID_" + userId));
                wallet.setUserId(userId);
                wallet.setName(walletName);
                wallet.setBalance(Money.of(200, "EUR"));
                wallet.setActive(true);

                result.add(wallet);
            }
        }

        final String mockResponseBody1000 = converter.getObjectMapper().writeValueAsString(result);
        var emptyJsonArray = new JSONArray();

        getMockServer(MOCK_WALLETS_PORT).
            when(request().
                     withPath("/v2/wallets").
                     withQueryStringParameter("tenant_id", "tenant-id").
                     withQueryStringParameter("type", "MERCHANT").
                     withQueryStringParameter("page", "0").
                     withQueryStringParameter("size", "1000").
                     withQueryStringParameter("sort", "user_id,ASC")
            ).
            respond(response().
                        withHeaders(new Header("Content-Type", "application/json; charset=utf-8")).
                        withStatusCode(200).
                        withBody(mockResponseBody1000));

        getMockServer(MOCK_WALLETS_PORT).
            when(request().
                     withPath("/v2/wallets").
                     withQueryStringParameter("tenant_id", "tenant-id").
                     withQueryStringParameter("type", "MERCHANT").
                     withQueryStringParameter("page", "1").
                     withQueryStringParameter("size", "1000").
                     withQueryStringParameter("sort", "user_id,ASC")
            ).
            respond(response().
                        withHeaders(new Header("Content-Type", "application/json; charset=utf-8")).
                        withStatusCode(200).
                        withBody(emptyJsonArray.toString()));

    }

    public static void mockWalletResponseForUsers(CustomMappingJackson2HttpMessageConverter converter,
                                          @Nonnull List<UserEntity> users)
        throws JsonProcessingException {
        var result = new ArrayList<Wallet>();

        for (int i = 0; i < users.size(); i++) {
            Wallet wallet = new Wallet();
            wallet.setWalletId(WalletId.valueOf("WALLET_ID_" + i));
            wallet.setUserId(users.get(i).getId());
            wallet.setName("WALLET_" + i);
            wallet.setBalance(Money.of(200, "EUR"));
            wallet.setActive(true);

            result.add(wallet);
        }
        final String mockResponseBody1000 = converter.getObjectMapper().writeValueAsString(result);
        var emptyJsonArray = new JSONArray();

        getMockServer(MOCK_WALLETS_PORT).
            when(request().
                     withPath("/v2/wallets").
                     withQueryStringParameter("tenant_id", "tenant-id").
                     withQueryStringParameter("type", "MERCHANT").
                     withQueryStringParameter("page", "0").
                     withQueryStringParameter("size", "1000").
                     withQueryStringParameter("sort", "user_id,ASC")
            ).
            respond(response().
                        withHeaders(new Header("Content-Type", "application/json; charset=utf-8")).
                        withStatusCode(200).
                        withBody(mockResponseBody1000));

        getMockServer(MOCK_WALLETS_PORT).
            when(request().
                     withPath("/v2/wallets").
                     withQueryStringParameter("tenant_id", "tenant-id").
                     withQueryStringParameter("type", "MERCHANT").
                     withQueryStringParameter("page", "1").
                     withQueryStringParameter("size", "1000").
                     withQueryStringParameter("sort", "user_id,ASC")
            ).
            respond(response().
                        withHeaders(new Header("Content-Type", "application/json; charset=utf-8")).
                        withStatusCode(200).
                        withBody(emptyJsonArray.toString()));

    }

    public static void mockWalletResponse(@Nonnull CustomMappingJackson2HttpMessageConverter converter,
                                          @Nonnull List<Wallet> wallets) throws JsonProcessingException {
        var first1000 = wallets;
        List<Wallet> remainWallets = new ArrayList<>();
        if (wallets.size() > 1000) {
            first1000 = wallets.subList(0, Math.abs(wallets.size() - 1)/2);
            remainWallets = wallets.subList(Math.abs(wallets.size() - 1)/2, wallets.size() - 1);
        }
        final String mockResponseBody1000 = converter.getObjectMapper().writeValueAsString(first1000);
        final String mockResponseBodyRemain = converter.getObjectMapper().writeValueAsString(remainWallets);
        var emptyJsonArray = new JSONArray();

        getMockServer(MOCK_WALLETS_PORT).
            when(request().
                     withPath("/v2/wallets").
                     withQueryStringParameter("tenant_id", "tenant-id").
                     withQueryStringParameter("type", "MERCHANT").
                     withQueryStringParameter("page", "0").
                     withQueryStringParameter("size", "1000").
                     withQueryStringParameter("sort", "user_id,ASC")
            ).
            respond(response().
                        withHeaders(new Header("Content-Type", "application/json; charset=utf-8")).
                        withStatusCode(200).
                        withBody(mockResponseBody1000));

        getMockServer(MOCK_WALLETS_PORT).
            when(request().
                     withPath("/v2/wallets").
                     withQueryStringParameter("tenant_id", "tenant-id").
                     withQueryStringParameter("type", "MERCHANT").
                     withQueryStringParameter("page", "1").
                     withQueryStringParameter("size", "1000").
                     withQueryStringParameter("sort", "user_id,ASC")
            ).
            respond(response().
                        withHeaders(new Header("Content-Type", "application/json; charset=utf-8")).
                        withStatusCode(200).
                        withBody(mockResponseBodyRemain));

        getMockServer(MOCK_WALLETS_PORT).
            when(request().
                     withPath("/v2/wallets").
                     withQueryStringParameter("tenant_id", "tenant-id").
                     withQueryStringParameter("type", "MERCHANT").
                     withQueryStringParameter("page", "2").
                     withQueryStringParameter("size", "1000").
                     withQueryStringParameter("sort", "user_id,ASC")
            ).
            respond(response().
                        withHeaders(new Header("Content-Type", "application/json; charset=utf-8")).
                        withStatusCode(200).
                        withBody(emptyJsonArray.toString()));

    }

}

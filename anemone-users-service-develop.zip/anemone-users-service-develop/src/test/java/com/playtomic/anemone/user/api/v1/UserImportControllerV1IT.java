package com.playtomic.anemone.user.api.v1;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.mockserver.model.HttpRequest.request;
import static org.mockserver.model.HttpResponse.response;

import com.playtomic.anemone.UserApplication;
import com.playtomic.anemone.domain.user.User;
import com.playtomic.anemone.domain.user.UserId;
import com.playtomic.anemone.domain.user.UserRole;
import com.playtomic.anemone.jwt.AccessJwtToken;
import com.playtomic.anemone.jwt.JwtTokenFactory;
import com.playtomic.anemone.spring.config.AnemoneUserPrincipal;
import com.playtomic.anemone.test.TestCredentialsService;
import com.playtomic.anemone.test.WithMockUser;
import com.playtomic.anemone.user.config.AbstractTestContainersSupport;
import com.playtomic.anemone.user.dao.userimports.UserImportRepository;
import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import org.apache.http.HttpStatus;
import org.apache.http.entity.ContentType;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockserver.model.Header;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = UserApplication.class)
@ExtendWith(SpringExtension.class)
public class UserImportControllerV1IT extends AbstractTestContainersSupport {

    private static final int MOCK_TENANTS_PORT = 10000;

    public static final String USER_IMPORTS_API_V1 = "/v1/user_imports";

    @Autowired
    private UserImportRepository userImportRepository;

    @Autowired
    private JwtTokenFactory jwtTokenFactory;

    @Autowired
    private TestCredentialsService testCredentialsService;

    @AfterEach
    public void clearRepos() {
        userImportRepository.deleteAll();
        SecurityContextHolder.clearContext();
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    protected void testCreateUserImport_resultOK() throws IOException, InterruptedException {
        mockTenantResponse("tenant-id", "/mock_single_anemone_active_tenant_public.json");

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);

        File file = loadResource(getCurrentPackageAsClasspath() + "/test_ok.csv").getFile();

        given()
            .contentType(ContentType.MULTIPART_FORM_DATA.toString())
            .header("Authorization", authHeader)
            .queryParam("name", "Test Import")
            .queryParam("tenant_id", "tenant-id")
            .multiPart("file", file)
            .post(USER_IMPORTS_API_V1)
            .then()
            .log().all()
            .statusCode(HttpStatus.SC_OK)
            .body("tenant_id", is("tenant-id"))
            .body("status", is("PROCESSING"))
            .body("result.total", is(11))
            .body("result.processed", is(0))
            .body("result.succeeded", is(0))
            .body("result.failed", is(0));

    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    protected void testCreateUserImport_missingColumnsInRecord() throws IOException, InterruptedException {
        mockTenantResponse("tenant-id", "/mock_single_anemone_active_tenant_public.json");

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);

        File file = loadResource(getCurrentPackageAsClasspath() + "/test_missing_columns_in_record.csv").getFile();

        given()
            .contentType(ContentType.MULTIPART_FORM_DATA.toString())
            .header("Authorization", authHeader)
            .queryParam("name", "Test Import")
            .queryParam("tenant_id", "tenant-id")
            .multiPart("file", file)
            .post(USER_IMPORTS_API_V1)
            .then()
            .log().all()
            .statusCode(HttpStatus.SC_UNPROCESSABLE_ENTITY)
            .body("status", is("USER_IMPORT_TOO_FEW_COLUMNS_IN_RECORD"))
            .body("localized_message", is("Row 3 contains 3 columns, 7 were expected"));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_CUSTOMER)
    protected void testCreateUserImport_resultKO_forbidden() throws IOException {
        mockTenantResponse("tenant-id", "/mock_single_anemone_active_tenant_public.json");

        File file = loadResource(getCurrentPackageAsClasspath() + "/test_ok.csv").getFile();

        given()
            .contentType(ContentType.MULTIPART_FORM_DATA.toString())
            .header("Authorization", createAuthHeader())
            .queryParam("name", "Test Import")
            .queryParam("tenant_id", "tenant-id")
            .multiPart("file", file)
            .post(USER_IMPORTS_API_V1)
            .then()
            .log().all()
            .statusCode(HttpStatus.SC_FORBIDDEN);
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_ADMIN)
    void testCreateUserImport_tooManyRows_badRequest() throws IOException {
        mockTenantResponse("tenant-id", "/mock_single_anemone_active_tenant_public.json");

        File file = loadResource(getCurrentPackageAsClasspath() + "/test_too_many_rows.csv").getFile();

        given()
            .contentType(ContentType.MULTIPART_FORM_DATA.toString())
            .header("Authorization", createAuthHeader())
            .queryParam("name", "Test Import")
            .queryParam("tenant_id", "tenant-id")
            .multiPart("file", file)
            .post(USER_IMPORTS_API_V1)
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_BAD_REQUEST)
            .body("status", is("USER_IMPORT_FILE_CONTAINS_TOO_MANY_ROWS"));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_ADMIN)
    void testCreateUserImport_fileSizeTooBig_badRequest() throws IOException {
        mockTenantResponse("tenant-id", "/mock_single_anemone_active_tenant_public.json");

        File file = loadResource(getCurrentPackageAsClasspath() + "/test_file_size_too_big.csv").getFile();

        given()
            .contentType(ContentType.MULTIPART_FORM_DATA.toString())
            .header("Authorization", createAuthHeader())
            .queryParam("name", "Test Import")
            .queryParam("tenant_id", "tenant-id")
            .multiPart("file", file)
            .post(USER_IMPORTS_API_V1)
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_BAD_REQUEST)
            .body("status", is("USER_IMPORT_FILE_IS_TOO_BIG"));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_ADMIN)
    void testCreateUserImport_inactiveVenue() throws IOException {
        mockTenantResponse("tenant-id-inactive", "/mock_single_anemone_inactive_tenant_public.json");

        File file = loadResource(getCurrentPackageAsClasspath() + "/test_ok.csv").getFile();

        given()
            .contentType(ContentType.MULTIPART_FORM_DATA.toString())
            .header("Authorization", createAuthHeader())
            .queryParam("name", "Test Import")
            .queryParam("tenant_id", "tenant-id-inactive")
            .multiPart("file", file)
            .post(USER_IMPORTS_API_V1)
            .then()
            .log()
            .all()
            //product requested to allow import of users when venue is inactive
            .statusCode(HttpStatus.SC_OK);
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    protected void testReadUserImport_searchByTenantId_resultOK() throws IOException {
        mockTenantResponse("tenant-id", "/mock_single_anemone_active_tenant_public.json");

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);

        File file = loadResource(getCurrentPackageAsClasspath() + "/test_ok.csv").getFile();

        given()
            .contentType(ContentType.MULTIPART_FORM_DATA.toString())
            .header("Authorization", authHeader)
            .queryParam("name", "Test Import")
            .queryParam("tenant_id", "tenant-id")
            .multiPart("file", file)
            .post(USER_IMPORTS_API_V1)
            .then()
            .log().all()
            .statusCode(HttpStatus.SC_OK);

        file = loadResource(getCurrentPackageAsClasspath() + "/test_ok_with_errors.csv").getFile();

        given()
            .contentType(ContentType.MULTIPART_FORM_DATA.toString())
            .header("Authorization", authHeader)
            .queryParam("name", "Test Import w/ errors")
            .queryParam("tenant_id", "tenant-id")
            .multiPart("file", file)
            .post(USER_IMPORTS_API_V1)
            .then()
            .log().all()
            .statusCode(HttpStatus.SC_OK);

        given()
            .contentType(ContentType.MULTIPART_FORM_DATA.toString())
            .header("Authorization", authHeader)
            .queryParam("tenant_id", "tenant-id")
            .get(USER_IMPORTS_API_V1)
            .then()
            .log().all()
            .statusCode(HttpStatus.SC_OK)
            .body("$", hasSize(2))
            .body("error_details[0]", hasSize(0))
            .body("error_details[1]", hasSize(0));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_ADMIN)
    protected void testCreateUserImport_resultKO_mismatchColumns() throws IOException {
        mockTenantResponse("tenant-id", "/mock_single_anemone_active_tenant_public.json");

        File file = loadResource(getCurrentPackageAsClasspath() + "/test_mismatch_columns.csv").getFile();

        given()
            .contentType(ContentType.MULTIPART_FORM_DATA.toString())
            .header("Authorization", createAuthHeader())
            .queryParam("name", "Test Import")
            .queryParam("tenant_id", "tenant-id")
            .multiPart("file", file)
            .post(USER_IMPORTS_API_V1)
            .then()
            .log().all()
            .statusCode(HttpStatus.SC_BAD_REQUEST)
            .body("status", is("USER_IMPORT_MISMATCH"))
            .body("missing_headers", hasSize(4))
            .body("missing_headers[0]", is("phone_number"))
            .body("missing_headers[1]", is("birthdate"))
            .body("missing_headers[2]", is("category_name"))
            .body("missing_headers[3]", is("category_expires_at"))
            .body("extra_headers", hasSize(4))
            .body("extra_headers[0]", is("phone_numbers"))
            .body("extra_headers[1]", is("birth_date"))
            .body("extra_headers[2]", is("categoryname"))
            .body("extra_headers[3]", is("categoryexpiration"));

        given()
            .contentType(ContentType.MULTIPART_FORM_DATA.toString())
            .header("Authorization", createAuthHeader())
            .queryParam("name", "Test Import")
            .queryParam("tenant_id", "tenant-id")
            .queryParam("mismatch", "phone_number:phone_numbers")
            .multiPart("file", file)
            .post(USER_IMPORTS_API_V1)
            .then()
            .log().all()
            .statusCode(HttpStatus.SC_BAD_REQUEST)
            .body("status", is("USER_IMPORT_MISMATCH"))
            .body("missing_headers", hasSize(4))
            .body("missing_headers[0]", is("phone_number"))
            .body("missing_headers[1]", is("birthdate"))
            .body("missing_headers[2]", is("category_name"))
            .body("missing_headers[3]", is("category_expires_at"))
            .body("extra_headers", hasSize(4))
            .body("extra_headers[0]", is("phone_numbers"))
            .body("extra_headers[1]", is("birth_date"))
            .body("extra_headers[2]", is("categoryname"))
            .body("extra_headers[3]", is("categoryexpiration"));

        given()
            .contentType(ContentType.MULTIPART_FORM_DATA.toString())
            .header("Authorization", createAuthHeader())
            .queryParam("name", "Test Import")
            .queryParam("tenant_id", "tenant-id")
            .queryParam("mismatch", "phone_number:phone_numbers,birthdate:birth_date,category_name:categoryname,category_expires_at:categoryexpiration")
            .multiPart("file", file)
            .post(USER_IMPORTS_API_V1)
            .then()
            .log().all()
            .statusCode(HttpStatus.SC_OK);
    }

    @Nonnull
    public static Map<String, List<String>> tenantsIdsClaimData(@Nonnull String... tenantIds) {
        return Map.of("tenant_ids", Arrays.asList(tenantIds));
    }

    @Nonnull
    private User getCurrentUser() {
        AnemoneUserPrincipal currentUserDetails =
            (AnemoneUserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return currentUserDetails.getUser();
    }

    @Nonnull
    private String createAuthHeader() {
        return createAuthHeader(getCurrentUser().getId(), null);
    }

    @Nonnull
    private String createAuthHeader(@Nullable Map<String, Object> extraClaims) {
        return createAuthHeader(getCurrentUser().getId(), extraClaims);
    }

    @Nonnull
    private String createAuthHeader(@Nonnull UserId userId, @Nullable Map<String, Object> extraClaims) {
        Collection<GrantedAuthority> authorities = testCredentialsService.getTestPrincipal().getUser().getOriginalAuthorities();

        AccessJwtToken token = extraClaims == null ?
            jwtTokenFactory.createAccessJwtToken(userId.toString(), null, authorities) :
            jwtTokenFactory.createAccessJwtTokenWithCustomClaims(userId.toString(), null, authorities, extraClaims);

        return "Bearer " + token.getToken();
    }

    private void mockTenantResponse(@Nonnull String tenantId, @Nonnull String responseBodyPath) {

        String responseBody = readAsText(getCurrentPackageAsClasspath() + responseBodyPath);

        getMockServer(MOCK_TENANTS_PORT).
            when(request().
                withPath("/v1/tenants/" + tenantId)
            ).
            respond(response().
                withHeaders(new Header("Content-Type", "application/json; charset=utf-8")).
                withStatusCode(200).
                withBody(responseBody));

        getMockServer(MOCK_TENANTS_PORT).
            when(request().
                withPath("/v1/tenants/" + tenantId + "/communications")
            ).
            respond(response().
                withHeaders(new Header("Content-Type", "application/json; charset=utf-8")).
                withStatusCode(200).
                withBody((String) null));
    }

}

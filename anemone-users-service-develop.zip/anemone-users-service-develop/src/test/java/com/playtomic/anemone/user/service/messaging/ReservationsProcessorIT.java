package com.playtomic.anemone.user.service.messaging;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockserver.model.HttpRequest.request;
import static org.mockserver.model.HttpResponse.response;

import com.playtomic.anemone.UserApplication;
import com.playtomic.anemone.domain.location.DefaultLocation;
import com.playtomic.anemone.user.config.AbstractTestContainersSupport;
import com.playtomic.anemone.user.dao.PlaytomicUserType;
import com.playtomic.anemone.user.dao.UserEntity;
import com.playtomic.anemone.user.dao.UserRepository;
import com.playtomic.anemone.user.domain.reservation.MerchantUserId;
import com.playtomic.anemone.user.domain.reservation.Reservation;
import com.playtomic.anemone.user.domain.reservation.ReservationId;
import com.playtomic.anemone.user.domain.tenant.ReservationTenant;
import com.playtomic.anemone.user.domain.tenant.TenantAccountId;
import com.playtomic.anemone.user.domain.tenant.TenantAddress;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import com.playtomic.anemone.user.domain.users.UserLegacy;
import com.playtomic.anemone.user.model.CustomerUserProfile;
import com.playtomic.anemone.user.service.UserService;
import com.playtomic.anemone.user.service.exception.UserNotFoundException;
import java.net.MalformedURLException;
import java.time.ZoneId;
import java.util.Locale;
import javax.annotation.Nonnull;
import org.apache.commons.lang3.LocaleUtils;
import org.json.JSONObject;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockserver.client.MockServerClient;
import org.mockserver.model.Header;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.messaging.support.GenericMessage;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = UserApplication.class)
@ExtendWith(SpringExtension.class)
public class ReservationsProcessorIT extends AbstractTestContainersSupport {

    private static int MOCK_TENANTS_PORT = 10000;

    @Autowired
    private ReservationsProcessor processor;

    @Autowired
    private UserService userService;

    @Autowired
    private UserRepository userRepository;

    private ReservationTenant tenant;

    @BeforeEach
    public void setup() throws MalformedURLException {
        TenantAddress tenantAddress = new TenantAddress(
            "Fake Street 123",
            null,
            null,
            null,
            null,
            "Spain",
            "ES",
            new DefaultLocation(40.416729, -3.703339),
            ZoneId.of("Europe/Madrid")
        );
        tenant = new ReservationTenant(TenantId.valueOf("tenant-id"));
    }

    @AfterEach
    public void reset(@Autowired UserRepository userRepository) {
        resetMockServers();
        userRepository.deleteAll();
    }

    private long newUser() {
        UserEntity entity = new UserEntity("test-user", "", "user@email.com",  true, "", false, true, true, null, null,null, "ES", null,
                LocaleUtils.toLocale("es_ES"), PlaytomicUserType.ONLINE);
        userRepository.save(entity);

        return entity.getId();
    }



    @Test
    public void link_with_merchant_user_id() throws UserNotFoundException {
        mockTenantResponse();
        mockTenantResponseToGetByIds("tenant-id");
        long id = newUser();

        Reservation r =
            new Reservation(
                ReservationId.valueOf("reservation-id"),
                "CONFIRMED",
                UserLegacy.valueOf(id),
                tenant,
                MerchantUserId.valueOf("1")
                );

        ReservationEvent event = new ReservationEvent(null, r);

        processor.handle(new GenericMessage<>(event));

        CustomerUserProfile user = userService.getUserById(UserLegacy.valueOf(id));
        assertThat(user.getLinkedTenantsAccounts()).hasSize(1);
        assertThat(user.getLinkedTenantsAccounts().iterator().next().getMerchantUserId()).isEqualTo(TenantAccountId.valueOf("1"));
        assertThat(user.getLinkedTenantsAccounts().iterator().next().getTenantId()).isEqualTo(TenantId.valueOf("tenant-id"));
    }

    @Test
    public void autolink_with_no_merchant_user_id() throws UserNotFoundException {
        mockTenantResponse();
        MockServerClient crmMock = getMockServer(12345);

        crmMock
            .when(request()
                .withMethod("GET")
                .withQueryStringParameter("email", "user@email.com")
                .withPath("/api2/findcustomer"))
            .respond(response()
                .withHeader(Header.header("Content-Type", "application/json"))
                .withStatusCode(200)
                .withBody("{\"idCustomer\": 123, \"entity\": {\"idCustomerType\": \"147\"}}"));

        long id = newUser();
        Reservation r =
            new Reservation(
                ReservationId.valueOf("reservation-id"),
                "CONFIRMED",
                UserLegacy.valueOf(id),
                tenant,
                null
            );

        ReservationEvent event = new ReservationEvent(null, r);

        processor.handle(new GenericMessage<>(event));

        CustomerUserProfile user = userService.getUserById(UserLegacy.valueOf(id));
        assertThat(user.getLinkedTenantsAccounts()).hasSize(1);
        assertThat(user.getLinkedTenantsAccounts().iterator().next().getMerchantUserId()).isEqualTo(TenantAccountId.valueOf("123"));
        assertThat(user.getLinkedTenantsAccounts().iterator().next().getTenantId()).isEqualTo(TenantId.valueOf("tenant-id"));
        assertThat(user.getTenantTags().iterator().next().getTags()).hasSize(1);
        assertThat(user.getTenantTags().iterator().next().getTags()).contains("SYLTEK_CUSTOMER_TYPE_147");
        assertThat(user.getTenantTags().iterator().next().getTenantId()).isEqualTo(TenantId.valueOf("tenant-id"));

    }

    @Test
    public void autolink_with_no_merchant_user_id_not_existing() throws UserNotFoundException {
        mockTenantResponse();
        MockServerClient crmMock = getMockServer(12345);

        crmMock
            .when(request()
                .withMethod("GET")
                .withQueryStringParameter("email", "user@email.com")
                .withPath("/api2/findcustomer"))
            .respond(response()
                .withHeader(Header.header("Content-Type", "application/json"))
                .withStatusCode(200)
                .withBody("{\"error\":\"100\"}")); // CUSTOMER_NOT_FOUND

        long id = newUser();
        Reservation r =
            new Reservation(
                ReservationId.valueOf("reservation-id"),
                "CONFIRMED",
                UserLegacy.valueOf(id),
                tenant,
                null
            );

        ReservationEvent event = new ReservationEvent(null, r);

        processor.handle(new GenericMessage<>(event));

        CustomerUserProfile user = userService.getUserById(UserLegacy.valueOf(id));
        assertThat(user.getLinkedTenantsAccounts()).hasSize(0);
    }

    private void mockTenantResponse() {
        getMockServer(MOCK_TENANTS_PORT).
                when(request().
                        withPath("/v1/tenants/tenant-id")
                ).
                respond(response().
                        withHeaders(new Header("Content-Type", "application/json; charset=utf-8")).
                        withStatusCode(200).
                        withBody(getTenantMockResponse("tenant-id")));
    }

    private void mockTenantResponseToGetByIds(@Nonnull String tenantId) {

        getMockServer(MOCK_TENANTS_PORT).
            when(request()
                .withPath("/v1/tenants")
                .withQueryStringParameter("tenant_id",tenantId))
            .respond(response().
                withHeaders(new Header("Content-Type", "application/json; charset=utf-8"))
                .withStatusCode(200)
                .withBody("[" + getTenantMockResponse(tenantId) + "]"));
    }

    @Nonnull
    private String getTenantMockResponse(@Nonnull String tenantId) {
        JSONObject tenant = new JSONObject()
            .put("tenant_id", "tenant-id")
            .put("tenant_name", "Tenant")
            .put("communications_language", Locale.ENGLISH)
            .put("address", new JSONObject()
                .put("street", "Fake Street 123")
                .put("coordinate", new JSONObject()
                    .put("lat", "40.416729")
                    .put("lon", "-3.703339")
                )
                .put("timezone", "Europe/Madrid")
            )
            .put("url", "http://localhost:12345")
            .put("tenant_type", "SYLTEKCRM")
            .put("playtomic_status", "ACTIVE")
            .put("default_currency", "EUR")
            ;
        return tenant.toString();
    }
}

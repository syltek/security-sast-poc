package com.playtomic.anemone.user.api.v2;

import static io.restassured.RestAssured.given;
import static java.time.ZoneOffset.UTC;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.hasEntry;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.isEmptyOrNullString;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockserver.model.HttpRequest.request;
import static org.mockserver.model.HttpResponse.response;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.playtomic.anemone.UserApplication;
import com.playtomic.anemone.category.dao.CategoryDocument;
import com.playtomic.anemone.category.dao.CategoryRepository;
import com.playtomic.anemone.category.domain.CategoryId;
import com.playtomic.anemone.converter.CustomMappingJackson2HttpMessageConverter;
import com.playtomic.anemone.domain.user.User;
import com.playtomic.anemone.domain.user.UserId;
import com.playtomic.anemone.domain.user.UserRole;
import com.playtomic.anemone.jwt.AccessJwtToken;
import com.playtomic.anemone.jwt.JwtTokenFactory;
import com.playtomic.anemone.spring.config.AnemoneUserPrincipal;
import com.playtomic.anemone.test.TestCredentialsService;
import com.playtomic.anemone.test.WithMockUser;
import com.playtomic.anemone.user.config.AbstractTestContainersSupport;
import com.playtomic.anemone.user.config.TestClockProviderConfiguration.TestClockProvider;
import com.playtomic.anemone.user.dao.CoachAccountEntity;
import com.playtomic.anemone.user.dao.LinkedAccountEntity;
import com.playtomic.anemone.user.dao.PermissionRepository;
import com.playtomic.anemone.user.dao.PlaytomicUserType;
import com.playtomic.anemone.user.dao.TenantOwnerAccountEntity;
import com.playtomic.anemone.user.dao.UserEntity;
import com.playtomic.anemone.user.dao.UserRepository;
import com.playtomic.anemone.user.dao.UserRoleEntity;
import com.playtomic.anemone.user.dao.UserStatus;
import com.playtomic.anemone.user.dao.permissions.PermissionDocument;
import com.playtomic.anemone.user.domain.LinkingType;
import com.playtomic.anemone.user.domain.matches.MatchStatus;
import com.playtomic.anemone.user.domain.matches.SportId;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import com.playtomic.anemone.user.domain.users.UserLegacy;
import com.playtomic.anemone.user.domain.wallet.Wallet;
import com.playtomic.anemone.user.domain.wallet.WalletId;
import com.playtomic.anemone.user.model.UserGender;
import com.playtomic.anemone.user.model.permissions.PermissionLevel;
import com.playtomic.anemone.user.model.permissions.PermissionName;
import com.playtomic.anemone.user.model.role.PlaytomicUserRole;
import com.playtomic.anemone.user.service.anemone.EmailServiceClient;
import com.playtomic.anemone.user.service.email.EmailMessage;
import io.restassured.http.ContentType;
import io.restassured.parsing.Parser;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.time.Clock;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.validation.ClockProvider;
import liquibase.util.csv.CSVReader;
import org.apache.commons.io.IOUtils;
import org.apache.http.HttpStatus;
import org.assertj.core.api.Assertions;
import org.hamcrest.Matchers;
import org.javamoney.moneta.Money;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockserver.client.MockServerClient;
import org.mockserver.model.Header;
import org.mockserver.model.HttpStatusCode;
import org.mockserver.verify.VerificationTimes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.io.ClassPathResource;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = UserApplication.class)
@ExtendWith(SpringExtension.class)
public class UserControllerV2IT extends AbstractTestContainersSupport {

    private static final int MOCK_TENANTS_PORT = 10000;

    public static final String USERS_API_V2 = "/v2/users";

    private static final int MOCK_SMS_PORT = 10004;
    private final String SMS_ENDPOINT = "/v1/sms";

    private static final int MOCK_PAYMENTS_PORT = 9000;

    private static final int MOCK_MATCHES_PORT = 10003;

    private static final int MOCK_WALLETS_PORT = 10002;

    private final static Instant NOW = ZonedDateTime.of(2021, 1, 1, 12, 0, 0, 0, UTC).toInstant();

    @Nonnull
    @Autowired
    private UserRepository userRepository;

    @Nonnull
    @Autowired
    private PermissionRepository permissionRepository;
    @Nonnull
    @Autowired
    private JwtTokenFactory jwtTokenFactory;

    @Nonnull
    @Autowired
    private TestCredentialsService testCredentialsService;

    @Nonnull
    @Autowired
    private ClockProvider clockProvider;

    @Nonnull
    @Autowired
    private CategoryRepository categoryRepository;

    @Nonnull
    @MockBean
    EmailServiceClient emailServiceClient;

    @Autowired
    private TestClockProvider testClockProvider;

    @Autowired
    private CustomMappingJackson2HttpMessageConverter converter;

    @BeforeEach
    void beforeEach() {
        // Use fixed time for checking precomputed test token
        testClockProvider.setClock(Clock.fixed(NOW, ZoneOffset.UTC));
    }

    @AfterEach
    public void clearRepos() {
        userRepository.deleteAll();
        permissionRepository.deleteAll();
        categoryRepository.deleteAll();;
        SecurityContextHolder.clearContext();
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    public void test_post_user() {
        UserEntity userEntity = new UserEntity("Old user", "some-hash", "existing@domain.com", true, "+34 123456789", true, true, true, "ES", PlaytomicUserType.ONLINE);
        userRepository.save(userEntity);

        JSONObject address = new JSONObject()
            .put("street", "S1")
            .put("zip_code", "Z1")
            .put("city", "C1")
            .put("state", "S1")
            ;

        JSONObject o = new JSONObject()
            .put("email", "Existing@domain.com")
            .put("full_name", "An user name")
            .put("country_code", "ES")
            .put("communications_language", "es_ES")
            .put("address", address)
        ;

        // Repeated email
        given()
            .contentType("application/json")
            .header("Authorization", createAuthHeader())
            .body(o.toString())
            .when()
            .post(USERS_API_V2)
            .then()
            .statusCode(HttpStatus.SC_BAD_REQUEST)
        ;

        o = new JSONObject()
            .put("email", "new@domain.com")
            .put("full_name", "An user name")
            .put("phone", "+34 123456789")
            .put("country_code", "ES")
            .put("communications_language", "sv_SE")
            .put("address", address)
        ;

        // Repeated phone
        given()
            .contentType("application/json")
            .header("Authorization", createAuthHeader())
            .body(o.toString())
            .when()
            .post(USERS_API_V2)
            .then()
            .statusCode(HttpStatus.SC_UNPROCESSABLE_ENTITY)
        ;

        o = new JSONObject()
            .put("email", "new@domain.com")
            .put("full_name", "An user name")
            .put("phone", "+34 223456789")
            .put("country_code", "ES")
            .put("communications_language", "fi_FI")
            .put("address", address)
        ;

        // correct call
        given()
            .contentType("application/json")
            .header("Authorization",
                "Bearer " + jwtTokenFactory
                    .createAccessJwtToken(getCurrentUser().getId().getValue(), getCurrentUser().getEmail(), getCurrentUser().getOriginalAuthorities())
                    .getToken())
            .body(o.toString())
            .when()
            .post(USERS_API_V2)
            .then()
            .statusCode(HttpStatus.SC_OK)
            .body("user_id", is(notNullValue()))
            .body("address.city", is("C1"))
        ;

        UserEntity
            user =
            userRepository.findUserByEmail("new@domain.com").get();

        assertThat(user.getFullName()).isEqualTo("An user name");
        assertThat(user.isEmailVerified()).isFalse();
        assertThat(user.getPhone()).isEqualTo("+34 223456789");
        assertThat(user.getCountryCode()).isEqualTo("ES");
        assertThat(user.getCommunicationsLanguage()).isEqualTo("fi_FI");
        assertThat(user.getAddressCity()).isEqualTo("C1");
        assertThat(user.getCreatedBy()).isNotBlank().isEqualTo(getCurrentUser().getId().getValue());
        assertThat(user.getType()).isEqualTo(PlaytomicUserType.ONSITE);
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    public void test_post_user_with_extra_data() {
        mockTenantResponse("tenant-id", "/mock_anemone_single_tenant_anemone.json");

        UserEntity userEntity = new UserEntity("Old user", "some-hash", "existing@domain.com", true,
            "+34 123456789", true, true, true, "ES", PlaytomicUserType.ONLINE);
        userRepository.save(userEntity);

        JSONObject o = new JSONObject()
            .put("email", "new@domain.com")
            .put("full_name", "An user name")
            .put("phone", "+34 223456789")
            .put("country_code", "ES")
            .put("communications_language", "fi_FI")
            .put("gender", "MALE")
            .put("birth_date", "2020-01-15T00:00:00")
        ;

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);

        given()
            .contentType("application/json")
            .header("Authorization", createAuthHeader(extraClaims))
            .body(o.toString())
            .when()
            .post(USERS_API_V2)
            .then()
            .statusCode(HttpStatus.SC_OK)
            .body("user_id", is(notNullValue()))
            .body("gender", is("MALE"))
            .body("birth_date", is("2020-01-15T00:00:00"))
            .body("type", is("ONSITE"))
        ;
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    public void test_post_user_with_tenant_id() {
        mockTenantResponse("tenant-id", "/mock_anemone_single_tenant_anemone.json");
        mockTenantCommunicationsResponse("tenant-id", "{\"welcome_message\" : \"welcome_message\"}");

        UserEntity userEntity = new UserEntity("Old user", "some-hash", "existing@domain.com", true,
            "+34 123456789", true, true, true, "ES", PlaytomicUserType.ONLINE);
        userRepository.save(userEntity);

        JSONObject o = new JSONObject()
            .put("email", "new@domain.com")
            .put("full_name", "An user name")
            .put("phone", "+34 223456789")
            .put("country_code", "ES")
            .put("created_by_tenant_id", "tenant-id");

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);

        given()
            .contentType("application/json")
            .header("Authorization", createAuthHeader(extraClaims))
            .body(o.toString())
            .when()
            .post(USERS_API_V2)
            .then()
            .statusCode(HttpStatus.SC_OK)
            .body("user_id", is(notNullValue()))
            .body("communications_language", is("es_ES"))
            .body("type", is("ONSITE"));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    public void test_post_user_with_tenant_id_and_communications_null() {
        mockTenantResponse("tenant-id", "/mock_anemone_single_tenant_anemone.json");
        mockTenantCommunicationsResponse("tenant-id", null);

        UserEntity userEntity = new UserEntity("Old user", "some-hash", "existing@domain.com", true,
            "+34 123456789", true, true, true, "ES", PlaytomicUserType.ONLINE);
        userRepository.save(userEntity);

        JSONObject o = new JSONObject()
            .put("email", "new@domain.com")
            .put("full_name", "An user name")
            .put("phone", "+34 223456789")
            .put("country_code", "ES")
            .put("created_by_tenant_id", "tenant-id");

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);

        given()
            .contentType("application/json")
            .header("Authorization", createAuthHeader(extraClaims))
            .body(o.toString())
            .when()
            .post(USERS_API_V2)
            .then()
            .statusCode(HttpStatus.SC_OK)
            .body("user_id", is(notNullValue()));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_ANEMONE)
    public void testSearchUsersByUserId() throws Exception {
        List<UserEntity> users = Arrays.asList(
                createUser("User Test", "ok@email.com"),
                createUser("Angel Garcia", "angelgarcia@syltek.com"),
                createUser("Manuel Gonzalez", "manuelgonzalez@syltek.com"),
                createUser("Sergio Garcia", "sergiomoratilla@syltek.com"),
                createUser("Carlos Garcia", "carlosgarcia@syltek.com"),
                createUser("Fulano Perez", "fulano@perez.com")
        );

        users.get(1).setEmailVerified(false);
        users.get(1).setCountryCode("SE");
        userRepository.saveAll(users);

        // Search by id
        given()
                .param("user_id", users.get(1).getId())
                .header("Authorization", createAuthHeader())
                .get(USERS_API_V2)
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_OK)
                .body("$", hasSize(1))
                .body("[0].user_id", is(users.get(1).getId().toString()))
                .body("[0].email", is(users.get(1).getEmail()))
                .body("[0].phone", is(users.get(1).getPhone()))
                .body("[0].country_code", is(users.get(1).getCountryCode()))
                .body("[0].communications_language", is("es_ES"))  // es_ES because users are created as ES and customized afterwards
                .body("[0].country_code", is("SE"))
                .body("[0].is_email_verified", is(users.get(1).isEmailVerified()))
                .body("[0].is_phone_verified", is(users.get(1).isPhoneVerified()))
                .body("[0].is_validated", is(users.get(1).isEmailVerified()));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_CUSTOMER)
    public void test_get_by_username_role_customer() {
        // by name
        given()
                .param("name", "Garci")
                .header("Authorization", createAuthHeader())
                .get(USERS_API_V2)
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_FORBIDDEN)
        ;

        // by name but not tenant allowed
        given()
                .param("name", "Garci")
                .param("tenant_id", "tenant-id")
                .header("Authorization", createAuthHeader())
                .get(USERS_API_V2)
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_FORBIDDEN)
        ;
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    public void test_get_by_username_role_manager() {
        List<UserEntity> users = Arrays.asList(
                createUser("User Test", "ok@email.com"),
                createUser("Garcia Angel", "angelgarcia@syltek.com"),
                createUser("Gonzalez Manuel", "manuelgonzalez@syltek.com"),
                createUser("Garcia Sergio", "sergiomoratilla@syltek.com"),
                createUser("Garcia Carlos", "carlosgarcia@syltek.com"),
                createUser("Perez Fulano", "fulano@perez.com")
        );

        userRepository.saveAll(users);

        Map<String, List<String>> claimData = tenantsIdsClaimData("allowed-tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);

        // not allowed tenant-id
        given()
                .param("name", "Garci")
                .param("tenant_id", "forbidden-tenant-id")
                .header("Authorization", createAuthHeader(extraClaims))
                .get(USERS_API_V2)
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_FORBIDDEN)
        ;

        // allowed tenant od
        given()
                .param("name", "Garci")
                .param("tenant_id", "allowed-tenant-id")
                .header("Authorization", createAuthHeader(extraClaims))
                .get(USERS_API_V2)
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_OK)
                .body("$", hasSize(0))
        ;

        // link some user to the tenant
        users.get(4).setLinkedAccounts(Collections.singleton(
                new LinkedAccountEntity(users.get(3), "allowed-tenant-id", "1234", null, null)
        ));
        userRepository.saveAll(users);


        given()
                .param("name", "Garci")
                .param("tenant_id", "allowed-tenant-id")
                .header("Authorization", createAuthHeader(extraClaims))
                .get(USERS_API_V2)
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_OK)
                .body("$", hasSize(1))
        ;
    }


    @Test
    @WithMockUser(role = UserRole.ROLE_ANEMONE)
    public void testSearchUsersByUserRole() throws Exception {
        List<UserEntity> users = Arrays.asList(
                createUser("User Test", "ok@email.com"),
                createUser("Angel Garcia", "angelgarcia@syltek.com"),
                createUser("Manuel Gonzalez", "manuelgonzalez@syltek.com"),
                createUser("Sergio Garcia", "sergiomoratilla@syltek.com"),
                createUser("Carlos Garcia", "carlosgarcia@syltek.com"),
                createUser("Fulano Perez", "fulano@perez.com")
        );

        Set<UserRoleEntity> userRoles = new HashSet<>();
        userRoles.add(new UserRoleEntity(users.get(1), PlaytomicUserRole.ROLE_TENANT_MANAGER, "tenant-1"));
        users.get(1).setUserRoles(userRoles);
        userRepository.saveAll(users);

        // Search by id
        given()
                .param("user_role", "ROLE_TENANT_MANAGER")
                .header("Authorization", createAuthHeader())
                .get(USERS_API_V2)
                .then()
                .log().all()
                .statusCode(HttpStatus.SC_OK)
                .body("$", hasSize(1))
                .body("[0].user_id", is(users.get(1).getId().toString()))
                .body("[0].email", is(users.get(1).getEmail()))
                .body("[0].phone", is(users.get(1).getPhone()))
                .body("[0].country_code", is(users.get(1).getCountryCode()));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_ANEMONE)
    public void testSearchUsersByUserRoleAndTenantId() throws Exception {
        List<UserEntity> users = Arrays.asList(
                createUser("User Test", "ok@email.com"),
                createUser("Angel Garcia", "angelgarcia@syltek.com"),
                createUser("Manuel Gonzalez", "manuelgonzalez@syltek.com"),
                createUser("Sergio Garcia", "sergiomoratilla@syltek.com"),
                createUser("Carlos Garcia", "carlosgarcia@syltek.com"),
                createUser("Fulano Perez", "fulano@perez.com")
        );

        Set<UserRoleEntity> userRolesFindable = new HashSet<>();
        userRolesFindable.add(new UserRoleEntity(users.get(1), PlaytomicUserRole.ROLE_TENANT_MANAGER, "tenant-1"));
        users.get(1).setUserRoles(userRolesFindable);
        Set<UserRoleEntity> userRolesNoFindable = new HashSet<>();
        userRolesNoFindable.add(new UserRoleEntity(users.get(2), PlaytomicUserRole.ROLE_TENANT_MANAGER, "tenant-2"));
        users.get(2).setUserRoles(userRolesNoFindable);
        userRepository.saveAll(users);

        // Search by id
        given()
                .param("user_role", "ROLE_TENANT_MANAGER")
                .param("tenant_id", "tenant-1")
                .header("Authorization", createAuthHeader())
                .get(USERS_API_V2)
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_OK)
                .body("$", hasSize(1))
                .body("[0].user_id", is(users.get(1).getId().toString()))
                .body("[0].email", is(users.get(1).getEmail()))
                .body("[0].phone", is(users.get(1).getPhone()))
                .body("[0].country_code", is(users.get(1).getCountryCode()));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    public void testSearchUsersByHasLinkedAccountAndTenantId() throws Exception {
        List<UserEntity> users = Arrays.asList(
            createUser("User Test", "ok@email.com"),
            createUser("Angel Garcia", "angelgarcia@syltek.com"),
            createUser("Manuel Gonzalez", "manuelgonzalez@syltek.com"),
            createUser("Sergio Garcia", "sergiomoratilla@syltek.com"),
            createUser("Carlos Garcia", "carlosgarcia@syltek.com"),
            createUser("Fulano Perez", "fulano@perez.com")
        );

        Set<LinkedAccountEntity> linkedAccountEntities = new HashSet<>();
        linkedAccountEntities.add(new LinkedAccountEntity(users.get(0), "tenant-1", users.get(0).getId().toString(), true, LinkingType.MANUAL_LINK));
        users.get(0).setLinkedAccounts(linkedAccountEntities);

        Set<LinkedAccountEntity> linkedAccountNoFindable = new HashSet<>();
        linkedAccountNoFindable.add(new LinkedAccountEntity(users.get(1), "tenant-2", users.get(1).getId().toString(), true, LinkingType.MANUAL_LINK));
        users.get(1).setLinkedAccounts(linkedAccountNoFindable);

        userRepository.saveAll(users);

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-1");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);

        given()
            .param("has_linked_account", true)
            .param("tenant_id", "tenant-1")
            .header("Authorization", createAuthHeader(extraClaims))
            .get(USERS_API_V2)
            .then()
            .log().body()
            .statusCode(HttpStatus.SC_OK)
            .body("$", hasSize(1))
            .body("[0].user_id", is(users.get(0).getId().toString()))
        ;

        given()
            .param("has_linked_account", true)
            .param("tenant_id", "tenant-2")
            .header("Authorization", createAuthHeader(extraClaims))
            .get(USERS_API_V2)
            .then()
            .log().body()
            .statusCode(HttpStatus.SC_FORBIDDEN)
        ;

        // wrong param
        given()
            .param("tenant_id", "tenant-1")
            .header("Authorization", createAuthHeader(extraClaims))
            .get(USERS_API_V2)
            .then()
            .log().body()
            .statusCode(HttpStatus.SC_BAD_REQUEST)
        ;
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    public void testSearchUsersByHasCoachAccountAndTenantId() throws Exception {
        List<UserEntity> users = Arrays.asList(
            createUser("User Test", "ok@email.com"),
            createUser("Angel Garcia", "angelgarcia@syltek.com"),
            createUser("Manuel Gonzalez", "manuelgonzalez@syltek.com"),
            createUser("Sergio Garcia", "sergiomoratilla@syltek.com"),
            createUser("Carlos Garcia", "carlosgarcia@syltek.com"),
            createUser("Fulano Perez", "fulano@perez.com")
        );

        Set<CoachAccountEntity> coachAccountEntities = new HashSet<>();
        coachAccountEntities.add(new CoachAccountEntity(randomId(), users.get(0), "tenant-1", Arrays.asList(SportId.valueOf("PADEL")), "Some experience", "Some ages", "Some description"));
        users.get(0).setCoachAccounts(coachAccountEntities);

        Set<CoachAccountEntity> coachAccountEntitiesNoFindable = new HashSet<>();
        coachAccountEntitiesNoFindable.add(new CoachAccountEntity(randomId(), users.get(1), "tenant-2", Arrays.asList(SportId.valueOf("PADEL")), "Some experience", "Some ages", "Some description"));
        users.get(1).setCoachAccounts(coachAccountEntitiesNoFindable);

        userRepository.saveAll(users);

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-1");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);

        given()
            .param("has_coach_account", true)
            .param("tenant_id", "tenant-1")
            .header("Authorization", createAuthHeader(extraClaims))
            .get(USERS_API_V2)
            .then()
            .log().body()
            .statusCode(HttpStatus.SC_OK)
            .body("$", hasSize(1))
            .body("[0].user_id", is(users.get(0).getId().toString()))
        ;

        given()
            .param("has_coach_account", true)
            .param("tenant_id", "tenant-2")
            .header("Authorization", createAuthHeader(extraClaims))
            .get(USERS_API_V2)
            .then()
            .log().body()
            .statusCode(HttpStatus.SC_FORBIDDEN)
        ;

    }

    @Nonnull
    private String randomId() {
        return UUID.randomUUID().toString();
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    public void testCoachAccounts() throws Exception {
        UserEntity user = createUser("User Test", "ok@email.com");
        userRepository.save(user);

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-1");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);

        JSONArray sports = new JSONArray().put("PADEL");
        JSONObject o = new JSONObject()
            .put("experience", "Some experience")
            .put("ages", "Some age")
            .put("description", "Some description")
            .put("sport_ids", sports)
            ;

        //Put account with experience, ages and description == null
        JSONObject oNull = new JSONObject()
                .put("sport_ids", sports)
                ;

        given()
            .contentType(ContentType.JSON)
            .header("Authorization", createAuthHeader(extraClaims))
            .pathParam("user_id", user.getId())
            .pathParam("tenant_id", "tenant-1")
            .body(oNull.toString())
            .put(USERS_API_V2+"/{user_id}/coach_accounts/{tenant_id}")
            .then()
            .log().all()
            .statusCode(HttpStatus.SC_OK)
        ;

        //Put account
        given()
            .contentType(ContentType.JSON)
            .header("Authorization", createAuthHeader(extraClaims))
            .pathParam("user_id", user.getId())
            .pathParam("tenant_id", "tenant-1")
            .body(o.toString())
            .put(USERS_API_V2+"/{user_id}/coach_accounts/{tenant_id}")
            .then()
            .log().all()
            .statusCode(HttpStatus.SC_OK)
        ;

        //Get saved account
        given()
            .param("has_coach_account", true)
            .param("tenant_id", "tenant-1")
            .header("Authorization", createAuthHeader(UserId.valueOf(""+user.getId())))
            .pathParam("user_id", user.getId())
            .get(USERS_API_V2+"/{user_id}")
            .then()
            .log().all()
            .statusCode(HttpStatus.SC_OK)
            .body("coach_accounts[0].description", is("Some description"))
            .body("coach_accounts[0].ages", is("Some age"))
            .body("coach_accounts[0].experience", is("Some experience"))
            .body("coach_accounts[0].sport_ids[0]", is("PADEL"))
        ;

        //Put on forbidden tenant
        given()
            .contentType(ContentType.JSON)
            .header("Authorization", createAuthHeader(extraClaims))
            .pathParam("user_id", user.getId())
            .pathParam("tenant_id", "tenant-2")
            .body(o.toString())
            .put(USERS_API_V2+"/{user_id}/coach_accounts/{tenant_id}")
            .then()
            .log().all()
            .statusCode(HttpStatus.SC_FORBIDDEN)
        ;

        //Delete saved account
        given()
            .header("Authorization", createAuthHeader(extraClaims))
            .pathParam("user_id", user.getId())
            .pathParam("tenant_id", "tenant-1")
            .delete(USERS_API_V2+"/{user_id}/coach_accounts/{tenant_id}")
            .then()
            .log().all()
            .statusCode(HttpStatus.SC_OK)
        ;

        //Forbidden delete
        given()
            .header("Authorization", createAuthHeader(extraClaims))
            .pathParam("user_id", user.getId())
            .pathParam("tenant_id", "tenant-2")
            .delete(USERS_API_V2+"/{user_id}/coach_accounts/{tenant_id}")
            .then()
            .log().all()
            .statusCode(HttpStatus.SC_FORBIDDEN)
        ;

        given()
            .param("has_coach_account", true)
            .param("tenant_id", "tenant-1")
            .header("Authorization", createAuthHeader(UserId.valueOf(""+user.getId())))
            .pathParam("user_id", user.getId())
            .get(USERS_API_V2+"/{user_id}")
            .then()
            .log().all()
            .statusCode(HttpStatus.SC_OK)
            .body("coach_accounts[0].description", nullValue())
        ;
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_ANEMONE)
    public void testSearchUsersByUserIdList() throws Exception {
        List<UserEntity> users = Arrays.asList(
                createUser("User Test", "ok@email.com"),
                createUser("Angel Garcia", "angelgarcia@syltek.com"),
                createUser("Manuel Gonzalez", "manuelgonzalez@syltek.com"),
                createUser("Sergio Garcia", "sergiomoratilla@syltek.com"),
                createUser("Carlos Garcia", "carlosgarcia@syltek.com"),
                createUser("Fulano Perez", "fulano@perez.com")
        );

        users.get(1).setEmailVerified(false);
        users.get(1).setAcceptsPrivacyPolicy(false);
        users.get(3).setProfilePhotoFilename("photo");
        userRepository.saveAll(users);

        // Search by id
        given()
                .param("user_id", users.get(1).getId() + "," + users.get(3).getId() + "," + users.get(5).getId())
                .header("Authorization", createAuthHeader())
                .get(USERS_API_V2)
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_OK)
                .body("$", hasSize(2))
                .body("[0].user_id", is(users.get(3).getId().toString()))
                .body("[0].email", is(users.get(3).getEmail()))
                .body("[0].phone", is(users.get(3).getPhone()))
                .body("[0].picture", is(notNullValue()))
                .body("[0].is_email_verified", is(users.get(3).isEmailVerified()))
                .body("[0].is_phone_verified", is(users.get(3).isPhoneVerified()))
                .body("[0].is_validated", is(users.get(3).isEmailVerified()))
                .body("[0].country_code", is(users.get(3).getCountryCode()))
                .body("[0].communications_language", is("es_ES"))
                .body("[1].user_id", is(users.get(5).getId().toString()))
                .body("[1].email", is(users.get(5).getEmail()))
                .body("[1].phone", is(users.get(5).getPhone()))
                .body("[1].is_email_verified", is(users.get(5).isEmailVerified()))
                .body("[1].is_phone_verified", is(users.get(5).isPhoneVerified()))
                .body("[1].is_validated", is(users.get(5).isEmailVerified()))
                .body("[1].country_code", is(users.get(5).getCountryCode()))
                .body("[1].communications_language", is("es_ES"));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_CUSTOMER)
    public void testSearchUsersByNameAndEmail() throws Exception {
        List<UserEntity> users = Arrays.asList(
                createUser("User Test", "ok@email.com", "+44 123456789"),
                createUser("Garcia Angel", "angelgarcia@syltek.com", "+34 687929298"),
                createUser("Gonzalez Manuel ", "manuelgonzalez@syltek.com"),
                createUser("Garcia Sergio", "sergiomoratilla@syltek.com"),
                createUser("Garcia Carlos", "carlosgarcia@syltek.com"),
                createUser("Perez Fulano", "fulano@perez.com", "+34 66666666")
        );

        users.get(1).setEmailVerified(false);
        users.get(3).setProfilePhotoFilename("photo");
        users.get(3).setAcceptsPrivacyPolicy(false);
        userRepository.saveAll(users);

        UserId spanishUserId = UserLegacy.valueOf(users.get(5).getId());

        // Search by id
        given()
                .param("user_id", users.get(1).getId())
                .header("Authorization", createAuthHeader())
                .get(USERS_API_V2)
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_OK)
                .body("$", hasSize(1))
                .body("[0].user_id", is(users.get(1).getId().toString()))
                .body("[0].email", isEmptyOrNullString())
                .body("[0].country_code", is(users.get(1).getCountryCode()))
                .body("[0].communications_language", is("es_ES"));

        // Search by name
        given()
                .param("q", "garc")
                .header("Authorization", createAuthHeader())
                .get(USERS_API_V2)
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_OK)
                .body("$", hasSize(2))
                .body("[0].user_id", is(users.get(4).getId().toString()))
                .body("[0].email", isEmptyOrNullString())
                .body("[0].communications_language", is("es_ES"))
                .body("[1].user_id", is(users.get(1).getId().toString()))
                .body("[1].email", isEmptyOrNullString())
                .body("[1].communications_language", is("es_ES"));

        // Search by email (exact match)
        given()
                .param("q", "angelgarcia@syltek.com")
                .header("Authorization", createAuthHeader())
                .get(USERS_API_V2)
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_OK)
                .body("$", hasSize(1))
                .body("[0].user_id", is(users.get(1).getId().toString()))
                .body("[0].email", isEmptyOrNullString());

        // Search by email (partial match)
        given()
                .param("q", "angelgarcia")
                .header("Authorization", createAuthHeader())
                .get(USERS_API_V2)
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_OK)
                .body("$", hasSize(0));
        given()
                .param("q", "syltek.com")
                .header("Authorization", createAuthHeader())
                .get(USERS_API_V2)
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_OK)
                .body("$", hasSize(0));

        // Search by phone (exact match)
        given()
                .param("q", "+44 123456789")
                .header("Authorization", createAuthHeader(spanishUserId))
                .get(USERS_API_V2)
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_OK)
                .body("$", hasSize(1))
                .body("[0].user_id", is(users.get(0).getId().toString()));

        // Search by phone (exact match, wrong format, no country code)
        given()
                .param("q", "(687) 92-92-98")
                .header("Authorization", createAuthHeader(spanishUserId))
                .get(USERS_API_V2)
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_OK)
                .body("$", hasSize(1))
                .body("[0].user_id", is(users.get(1).getId().toString()));

        // Search by phone (exact match, wrong format)
        given()
                .param("q", "+34 687 92 92 98")
                .header("Authorization", createAuthHeader(spanishUserId))
                .get(USERS_API_V2)
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_OK)
                .body("$", hasSize(1))
                .body("[0].user_id", is(users.get(1).getId().toString()));

        // Search by phone (partial match)
        given()
                .param("q", "+34 687929")
                .header("Authorization", createAuthHeader(spanishUserId))
                .get(USERS_API_V2)
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_OK)
                .body("$", hasSize(0));

        // Not enough length
        given()
                .param("q", "ga")
                .header("Authorization", createAuthHeader())
                .get(USERS_API_V2)
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_OK)
                .body("$", hasSize(0));

        // Search by multiple emails
        given()
                .param("email", "angelgarcia@syltek.com", "manuelgonzalez@syltek.com", "other-bad@email.com")
                .header("Authorization", createAuthHeader())
                .get(USERS_API_V2)
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_OK)
                .body("$", hasSize(2))
                .body("[0].user_id", is(users.get(2).getId().toString()))
                .body("[0].email", is(users.get(2).getEmail()))
                .body("[0].phone", isEmptyOrNullString())
                .body("[1].user_id", is(users.get(1).getId().toString()))
                .body("[1].email", is(users.get(1).getEmail()))
                .body("[1].phone", isEmptyOrNullString())
        ;


        // Search by single unformatted phones with non-breaking white space and international prefix
        given()
                .param("phone", "+44\u00a0(123) 45-67-89")
                .header("Authorization", createAuthHeader(spanishUserId))
                .get(USERS_API_V2)
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_OK)
                .body("$", hasSize(1))
                .body("[0].user_id", is(users.get(0).getId().toString()))
                .body("[0].phone", is(users.get(0).getPhone()))
                .body("[0].email", isEmptyOrNullString())
        ;

        // Search by multiple phones
        given()
                .param("phone", "687 92 92 98", "+44 123456789", "68788888")
                .header("Authorization", createAuthHeader(spanishUserId))
                .get(USERS_API_V2)
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_OK)
                .body("$", hasSize(2))
                .body("[0].user_id", is(users.get(0).getId().toString()))
                .body("[0].phone", is(users.get(0).getPhone()))
                .body("[0].email", isEmptyOrNullString())
                .body("[1].user_id", is(users.get(1).getId().toString()))
                .body("[1].phone", is(users.get(1).getPhone()))
                .body("[1].email", isEmptyOrNullString())
        ;

        // Search by multiple email and phones: this is an intersection now.
        given()
                .param("email", "angelgarcia@syltek.com", "manuelgonzalez@syltek.com", "other-bad@email.com")
                .param("phone", "687 92 92 98", "+44\u00a0(123)456-789", "68788888")
                .header("Authorization", createAuthHeader(spanishUserId))
                .get(USERS_API_V2)
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_OK)
                .body("$", hasSize(1))
                .body("[0].user_id", is(users.get(1).getId().toString())) // angel
                .body("[0].email",   is(users.get(1).getEmail()))
                .body("[0].phone",   is(users.get(1).getPhone()))
        ;



        // Search by incorrect phone returns error
        given()
                .param("phone", "988*888")
                .header("Authorization", createAuthHeader(spanishUserId))
                .get(USERS_API_V2)
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_BAD_REQUEST)
                .body("status", is("INVALID_PHONE"))
                .body("localized_message", containsString("988*888"));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_ANEMONE)
    public void testSearchUsersWrongParameters() throws Exception {
        List<UserEntity> users = Arrays.asList(
                createUser("User Test", "ok@email.com"),
                createUser("Angel Garcia", "angelgarcia@syltek.com"),
                createUser("Manuel Gonzalez", "manuelgonzalez@syltek.com"),
                createUser("Sergio Garcia", "sergiomoratilla@syltek.com"),
                createUser("Carlos Garcia", "carlosgarcia@syltek.com"),
                createUser("Fulano Perez", "fulano@perez.com")
        );

        users.get(1).setEmailVerified(false);
        users.get(3).setProfilePhotoFilename("photo");
        userRepository.saveAll(users);

        // Search by id
        given()
                .header("Authorization", createAuthHeader())
                .get(USERS_API_V2)
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_BAD_REQUEST);
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_ADMIN)
    public void testSearchUsersWithAdminRoleReturnsEmailsAndPhones() throws Exception {
        List<UserEntity> users = Arrays.asList(
                createUser("User Test", "ok@email.com"),
                createUser("Garcia Angel", "angelgarcia@syltek.com"),
                createUser("Gonzalez Manuel", "manuelgonzalez@syltek.com"),
                createUser("Garcia Sergio", "sergiomoratilla@syltek.com"),
                createUser("GarciaCarlos", "carlosgarcia@syltek.com"),
                createUser("Perez Fulano", "fulano@perez.com")
        );

        users.get(1).setEmailVerified(false);
        users.get(3).setProfilePhotoFilename("photo");
        userRepository.saveAll(users);

        // Search by name
        given()
                .param("q", "garc")
                .header("Authorization", createAuthHeader())
                .get(USERS_API_V2)
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_OK)
                .body("$", hasSize(3))
                .body("[0].user_id", is(users.get(3).getId().toString()))
                .body("[0].email", is(users.get(3).getEmail()))
                .body("[0].phone", is(users.get(3).getPhone()))
                .body("[0].country_code", is(users.get(3).getCountryCode()))
                .body("[0].communications_language", is("es_ES"));
    }

    @Test
    public void testSearchUsersWithoutSession_ReturnsPublicUser() throws Exception {
        UserEntity user = createUser("User Test", "ok@email.com");
        given()
                .param("q", "User")
                .get(USERS_API_V2)
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("$", hasSize(1))
                .body("[0].user_id", is(user.getId().toString()))
                .body("[0].full_name", is(user.getFullName()))
                .body("[0].email", is(nullValue()))
                .body("[0].phone", is(nullValue()))
                .body("[0].address.street", is(nullValue()))
                .body("[0].address.city", is(user.getAddressCity()))
                .body("[0].address.zip_code", is(nullValue()))
                .body("[0].communications_language", is("es_ES"));
    }

    // Seriously I can't believe this test worked: createUser has a different id than WithMockUser
    @Test
    @WithMockUser(role = UserRole.ROLE_CUSTOMER)
    public void testSearchUsersWithUserMe() throws Exception {
        UserEntity user = createUser("User Test", "ok@email.com");
        createUser("Another user", "other@email.com");

        given()
                .param("user_id", "me")
                .header("Authorization", createAuthHeader(UserLegacy.valueOf(user.getId())))
                .get(USERS_API_V2)
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_OK)
                .body("$", hasSize(1))
                .body("[0].user_id", is(user.getId().toString()))
                .body("[0].full_name", is(user.getFullName()))
                .body("[0].communications_language", is("es_ES"));

    }

    @Test
    @WithMockUser(role = UserRole.ROLE_ANEMONE)
    public void testSearchUserByMerchantUserId() {
        List<UserEntity> users = Arrays.asList(
                createUser("User Test", "ok@email.com"),
                createUser("Angel Garcia", "angelgarcia@syltek.com"),
                createUser("Manuel Gonzalez", "manuelgonzalez@syltek.com"),
                createUser("Sergio Garcia", "sergiomoratilla@syltek.com"),
                createUser("Carlos Garcia", "carlosgarcia@syltek.com"),
                createUser("Fulano Perez", "fulano@perez.com")
        );

        users.get(4).setLinkedAccounts(Collections.singleton(
                new LinkedAccountEntity(users.get(4), "test-tenant", "1234", null, null)
        ));
        userRepository.saveAll(users);

        given()
                .param("merchant_user_id", "1234")
                .header("Authorization", createAuthHeader())
                .get(USERS_API_V2)
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_OK)
                .body("$", hasSize(1))
                .body("[0].user_id", is(users.get(4).getId().toString()));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_ANEMONE)
    public void testSearchUserWithMultipleLinkedAccountsOrder() {
        mockTenantResponse("/mock_anemone_search_multiple_tenant_public.json");

        List<UserEntity> users = Arrays.asList(
                createUser("User Test", "ok@email.com"),
                createUser("Angel Garcia", "angelgarcia@syltek.com"),
                createUser("Manuel Gonzalez", "manuelgonzalez@syltek.com"),
                createUser("Sergio Garcia", "sergiomoratilla@syltek.com"),
                createUser("Carlos Garcia", "carlosgarcia@syltek.com"),
                createUser("Fulano Perez", "fulano@perez.com")
        );

        users.get(4).setLinkedAccounts(new HashSet<>(Arrays.asList(
                new LinkedAccountEntity(users.get(4), "test-tenant-01", "1234", null, null),
                new LinkedAccountEntity(users.get(4), "test-tenant-02", "1235", null, null),
                new LinkedAccountEntity(users.get(4), "test-tenant-03", "1236", null, null),
                new LinkedAccountEntity(users.get(4), "test-tenant-04", "1237", null, null))
        ));
        userRepository.saveAll(users);

        given()
                .header("Authorization", createAuthHeader())
                .get(USERS_API_V2 + "/" + users.get(4).getId())
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_OK)
                .body("user_id", is(users.get(4).getId().toString()))
                .body("linked_accounts", hasSize(4))
                .body("linked_accounts[0].tenant_id", is("test-tenant-01"))
                .body("linked_accounts[1].tenant_id", is("test-tenant-02"))
                .body("linked_accounts[2].tenant_id", is("test-tenant-03"))
                .body("linked_accounts[3].tenant_id", is("test-tenant-04"));

        given()
                .header("Authorization", createAuthHeader())
                .get(USERS_API_V2 + "/" + users.get(4).getId())
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_OK)
                .body("user_id", is(users.get(4).getId().toString()))
                .body("linked_accounts", hasSize(4))
                .body("linked_accounts[0].tenant_id", is("test-tenant-01"))
                .body("linked_accounts[1].tenant_id", is("test-tenant-02"))
                .body("linked_accounts[2].tenant_id", is("test-tenant-03"))
                .body("linked_accounts[3].tenant_id", is("test-tenant-04"));

        given()
                .header("Authorization", createAuthHeader())
                .get(USERS_API_V2 + "/" + users.get(4).getId())
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_OK)
                .body("user_id", is(users.get(4).getId().toString()))
                .body("linked_accounts", hasSize(4))
                .body("linked_accounts[0].tenant_id", is("test-tenant-01"))
                .body("linked_accounts[1].tenant_id", is("test-tenant-02"))
                .body("linked_accounts[2].tenant_id", is("test-tenant-03"))
                .body("linked_accounts[3].tenant_id", is("test-tenant-04"));
    }


    @Test
    @WithMockUser(role = UserRole.ROLE_ANEMONE)
    public void testSearchUserByMerchantUserIdAndTenantId() {
        List<UserEntity> users = Arrays.asList(
                createUser("User Test", "ok@email.com"),
                createUser("Angel Garcia", "angelgarcia@syltek.com"),
                createUser("Manuel Gonzalez", "manuelgonzalez@syltek.com"),
                createUser("Sergio Garcia", "sergiomoratilla@syltek.com"),
                createUser("Carlos Garcia", "carlosgarcia@syltek.com"),
                createUser("Fulano Perez", "fulano@perez.com")
        );

        users.get(4).setLinkedAccounts(Collections.singleton(
                new LinkedAccountEntity(users.get(4), "test-tenant", "1234", null, null)
        ));
        users.get(3).setLinkedAccounts(Collections.singleton(
                new LinkedAccountEntity(users.get(3), "test-tenant-2", "1234", null, null)
        ));
        userRepository.saveAll(users);

        given()
                .param("merchant_user_id", "1234")
                .param("tenant_id", "test-tenant-2")
                .header("Authorization", createAuthHeader())
                .get(USERS_API_V2)
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_OK)
                .body("$", hasSize(1))
                .body("[0].user_id", is(users.get(3).getId().toString()));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_ANEMONE)
    public void testSearchUserByMergedMerchantUserIdAndTenantId_returns0ResultsOK() {
        List<UserEntity> users = Arrays.asList(
                createUser("User Test", "ok@email.com"),
                createUser("Angel Garcia", "angelgarcia@syltek.com"),
                createUser("Manuel Gonzalez", "manuelgonzalez@syltek.com"),
                createUser("Sergio Garcia", "sergiomoratilla@syltek.com"),
                createUser("Carlos Garcia", "carlosgarcia@syltek.com"),
                createUser("Fulano Perez", "fulano@perez.com")
        );

        users.get(4).setLinkedAccounts(Collections.singleton(
                new LinkedAccountEntity(users.get(4), "test-tenant", "1234", null, null)
        ));
        users.get(3).setLinkedAccounts(Collections.singleton(
                new LinkedAccountEntity(users.get(3), "test-tenant-2", "1235", null, null)
        ));
        userRepository.saveAll(users);

        given()
                .param("merchant_user_id", "1235")
                .param("tenant_id", "test-tenant")
                .header("Authorization", createAuthHeader())
                .get(USERS_API_V2)
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_OK)
                .body("$", hasSize(0));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_ANEMONE)
    public void testSearchUserByUserRoleAndMerchantUserIdAndTenantId() {
        List<UserEntity> users = Arrays.asList(
                createUser("User Test", "ok@email.com"),
                createUser("Angel Garcia", "angelgarcia@syltek.com"),
                createUser("Manuel Gonzalez", "manuelgonzalez@syltek.com"),
                createUser("Sergio Garcia", "sergiomoratilla@syltek.com"),
                createUser("Carlos Garcia", "carlosgarcia@syltek.com"),
                createUser("Fulano Perez", "fulano@perez.com")
        );

        Set<UserRoleEntity> userRoles = new HashSet<>();
        userRoles.add(new UserRoleEntity(users.get(4), PlaytomicUserRole.ROLE_TENANT_MANAGER, "test-tenant"));
        users.get(4).setUserRoles(userRoles);

        users.get(4).setLinkedAccounts(Collections.singleton(
                new LinkedAccountEntity(users.get(4), "test-tenant", "1234", null, null)
        ));
        users.get(3).setLinkedAccounts(Collections.singleton(
                new LinkedAccountEntity(users.get(3), "test-tenant-2", "1234", null, null)
        ));
        userRepository.saveAll(users);

        given()
                .param("user_role", "ROLE_TENANT_MANAGER")
                .param("merchant_user_id", "1234")
                .param("tenant_id", "test-tenant")
                .header("Authorization", createAuthHeader())
                .get(USERS_API_V2)
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_OK)
                .body("$", hasSize(1))
                .body("[0].user_id", is(users.get(4).getId().toString()));
    }


    @Test
    @WithMockUser(role = UserRole.ROLE_ANEMONE)
    public void testSearchUserByMerchantUserIdAndTenantIdMultipleLinkedAccounts() {
        List<UserEntity> users = Arrays.asList(
                createUser("User Test", "ok@email.com"),
                createUser("Angel Garcia", "angelgarcia@syltek.com"),
                createUser("Manuel Gonzalez", "manuelgonzalez@syltek.com"),
                createUser("Sergio Garcia", "sergiomoratilla@syltek.com"),
                createUser("Carlos Garcia", "carlosgarcia@syltek.com"),
                createUser("Fulano Perez", "fulano@perez.com")
        );

        users.get(4).setLinkedAccounts(new HashSet<>(Arrays.asList(
                new LinkedAccountEntity(users.get(4), "test-tenant", "1234", null, null),
                new LinkedAccountEntity(users.get(4), "test-tenant-2", "1234", null, null)
        )));
        userRepository.saveAll(users);

        given()
                .param("merchant_user_id", "1234")
                .param("tenant_id", "test-tenant")
                .header("Authorization", createAuthHeader())
                .get(USERS_API_V2)
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_OK)
                .body("$", hasSize(1))
                .body("[0].user_id", is(users.get(4).getId().toString()));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_ANEMONE)
    public void testSearchUsersByIsMailVerified() throws Exception {
        List<UserEntity> users = Arrays.asList(
                createUser("User Test", "ok@email.com"),
                createUser("Angel Garcia", "angelgarcia@syltek.com"),
                createUser("Manuel Gonzalez", "manuelgonzalez@syltek.com"),
                createUser("Sergio Garcia", "sergiomoratilla@syltek.com"),
                createUser("Carlos Garcia", "carlosgarcia@syltek.com"),
                createUser("Fulano Perez", "fulano@perez.com")
        );

        users.get(1).setEmailVerified(false);
        userRepository.saveAll(users);

        given()
                .header("Authorization", createAuthHeader())
                .queryParam("email", "angelgarcia@syltek.com")
                .queryParam("is_email_verified", "false")
                .get(USERS_API_V2)
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_OK)
                .body("$", hasSize(1))
                .body("[0].user_id", is(users.get(1).getId().toString()))
                .body("[0].email", is(users.get(1).getEmail()))
                .body("[0].phone", is(users.get(1).getPhone()))
                .body("[0].is_email_verified", is(users.get(1).isEmailVerified()))
                .body("[0].is_phone_verified", is(users.get(1).isPhoneVerified()))
                .body("[0].is_validated", is(users.get(1).isEmailVerified()));

        given()
                .header("Authorization", createAuthHeader())
                .queryParam("email", "angelgarcia@syltek.com")
                .queryParam("is_email_verified", "true")
                .get(USERS_API_V2)
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_OK)
                .body("$", hasSize(0));

        given()
                .header("Authorization", createAuthHeader())
                .queryParam("email", "angelgarcia@syltek.com")
                .get(USERS_API_V2)
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_OK)
                .body("$", hasSize(1));
    }

    // Seriously I can't believe this test worked: createUser has a different id than WithMockUser
    @Test
    @WithMockUser(role = UserRole.ROLE_CUSTOMER)
    public void testGetUserProfile() throws Exception {
        mockTenantResponse("/mock_anemone_search_single_tenant_public.json");

        UserEntity userMe = createUser("User Test", "ok@email.com");
        LinkedAccountEntity linkedAccountEntity = new LinkedAccountEntity(userMe, "tenant-id", "1", null, null);
        userMe.setLinkedAccounts(Collections.singleton(linkedAccountEntity));
        userMe.setPhoneVerified(false);
        userRepository.save(userMe);

        UserEntity userOther = createUser("Another user", "other@email.com");

        // My user should contain all data
        given()
                .header("Authorization", createAuthHeader(UserLegacy.valueOf(userMe.getId())))
                .get(USERS_API_V2 + "/me")
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_OK)
                .body("user_id", is(userMe.getId().toString()))
                .body("full_name", is(userMe.getFullName()))
                .body("email", is(userMe.getEmail()))
                .body("phone", is(userMe.getPhone()))
                .body("is_email_verified", is(userMe.isEmailVerified()))
                .body("is_phone_verified", is(userMe.isPhoneVerified()))
                .body("is_validated", is(userMe.isEmailVerified()))
                .body("accepts_privacy", is(userMe.getAcceptsPrivacyPolicy()))
                .body("accepts_commercial", is(userMe.getAcceptsCommercialCommunications()))
                .body("linked_accounts", hasSize(1))
                .body("linked_accounts[0].tenant_id", is(linkedAccountEntity.getTenantId()))
                .body("linked_accounts[0].merchant_user_id", is(linkedAccountEntity.getMerchantUserId()))
                .body("country_code", is(userMe.getCountryCode()))
                .body("communications_language", is("es_ES"));

         // Other user should contain public data only
        given()
                .header("Authorization", createAuthHeader())
                .get(USERS_API_V2 + "/" + userOther.getId())
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_OK)
                .body("user_id", is(userOther.getId().toString()))
                .body("full_name", is(userOther.getFullName()))
                .body("email", is(nullValue()))
                .body("phone", is(nullValue()))
                .body("is_email_verified", is(userOther.isEmailVerified()))
                .body("is_phone_verified", is(userOther.isPhoneVerified()))
                .body("is_validated", is(userOther.isEmailVerified()))
                .body("accepts_privacy", is(nullValue()))
                .body("accepts_commercial", is(nullValue()))
                .body("linked_accounts", is(nullValue()))
                .body("country_code", is(userOther.getCountryCode()))
                .body("communications_language", is("es_ES"))
                .body("address", is(notNullValue()))
                .body("address.state", is(nullValue()))
                .body("address.zip_code", is(nullValue()))
                .body("address.street", is(nullValue()))
                .body("address.city", is(userOther.getAddressCity()))
                .body("address.country_code", is(userOther.getCountryCode()));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_ADMIN)
    public void testGetUserProfileWithExportPermissions() throws Exception {
        // when user require active permissions
        var withActivePermissions = true;
        var permissionsList = PermissionName.values();

        mockTenantResponse("/mock_anemone_search_single_tenant_public.json");

        UserEntity userMe = createUser("User Test", "ok@email.com");
        LinkedAccountEntity linkedAccountEntity = new LinkedAccountEntity(userMe, "tenant-id", "1", null, null);
        userMe.setLinkedAccounts(Collections.singleton(linkedAccountEntity));
        userMe.setPhoneVerified(false);
        userRepository.save(userMe);

        // given all permission
        var permissions = new EnumMap<PermissionName, PermissionLevel>(PermissionName.class);
        for (var permission : permissionsList) {
            permissions.put(permission, PermissionLevel.READ_WRITE);
        }

        PermissionDocument permissionDoc = new PermissionDocument(
            UUID.randomUUID().toString(),
            UserId.valueOf(userMe.getId().toString()),
            TenantId.valueOf("tenant-id"),
            permissions);
        permissionRepository.save(permissionDoc);

        UserEntity userOther = createUser("Another user", "other@email.com");

        // should get users with all active permissions
        var body = given()
            .header("Authorization", createAuthHeader(UserLegacy.valueOf(userMe.getId())))
            .contentType(ContentType.JSON)
            .param("with_active_permissions", withActivePermissions)
            .get(USERS_API_V2 + "/me")
            .then()
            .log().body()
            .statusCode(HttpStatus.SC_OK)
            .body("active_permissions", Matchers.hasSize(1))
            .extract().body();

        var target = body.jsonPath().getMap("active_permissions.permissions[0]");
        var permissionList = permissions.keySet().stream()
                                        .map(PermissionName::name)
                                        .collect(Collectors.toList());
        assertThat(target.keySet()).hasSameElementsAs(permissionList);
        assertThat(target.keySet().contains(PermissionName.EXPORT_CUSTOMER_PERMISSION.name())).isTrue();
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_CUSTOMER)
    public void test_anonymize_user_profile_without_restrictions_forbidden() {
        String userId = "1234";

        String body = "{"
            + "\"confirmation\": \"I have proof of consent to anonymize user " + userId+ "\""
            + "}";

        given()
            .header("Authorization", createAuthHeader())
            .contentType(ContentType.JSON)
            .body(body)
            .post(USERS_API_V2 + "/" +userId + "/anonymize")
            .then()
            .log().body()
            .statusCode(HttpStatus.SC_FORBIDDEN);
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_ADMIN)
    public void test_anonymize_user_profile_without_restrictions_ok() {
        String userName = "User Test";
        String userEmail = "ok@email.com";
        UserEntity testUser = createUser(userName, userEmail);
        LinkedAccountEntity linkedAccountEntity = new LinkedAccountEntity(testUser, "tenant-id", "1", null, null);
        testUser.setLinkedAccounts(Collections.singleton(linkedAccountEntity));
        testUser.setPhoneVerified(true);
        testUser.setEmailVerified(true);
        testUser.setFacebookId("faceId");
        testUser.setGoogleId("googleId");
        testUser.setPhone("0044333333333");
        testUser.setBio("bla bla bla");
        userRepository.save(testUser);

        // My user should contain all data
        String body = "{"
            + "\"confirmation\": \"I have proof of consent to anonymize user "+testUser.getId()+"\""
            + "}";

        given()
            .header("Authorization", createAuthHeader())
            .contentType(ContentType.JSON)
            .body(body)
            .post(USERS_API_V2 + "/" + testUser.getId() + "/anonymize")
            .then()
            .log().body()
            .statusCode(HttpStatus.SC_OK);

        UserEntity anonymizeUser = userRepository.findById(testUser.getId()).orElseThrow();
        assertThat(anonymizeUser.getFullName()).isNotEqualTo(userName);
        assertThat(anonymizeUser.getEmail()).isNotEqualTo(userEmail);
        assertThat(anonymizeUser.getPasswordHash()).isEmpty();
        assertThat(anonymizeUser.getBio()).isNull();
        assertThat(anonymizeUser.getPhone()).isNull();
        assertThat(anonymizeUser.isEmailVerified()).isFalse();
        assertThat(anonymizeUser.isPhoneVerified()).isFalse();
        assertThat(anonymizeUser.getAddressCity()).isNull();
        assertThat(anonymizeUser.getAddressState()).isNull();
        assertThat(anonymizeUser.getAddressStreet()).isNull();
        assertThat(anonymizeUser.getAddressZipCode()).isNull();
        assertThat(anonymizeUser.getGoogleId()).isNull();
        assertThat(anonymizeUser.getFacebookId()).isNull();
        assertThat(anonymizeUser.isDeleted()).isTrue();
        assertThat(anonymizeUser.getStatus()).isEqualTo(UserStatus.DISABLED);
    }

    @Test
    @WithMockUser(userId = "user-id-1", role = UserRole.ROLE_CUSTOMER)
    public void test_anonymize_user_profile_with_restrictions_forbidden() {
        String otherUserId = "1234";

        given()
                .header("Authorization", createAuthHeader())
                .contentType(ContentType.JSON)
                .delete(USERS_API_V2 + "/" + otherUserId + "/anonymize")
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_FORBIDDEN);
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_CUSTOMER)
    public void test_anonymize_user_profile_with_restrictions_ok() {
        UserEntity user = createUser("user to delete", "email@fake.com");
        String userId = user.getId().toString();

        mockPaymentsResponse(userId, true);
        mockMatchesResponse(userId, true);

        given()
                .header("Authorization", createAuthHeader(UserId.valueOf(userId)))
                .contentType(ContentType.JSON)
                .delete(USERS_API_V2 + "/" + userId + "/anonymize")
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_NO_CONTENT);
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_CUSTOMER)
    public void test_anonymize_user_profile_with_debts_error() {
        UserEntity user = createUser("user to delete", "email@fake.com");
        String userId = user.getId().toString();

        mockPaymentsResponse(userId, false);
        mockMatchesResponse(userId, true);

        given()
                .header("Authorization", createAuthHeader(UserId.valueOf(userId)))
                .contentType(ContentType.JSON)
                .delete(USERS_API_V2 + "/" + userId + "/anonymize")
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_CONFLICT);
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_CUSTOMER)
    public void test_anonymize_user_profile_with_recent_match() {
        UserEntity user = createUser("user to delete", "email@fake.com");
        String userId = user.getId().toString();

        mockPaymentsResponse(userId, true);
        mockMatchesResponse(userId, false);

        given()
                .header("Authorization", createAuthHeader(UserId.valueOf(userId)))
                .contentType(ContentType.JSON)
                .delete(USERS_API_V2 + "/" + userId + "/anonymize")
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_CONFLICT);
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_CUSTOMER)
    public void testGetUserProfile_notFound() throws Exception {
        // My user should contain all data
        given()
                .header("Authorization", createAuthHeader())
                .get(USERS_API_V2 + "/2131443")
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_NOT_FOUND);
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_CUSTOMER)
    public void testResendValidationEmail() {
        UserEntity userMe = createUser("User Test", "ok@email.com");
        userRepository.save(userMe);

        given()
                .header("Authorization", createAuthHeader(UserLegacy.valueOf(userMe.getId())))
                .contentType(ContentType.JSON)
                .body("{\"return_path\": \"/v1/sample/url\"}")
                .post(USERS_API_V2 + "/me/validation_email")
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_OK);
        verify(emailServiceClient, times(1)).sendEmail(any(EmailMessage.class));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_CUSTOMER)
    public void testResendValidationEmailWithContentTypeAndEmptyObjectAsBody() {
        UserEntity userMe = createUser("User Test", "ok@email.com");
        userRepository.save(userMe);

        given()
                .header("Authorization", createAuthHeader(UserLegacy.valueOf(userMe.getId())))
                .contentType(ContentType.JSON)
                .body("{}")
                .post(USERS_API_V2 + "/me/validation_email")
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_OK);

        verify(emailServiceClient, times(1)).sendEmail(any(EmailMessage.class));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_CUSTOMER)
    public void testResendValidationEmailWithContentTypeNoBody() {
        UserEntity userMe = createUser("User Test", "ok@email.com");
        userRepository.save(userMe);

        given()
                .header("Authorization", createAuthHeader(UserLegacy.valueOf(userMe.getId())))
                .contentType(ContentType.JSON)
                .post(USERS_API_V2 + "/me/validation_email")
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_OK);

        verify(emailServiceClient, times(1)).sendEmail(any(EmailMessage.class));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_CUSTOMER)
    public void testValidatePhoneSMS(){
        UserEntity userMe = userRepository.save(createUser("User Test", "ok@email.com"));

        MockServerClient mockServerSmsService = mockSMSService(HttpStatusCode.OK_200);

        JSONObject body = new JSONObject();
        body.put("phone", "+34 111111111");

        given()
                .header("Authorization", createAuthHeader(UserLegacy.valueOf(userMe.getId())))
                .contentType(ContentType.JSON)
                .body(body.toString())
                .post(USERS_API_V2 + "/me/validation_sms")
                .then()
                .statusCode(HttpStatus.SC_OK);

        mockServerSmsService.verify(
                request()
                        .withPath(SMS_ENDPOINT)
                        .withMethod("POST"),
                VerificationTimes.once()
        );

        userMe.setPhone((String) body.get("phone"));
        userMe.setPhoneVerified(true);
        userRepository.save(userMe);

        given()
                .header("Authorization", createAuthHeader(UserLegacy.valueOf(userMe.getId())))
                .contentType(ContentType.JSON)
                .body(body.toString())
                .post(USERS_API_V2 + "/me/validation_sms")
                .then()
                .statusCode(HttpStatus.SC_UNPROCESSABLE_ENTITY);

        // userId has to be numeric
        int otherUserId = 100000;
        given()
                .header("Authorization", createAuthHeader(UserLegacy.valueOf(userMe.getId())))
                .contentType(ContentType.JSON)
                .body(body.toString())
                .post(USERS_API_V2 + "/" + otherUserId + "/validation_sms")
                .then()
                .statusCode(HttpStatus.SC_FORBIDDEN);
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    public void test_delete_user_role_manager() {
        UserEntity userOther = createUser("Another user", "other@email.com");

        given()
                .header("Authorization", createAuthHeader())
                .delete(USERS_API_V2 + "/" + userOther.getId())
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_FORBIDDEN)
        ;
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_ADMIN)
    public void test_delete_user_role_admin() {
        UserEntity userOther = createUser("Another user", "other@email.com");

        given()
                .header("Authorization", createAuthHeader())
                .delete(USERS_API_V2 + "/" + userOther.getId())
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_NO_CONTENT)
        ;
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    public void test_get_user_permissions_forbidden() {
        // Creating user
        UserEntity user = userRepository.save(createUser("User Test", "ok@email.com"));

        // Creating permissions for user and tenant
        EnumMap<PermissionName, PermissionLevel> permissions = new EnumMap<>(PermissionName.class);
        permissions.put(PermissionName.BILLING_PERMISSION, PermissionLevel.READ_ONLY);
        PermissionDocument permissionDoc = new PermissionDocument(
                UUID.randomUUID().toString(),
                UserId.valueOf(user.getId().toString()),
                TenantId.valueOf("tenant-id"),
                permissions);
        permissionRepository.save(permissionDoc);

        // Building request
        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);

        given()
                .contentType(ContentType.JSON)
                .header("Authorization", createAuthHeader(extraClaims))
                .param("tenant_id", "other-tenant-id")
                .when()
                .get(USERS_API_V2 + "/" + user.getId()  + "/permissions")
                .then()
                .statusCode(HttpStatus.SC_FORBIDDEN);
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    public void test_get_user_permissions_empty_ok() {
        // Creating user
        UserEntity user = userRepository.save(createUser("User Test", "ok@email.com"));

        // No permissions for user and tenant

        // Building request
        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);

        given()
                .contentType(ContentType.JSON)
                .header("Authorization", createAuthHeader(extraClaims))
                .param("tenant_id", "tenant-id")
                .when()
                .get(USERS_API_V2 + "/" + user.getId()  + "/permissions")
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("tenant_id", is("tenant-id"))
                .body("permissions", notNullValue());
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    public void test_get_user_permissions_ok() {
        // Creating user
        UserEntity user = userRepository.save(createUser("User Test", "ok@email.com"));

        // Creating permissions for user and tenant
        EnumMap<PermissionName, PermissionLevel> permissions = new EnumMap<>(PermissionName.class);
        permissions.put(PermissionName.BILLING_PERMISSION, PermissionLevel.READ_ONLY);
        PermissionDocument permissionDoc = new PermissionDocument(
                UUID.randomUUID().toString(),
                UserId.valueOf(user.getId().toString()),
                TenantId.valueOf("tenant-id"),
                permissions);
        permissionRepository.save(permissionDoc);

        // Building request
        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);

        given()
                .contentType(ContentType.JSON)
                .header("Authorization", createAuthHeader(extraClaims))
                .param("tenant_id", "tenant-id")
                .when()
                .get(USERS_API_V2 + "/" + user.getId()  + "/permissions")
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("tenant_id", is("tenant-id"))
                .body("permissions", hasEntry(is(PermissionName.BILLING_PERMISSION.name()), is(PermissionLevel.READ_ONLY.name())));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
     void test_delete_user_permissions_ok() {
        UserEntity user = userRepository.save(createUser("User Test", "ok@email.com"));

        EnumMap<PermissionName, PermissionLevel> permissions = new EnumMap<>(PermissionName.class);
        permissions.put(PermissionName.BILLING_PERMISSION, PermissionLevel.READ_ONLY);
        PermissionDocument permissionDoc = new PermissionDocument(
            UUID.randomUUID().toString(),
            UserId.valueOf(user.getId().toString()),
            TenantId.valueOf("tenant-id"),
            permissions);
        permissionRepository.save(permissionDoc);
        assertThat(permissionRepository.findByUserIdAndTenantId(UserId.valueOf(user.getId().toString()), TenantId.valueOf("tenant-id"))).isPresent();

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);

        given()
            .contentType(ContentType.JSON)
            .header("Authorization", createAuthHeader(extraClaims))
            .param("tenant_id", "tenant-id")
            .when()
            .delete(USERS_API_V2 + "/" + user.getId()  + "/permissions")
            .then()
            .statusCode(HttpStatus.SC_NO_CONTENT);

        assertThat(permissionRepository.findByUserIdAndTenantId(UserId.valueOf(user.getId().toString()), TenantId.valueOf("tenant-id"))).isEmpty();
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    public void test_put_all_user_permissions_forbidden() {
        // Creating user
        UserEntity user = userRepository.save(createUser("User Test", "ok@email.com"));

        // No previous permissions for user and tenant

        // Building request
        JSONObject body = new JSONObject();
        body.put("tenant_id", "other-tenant-id");
        JSONObject mapPermissions = new JSONObject();
        mapPermissions.put(PermissionName.BILLING_PERMISSION.name(), PermissionLevel.READ_ONLY.name());
        body.put("permissions", mapPermissions);

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);

        given()
                .contentType(ContentType.JSON)
                .header("Authorization", createAuthHeader(extraClaims))
                .body(body.toString())
                .when()
                .put(USERS_API_V2 + "/" + user.getId()  + "/permissions")
                .then()
                .statusCode(HttpStatus.SC_FORBIDDEN);
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    public void test_put_all_user_permissions_user_not_found() {
        // No new user

        // No previous permissions for user and tenant

        // Building request
        JSONObject body = new JSONObject();
        body.put("tenant_id", "tenant-id");
        JSONObject mapPermissions = new JSONObject();
        mapPermissions.put(PermissionName.BILLING_PERMISSION.name(), PermissionLevel.READ_ONLY.name());
        body.put("permissions", mapPermissions);

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);

        given()
                .contentType(ContentType.JSON)
                .header("Authorization", createAuthHeader(extraClaims))
                .body(body.toString())
                .when()
                .put(USERS_API_V2 + "/user-id-not-found/permissions")
                .then()
                .statusCode(HttpStatus.SC_NOT_FOUND);
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    public void test_put_all_user_permissions_no_previous_permissions_ok() {
        // Creating user
        UserEntity user = userRepository.save(createUser("User Test", "ok@email.com"));

        // No previous permissions for user and tenant

        // Building request
        JSONObject body = new JSONObject();
        body.put("tenant_id", "tenant-id");
        JSONObject mapPermissions = new JSONObject();
        mapPermissions.put(PermissionName.BILLING_PERMISSION.name(), PermissionLevel.READ_ONLY.name());
        body.put("permissions", mapPermissions);

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);

        given()
                .contentType(ContentType.JSON)
                .header("Authorization", createAuthHeader(extraClaims))
                .body(body.toString())
                .when()
                .put(USERS_API_V2 + "/" + user.getId()  + "/permissions")
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("tenant_id", is("tenant-id"))
                .body("permissions", hasEntry(is(PermissionName.BILLING_PERMISSION.name()), is(PermissionLevel.READ_ONLY.name())));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    public void test_put_all_user_permissions_with_previous_permissions_ok() {
        // Creating user
        UserEntity user = userRepository.save(createUser("User Test", "ok@email.com"));

        // Creating permissions for user and tenant
        EnumMap<PermissionName, PermissionLevel> permissions = new EnumMap<>(PermissionName.class);
        permissions.put(PermissionName.CHATS_PERMISSION, PermissionLevel.READ_WRITE);
        PermissionDocument permissionDoc = new PermissionDocument(
                UUID.randomUUID().toString(),
                UserId.valueOf(user.getId().toString()),
                TenantId.valueOf("tenant-id"),
                permissions);
        permissionRepository.save(permissionDoc);

        // Building request
        JSONObject body = new JSONObject();
        body.put("tenant_id", "tenant-id");
        JSONObject mapPermissions = new JSONObject();
        mapPermissions.put(PermissionName.BILLING_PERMISSION.name(), PermissionLevel.READ_ONLY.name());
        body.put("permissions", mapPermissions);

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);

        given()
                .contentType(ContentType.JSON)
                .header("Authorization", createAuthHeader(extraClaims))
                .body(body.toString())
                .when()
                .put(USERS_API_V2 + "/" + user.getId()  + "/permissions")
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("tenant_id", is("tenant-id"))
                .body("permissions", hasEntry(is(PermissionName.BILLING_PERMISSION.name()), is(PermissionLevel.READ_ONLY.name())));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    public void test_put_one_user_permission_forbidden() {
        // Creating user
        UserEntity user = userRepository.save(createUser("User Test", "ok@email.com"));

        // No previous permissions for user and tenant

        // Building request
        JSONObject body = new JSONObject();
        body.put("tenant_id", "other-tenant-id");
        body.put("permission_level", PermissionLevel.READ_ONLY.name());

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);

        given()
                .contentType(ContentType.JSON)
                .header("Authorization", createAuthHeader(extraClaims))
                .body(body.toString())
                .when()
                .put(USERS_API_V2 + "/" + user.getId()  + "/permissions/" + PermissionName.BILLING_PERMISSION.name())
                .then()
                .statusCode(HttpStatus.SC_FORBIDDEN);
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    public void test_put_one_user_permission_create_ok() {
        // Creating user
        UserEntity user = userRepository.save(createUser("User Test", "ok@email.com"));

        // No previous permissions for user and tenant

        // Building request
        JSONObject body = new JSONObject();
        body.put("tenant_id", "tenant-id");
        body.put("permission_level", PermissionLevel.READ_ONLY.name());

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);

        given()
                .contentType(ContentType.JSON)
                .header("Authorization", createAuthHeader(extraClaims))
                .body(body.toString())
                .when()
                .put(USERS_API_V2 + "/" + user.getId()  + "/permissions/" + PermissionName.BILLING_PERMISSION.name())
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("tenant_id", is("tenant-id"))
                .body("permissions", hasEntry(is(PermissionName.BILLING_PERMISSION.name()), is(PermissionLevel.READ_ONLY.name())));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    public void test_put_one_user_permission_create_error() {
        // Creating user
        UserEntity user = userRepository.save(createUser("User Test", "ok@email.com"));

        // No previous permissions for user and tenant

        // Building request
        JSONObject body = new JSONObject();
        body.put("tenant_id", "tenant-id");
        body.put("permission_level", JSONObject.NULL);

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);

        given()
                .contentType(ContentType.JSON)
                .header("Authorization", createAuthHeader(extraClaims))
                .body(body.toString())
                .when()
                .put(USERS_API_V2 + "/" + user.getId()  + "/permissions/" + PermissionName.BILLING_PERMISSION.name())
                .then()
                .statusCode(HttpStatus.SC_BAD_REQUEST);
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    public void test_put_one_user_permission_add_ok() {
        // Creating user
        UserEntity user = userRepository.save(createUser("User Test", "ok@email.com"));

        // Creating permissions for user and tenant
        EnumMap<PermissionName, PermissionLevel> permissions = new EnumMap<>(PermissionName.class);
        permissions.put(PermissionName.CHATS_PERMISSION, PermissionLevel.READ_WRITE);
        PermissionDocument permissionDoc = new PermissionDocument(
                UUID.randomUUID().toString(),
                UserId.valueOf(user.getId().toString()),
                TenantId.valueOf("tenant-id"),
                permissions);
        permissionRepository.save(permissionDoc);

        // Building request
        JSONObject body = new JSONObject();
        body.put("tenant_id", "tenant-id");
        body.put("permission_level", PermissionLevel.READ_ONLY.name());

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);

        given()
                .contentType(ContentType.JSON)
                .header("Authorization", createAuthHeader(extraClaims))
                .body(body.toString())
                .when()
                .put(USERS_API_V2 + "/" + user.getId()  + "/permissions/" + PermissionName.BILLING_PERMISSION.name())
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("tenant_id", is("tenant-id"))
                .body("permissions", hasEntry(is(PermissionName.CHATS_PERMISSION.name()), is(PermissionLevel.READ_WRITE.name())))
                .body("permissions", hasEntry(is(PermissionName.BILLING_PERMISSION.name()), is(PermissionLevel.READ_ONLY.name())));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    public void test_put_one_user_permission_update_ok() {
        // Creating user
        UserEntity user = userRepository.save(createUser("User Test", "ok@email.com"));

        // Creating permissions for user and tenant
        EnumMap<PermissionName, PermissionLevel> permissions = new EnumMap<>(PermissionName.class);
        permissions.put(PermissionName.CHATS_PERMISSION, PermissionLevel.READ_WRITE);
        PermissionDocument permissionDoc = new PermissionDocument(
                UUID.randomUUID().toString(),
                UserId.valueOf(user.getId().toString()),
                TenantId.valueOf("tenant-id"),
                permissions);
        permissionRepository.save(permissionDoc);

        // Building request
        JSONObject body = new JSONObject();
        body.put("tenant_id", "tenant-id");
        body.put("permission_level", PermissionLevel.READ_ONLY.name());

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);

        given()
                .contentType(ContentType.JSON)
                .header("Authorization", createAuthHeader(extraClaims))
                .body(body.toString())
                .when()
                .put(USERS_API_V2 + "/" + user.getId()  + "/permissions/" + PermissionName.CHATS_PERMISSION.name())
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("tenant_id", is("tenant-id"))
                .body("permissions", hasEntry(is(PermissionName.CHATS_PERMISSION.name()), is(PermissionLevel.READ_ONLY.name())));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    public void test_put_one_user_permission_delete_ok() {
        // Creating user
        UserEntity user = userRepository.save(createUser("User Test", "ok@email.com"));

        // Creating permissions for user and tenant
        EnumMap<PermissionName, PermissionLevel> permissions = new EnumMap<>(PermissionName.class);
        permissions.put(PermissionName.BILLING_PERMISSION, PermissionLevel.READ_ONLY);
        permissions.put(PermissionName.CHATS_PERMISSION, PermissionLevel.READ_WRITE);
        PermissionDocument permissionDoc = new PermissionDocument(
                UUID.randomUUID().toString(),
                UserId.valueOf(user.getId().toString()),
                TenantId.valueOf("tenant-id"),
                permissions);
        permissionRepository.save(permissionDoc);

        // Building request
        JSONObject body = new JSONObject();
        body.put("tenant_id", "tenant-id");
        body.put("permission_level", JSONObject.NULL);

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);

        given()
                .contentType(ContentType.JSON)
                .header("Authorization", createAuthHeader(extraClaims))
                .body(body.toString())
                .when()
                .put(USERS_API_V2 + "/" + user.getId()  + "/permissions/" + PermissionName.CHATS_PERMISSION.name())
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("tenant_id", is("tenant-id"))
                .body("permissions", hasEntry(is(PermissionName.BILLING_PERMISSION.name()), is(PermissionLevel.READ_ONLY.name())))
                .body("permissions", not(hasEntry(is(PermissionName.CHATS_PERMISSION.name()), is(PermissionLevel.READ_ONLY.name()))));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_ADMIN)
    public void test_tenant_owner_accounts() {
        UserEntity userEntity = new UserEntity("User", "some-hash", "existing@domain.com", true, "+34 123456789", true, true, true, "ES", PlaytomicUserType.ONLINE);
        userRepository.save(userEntity);
        Long userId = userEntity.getId();

        mockTenantResponse("tenant-1", "/mock_anemone_single_tenant_anemone.json");

        // Get account
        given()
            .contentType("application/json")
            .header("Authorization", createAuthHeader())
            .when()
            .get(USERS_API_V2+"/"+userId)
            .then()
            .log().all()
            .body("tenant_owner_accounts.size()", is(0))
            .statusCode(HttpStatus.SC_OK)
        ;

        // Put account
        given()
            .contentType("application/json")
            .header("Authorization", createAuthHeader())
            .when()
            .put(USERS_API_V2 + "/" + userId + "/tenant_owner_accounts/tenant-1")
            .then()
            .log().all()
            .body("tenant_owner_accounts[0].tenant_id", is("tenant-1"))
            .statusCode(HttpStatus.SC_OK)
        ;

        // Get account
        given()
            .contentType("application/json")
            .header("Authorization", createAuthHeader())
            .when()
            .get(USERS_API_V2+"/"+userId)
            .then()
            .log().all()
            .body("tenant_owner_accounts[0].tenant_id", is("tenant-1"))
            .body("tenant_owner_accounts.size()", is(1))
            .statusCode(HttpStatus.SC_OK)
        ;

        // Get account
        given()
            .contentType("application/json")
            .header("Authorization", createAuthHeader())
            .when()
            .delete(USERS_API_V2 + "/" + userId + "/tenant_owner_accounts/tenant-1")
            .then()
            .log().all()
            .body("tenant_owner_accounts.size()", is(0))
            .statusCode(HttpStatus.SC_OK)
        ;

        // Get account
        given()
            .contentType("application/json")
            .header("Authorization", createAuthHeader())
            .when()
            .get(USERS_API_V2 + "/" + userId)
            .then()
            .log().all()
            .body("tenant_owner_accounts.size()", is(0))
            .statusCode(HttpStatus.SC_OK)
        ;

    }

    @Test
    @WithMockUser(role = UserRole.ROLE_ADMIN)
    void test_patch_tenant_owner_accounts() {

        userRepository.deleteAll();
        String tenantId = "tenant-id";

        UserEntity userEntity = new UserEntity("User", "some-hash", "existing@domain.com", true, "+34 123456789", true, true, true, "ES", PlaytomicUserType.ONLINE);

        TenantOwnerAccountEntity tenantOwnerAccountEntity = new TenantOwnerAccountEntity();
        tenantOwnerAccountEntity.setId("tenant-account-owner-id");
        tenantOwnerAccountEntity.setUser(userEntity);
        tenantOwnerAccountEntity.setTenantId(tenantId);

        userEntity.setTenantOwnerAccounts(Set.of(tenantOwnerAccountEntity));
        Long userId = userRepository.save(userEntity).getId();

        JSONObject body = new JSONObject();
        body.put("accepts_marketing_communications", true);
        body.put("accepts_cx_whatsapp_communications", true);

        mockTenantResponse("tenant-id", "/mock_anemone_single_tenant_anemone.json");

        given()
            .contentType("application/json")
            .header("Authorization", createAuthHeader(UserId.valueOf(userId.toString())))
            .when()
            .body(body.toString())
            .patch(USERS_API_V2+ "/" + userId + "/tenant_owner_accounts/" + tenantId)
            .then()
            .log().all()
            .statusCode(HttpStatus.SC_OK)
            .body("tenant_id", is(tenantId))
            .body("accepts_marketing_communications", is(true))
            .body("accepts_marketing_behaviour_analysis", is(false))
            .body("accepts_cx_questionnaires", is(false))
            .body("accepts_cx_whatsapp_communications", is(true));

    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void test_categories_permission_ok() {
        UserEntity user = userRepository.save(createUser("User Test", "ok@email.com"));

        JSONObject body = new JSONObject();
        body.put("tenant_id", "tenant-id");
        JSONObject mapPermissions = new JSONObject();
        mapPermissions.put(PermissionName.CUSTOMER_CATEGORIES_PERMISSION.name(), PermissionLevel.READ_ONLY.name());
        body.put("permissions", mapPermissions);

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);

        given()
            .contentType(ContentType.JSON)
            .header("Authorization", createAuthHeader(extraClaims))
            .body(body.toString())
            .when()
            .put(USERS_API_V2 + "/" + user.getId()  + "/permissions/")
            .then()
            .log().all()
            .statusCode(HttpStatus.SC_OK)
            .body("tenant_id", is("tenant-id"))
            .body("permissions", hasEntry(is(PermissionName.CUSTOMER_CATEGORIES_PERMISSION.name()), is(PermissionLevel.READ_ONLY.name())));

        body = new JSONObject();
        body.put("tenant_id", "tenant-id");
        body.put("permission_level", PermissionLevel.READ_WRITE.name());
        given()
            .contentType(ContentType.JSON)
            .header("Authorization", createAuthHeader(extraClaims))
            .body(body.toString())
            .when()
            .put(USERS_API_V2 + "/" + user.getId()  + "/permissions/" + PermissionName.CUSTOMER_CATEGORIES_PERMISSION.name())
            .then()
            .log().all()
            .statusCode(HttpStatus.SC_OK)
            .body("tenant_id", is("tenant-id"))
            .body("permissions", hasEntry(is(PermissionName.CUSTOMER_CATEGORIES_PERMISSION.name()), is(PermissionLevel.READ_WRITE.name())));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void testExportCustomers() throws JsonProcessingException {
        mockTenantResponse("tenant-id", "/mock_anemone_single_tenant_anemone.json");

        List<UserEntity> users = Arrays.asList(
            createUser("User Test", "ok@email.com"),
            createUser("Angel Garcia", "angelgarcia@syltek.com"),
            createUser("Manuel Gonzalez", "manuelgonzalez@syltek.com"),
            createUser("Sergio Garcia", "sergiomoratilla@syltek.com"),
            createUser("Carlos Garcia", "carlosgarcia@syltek.com"),
            createUser("Fulano Perez", "fulano@perez.com")
        );

        UserControllerV2ITHelper.mockWalletResponse(converter, new HashMap<String, Long>());

        var zoneId = ZoneId.of("Europe/Madrid");
        var categoryId = CategoryId.valueOf(UUID.randomUUID());
        var category = categoryRepository.save(new CategoryDocument(categoryId, TenantId.valueOf("tenant-id"), "VIP", null, null, null, null));
        var userWithCategoryWithoutExpiration = users.get(0);
        var acceptedCommercialCom1 = new LinkedAccountEntity(userWithCategoryWithoutExpiration, "tenant-id", userWithCategoryWithoutExpiration.getId().toString(), true, LinkingType.MANUAL_LINK);
        userWithCategoryWithoutExpiration.setLinkedAccounts(Set.of(acceptedCommercialCom1));
        userWithCategoryWithoutExpiration.addCategory(category, null);
        userWithCategoryWithoutExpiration = userRepository.save(userWithCategoryWithoutExpiration);
        var userWithCategoryAndExpiration = users.get(1);
        var acceptedCommercialCom2 = new LinkedAccountEntity(userWithCategoryAndExpiration, "tenant-id", userWithCategoryAndExpiration.getId().toString(), true,
                                                             LinkingType.MANUAL_LINK);
        userWithCategoryAndExpiration.setLinkedAccounts(Set.of(acceptedCommercialCom2));
        var categoryExpiration = clockProvider.getClock().instant().plus(10, ChronoUnit.DAYS);
        userWithCategoryAndExpiration.addCategory(category, categoryExpiration);
        userWithCategoryAndExpiration.setGender(UserGender.MALE);
        userWithCategoryAndExpiration.setBirthDate(LocalDate.of(1989, 12, 10).atStartOfDay().atZone(zoneId).toInstant());
        userWithCategoryAndExpiration.setPhone("+34 641234901");
        userWithCategoryAndExpiration = userRepository.save(userWithCategoryAndExpiration);
        var expectedExpiration = categoryExpiration.atZone(zoneId).toLocalDate();
        var userWithoutCategoryRejected = users.get(2);
        var rejectedCommercialCom = new LinkedAccountEntity(userWithoutCategoryRejected, "tenant-id", userWithoutCategoryRejected.getId().toString(), false, LinkingType.MANUAL_LINK);
        userWithoutCategoryRejected.setLinkedAccounts(Set.of(rejectedCommercialCom));
        userWithoutCategoryRejected = userRepository.save(userWithoutCategoryRejected);

        var userWithoutCategoryNonSetCom = users.get(3);
        var notSetCommercialCom = new LinkedAccountEntity(userWithoutCategoryNonSetCom, "tenant-id", userWithoutCategoryNonSetCom.getId().toString(), null, LinkingType.MANUAL_LINK);
        userWithoutCategoryNonSetCom.setLinkedAccounts(Set.of(notSetCommercialCom));
        userWithoutCategoryNonSetCom = userRepository.save(userWithoutCategoryNonSetCom);

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);

        var content = given()
            .param("tenant_id", "tenant-id")
            .header("Authorization", createAuthHeader(extraClaims))
            .get(USERS_API_V2 + "/customers/csv")
            .then()
            .log().all()
            .using().parser("text/csv", Parser.TEXT)
            .statusCode(HttpStatus.SC_OK)
            .extract().body().asString();
        // it will be the same for all users
        var connectedAt = userWithCategoryWithoutExpiration.getLinkedAccount(TenantId.valueOf("tenant-id")).get().getCreatedAt().atZone(zoneId).toLocalDate();

        assertThat(content).isEqualTo(
            "name,email,commercial_communications,category,category_expiration,birthday,gender,phone_number,connected_date\r\n"
                + "Angel Garcia,angelgarcia@syltek.com,accepted,VIP,"  + expectedExpiration + ",1989-12-10,MALE,+34 641234901," + connectedAt + "\r\n"
                + "User Test,ok@email.com,accepted,VIP,,,,," + connectedAt + "\r\n"
                + "Manuel Gonzalez,manuelgonzalez@syltek.com,rejected,,,,,," + connectedAt + "\r\n"
                + "Sergio Garcia,sergiomoratilla@syltek.com,undefined,,,,,," + connectedAt + "\r\n")
        ;
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void testExportCustomersWithWallets() throws JsonProcessingException {
        mockTenantResponse("tenant-id", "/mock_anemone_single_tenant_anemone.json");

        List<UserEntity> users = Arrays.asList(
            createUser("User Test", "ok@email.com"),
            createUser("Angel Garcia", "angelgarcia@syltek.com"),
            createUser("Manuel Gonzalez", "manuelgonzalez@syltek.com"),
            createUser("Sergio Garcia", "sergiomoratilla@syltek.com"),
            createUser("Carlos Garcia", "carlosgarcia@syltek.com"),
            createUser("Fulano Perez", "fulano@perez.com")
        );

        var userWallet = new HashMap<String, Long>();
        userWallet.put("WALLET_0", users.get(0).getId());
        userWallet.put("WALLET_1", users.get(0).getId());
        UserControllerV2ITHelper.mockWalletResponse(converter, userWallet);

        var zoneId = ZoneId.of("Europe/Madrid");
        var categoryId = CategoryId.valueOf(UUID.randomUUID());
        var category = categoryRepository.save(new CategoryDocument(categoryId, TenantId.valueOf("tenant-id"), "VIP", null, null, null, null));
        var userWithCategoryWithoutExpiration = users.get(0);
        var acceptedCommercialCom1 = new LinkedAccountEntity(userWithCategoryWithoutExpiration, "tenant-id",
                                                             userWithCategoryWithoutExpiration.getId().toString(), true, LinkingType.MANUAL_LINK);
        userWithCategoryWithoutExpiration.setLinkedAccounts(Set.of(acceptedCommercialCom1));
        userWithCategoryWithoutExpiration.addCategory(category, null);
        userWithCategoryWithoutExpiration = userRepository.save(userWithCategoryWithoutExpiration);
        var userWithCategoryAndExpiration = users.get(1);
        var acceptedCommercialCom2 = new LinkedAccountEntity(userWithCategoryAndExpiration, "tenant-id",
                                                             userWithCategoryAndExpiration.getId().toString(), true,
                                                             LinkingType.MANUAL_LINK);
        userWithCategoryAndExpiration.setLinkedAccounts(Set.of(acceptedCommercialCom2));
        var categoryExpiration = clockProvider.getClock().instant().plus(10, ChronoUnit.DAYS);
        userWithCategoryAndExpiration.addCategory(category, categoryExpiration);
        userWithCategoryAndExpiration.setGender(UserGender.MALE);
        userWithCategoryAndExpiration.setBirthDate(LocalDate.of(1989, 12, 10).atStartOfDay().atZone(zoneId).toInstant());
        userWithCategoryAndExpiration.setPhone("+34 641234901");
        userWithCategoryAndExpiration = userRepository.save(userWithCategoryAndExpiration);
        var expectedExpiration = categoryExpiration.atZone(zoneId).toLocalDate();
        var userWithoutCategoryRejected = users.get(2);
        var rejectedCommercialCom = new LinkedAccountEntity(userWithoutCategoryRejected, "tenant-id", userWithoutCategoryRejected.getId().toString(),
                                                            false, LinkingType.MANUAL_LINK);
        userWithoutCategoryRejected.setLinkedAccounts(Set.of(rejectedCommercialCom));
        userWithoutCategoryRejected = userRepository.save(userWithoutCategoryRejected);

        var userWithoutCategoryNonSetCom = users.get(3);
        var notSetCommercialCom = new LinkedAccountEntity(userWithoutCategoryNonSetCom, "tenant-id", userWithoutCategoryNonSetCom.getId().toString(),
                                                          null, LinkingType.MANUAL_LINK);
        userWithoutCategoryNonSetCom.setLinkedAccounts(Set.of(notSetCommercialCom));
        userWithoutCategoryNonSetCom = userRepository.save(userWithoutCategoryNonSetCom);

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);

        var content = given()
            .param("tenant_id", "tenant-id")
            .header("Authorization", createAuthHeader(extraClaims))
            .get(USERS_API_V2 + "/customers/csv")
            .then()
            .log().all()
            .using().parser("text/csv", Parser.TEXT)
            .statusCode(HttpStatus.SC_OK)
            .extract().body().asString();
        // it will be the same for all users
        var connectedAt = userWithCategoryWithoutExpiration.getLinkedAccount(TenantId.valueOf("tenant-id")).get().getCreatedAt().atZone(zoneId)
                                                           .toLocalDate();
        var expectedWalletHeaders = ",wallet_name,balance,wallet_name_2,balance_2,sum_of_wallets,currency";
        var expectedWalletValues = ",WALLET_1,200.0,WALLET_0,200.0,400.0,EUR";
        var expectedEmptiesWalletValues = ",,,,,,";

        assertThat(content).isEqualTo(
            "name,email,commercial_communications,category,category_expiration,birthday,gender,phone_number,connected_date" + expectedWalletHeaders
                + "\r\n"
                + "Angel Garcia,angelgarcia@syltek.com,accepted,VIP," + expectedExpiration + ",1989-12-10,MALE,+34 641234901," + connectedAt
                + expectedEmptiesWalletValues + "\r\n"
                + "User Test,ok@email.com,accepted,VIP,,,,," + connectedAt + expectedWalletValues + "\r\n"
                + "Manuel Gonzalez,manuelgonzalez@syltek.com,rejected,,,,,," + connectedAt + expectedEmptiesWalletValues + "\r\n"
                + "Sergio Garcia,sergiomoratilla@syltek.com,undefined,,,,,," + connectedAt + expectedEmptiesWalletValues + "\r\n")
        ;
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void testExport1100CustomersWithWallets() throws IOException {
        mockTenantResponse("tenant-id", "/mock_anemone_single_tenant_anemone.json");

        List<UserEntity> users = new ArrayList<>();
        List<Wallet> wallets = new ArrayList<>();
        var zoneId = ZoneId.of("Europe/Madrid");
        String createdAt = null;
        for (int i = 0; i < 1100; i++) {
            var user = createUser("User Test " + i, "ok"+ i + "@email.com");

            Wallet wallet = new Wallet();
            wallet.setUserId(user.getId());
            wallet.setWalletId(WalletId.valueOf("amw:48f8180f-3cb5-4c0c-98e2-283c61083dc7"));
            wallet.setName("WALLET_0");
            wallet.setBalance(Money.of(200 + i, "EUR"));
            wallet.setActive(true);

            var linkedAccountEntity = new LinkedAccountEntity(user, "tenant-id",
                                                                 user.getId().toString(), true,
                                                                 LinkingType.MANUAL_LINK);

            user.setLinkedAccounts(Set.of(linkedAccountEntity));

            users.add(user);
            wallets.add(wallet);
        }

        UserControllerV2ITHelper.mockWalletResponse(converter, wallets);
        var usersSaved = userRepository.saveAll(users);
        var userSaved = usersSaved.iterator().next();
        createdAt = userSaved.getLinkedAccount(TenantId.valueOf("tenant-id")).get().getCreatedAt().atZone(zoneId)
                        .toLocalDate().toString();
        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);

        var actual = given()
            .param("tenant_id", "tenant-id")
            .header("Authorization", createAuthHeader(extraClaims))
            .get(USERS_API_V2 + "/customers/csv")
            .then()
            .log().all()
            .using().parser("text/csv", Parser.TEXT)
            .statusCode(HttpStatus.SC_OK)
            .extract().body().asString();

        // expected data is too big to place it in a string variable
        ClassPathResource resource = new ClassPathResource("com/playtomic/anemone/user/api/v2/expected_export_wallet.csv");
        InputStream inputStream = resource.getInputStream();
        String expected = IOUtils.toString(inputStream, StandardCharsets.UTF_8).replace("2022-04-04", createdAt);
        assertThat(actual).isEqualTo(expected);
    }



    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void testExportCustomersWithDifferentWalletsForEachUser() throws IOException {
        mockTenantResponse("tenant-id", "/mock_anemone_single_tenant_anemone.json");

        List<UserEntity> users = Arrays.asList(
            createUser("User Test", "ok@email.com"),
            createUser("Angel Garcia", "angelgarcia@syltek.com"),
            createUser("Manuel Gonzalez", "manuelgonzalez@syltek.com"),
            createUser("Sergio Garcia", "sergiomoratilla@syltek.com"),
            createUser("Carlos Garcia", "carlosgarcia@syltek.com"),
            createUser("Fulano Perez", "fulano@perez.com")
        );
        List<Wallet> wallets = new ArrayList<>();
        for (int i = 0; i < users.size(); i++) {
            var user = users.get(i);
            var linkedAccountEntity = new LinkedAccountEntity(user, "tenant-id",
                                                              user.getId().toString(), true,
                                                              LinkingType.MANUAL_LINK);
            user.setLinkedAccounts(Set.of(linkedAccountEntity));

            Wallet wallet = new Wallet();
            wallet.setUserId(user.getId());
            wallet.setWalletId(WalletId.valueOf("WALLET_ID_" + i));
            wallet.setName("WALLET_" + i);
            wallet.setBalance(Money.of(200 + i, "EUR"));
            wallet.setActive(true);

            wallets.add(wallet);
        }
        var linkedUsers = userRepository.saveAll(users);
        UserControllerV2ITHelper.mockWalletResponse(converter, wallets);

        var zoneId = ZoneId.of("Europe/Madrid");

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);

        var content = given()
            .param("tenant_id", "tenant-id")
            .header("Authorization", createAuthHeader(extraClaims))
            .get(USERS_API_V2 + "/customers/csv")
            .then()
            .using().parser("text/csv", Parser.TEXT)
            .statusCode(HttpStatus.SC_OK)
            .extract().body().asString();

        CSVReader reader = new CSVReader(new StringReader(content));
        var myEntries = reader.readAll();
        var walletPositions = new ArrayList<Integer>();
        boolean areWalletInDifferentColumns = true;
        String csvActualHeader = Arrays.stream(myEntries.get(0)).collect(Collectors.joining(","));

        for (String[] line : myEntries) {
            int postWallet0 = Arrays.asList(line).indexOf("WALLET_0");
            if (postWallet0 != -1) {
                areWalletInDifferentColumns = !walletPositions.contains(postWallet0);
                walletPositions.add(postWallet0);
                if (!areWalletInDifferentColumns) {
                    break;
                }
            }
            int postWallet1 = Arrays.asList(line).indexOf("WALLET_1");
            if (postWallet1 != -1) {
                areWalletInDifferentColumns = !walletPositions.contains(postWallet1);
                walletPositions.add(postWallet1);
                if (!areWalletInDifferentColumns) {
                    break;
                }
            }
            int postWallet2 = Arrays.asList(line).indexOf("WALLET_2");
            if (postWallet2 != -1) {
                areWalletInDifferentColumns = !walletPositions.contains(postWallet2);
                walletPositions.add(postWallet2);
                if (!areWalletInDifferentColumns) {
                    break;
                }
            }
            int postWallet3 = Arrays.asList(line).indexOf("WALLET_3");
            if (postWallet3 != -1) {
                areWalletInDifferentColumns = !walletPositions.contains(postWallet3);
                walletPositions.add(postWallet3);
                if (!areWalletInDifferentColumns) {
                    break;
                }
            }
            int postWallet4 = Arrays.asList(line).indexOf("WALLET_4");
            if (postWallet4 != -1) {
                areWalletInDifferentColumns = !walletPositions.contains(postWallet4);
                walletPositions.add(postWallet4);
                if (!areWalletInDifferentColumns) {
                    break;
                }
            }
            int postWallet5 = Arrays.asList(line).indexOf("WALLET_5");
            if (postWallet5 != -1) {
                areWalletInDifferentColumns = !walletPositions.contains(postWallet5);
                walletPositions.add(postWallet5);
                if (!areWalletInDifferentColumns) {
                    break;
                }
            }
        }
        var expectedWalletHeaders = "name,email,commercial_communications,category,category_expiration,birthday,gender,phone_number,connected_date,"
            + "wallet_name,balance,wallet_name_2,balance_2,wallet_name_3,balance_3,wallet_name_4,balance_4,wallet_name_5,balance_5,wallet_name_6,balance_6,sum_of_wallets,currency";

        // wallets should be place in different columns
        Assertions.assertThat(areWalletInDifferentColumns).isTrue();
        // should display all wallets
        Assertions.assertThat(walletPositions.size()).isEqualTo(6);
        Assertions.assertThat(csvActualHeader).isEqualTo(expectedWalletHeaders);
    }

    @Nonnull
    private UserEntity createUser(String name, String email) {
        return createUser(name, email, null);
    }

    @Nonnull
    private UserEntity createUser(String name, String email, String phone) {
        String hashPassword = new BCryptPasswordEncoder().encode("password");
        UserEntity userEntity = new UserEntity(name, hashPassword, email, true, phone, phone != null, null,null, "ES", PlaytomicUserType.ONLINE);

        userEntity.setAddressState("Tests tests");
        userEntity.setAddressStreet("Tests Street");
        userEntity.setAddressZipCode("Test zip code");
        userEntity.setAddressCity("Test city");

        return userRepository.save(userEntity);
    }

    @Nonnull
    private User getCurrentUser() {
        AnemoneUserPrincipal currentUserDetails =
            (AnemoneUserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return currentUserDetails.getUser();
    }

    @Nonnull
    public static Map<String, List<String>> tenantsIdsClaimData(@Nonnull String... tenantIds) {
        return Map.of("tenant_ids", Arrays.asList(tenantIds));
    }

    @Nonnull
    private String createAuthHeader() {
        return createAuthHeader(getCurrentUser().getId(), null);
    }

    @Nonnull
    private String createAuthHeader(@Nonnull UserId userId) {
        return createAuthHeader(userId, null);
    }

    @Nonnull
    private String createAuthHeader(@Nullable Map<String, Object> extraClaims) {
        return createAuthHeader(getCurrentUser().getId(), extraClaims);
    }

    @Nonnull
    private String createAuthHeader(@Nonnull UserId userId, @Nullable Map<String, Object> extraClaims) {
        Collection<GrantedAuthority> authorities = testCredentialsService.getTestPrincipal().getUser().getOriginalAuthorities();

        AccessJwtToken token = extraClaims == null ?
            jwtTokenFactory.createAccessJwtToken(userId.toString(), null, authorities) :
            jwtTokenFactory.createAccessJwtTokenWithCustomClaims(userId.toString(), null, authorities, extraClaims);

        return "Bearer " + token.getToken();
    }

    private void mockTenantResponse(@Nonnull String responseBodyPath) {

        String responseBody = readAsText(getCurrentPackageAsClasspath() + responseBodyPath);

        getMockServer(MOCK_TENANTS_PORT).
            when(request().
                withPath("/v1/tenants")
            ).
            respond(response().
                withHeaders(new Header("Content-Type", "application/json; charset=utf-8")).
                withStatusCode(200).
                withBody(responseBody));
    }

    private void mockTenantResponse(@Nonnull String tenantId, @Nonnull String responseBodyPath) {

        String responseBody = readAsText(getCurrentPackageAsClasspath() + responseBodyPath);

        getMockServer(MOCK_TENANTS_PORT).
            when(request().
                withPath("/v1/tenants/" + tenantId)
            ).
            respond(response().
                withHeaders(new Header("Content-Type", "application/json; charset=utf-8")).
                withStatusCode(200).
                withBody(responseBody));
    }

    private void mockTenantCommunicationsResponse(@Nonnull String tenantId, @Nullable String responseBody) {
        getMockServer(MOCK_TENANTS_PORT).
            when(request().
                withPath("/v1/tenants/" + tenantId + "/communications")
            ).
            respond(response().
                withHeaders(new Header("Content-Type", "application/json; charset=utf-8")).
                withStatusCode(200).
                withBody(responseBody));
    }

    private MockServerClient mockSMSService(@Nonnull HttpStatusCode statusCode) {
        MockServerClient mockServerClient = getMockServer(MOCK_SMS_PORT);

        mockServerClient.reset().
                when(request().
                        withPath(SMS_ENDPOINT)).
                respond(response().
                        withStatusCode(statusCode.code())
                );

        return mockServerClient;
    }

    private void mockPaymentsResponse(@Nonnull String userId, boolean returnEmptyList) {
        JSONArray mockResponseBody = new JSONArray();

        if (!returnEmptyList) {
            JSONObject debt = new JSONObject()
                    .put("debt_id", "debt-random-uuid");
            mockResponseBody = mockResponseBody.put(debt);
        }

        getMockServer(MOCK_PAYMENTS_PORT).
                when(request().
                        withPath("/v1/debts").
                        withQueryStringParameter("is_settled", "false").
                        withQueryStringParameter("user_id", userId).
                        withQueryStringParameter("size", "1")
                ).
                respond(response().
                        withHeaders(new Header("Content-Type", "application/json; charset=utf-8")).
                        withStatusCode(200).
                        withBody(mockResponseBody.toString()));
    }

    private void mockMatchesResponse(@Nonnull String userId, boolean returnEmptyList) {
        String afterEndDate = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'").withZone(ZoneId.from(ZoneOffset.UTC)).format(NOW.minus(3, ChronoUnit.HOURS));

        JSONArray mockResponseBody = new JSONArray();

        if (!returnEmptyList) {
            JSONObject tenant = new JSONObject()
                    .put("tenant_id", "tenant-random-uuid");
            JSONObject player = new JSONObject()
                    .put("user_id", "user-random-uuid");
            JSONObject team = new JSONObject()
                    .put("team_id", "team-random-uuid")
                    .put("players", new JSONArray().put(player));
            JSONObject match = new JSONObject()
                    .put("match_id", "match-random-uuid")
                    .put("tenant", tenant)
                    .put("teams", new JSONArray().put(team))
                    .put("status", MatchStatus.PENDING)
                    .put("is_playtomic_managed", true);

            mockResponseBody = mockResponseBody.put(match);
        }

        getMockServer(MOCK_MATCHES_PORT).
                when(request().
                        withPath("/v1/matches").
                        withQueryStringParameter("disable_price_calculation", "true").
                        withQueryStringParameter("match_status", "PENDING", "IN_PROGRESS", "PLAYED").
                        withQueryStringParameter("after_end_date", afterEndDate).
                        withQueryStringParameter("player_user_id", userId).
                        withQueryStringParameter("size", "1")
                ).
                respond(response().
                        withHeaders(new Header("Content-Type", "application/json; charset=utf-8")).
                        withStatusCode(200).
                        withBody(mockResponseBody.toString()));
    }
}

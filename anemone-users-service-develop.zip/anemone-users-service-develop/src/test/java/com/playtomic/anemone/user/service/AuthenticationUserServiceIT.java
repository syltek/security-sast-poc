package com.playtomic.anemone.user.service;

import com.playtomic.anemone.UserApplication;
import com.playtomic.anemone.domain.Email;
import com.playtomic.anemone.jwt.JwtSettings;
import com.playtomic.anemone.user.config.AbstractTestContainersSupport;
import com.playtomic.anemone.user.config.TestClockProviderConfiguration.TestClockProvider;
import com.playtomic.anemone.user.dao.UserEntity;
import com.playtomic.anemone.user.dao.UserRepository;
import com.playtomic.anemone.user.model.LoginAuthTokens;
import com.playtomic.anemone.user.service.exception.EmailNotAvailableException;
import com.playtomic.anemone.user.service.exception.InvalidPasswordException;
import com.playtomic.anemone.user.service.exception.PhoneNotAvailableException;
import com.playtomic.anemone.user.service.exception.UserNotFoundException;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.Set;
import javax.annotation.Nonnull;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.util.Assert;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = UserApplication.class)
@ExtendWith(SpringExtension.class)
public class AuthenticationUserServiceIT extends AbstractTestContainersSupport {

    private static final long DIFF_TOLERANCE_MILLISECONDS = 1000;
    @Autowired
    @Nonnull
    private UserRepository userRepository;

    @Autowired
    @Nonnull
    private UserService userService;

    @Autowired
    @Nonnull
    private JwtSettings jwtSettings;

    @Autowired
    @Nonnull
    private AuthenticationService authenticationService;

    @Autowired
    @Nonnull
    private TestClockProvider testClockProvider;

    @AfterEach
    protected void cleanRepoAfterEach() {
        userRepository.deleteAll();
    }

    @BeforeEach
    void beforeEach() {
        testClockProvider.setClock(Clock.systemDefaultZone());
    }

    @Test
    public void test_login_expirations()
        throws PhoneNotAvailableException, EmailNotAvailableException, UserNotFoundException, InvalidPasswordException {
        String userToBeCreatedEmail = "user-to-be-created@emailprovider.com";
        String userToBeCreatedPassword = "user-to-be-created-paSs_1";
        String userToBeCreatedName = "user-to-be-created-name";
        String userToBeCreatedCountryCode = "es";
        String creatorUser = "creatorUser";

        userService
            .registerEmailUser(new Email(userToBeCreatedEmail), userToBeCreatedPassword, userToBeCreatedName, null, null, null,
                userToBeCreatedCountryCode, null, false, null, creatorUser, null, Set.of());

        UserEntity storedUserEntity = userRepository.findUserByEmail(userToBeCreatedEmail).orElse(new UserEntity());

        Instant now = testClockProvider.getClock().instant();
        LoginAuthTokens tokens = authenticationService.login(new Email(userToBeCreatedEmail), userToBeCreatedPassword);


        Assert.isTrue(jwtSettings.getRefreshTokenExpirationSeconds() > jwtSettings.getTokenExpirationSeconds(), "Incoherent expiration configuration");

        Instant parsedExpiration = ((Claims)Jwts.parser().setSigningKey(jwtSettings.getTokenSigningKey()).parse(tokens.getAccessToken().getToken()).getBody()).getExpiration().toInstant();
        Instant parsedRefreshExpiration = ((Claims) Jwts.parser().setSigningKey(jwtSettings.getTokenSigningKey()).parse(tokens.getRefreshToken().getToken()).getBody()).getExpiration().toInstant();

        checkDifference(tokens.getAccessTokenExpiration(), now.plusSeconds(jwtSettings.getTokenExpirationSeconds()), "Incorrect token expiration");
        checkDifference(tokens.getAccessTokenExpiration(), parsedExpiration, "Incorrect token expiration");

        checkDifference(tokens.getRefreshTokenExpiration(), now.plusSeconds(jwtSettings.getRefreshTokenExpirationSeconds()), "Incorrect refresh token expiration");
        checkDifference(tokens.getRefreshTokenExpiration(), parsedRefreshExpiration, "Incorrect refresh token expiration");
    }

    private void checkDifference(Instant a, Instant b, String errorMessage) {
        Duration diff = Duration.between(a, b);
        Assert.isTrue(Math.abs(diff.toMillis()) < DIFF_TOLERANCE_MILLISECONDS, errorMessage + ":" + diff);
    }

}

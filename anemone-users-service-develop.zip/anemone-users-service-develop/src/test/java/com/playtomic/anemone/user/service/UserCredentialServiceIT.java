package com.playtomic.anemone.user.service;

import com.playtomic.anemone.UserApplication;
import com.playtomic.anemone.domain.Email;
import com.playtomic.anemone.test.WithMockUser;
import com.playtomic.anemone.user.config.AbstractTestContainersSupport;
import com.playtomic.anemone.user.dao.PasswordResetRequestEntity;
import com.playtomic.anemone.user.dao.PasswordResetRequestRepository;
import com.playtomic.anemone.user.dao.PlaytomicUserType;
import com.playtomic.anemone.user.dao.UserEntity;
import com.playtomic.anemone.user.dao.UserRepository;
import com.playtomic.anemone.user.model.CustomerUserProfile;
import com.playtomic.anemone.user.service.exception.PasswordResetRequestNotFound;
import java.net.URI;
import java.util.Base64;
import javax.annotation.Nonnull;
import static org.assertj.core.api.Assertions.assertThat;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockserver.client.MockServerClient;
import static org.mockserver.model.HttpRequest.request;
import static org.mockserver.model.HttpResponse.response;
import org.mockserver.model.HttpStatusCode;
import org.mockserver.verify.VerificationTimes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.util.Assert;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = UserApplication.class)
@ExtendWith(SpringExtension.class)
public class UserCredentialServiceIT extends AbstractTestContainersSupport {

    private static int MOCK_SMS_PORT = 10004;
    private final String SMS_ENDPOINT = "/v1/sms";

    @Autowired
    private PasswordResetRequestRepository resetRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private UserServicePersistenceComponent userServicePersistenceComponent;

    @Autowired
    private UserCredentialService userCredentialService;

    @Value("${anemone.emails-hash.key}")
    private String emailPrivateKey;

    @AfterEach
    protected void cleanRepoAfterEach() {
        resetRepository.deleteAll();
        userRepository.deleteAll();
        teardownMockServers();
    }

    @Test
    public void testPasswordResetService() {
        Email okEmail = new Email("test@domain.com");
        Email notFoundEmail = new Email("notfound@domain.com");

        String okToken = "123456";
        String notValidToken = "11111";

        String newPassword = "newPassword";

        PasswordResetRequestEntity passwordReset = new PasswordResetRequestEntity(okEmail, okToken);
        resetRepository.save(passwordReset);

        UserEntity user = new UserEntity("User Test", "", okEmail.getEmail(), false, null, false, null,null, "ES", PlaytomicUserType.ONLINE);
        userRepository.save(user);

        // Not valid token
        try {
            userCredentialService.resetPassword(okEmail, notValidToken, newPassword);
            Assert.isTrue(false, "Expected PasswordResetRequestNotFound");
        } catch (PasswordResetRequestNotFound e) {
            // ok, expected
        }

        // OK
        try {
            userCredentialService.resetPassword(okEmail, okToken, newPassword);
        } catch (PasswordResetRequestNotFound e) {
            throw new IllegalStateException("Not expected exception when updating password", e);
        }

        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        user = userRepository.findUserByEmail(okEmail.getEmail()).get();
        Assert.isTrue(encoder.matches(newPassword, user.getPasswordHash()), "Password was not correctly updated");

        // Already used token
        try {
            userCredentialService.resetPassword(okEmail, okToken, newPassword);
        } catch (PasswordResetRequestNotFound passwordResetRequestNotFound) {
            passwordResetRequestNotFound.printStackTrace();
        }

        // Not valid email
        try {
            userCredentialService.resetPassword(notFoundEmail, okToken, newPassword);
            Assert.isTrue(false, "Expected PasswordResetRequestNotFound");
        } catch (PasswordResetRequestNotFound e) {
            // ok, expected
        }
    }

    @Test
    public void testEmailValidateService() {

        String notValidEmailHash = "invalidtoken";
        String notValidUser = encodeEmail("invalid@email.com");
        String okEmail = encodeEmail("valid@email.com");

        UserEntity user = new UserEntity("User Test", "", "valid@email.com", true, null, false,null,null, "ES", PlaytomicUserType.ONLINE);
        userRepository.save(user);

        // Not valid token hash
        try {
            userCredentialService.verifyEmailToken(notValidEmailHash);
            Assert.isTrue(false, "Expected Validate to fail");
        } catch (Exception e) {
            // ok, expected
        }

        // Not found user email
        try {
            userCredentialService.verifyEmailToken(notValidUser);
            Assert.isTrue(false, "Expected Validate to fail");
        } catch (Exception e) {
            // ok, expected
        }

        // OK
        try {
            userCredentialService.verifyEmailToken(okEmail);
        } catch (Exception e) {
            throw new IllegalStateException("Not expected exception when validating email", e);
        }
        UserEntity newUser = userRepository.findUserByEmail("valid@email.com").get();
        Assert.isTrue(newUser.isEmailVerified(), "User should have email verified.");
    }

    @Test
    public void testMailUriEncoding() {
        // TODO: no sure what this test checks now, because + is a valid base64 char.
        final String expectedEncodedEmail = "non-existing+2@domain.com";

        Email email = new Email("non-existing+2@domain.com");
        String hashedEmail = userCredentialService.encodeEmail(email);
        URI generatedUri = userCredentialService.generateRedirectValidateUserUrl(email, hashedEmail);
        String queryString = generatedUri.getRawQuery();
        String resultEmail = queryString.substring(queryString.indexOf("email=") + 6, queryString.indexOf("&"));

        assertThat(resultEmail).isEqualTo(expectedEncodedEmail);
    }

    @Test
    @WithMockUser
    public void testSendValidationSms() {

        MockServerClient mockServerSmsService = mockSMSService(HttpStatusCode.OK_200);

        UserEntity userEntity = userRepository.save(new UserEntity("User Test", "", "mock@email.com", false, null, false, null,null, "ES", PlaytomicUserType.ONLINE));
        CustomerUserProfile user = userServicePersistenceComponent.mapUserEntityToDomain(userEntity);

        userCredentialService.sendValidationSms(user, "+34 11111111111");

        mockServerSmsService.verify(
                request()
                        .withPath(SMS_ENDPOINT)
                        .withMethod("POST"),
                VerificationTimes.once()
        );
    }

    private String encodeEmail(@Nonnull String email) {
        String hashSignature = emailPrivateKey + email;
        String hash = email + ";" + new BCryptPasswordEncoder().encode(hashSignature);
        return Base64.getEncoder().encodeToString(hash.getBytes());
    }

    private MockServerClient mockSMSService(@Nonnull HttpStatusCode statusCode) {
        MockServerClient mockServerClient = getMockServer(MOCK_SMS_PORT);

        mockServerClient.reset().
                when(request().
                        withPath(SMS_ENDPOINT)).
                respond(response().
                        withStatusCode(statusCode.code())
                );

        return mockServerClient;
    }
}

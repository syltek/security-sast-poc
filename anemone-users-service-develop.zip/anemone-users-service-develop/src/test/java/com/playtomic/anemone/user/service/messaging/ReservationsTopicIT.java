package com.playtomic.anemone.user.service.messaging;

import com.playtomic.anemone.UserApplication;
import com.playtomic.anemone.user.config.AbstractTestContainersSupport;
import com.playtomic.anemone.user.config.MessagingConfiguration.ReservationsTopic;
import java.util.Locale;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.messaging.Message;
import org.springframework.messaging.converter.MessageConversionException;
import org.springframework.messaging.support.GenericMessage;
import org.springframework.test.context.junit.jupiter.SpringExtension;

/**
 * This tests the configuration of the topic and the json parsing.
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = UserApplication.class)
@ExtendWith(SpringExtension.class)
public class ReservationsTopicIT extends AbstractTestContainersSupport {

    @Autowired
    private ReservationsTopic topic;

    protected Message jsonMessage(String json) {
        // This header is not required because it is configured in the application.yml
        // ImmutableMap<String, String> headers = ImmutableMap.of("content-type", "application/json");
        return new GenericMessage<>(json);
    }

    @Test
    public void badFormatMatch() {
        String body = "{\"timestamp\": null}";
        assertThatThrownBy(() -> topic.input().send(jsonMessage(body))).isInstanceOf(MessageConversionException.class);
    }

    @Test
    public void okFormatMatch() throws JSONException {

        JSONObject event = new JSONObject()
            .put("event_type", "RESERVATION_CONFIRMED")
            .put("reservation", new JSONObject()
                .put("reservation_id", "reservation-id")
                .put("status", "CONFIRMED")
                .put("user_id", "user-id")
                .put("merchant_user_id", "1")
                .put("tenant", new JSONObject()
                    .put("tenant_id", "tenant-id")
                    .put("tenant_name", "Tenant")
                    .put("address", new JSONObject()
                        .put("street", "Fake Street 123")
                        .put("coordinate", new JSONObject()
                            .put("lat", "40.416729")
                            .put("lon", "-3.703339")
                        )
                        .put("timezone", "Europe/Madrid")
                    )
                    .put("playtomic_status", "ACTIVE")
                    .put("url", "http://localhost")
                    .put("tenant_type", "SYLTEKCRM")
                    .put("is_playtomic_partner", false)
                    .put("communications_language", Locale.ENGLISH)
                )
            );

        topic.input().send(jsonMessage(event.toString()));
    }
}

package com.playtomic.anemone.user.service;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockserver.model.HttpRequest.request;
import static org.mockserver.model.HttpResponse.response;

import com.playtomic.anemone.Constants;
import com.playtomic.anemone.UserApplication;
import com.playtomic.anemone.category.dao.CategoryDocument;
import com.playtomic.anemone.category.dao.CategoryRepository;
import com.playtomic.anemone.category.domain.CategoryId;
import com.playtomic.anemone.category.service.scheduler.CategorySchedulerServiceComponent;
import com.playtomic.anemone.domain.Email;
import com.playtomic.anemone.domain.location.DefaultLocation;
import com.playtomic.anemone.domain.user.UserId;
import com.playtomic.anemone.user.config.AbstractTestContainersSupport;
import com.playtomic.anemone.user.dao.GdprAuditRepository;
import com.playtomic.anemone.user.dao.PlaytomicUserType;
import com.playtomic.anemone.user.dao.UserEntity;
import com.playtomic.anemone.user.dao.UserRepository;
import com.playtomic.anemone.user.domain.UserProfile;
import com.playtomic.anemone.user.domain.tenant.Tenant;
import com.playtomic.anemone.user.domain.tenant.TenantAddress;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import com.playtomic.anemone.user.domain.users.UserLegacy;
import com.playtomic.anemone.user.model.CustomerUserProfile;
import com.playtomic.anemone.user.model.TenantTag;
import com.playtomic.anemone.user.service.exception.EmailNotAvailableException;
import com.playtomic.anemone.user.service.exception.PhoneNotAvailableException;
import com.playtomic.anemone.user.service.exception.TenantNotFoundException;
import com.playtomic.anemone.user.service.exception.UserNotFoundException;
import com.playtomic.anemone.user.service.facebook.FacebookId;
import com.playtomic.anemone.user.service.facebook.FacebookUserData;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Instant;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import javax.annotation.Nonnull;
import javax.validation.ClockProvider;
import org.assertj.core.api.Assertions;
import org.json.JSONObject;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockserver.model.Header;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpMethod;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.util.Assert;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = UserApplication.class)
@ExtendWith(SpringExtension.class)
public class UserServiceIT extends AbstractTestContainersSupport {

    @Autowired
    @Nonnull
    private UserRepository userRepository;

    @Autowired
    @Nonnull
    private GdprAuditRepository gdprAuditRepository;

    @Autowired
    @Nonnull
    private UserService userService;

    @Autowired
    @Nonnull
    private CategoryRepository categoryRepository;

    @Autowired
    @Nonnull
    private ClockProvider clockProvider;
    @MockBean
    @Nonnull
    private CategorySchedulerServiceComponent categorySchedulerServiceComponent;

    @AfterEach
    protected void cleanRepoAfterEach() {
        userRepository.deleteAll();
        categoryRepository.deleteAll();
    }


    @Test
    public void test_Facebook_NoEmail_NotValidated() throws PhoneNotAvailableException, EmailNotAvailableException {
        FacebookUserData
            facebookData =
            new FacebookUserData(FacebookId.valueOf("facebook-id"), "facebook user", null, false);

        int sizeGdprAudit = gdprAuditRepository.findAll().size();

        UserProfile user = userService.registerFacebookUser(facebookData, null, "ES", null, null, false, "creator-user");

        Assert.isTrue(!user.isValidated(), "user must no be validated");
        Assert.isNull(user.getEmail(), "user must no have email");
        Assert.notNull(user.getName(), "user must have fullName");

        Assert.isTrue(gdprAuditRepository.findAll().size() == sizeGdprAudit + 1, "Wrong GDPR entry created");
    }

    @Test
    public void test_Facebook_NoEmail_Verified() {
        FacebookUserData
                facebookData =
                new FacebookUserData(FacebookId.valueOf("facebook-id"), "facebook user", null, true);
        try {
            int sizeGdprAudit = gdprAuditRepository.findAll().size();

            UserProfile user = userService.registerFacebookUser(facebookData, null, "ES", null, null, false, "creator-user");

            Assert.isTrue(!user.isValidated(), "user must not be validated");
            Assert.isNull(user.getEmail(), "user must no have email");
            Assert.notNull(user.getName(), "user must have fullName");

            Assert.isTrue(gdprAuditRepository.findAll().size() == sizeGdprAudit + 1, "Wrong GDPR entry created");

        } catch (Throwable e) {
            Assert.isTrue(false, "Unexpected exception");
        }
    }

    @Test
    public void test_Facebook_Email_Verified() {
        FacebookUserData
                facebookData =
                new FacebookUserData(FacebookId.valueOf("facebook-id"), "facebook user",
                        new Email("email@facebook.com"), true);
        try {
            int sizeGdprAudit = gdprAuditRepository.findAll().size();

            UserProfile user = userService.registerFacebookUser(facebookData, null, "ES", null, null, false, "creator-user");

            Assert.isTrue(user.isValidated(), "user must be validated");
            Assert.notNull(user.getEmail(), "user must have email");
            Assert.notNull(user.getName(), "user must have fullName");

            Assert.isTrue(gdprAuditRepository.findAll().size() == sizeGdprAudit + 1, "Wrong GDPR entry created");

        } catch (Throwable e) {
            Assert.isTrue(false, "Unexpected exception");
        }
    }

    @Test
    public void test_Facebook_Merge_And_Validate() throws PhoneNotAvailableException, EmailNotAvailableException {
        // Create a non-validated user.
        UserEntity
                userEntity =
                new UserEntity("facebook user", "password-hash", "email@facebook.com", false, null, false, null, null, "ES", PlaytomicUserType.ONLINE);
        userRepository.save(userEntity);

        // Merge from facebook with a validated user.
        FacebookUserData
                facebookData =
                new FacebookUserData(FacebookId.valueOf("facebook-id"), "facebook user",
                        new Email("email@facebook.com"), true);

        int sizeGdprAudit = gdprAuditRepository.findAll().size();

        UserProfile user = userService.registerFacebookUser(facebookData, null, "ES", null, null, false, "creator-user");

        Assert.isTrue(user.isValidated(), "user must be validated");
        Assert.notNull(user.getEmail(), "user must have email");
        Assert.notNull(user.getName(), "user must have fullName");

        Assert.isTrue(gdprAuditRepository.findAll().size() == sizeGdprAudit + 1, "Wrong GDPR entry created");


        Assert.isTrue(userRepository.findAll(PageRequest.of(0, 10)).getTotalElements() == 1, "User must be merged");
    }

    @Test
    public void test_Facebook_Moonrune_Names()
            throws UserNotFoundException, PhoneNotAvailableException, EmailNotAvailableException {
        FacebookUserData
                facebookData =
                new FacebookUserData(FacebookId.valueOf("facebook-id"), "الرَّحْمَنِ الرَّحِيمِ",
                        new Email("email@facebook.com"), true);

        int sizeGdprAudit = gdprAuditRepository.findAll().size();

        UserProfile user = userService.registerFacebookUser(facebookData, null, "ES", null, null, false, "creator-user");
        user = userService.getUserById(user.getId());
        String name = user.getName();
        Assert.isTrue(name.equals("الرَّحْمَنِ الرَّحِيمِ"), "Name is wrongly encoded");

        Assert.isTrue(gdprAuditRepository.findAll().size() == sizeGdprAudit + 1, "Wrong GDPR entry created");

        sizeGdprAudit = gdprAuditRepository.findAll().size();

        facebookData =
            new FacebookUserData(FacebookId.valueOf("facebook-id-2"), "日本語 かわいい ですِ",
                new Email("email2@facebook.com"), true);
        user = userService.registerFacebookUser(facebookData, null, "ES", null, null, false, "creator-user");
        user = userService.getUserById(user.getId());
        name = user.getName();
        Assert.isTrue(name.equals("日本語 かわいい ですِ"), "Name is wrongly encoded");

        Assert.isTrue(gdprAuditRepository.findAll().size() == sizeGdprAudit + 1, "Wrong GDPR entry created");

        sizeGdprAudit = gdprAuditRepository.findAll().size();

        facebookData =
            new FacebookUserData(FacebookId.valueOf("facebook-id-3"), "我們賣狗作為食物",
                new Email("email3@facebook.com"), true);
        user = userService.registerFacebookUser(facebookData, null, "ES", null, null, false, "creator-user");
        user = userService.getUserById(user.getId());
        name = user.getName();
        Assert.isTrue(name.equals("我們賣狗作為食物"), "Name is wrongly encoded");

        Assert.isTrue(gdprAuditRepository.findAll().size() == sizeGdprAudit + 1, "Wrong GDPR entry created");

        sizeGdprAudit = gdprAuditRepository.findAll().size();

        facebookData =
            new FacebookUserData(FacebookId.valueOf("facebook-id-4"), "กับดักไม่ใช่เกย์",
                new Email("email4@facebook.com"), true);
        user = userService.registerFacebookUser(facebookData, null, "ES", null, null, false, "creator-user");
        user = userService.getUserById(user.getId());
        name = user.getName();
        Assert.isTrue(name.equals("กับดักไม่ใช่เกย์"), "Name is wrongly encoded");

        Assert.isTrue(gdprAuditRepository.findAll().size() == sizeGdprAudit + 1, "Wrong GDPR entry created");
    }

    @Test
    void test_registerFacebookUser_successWithCreatedBy() throws PhoneNotAvailableException, EmailNotAvailableException {
        String userFaceBookId = "facebook-id";
        String userFaceBookUser = "facebook user";
        String userToBeCreatedCountryCode = "es";
        String creatorUser = "creator-user";

        FacebookUserData
            facebookData =
            new FacebookUserData(FacebookId.valueOf(userFaceBookId), userFaceBookUser, null, false);

        userService.registerFacebookUser(facebookData, null, userToBeCreatedCountryCode, null, null, false, creatorUser);

        UserEntity storedUserEntity = userRepository.findUserByFacebookId(facebookData.getFacebookId().getValue()).orElse(new UserEntity());

        Assertions.assertThat(storedUserEntity)
            .matches(userEntity -> userFaceBookId.equals(userEntity.getFacebookId()))
            .matches(userEntity -> userToBeCreatedCountryCode.equals(userEntity.getCountryCode()))
            .matches(userEntity -> creatorUser.equals(userEntity.getCreatedBy()));
    }

    @Test
    void test_registerEmailUser_successWithCreatedBy() throws PhoneNotAvailableException, EmailNotAvailableException, TenantNotFoundException {
        String userToBeCreatedEmail = "user-to-be-created@emailprovider.com";
        String userToBeCreatedPassword = "user-to-be-created-Pass_1";
        String userToBeCreatedName = "user-to-be-created-name";
        String userToBeCreatedCountryCode = "es";
        String creatorUser = "creatorUser";

        getMockServer(10019).
            when(request()
                     .withMethod(String.valueOf(HttpMethod.POST))
                     .withPath("/v1/emails")
            ).
            respond(response().withStatusCode(200));

        userService
            .registerEmailUser(new Email(userToBeCreatedEmail), userToBeCreatedPassword, userToBeCreatedName, null, null, null,
                userToBeCreatedCountryCode, null, false, null, creatorUser, null, Set.of());

        UserEntity storedUserEntity = userRepository.findUserByEmail(userToBeCreatedEmail).orElse(new UserEntity());

        Assertions.assertThat(storedUserEntity)
            .matches(userEntity -> userToBeCreatedEmail.equals(userEntity.getEmail()))
            .matches(userEntity -> userToBeCreatedName.equals(userEntity.getFullName()))
            .matches(userEntity -> userToBeCreatedCountryCode.equals(userEntity.getCountryCode()))
            .matches(userEntity -> creatorUser.equals(userEntity.getCreatedBy()));
    }

    @Test
    void test_registerEmailUser_successWithCreatedByTenant()
        throws PhoneNotAvailableException, EmailNotAvailableException, TenantNotFoundException, MalformedURLException {
        String userToBeCreatedEmail = "user-to-be-created@emailprovider.com";
        String userToBeCreatedPassword = "user-to-be-created-pasS_1";
        String userToBeCreatedName = "user-to-be-created-name";
        String userToBeCreatedCountryCode = "es";
        String creatorUser = "creatorUser";
        TenantId tenantId = TenantId.valueOf(UUID.randomUUID().toString());

        JSONObject tenant = new JSONObject()
            .put("tenant_id", tenantId.getValue())
            .put("communications_language", Locale.ENGLISH)
            .put("tenant_name", "Tenant")
            .put("address", new JSONObject()
                .put("street", "Fake Street 123")
                .put("coordinate", new JSONObject()
                    .put("lat", "40.416729")
                    .put("lon", "-3.703339")
                )
                .put("timezone", "Europe/Madrid")
            )
            .put("url", "http://localhost:12345")
            .put("tenant_type", "SYLTEKCRM")
            .put("playtomic_status", "ACTIVE")
            .put("default_currency", "EUR");

        getMockServer(10000).
            when(request()
                .withMethod(String.valueOf(HttpMethod.GET))
                .withPath("/v1/tenants/" + tenantId.getValue())
            ).
            respond(response().
                withHeaders(new Header("Content-Type", "application/json")).
                withStatusCode(200).
                withBody(tenant.toString()));

        getMockServer(10000).
            when(request()
                .withMethod(String.valueOf(HttpMethod.GET))
                .withPath("/v1/tenants/" + tenantId.getValue() + "/communications")
            ).
            respond(response().
                withHeaders(new Header("Content-Type", "application/json")).
                withStatusCode(200)
                .withBody(""));

        userService
            .registerEmailUser(new Email(userToBeCreatedEmail), userToBeCreatedPassword, userToBeCreatedName, null, null, null,
                userToBeCreatedCountryCode, null, false, null, creatorUser, tenantId, Set.of());

        UserEntity storedUserEntity = userRepository.findUserByEmail(userToBeCreatedEmail).orElse(new UserEntity());

        Assertions.assertThat(storedUserEntity)
            .matches(userEntity -> userToBeCreatedEmail.equals(userEntity.getEmail()))
            .matches(userEntity -> userToBeCreatedName.equals(userEntity.getFullName()))
            .matches(userEntity -> userToBeCreatedCountryCode.equals(userEntity.getCountryCode()))
            .matches(userEntity -> creatorUser.equals(userEntity.getCreatedBy()))
            .matches(userEntity -> tenantId.getValue().equals(userEntity.getCreatedByTenant()));
    }

    @Test
    void test_registerEmailUser_successWithoutCreatedByTenant()
        throws PhoneNotAvailableException, EmailNotAvailableException, TenantNotFoundException {
        String userToBeCreatedEmail = "user-to-be-created@emailprovider.com";
        String userToBeCreatedPassword = "user-to-be-created-pasS1";
        String userToBeCreatedName = "user-to-be-created-name";
        String userToBeCreatedCountryCode = "es";
        String creatorUser = "creatorUser";

        userService
            .registerEmailUser(new Email(userToBeCreatedEmail), userToBeCreatedPassword, userToBeCreatedName, null, null, null,
                userToBeCreatedCountryCode, null, false, null, creatorUser, null, Set.of());

        UserEntity storedUserEntity = userRepository.findUserByEmail(userToBeCreatedEmail).orElse(new UserEntity());

        Assertions.assertThat(storedUserEntity)
            .matches(userEntity -> userToBeCreatedEmail.equals(userEntity.getEmail()))
            .matches(userEntity -> userToBeCreatedName.equals(userEntity.getFullName()))
            .matches(userEntity -> userToBeCreatedCountryCode.equals(userEntity.getCountryCode()))
            .matches(userEntity -> creatorUser.equals(userEntity.getCreatedBy()));

        Assertions.assertThat(storedUserEntity.getCreatedByTenant()).isNull();
    }

    @Test
    void test_syncUserCategory() throws MalformedURLException, UserNotFoundException {
        var tenantAddress = new TenantAddress(
            "Fake Street 123",
            null,
            null,
            null,
            null,
            "Spain",
            "ES",
            new DefaultLocation(40.416729, -3.703339),
            ZoneId.of("Europe/Madrid")
        );
        var tenant = new Tenant(TenantId.valueOf("tenant-id"), new URL("http://localhost:12345"), "Test", "ANEMONE", tenantAddress, "ACTIVE", null,
            null, Locale.ENGLISH, Constants.EUR);
        ZoneId zoneId = tenant.getTenantAddress().getZoneId();

        var userProfile = userService
            .registerImportedEmailUser(new Email("test@playtomic.io"), "password_1232S", "Test", null, null, null,
                "es", null, Locale.ENGLISH, null, null, tenant, "manager");
        var vip = categoryRepository.save(new CategoryDocument(CategoryId.valueOf(UUID.randomUUID()), tenant.getTenantId(), "Vip", null
        , null, null, null));

        Assertions.assertThat(userProfile.getTenantTags()).hasSize(0);

        //test no category
        userProfile = userService.syncUserCategory(userProfile, tenant, "", null);

        Assertions.assertThat(userProfile.getTenantTags()).hasSize(0);

        //test adding category
        userProfile = userService.syncUserCategory(userProfile, tenant, "Vip", null);

        Assertions.assertThat(userProfile.getTenantTags()).hasSize(1).flatExtracting(TenantTag::getTagsDetails)
            .element(0)
            .extracting( "expiresAt").isNull();

        //test update of the category expiresAt
        var newExpiresAt = clockProvider.getClock().instant().plus(2, ChronoUnit.DAYS).truncatedTo(ChronoUnit.SECONDS);
        userProfile = userService.syncUserCategory(userProfile, tenant, "Vip", newExpiresAt);

        Assertions.assertThat(userProfile.getTenantTags()).hasSize(1).flatExtracting(TenantTag::getTagsDetails)
            .element(0)
                  .extracting("expiresAt").isEqualTo(
                      newExpiresAt.atZone(zoneId).toLocalDate().atTime(LocalTime.MAX).atZone(zoneId).toInstant().truncatedTo(ChronoUnit.SECONDS));

        //test replacing the category
        var gold = categoryRepository.save(new CategoryDocument(CategoryId.valueOf(UUID.randomUUID()), tenant.getTenantId(),
            "Gold", null, null, null, null));

        newExpiresAt = clockProvider.getClock().instant().plus(3, ChronoUnit.DAYS).truncatedTo(ChronoUnit.SECONDS);
        userProfile = userService.syncUserCategory(userProfile, tenant, "Gold", newExpiresAt);

        Assertions.assertThat(userProfile.getTenantTags()).hasSize(1).flatExtracting(TenantTag::getTagsDetails)
            .element(0)
                  .extracting("tag", "expiresAt").contains(gold.getId().toString(),
                                                           newExpiresAt.atZone(zoneId).toLocalDate().atTime(LocalTime.MAX).atZone(zoneId).toInstant()
                                                                       .truncatedTo(ChronoUnit.SECONDS));

        //test removing the category
        userProfile = userService.syncUserCategory(userProfile, tenant, "", null);
        Assertions.assertThat(userProfile.getTenantTags()).hasSize(0);
        userProfile = userService.syncUserCategory(userProfile, tenant, "Vip", null);
        Assertions.assertThat(userProfile.getTenantTags()).hasSize(1);
        userProfile = userService.syncUserCategory(userProfile, tenant, null, null);
        Assertions.assertThat(userProfile.getTenantTags()).hasSize(0);
    }

    @Test
    void test_set_subscription_info() {
        UserEntity userEntity = new UserEntity("user", "password-hash", "email@email.com", false,
            null, false, null, null, "ES", PlaytomicUserType.ONLINE);
        userRepository.save(userEntity);

        // initial
        UserId id = UserLegacy.valueOf(userEntity.getId());
        UserEntity initialUserEntity = userRepository.findById(userEntity.getId()).get();
        assertThat(initialUserEntity.getIsPremium()).isFalse();
        assertThat(initialUserEntity.getPremiumExpiresAt()).isNull();

        Instant now = clockProvider.getClock().instant().truncatedTo(ChronoUnit.SECONDS);

        {
            // subscribed, not expired
            Instant expiration = now.plusSeconds(120);
            userService.setPremiumInfo(id, true, expiration);
            UserEntity storedUserEntity = userRepository.findById(userEntity.getId()).get();
            assertThat(storedUserEntity.getIsPremium()).isTrue();
            assertThat(storedUserEntity.getPremiumExpiresAt()).isEqualTo(expiration);

            CustomerUserProfile user = userService.getUserById(id);
            assertThat(user.isPremium()).isTrue();
        }


        {
            // subscribed, expired
            Instant expiration = now.minusSeconds(120);
            userService.setPremiumInfo(id, true, expiration);
            UserEntity storedUserEntity = userRepository.findById(userEntity.getId()).get();
            assertThat(storedUserEntity.getIsPremium()).isTrue();
            assertThat(storedUserEntity.getPremiumExpiresAt()).isEqualTo(expiration);

            CustomerUserProfile user = userService.getUserById(id);
            assertThat(user.isPremium()).isFalse();
        }

        {
            // not subscribed, expiration does not matter
            Instant expiration = now.plusSeconds(120);
            userService.setPremiumInfo(id, false, expiration);
            UserEntity storedUserEntity = userRepository.findById(userEntity.getId()).get();
            assertThat(storedUserEntity.getIsPremium()).isFalse();
            assertThat(storedUserEntity.getPremiumExpiresAt()).isNotNull();

            CustomerUserProfile user = userService.getUserById(id);
            assertThat(user.isPremium()).isFalse();
        }

    }

}

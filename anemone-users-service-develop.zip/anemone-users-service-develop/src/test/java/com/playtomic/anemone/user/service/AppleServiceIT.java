package com.playtomic.anemone.user.service;

import com.playtomic.anemone.UserApplication;
import com.playtomic.anemone.user.config.AbstractTestContainersSupport;
import com.playtomic.anemone.user.config.TestClockProviderConfiguration.TestClockProvider;
import com.playtomic.anemone.user.service.apple.AppleService;
import com.playtomic.anemone.user.service.apple.AppleUserData;
import com.playtomic.anemone.user.service.apple.exception.InvalidAppleTokenException;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.util.Assert;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = UserApplication.class)
@ExtendWith(SpringExtension.class)
class AppleServiceIT extends AbstractTestContainersSupport {

    @Autowired
    private AppleService appleService;

    @Autowired
    private TestClockProvider testClockProvider;

    @BeforeEach
    void beforeEach() {
        // Use fixed time for checking precomputed test token
        testClockProvider.setClock(Clock.fixed(Instant.ofEpochSecond(1596448500), ZoneOffset.UTC));
    }

    @Test
    void testIfJWTHasWrongFormat_throwsException() {
        Exception ex = null;
        try {
            appleService.getUserData("WrongJWTformat");
        } catch (InvalidAppleTokenException e) {
            ex = e;
        }
        Assert.notNull(ex, "Should have fired exception");
    }

    @Test
    void testIfJWTSigningFails_throwsException() {
        Exception ex = null;
        try {
            appleService.getUserData(
                    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJodHRwczovL2FwcGxlaWQuYXBwbGUuY29tIiwiYXVkIjoiY29tLnBsYXl0b21pYy5kZXYiLCJleHAiOjE1OTY0NDg4NDAsImlhdCI6MTU5NjQ0ODI0MCwic3ViIjoiMDAwNDEyLmZlYjZjYjRhMDA5YzRlNDI4YzBmMmYwNTkwZTI0YzVkLjA5NTAiLCJjX2hhc2giOiJzTTMwcWhnbTROTjFLSnk2MkdCOFJBIiwiZW1haWwiOiJhbmdlbGdhcmNpYS5tYWlsK2VzQGdtYWlsLmNvbSIsImVtYWlsX3ZlcmlmaWVkIjoidHJ1ZSIsImF1dGhfdGltZSI6MTU5NjQ0ODI0MCwibm9uY2Vfc3VwcG9ydGVkIjp0cnVlfQ.HAm-E0qcY9temT04Cwdt2LiPrPCnXgoLU-h9HLZlnQQ");
        } catch (InvalidAppleTokenException e) {
            ex = e;
        }
        Assert.notNull(ex, "Should have fired exception");
    }

    @Test
    void testIfJWTIsCorrect_ReturnsData() throws InvalidAppleTokenException {
        AppleUserData
                userData =
                appleService.getUserData(
                        "eyJraWQiOiJZdXlYb1kiLCJhbGciOiJSUzI1NiJ9.eyJpc3MiOiJodHRwczovL2FwcGxlaWQuYXBwbGUuY29tIiwiYXVkIjoiY29tLnBsYXl0b21pYy5kZXYiLCJleHAiOjE2MTQ2NzQzNjgsImlhdCI6MTYxNDU4Nzk2OCwic3ViIjoiMDAxNjI3LjM0YmQyYjcyYzViZDQ1YmE5ZjRmM2VlZTRkNzYzZDg3LjA4NTkiLCJjX2hhc2giOiIwU3ZCRDYxRG9BT0U1cVU4RGFYekR3IiwiZW1haWwiOiJyc3ppdm1haHhwQHByaXZhdGVyZWxheS5hcHBsZWlkLmNvbSIsImVtYWlsX3ZlcmlmaWVkIjoidHJ1ZSIsImlzX3ByaXZhdGVfZW1haWwiOiJ0cnVlIiwiYXV0aF90aW1lIjoxNjE0NTg3OTY4LCJub25jZV9zdXBwb3J0ZWQiOnRydWV9.ZyBn_enXzD-3iheT6jmfBDUjUXNn4INuTADrRThnmGwV8RGpImgOSm3EEIiQrjKcPzTgvw8rFDI_D3aE9wOA2gqVd0Zh0HZarfwQWhWo02xyATeBQE1oKiWp96eZ-_wKF3GyjsBcJU6BBJShUc5IjqB0U9z2mCok0I35EAP7LyUoTlFGF3ZJJQ5T76_rkEjYElGLzctAGXyFlA6xITSaxAlemYV_epi51jPE8Ory_RztDlbhctIGNOBxbxHv2kCR3aUdbz0MX_7wpErM0KywEfV9Z6zcVe5xEEsSQI08SqfGqKFAkiGpDg8VdkLSznTNatXhCfNWOWcD1zEUWw3BjA");
        Assert.isTrue(userData.getAppleId().getValue().equals("001627.34bd2b72c5bd45ba9f4f3eee4d763d87.0859"));
        Assert.isTrue(userData.getEmail().getEmail().equals("rszivmahxp@privaterelay.appleid.com"));
        Assert.isTrue(userData.isVerified());
    }

}

package com.playtomic.anemone.user.domain;

import org.junit.jupiter.api.Test;
import org.springframework.util.Assert;

public class PasswordValidatorTest {

    @Test
    public void testValidPassword() {
        String[] validPasswords = {
            "Aaaa123",
            "aaAs12asaA",
            "1245afAdsA~@~$€"
        };

        for (String password : validPasswords) {
            Assert.isTrue(PasswordValidator.isValid(password), "Password must be valid: " + password);
        }
    }

    @Test
    public void testInvalidPassword() {
        String[] invalidPasswords = {
            "",
            "123456",
            "nouppercase",
            "NOLOWERCASE",
            "nouppercase123",
            "NOLOWERCASE123",
            "short",
            "long_long_long_long_long_long_long_long_long_long_long_long_long_long_long_long_long_long_long_long_long_long_long_long_"
        };

        for (String password : invalidPasswords) {
            Assert.isTrue(!PasswordValidator.isValid(password), "Password must be invalid: " + password);
        }
    }
}
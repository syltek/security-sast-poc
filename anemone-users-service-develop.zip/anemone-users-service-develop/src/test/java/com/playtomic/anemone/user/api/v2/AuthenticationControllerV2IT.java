package com.playtomic.anemone.user.api.v2;

import com.playtomic.anemone.UserApplication;
import com.playtomic.anemone.domain.Email;
import com.playtomic.anemone.jwt.JwtTokenFactory;
import com.playtomic.anemone.jwt.RawAccessJwtToken;
import com.playtomic.anemone.user.config.AbstractTestContainersSupport;
import com.playtomic.anemone.user.dao.GdprAuditEntity;
import com.playtomic.anemone.user.dao.GdprAuditRepository;
import com.playtomic.anemone.user.dao.JwtTokenRepository;
import com.playtomic.anemone.user.dao.PasswordResetRequestEntity;
import com.playtomic.anemone.user.dao.PasswordResetRequestRepository;
import com.playtomic.anemone.user.dao.PlaytomicUserType;
import com.playtomic.anemone.user.dao.UserEntity;
import com.playtomic.anemone.user.dao.UserRepository;
import com.playtomic.anemone.user.service.UserCredentialService;
import com.playtomic.anemone.user.service.UserService;
import com.playtomic.anemone.user.service.anemone.EmailServiceClient;
import com.playtomic.anemone.user.service.facebook.FacebookService;
import com.playtomic.anemone.user.service.google.GoogleService;
import static io.restassured.RestAssured.given;
import org.apache.http.HttpStatus;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doNothing;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.util.Assert;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = UserApplication.class)
@ExtendWith(SpringExtension.class)
public class AuthenticationControllerV2IT extends AbstractTestContainersSupport {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private JwtTokenRepository jwtTokenRepository;

    @Autowired
    private PasswordResetRequestRepository passwordResetRequestRepository;

    @Autowired
    private GdprAuditRepository gdprAuditRepository;

    @MockBean
    private FacebookService facebookService;

    @MockBean
    private GoogleService googleService;

    @Autowired
    private UserService userService;

    @Autowired
    private UserCredentialService userCredentialService;

    @Autowired
    private JwtTokenFactory jwtTokenFactory;

    private final String CHECK_AUTH_LOGIN = "/v2/auth/login";
    private final String CHECK_AUTH_LOGOUT = "/v2/auth/logout";
    private final String CHECK_AUTH_REFRESH = "/v2/auth/token";
    private final String CHECK_AUTH_REGISTER = "/v2/auth/register";
    private final String CHECK_VALIDATE = "/v2/auth/validate";

    private final String PASSWORD_RESET_REQUEST = "/v2/auth/password/request";
    private final String PASSWORD_RESET = "/v2/auth/password/reset";
    private final String PASSWORD_REDIRECT = "/v2/auth/password/redirect";

    @MockBean
    EmailServiceClient emailServiceClient;


    @BeforeEach
    public void setup() {
        doNothing().when(emailServiceClient).sendEmail(any());
    }

    @AfterEach
    public void clearRepos() {
        passwordResetRequestRepository.deleteAll();
        userRepository.deleteAll();
    }

    private String parseTokenId(String accessToken) {
        return jwtTokenFactory
            .validateJwtTokenAndParseClaims(new RawAccessJwtToken(accessToken))
            .getBody()
            .getId();
    }

    @Test
    public void test_login_gone() throws Exception {
        given()
                .params("facebook_token", "fake_token").
                when()
                .post(CHECK_AUTH_LOGIN).
                then()
                .statusCode(HttpStatus.SC_GONE);
    }

    @Test
    public void test_register_methods() throws Exception {
        String body = "{"
                + "\"email\":\"existing@domain.com\","
                + "\"password\":\"MyPassword1337\","
                + "\"name\":\"my name\","
                + "\"phone\":\"+34 123456789\""
                + "}";

        given()
                .contentType("application/json")
                .body(body)
                .when()
                .post(CHECK_AUTH_REGISTER)
                .then()
                .statusCode(HttpStatus.SC_OK).body("access_token", notNullValue());

        UserEntity
                user =
                userRepository.findUserByEmail("existing@domain.com")
                        .orElseThrow(() -> new IllegalStateException("user repo should contain created user"));
        Assert.isTrue(new BCryptPasswordEncoder().matches("MyPassword1337", user.getPasswordHash()),
                "Password is not correct");
        Assert.isTrue(!user.isEmailVerified(), "User should not have email verified");
        Assert.isTrue(user.getFullName().equals("my name"), "User name is not correct");
        Assert.isTrue(user.getPhone().equals("+34 123456789"), "Phone is not correct");
        Assert.isTrue(user.getCommunicationsLanguage().equals("es_ES"), "Communications language is not correct");

        // Second time should fail
        given()
                .contentType("application/json")
                .body(body)
                .when()
                .post(CHECK_AUTH_REGISTER)
                .then()
                .statusCode(HttpStatus.SC_BAD_REQUEST)
                .body("status", notNullValue())
                .body("localized_message", notNullValue());

        body = "{"
                + "\"email\":\"wrong email .com\","
                + "\"password\":\"MyPassword1337\","
                + "\"name\":\"my name\""
                + "}";

        given()
                .contentType("application/json")
                .body(body)
                .when()
                .post(CHECK_AUTH_REGISTER)
                .then()
                .statusCode(HttpStatus.SC_BAD_REQUEST)
                .body("status", notNullValue())
                .body("localized_message", notNullValue());

        // Badly formatted password, should fail miserably.
        body = "{"
                + "\"email\":\"existing@domain.com\","
                + "\"password\":\"badpassword\","
                + "\"name\":\"my name\""
                + "}";

        given()
                .contentType("application/json")
                .body(body)
                .when()
                .post(CHECK_AUTH_REGISTER)
                .then()
                .statusCode(HttpStatus.SC_BAD_REQUEST)
                .body("status", notNullValue())
                .body("localized_message", notNullValue());

        // Badly formatted phone, should fail miserably.
        body = "{"
                + "\"email\":\"existing@domain.com\","
                + "\"password\":\"MyPassword1337\","
                + "\"name\":\"my name\","
                + "\"phone\":\"+34 123-456789\""
                + "}";

        given()
                .contentType("application/json")
                .body(body)
                .when()
                .post(CHECK_AUTH_REGISTER)
                .then()
                .statusCode(HttpStatus.SC_BAD_REQUEST)
                .body("status", notNullValue())
                .body("localized_message", notNullValue());
    }

    @Test
    public void test_register_methods_format_phone() throws Exception {
        String body = "{"
                + "\"email\":\"existing@domain.com\","
                + "\"password\":\"MyPassword1337\","
                + "\"name\":\"my name\","
                + "\"phone\":\"+34 (1234)56789\","
                + "\"country_code\":\"SE\""
                + "}";

        given()
                .contentType("application/json")
                .body(body)
                .when()
                .post(CHECK_AUTH_REGISTER)
                .then()
                .statusCode(HttpStatus.SC_OK).body("access_token", notNullValue());

        UserEntity
                user =
                userRepository.findUserByEmail("existing@domain.com")
                        .orElseThrow(() -> new IllegalStateException("user repo should contain created user"));
        Assert.isTrue(new BCryptPasswordEncoder().matches("MyPassword1337", user.getPasswordHash()),
                "Password is not correct");
        Assert.isTrue(!user.isEmailVerified(), "User should not have email verified");
        Assert.isTrue(user.getFullName().equals("my name"), "User name is not correct");
        Assert.isTrue(user.getPhone().equals("+34 123456789"), "Phone is not correct");
        Assert.isTrue(user.getCommunicationsLanguage().equals("sv_SE"), "Communications language is not correct");
    }

    @Test
    public void test_register_methods_check_privacy_settings() throws Exception {

        String body = "{"
                + "\"email\":\"existing@domain.com\","
                + "\"password\":\"MyPassword1337\","
                + "\"name\":\"my name\","
                + "\"accepts_privacy\":true"
                + "}";

        given()
                .contentType("application/json")
                .body(body)
                .when()
                .post(CHECK_AUTH_REGISTER)
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("access_token", notNullValue());

        UserEntity user = userRepository.findUserByEmail("existing@domain.com")
                .orElseThrow(() -> new IllegalStateException("user repo should contain created user"));

        Assert.isTrue(new BCryptPasswordEncoder().matches("MyPassword1337", user.getPasswordHash()),
                "Password is not correct");
        Assert.isTrue(!user.isEmailVerified(), "User should not have email verified");
        Assert.isTrue(user.getFullName().equals("my name"), "User name is not correct");
        Assert.isTrue(user.getAcceptsPrivacyPolicy(), "Privacy policy not correctly set");
        Assert.isTrue(user.getAcceptsCommercialCommunications() == null,
                "Commercial communication acceptance is not correct");

        GdprAuditEntity gdprAuditEntity = gdprAuditRepository.findByUserId(user.getId())
                .orElseThrow(() -> new IllegalStateException("gdprAudit repo should contain created gdprAudit entry"));

        Assert.isTrue(gdprAuditEntity.getAcceptsPrivacyPolicy(), "Privacy policy not correctly set");
        Assert.isTrue(gdprAuditEntity.getAcceptsCommercialCommunications() == null,
                "Commercial communication acceptance is not correct");

        body = "{"
                + "\"email\":\"existing2@domain.com\","
                + "\"password\":\"MyPassword1337\","
                + "\"name\":\"my name\","
                + "\"accepts_commercial\":true"
                + "}";

        given()
                .contentType("application/json")
                .body(body)
                .when()
                .post(CHECK_AUTH_REGISTER)
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("access_token", notNullValue());

        user = userRepository.findUserByEmail("existing2@domain.com")
                .orElseThrow(() -> new IllegalStateException("user repo should contain created user"));

        Assert.isTrue(new BCryptPasswordEncoder().matches("MyPassword1337", user.getPasswordHash()),
                "Password is not correct");
        Assert.isTrue(!user.isEmailVerified(), "User should not have email verified");
        Assert.isTrue(user.getFullName().equals("my name"), "User name is not correct");
        Assert.isTrue(user.getAcceptsPrivacyPolicy() == null, "Privacy policy not correctly set");
        Assert.isTrue(user.getAcceptsCommercialCommunications(), "Commercial communication acceptance is not correct");

        gdprAuditEntity = gdprAuditRepository.findByUserId(user.getId())
                .orElseThrow(() -> new IllegalStateException("gdprAudit repo should contain created gdprAudit entry"));

        Assert.isTrue(gdprAuditEntity.getAcceptsPrivacyPolicy() == null, "Privacy policy not correctly set");
        Assert.isTrue(gdprAuditEntity.getAcceptsCommercialCommunications(),
                "Commercial communication acceptance is not correct");
    }

    @Test
    public void test_validate() throws Exception {
        String hashPassword = new BCryptPasswordEncoder().encode("mypassword");
        UserEntity user = new UserEntity("user", hashPassword, "existing@domain.com", false, null, false, null,null, "ES", PlaytomicUserType.ONLINE);
        userRepository.save(user);

        Email nonExistingEmail = new Email("non-existing@domain.com");
        String encodedEmail = userCredentialService.encodeEmail(nonExistingEmail);

        given()
                .param("validate_token", encodedEmail)
                .param("email", nonExistingEmail.toString())
                .contentType(MediaType.APPLICATION_FORM_URLENCODED_VALUE).
                when()
                .redirects().follow(false)
                .put(CHECK_VALIDATE).
                then()
                .statusCode(HttpStatus.SC_BAD_REQUEST);

        user = userRepository.findById(user.getId()).get();
        Assert.isTrue(!user.isEmailVerified(), "User has to not to have email verified.");

        Email newEmail = new Email("existing@domain.com");
        encodedEmail = userCredentialService.encodeEmail(newEmail);

        given()
                .param("validate_token", encodedEmail)
                .param("email", newEmail.toString())
                .contentType(MediaType.APPLICATION_FORM_URLENCODED_VALUE).
                when()
                .redirects().follow(false)
                .put(CHECK_VALIDATE).
                then()
                .statusCode(HttpStatus.SC_OK);

        user = userRepository.findById(user.getId()).get();
        Assert.isTrue(user.isEmailVerified(), "User should have email verified.");
    }

    @Test
    public void test_password_reset_without_redirect() throws Exception {
        String email = "existing@domain.com";
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        String hashPassword = encoder.encode("mypassword");
        UserEntity user = new UserEntity("user", hashPassword, email, true, null, false, null,null, "ES", PlaytomicUserType.ONLINE);
        userRepository.save(user);

        // 1) Request reset
        given()
                .params("email", email).
                when()
                .post(PASSWORD_RESET_REQUEST).
                then()
                .statusCode(HttpStatus.SC_OK);

        // 2) Use bad token
        given()
                .params("email", email)
                .params("password", "some-password")
                .params("reset_token", "invalid-token").
                when()
                .post(PASSWORD_RESET).
                then()
                .statusCode(HttpStatus.SC_NOT_FOUND);

        PasswordResetRequestEntity passwordRequest = passwordResetRequestRepository.findByEmailIgnoreCase(email);
        // 3) Use right token
        given()
                .params("email", email)
                .params("password", "some-password")
                .params("reset_token", passwordRequest.getToken()).
                when()
                .post(PASSWORD_RESET).
                then()
                .statusCode(HttpStatus.SC_OK);

        user = userRepository.findById(user.getId()).get();

        Assert.isTrue(encoder.matches("some-password", user.getPasswordHash()), "Password does not match");

        // 4) Check that token was consumpted
        given()
                .params("email", email)
                .params("password", "some-password")
                .params("reset_token", passwordRequest.getToken()).
                when()
                .post(PASSWORD_RESET).
                then()
                .statusCode(HttpStatus.SC_NOT_FOUND)
                .body("status", is("TOKEN_NOT_FOUND"));
    }
}

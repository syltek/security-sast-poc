package com.playtomic.anemone.category.api.v1;

import static com.playtomic.anemone.category.api.v1.request.CreateCategoryRequestBody.EXPIRATION_NOT_ALLOWED_FOR_MEMBERSHIP_CATEGORY_MSG;
import static com.playtomic.anemone.category.api.v1.request.CreateCategoryRequestBody.MEMBERSHIP_DETAILS_MUST_BE_SET_FOR_MEMBERSHIP_CATEGORY_MSG;
import static com.playtomic.anemone.category.api.v1.request.CreateCategoryRequestBody.MEMBERSHIP_NOT_ALLOWED_FOR_SIMPLE_CATEGORY_MSG;
import static io.restassured.RestAssured.given;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.mockserver.model.HttpRequest.request;
import static org.mockserver.model.HttpResponse.response;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.playtomic.anemone.UserApplication;
import com.playtomic.anemone.category.dao.BookingPrivilegeField;
import com.playtomic.anemone.category.dao.CategoryDocument;
import com.playtomic.anemone.category.dao.CategoryDocument.Status;
import com.playtomic.anemone.category.dao.CategoryExpirationField;
import com.playtomic.anemone.category.dao.CategoryRepository;
import com.playtomic.anemone.category.dao.MembershipDetailsField;
import com.playtomic.anemone.category.domain.CategoryId;
import com.playtomic.anemone.category.domain.CategoryType;
import com.playtomic.anemone.category.domain.ExpirationUnit;
import com.playtomic.anemone.category.domain.MembershipProductId;
import com.playtomic.anemone.category.domain.Visibility;
import com.playtomic.anemone.category.domain.scheduler.MemberTaskDetails;
import com.playtomic.anemone.converter.CustomMappingJackson2HttpMessageConverter;
import com.playtomic.anemone.domain.user.User;
import com.playtomic.anemone.domain.user.UserId;
import com.playtomic.anemone.domain.user.UserRole;
import com.playtomic.anemone.jwt.AccessJwtToken;
import com.playtomic.anemone.jwt.JwtTokenFactory;
import com.playtomic.anemone.spring.config.AnemoneUserPrincipal;
import com.playtomic.anemone.test.TestCredentialsService;
import com.playtomic.anemone.test.WithMockUser;
import com.playtomic.anemone.user.config.AbstractTestContainersSupport;
import com.playtomic.anemone.user.dao.LinkedAccountEntity;
import com.playtomic.anemone.user.dao.PlaytomicUserType;
import com.playtomic.anemone.user.dao.TenantTagEntity;
import com.playtomic.anemone.user.dao.TenantTagEntity.Type;
import com.playtomic.anemone.user.dao.TenantTagRepository;
import com.playtomic.anemone.user.dao.UserEntity;
import com.playtomic.anemone.user.dao.UserRepository;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.validation.ClockProvider;
import org.apache.http.HttpStatus;
import org.apache.http.entity.ContentType;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockserver.client.MockServerClient;
import org.mockserver.model.Header;
import org.mockserver.model.HttpRequest;
import org.mockserver.model.HttpStatusCode;
import org.mockserver.verify.VerificationTimes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = UserApplication.class)
@ExtendWith(SpringExtension.class)
@AutoConfigureMockMvc
//@DirtiesContext
class CategoryControllerV1IT extends AbstractTestContainersSupport {

    private static final int MOCK_TENANTS_PORT = 10000;
    private static final int EMAIL_MOCK_SERVER_PORT = 10019;
    private static final int SCHEDULER_MOCK_SERVER_PORT = 10014;
    private static final int SUBSCRIPTIONS_MOCK_SERVER_PORT = 10026;

    @Nonnull
    @Autowired
    private JwtTokenFactory jwtTokenFactory;

    @Nonnull
    @Autowired
    private TestCredentialsService testCredentialsService;
    @Nonnull
    @Autowired
    private CategoryRepository categoryRepository;
    @Nonnull
    @Autowired
    private TenantTagRepository tenantTagRepository;
    @Nonnull
    @Autowired
    private UserRepository userRepository;

    @Nonnull
    @Autowired
    private CustomMappingJackson2HttpMessageConverter customMappingJackson2HttpMessageConverter;

    @Nonnull
    @Autowired
    private ClockProvider clockProvider;

    @AfterEach
    public void clearRepos() {
        categoryRepository.deleteAll();
        userRepository.deleteAll();
        SecurityContextHolder.clearContext();
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void createCategory_with_mandatory_fields_ok() {
        mockTenantResponse("tenant-id", "/mock_anemone_single_tenant_public.json");

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);

        String body = "{"
            + "\"name\":\"VIP\","
            + "\"tenant_id\":\"tenant-id\","
            + "\"allow_single_payment_when_price_is_customized\": false"
            + "}";

        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .body(body)
            .post("/v1/categories")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_OK)
            .body("tenant_id", is("tenant-id"))
            .body("name", is("VIP"))
            .body("category_id", notNullValue());
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void getCategories_ok() {
        mockTenantResponse("tenant-id", "/mock_anemone_single_tenant_public.json");
        CategoryDocument vip = categoryRepository.save(new CategoryDocument(CategoryId.valueOf("86243c8b-b33c-44c8-829f-beeb4314cb67"),
            TenantId.valueOf("tenant-id"),
            "VIP",
            new CategoryExpirationField(ExpirationUnit.DAYS, 7),
            new BookingPrivilegeField(10, 5, 3, Duration.ofHours(2)), null, null));
        UserEntity userVip = createUser("User Test", "ok@email.com");
        userVip.setLinkedAccounts(Collections.singleton(new LinkedAccountEntity(userVip, "tenant-id", "1", null, null)));
        userVip.addCategory(vip, null);
        userRepository.save(userVip);

        CategoryDocument gold = categoryRepository.save(new CategoryDocument(CategoryId.valueOf("77243c9b-b73c-90c8-113f-beeb5657cb09"),
            TenantId.valueOf("tenant-id"),
            "Gold",
            new CategoryExpirationField(ExpirationUnit.DAYS, 7),
            new BookingPrivilegeField(10, 5, 3, Duration.ofHours(2)), null, null));
        UserEntity userGold1 = createUser("User Test", "ok@email.com");
        userGold1.setLinkedAccounts(Collections.singleton(new LinkedAccountEntity(userGold1, "tenant-id", "1", null, null)));
        userGold1.addCategory(gold, null);
        userRepository.save(userGold1);

        UserEntity userGold2 = createUser("User Test", "ok@email.com");
        userGold2.setLinkedAccounts(Collections.singleton(new LinkedAccountEntity(userGold2, "tenant-id", "1", null, null)));
        userGold2.addCategory(gold, null);
        userRepository.save(userGold2);

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);

        // without filtering name
        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .param("tenant_id", "tenant-id")
            .get("/v1/categories")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_OK)
            .body("$", hasSize(2))
            .body("[0].tenant_id", is("tenant-id"))
            .body("[0].name", is("VIP"))
            .body("[0].status", is("ENABLED"))
            .body("[0].category_id", is(vip.getId().getValue().toString()))
            .body("[0].customers", is(1))
            .body("[1].tenant_id", is("tenant-id"))
            .body("[1].name", is("Gold"))
            .body("[1].status", is("ENABLED"))
            .body("[1].category_id", is(gold.getId().getValue().toString()))
            .body("[1].customers", is(2));

        // verifies if ignore case is working
        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .param("tenant_id", "tenant-id")
            .param("name", "vip")
            .get("/v1/categories")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_OK)
            .body("$", hasSize(1))
            .body("[0].name", is("VIP"));

        // verifies if like is working
        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .param("tenant_id", "tenant-id")
            .param("name", "ol")
            .get("/v1/categories")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_OK)
            .body("$", hasSize(1))
            .body("[0].name", is("Gold"));

        // verifies if search by category_id is working
        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .param("tenant_id", "tenant-id")
            .param("category_id", "86243c8b-b33c-44c8-829f-beeb4314cb67")
            .get("/v1/categories")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_OK)
            .body("$", hasSize(1))
            .body("[0].tenant_id", is("tenant-id"))
            .body("[0].name", is("VIP"))
            .body("[0].status", is("ENABLED"))
            .body("[0].category_id", is("86243c8b-b33c-44c8-829f-beeb4314cb67"))
            .body("[0].customers", is(1));

        // verify active categories for user
        var activeAt = DateTimeFormatter.ISO_LOCAL_DATE_TIME.format(LocalDateTime.now(clockProvider.getClock()));
        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .param("tenant_id", "tenant-id")
            .param("user_id", userVip.getId())
            .param("active_at", activeAt)
            .get("/v1/categories")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_OK)
            .body("$", hasSize(1))
            .body("[0].tenant_id", is("tenant-id"))
            .body("[0].name", is("VIP"))
            .body("[0].status", is("ENABLED"))
            .body("[0].category_id", is(vip.getId().getValue().toString()))
            .body("[0].customers", is(1));

        // verify categories for user when active_at is missing
        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .param("user_id", userVip.getId())
            .param("active_at", activeAt)
            .get("/v1/categories")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_BAD_REQUEST);

        // verify categories for user and filter are used
        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .param("tenant_id", "tenant-id")
            .param("user_id", userVip.getId())
            .param("name", "v")
            .get("/v1/categories")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_BAD_REQUEST);

        // verify categories for user and categories id are used
        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .param("tenant_id", "tenant-id")
            .param("user_id", userVip.getId())
            .param("category_id", "86243c8b-b33c-44c8-829f-beeb4314cb67")
            .get("/v1/categories")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_BAD_REQUEST);
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void createCategory_with_all_fields_ok() {
        mockTenantResponse("tenant-id", "/mock_anemone_single_tenant_public.json");

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);

        String body = "{"
            + "\"name\":\"VIP\", "
            + "\"tenant_id\":\"tenant-id\", "
            + "\"expiration\" : {"
            + "     \"unit\":\"DAYS\", "
            + "     \"value\":\"7\""
            + " }, "
            + "\"booking_privilege\" : {"
            + "     \"days_of_booking_ahead\":\"10\", "
            + "     \"max_number_of_active_bookings\":\"5\", "
            + "     \"max_number_of_bookings_per_day\":\"3\", "
            + "     \"cancellation_policy\": {"
            + "         \"amount\":\"2\", "
            + "         \"unit\":\"HOURS\""
            + "     }"
            + " },"
            + "\"allow_single_payment_when_price_is_customized\": false"
            + "}";

        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .body(body)
            .post("/v1/categories")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_OK)
            .body("tenant_id", is("tenant-id"))
            .body("name", is("VIP"))
            .body("category_id", notNullValue())
            .body("expiration", notNullValue())
            .body("expiration.unit", is("DAYS"))
            .body("expiration.value", is(7))
            .body("booking_privilege", notNullValue())
            .body("booking_privilege.days_of_booking_ahead", is(10))
            .body("booking_privilege.max_number_of_active_bookings", is(5))
            .body("booking_privilege.max_number_of_bookings_per_day", is(3))
            .body("booking_privilege.cancellation_policy.amount", is(2))
            .body("booking_privilege.cancellation_policy.unit", is("HOURS"));

        // verify if BookingPrivilege were set correctly as all of them are same type
        CategoryDocument category = categoryRepository.findAll().get(0);
        BookingPrivilegeField bookingPrivilege = category.getBookingPrivilege();
        assertThat(bookingPrivilege).isNotNull();
        assertThat(bookingPrivilege.getDaysOfBookingAhead()).isEqualTo(10);
        assertThat(bookingPrivilege.getMaxNumberOfActiveBookings()).isEqualTo(5);
        assertThat(bookingPrivilege.getMaxNumberOfBookingsPerDay()).isEqualTo(3);
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void createCategory_withExistingName_error() {
        mockTenantResponse("tenant-id", "/mock_anemone_single_tenant_public.json");
        categoryRepository.save(new CategoryDocument(CategoryId.valueOf("86243c8b-b33c-44c8-829f-beeb4314cb67"),
            TenantId.valueOf("tenant-id"),
            "VIP",
            new CategoryExpirationField(ExpirationUnit.DAYS, 7),
            new BookingPrivilegeField(10, 5, 3, Duration.ofHours(2))
            , null, null));

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);

        String body = "{"
            + "\"name\":\"VIP\","
            + "\"tenant_id\":\"tenant-id\","
            + "\"allow_single_payment_when_price_is_customized\": false"
            + "}";

        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .body(body)
            .post("/v1/categories")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_BAD_REQUEST)
            .body("localized_message", is("This name already exists"))
            .body("status", is("NAME_ALREADY_EXISTS"));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void createCategory_withExistingName_forDifferentTenant_ok() {
        categoryRepository.save(new CategoryDocument(CategoryId.valueOf("86243c8b-b33c-44c8-829f-beeb4314cb67"),
            TenantId.valueOf("tenant-id1"),
            "VIP",
            new CategoryExpirationField(ExpirationUnit.DAYS, 7),
            new BookingPrivilegeField(10, 5, 3, Duration.ofHours(2)), null, null));

        mockTenantResponse("tenant-id2", "/mock_anemone_single_tenant_public.json");
        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id2");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);

        String body = "{"
            + "\"name\":\"VIP\","
            + "\"tenant_id\":\"tenant-id2\","
            + "\"allow_single_payment_when_price_is_customized\": false"
            + "}";

        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .body(body)
            .post("/v1/categories")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_OK);
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void createCategory_without_tenant_id_error() {
        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);

        String body = "{"
            + "\"name\":\"VIP\","
            + "\"allow_single_payment_when_price_is_customized\": false"
            + "}";

        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .body(body)
            .post("/v1/categories")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_BAD_REQUEST)
            .body("localized_message", is("Invalid value null for tenant_id, must not be null"));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void createCategory_without_name_error() {
        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);

        String body = "{"
            + "\"tenant_id\":\"tenant-id\","
            + "\"allow_single_payment_when_price_is_customized\": false"
            + "}";

        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .body(body)
            .post("/v1/categories")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_BAD_REQUEST)
            .body("localized_message", is("Invalid value null for name, must not be null"));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void createCategory_with_negative_expiration_value_error() {
        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);

        String body = "{"
            + "\"name\":\"VIP\","
            + "\"tenant_id\":\"tenant-id\","
            + "\"expiration\" : {"
            + "     \"unit\":\"DAYS\","
            + "     \"value\":\"-1\""
            + " },"
            + "\"allow_single_payment_when_price_is_customized\": false"
            + "}";

        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .body(body)
            .post("/v1/categories")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_BAD_REQUEST)
            .body("localized_message", is("Invalid value -1 for value, must be greater than or equal to 0"));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void createCategory_with_negative_days_of_booking_ahead_error() {
        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);

        String body = "{"
            + "\"name\":\"VIP\","
            + "\"tenant_id\":\"tenant-id\","
            + "\"booking_privilege\" : {"
            + "     \"days_of_booking_ahead\":\"-1\""
            + " },"
            + "\"allow_single_payment_when_price_is_customized\": false"
            + "}";

        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .body(body)
            .post("/v1/categories")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_BAD_REQUEST)
            .body("localized_message", is("Invalid value -1 for days_of_booking_ahead, must be greater than or equal to 0"));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void createCategory_with_negative_max_number_of_active_bookings_error() {
        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);

        String body = "{"
            + "\"name\":\"VIP\","
            + "\"tenant_id\":\"tenant-id\","
            + "\"booking_privilege\" : {"
            + "     \"max_number_of_active_bookings\":\"-1\""
            + " },"
            + "\"allow_single_payment_when_price_is_customized\": false"
            + "}";

        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .body(body)
            .post("/v1/categories")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_BAD_REQUEST)
            .body("localized_message", is("Invalid value -1 for max_number_of_active_bookings, must be greater than or equal to 0"));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void createCategory_with_negative_max_number_of_bookings_per_day_error() {
        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);

        String body = "{"
            + "\"name\":\"VIP\","
            + "\"tenant_id\":\"tenant-id\","
            + "\"booking_privilege\" : {"
            + "     \"max_number_of_bookings_per_day\":\"-1\""
            + " },"
            + "\"allow_single_payment_when_price_is_customized\": false"
            + "}";

        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .body(body)
            .post("/v1/categories")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_BAD_REQUEST)
            .body("localized_message", is("Invalid value -1 for max_number_of_bookings_per_day, must be greater than or equal to 0"));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void createCategory_withNullAllowSinglePaymentWhenPriceIsCustomized_200ok() {
        mockTenantResponse("tenant-id", "/mock_anemone_single_tenant_public.json");

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);

        String body = "{"
            + "\"name\":\"VIP\","
            + "\"tenant_id\":\"tenant-id\""
            + "}";

        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .body(body)
            .post("/v1/categories")
            .then()
            .log()
            .all()
            .body("allow_single_payment_when_price_is_customized", is(false));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void createSimpleCategory_membershipDetailsNotNull_400badRequest() {
        mockTenantResponse("tenant-id", "/mock_anemone_single_tenant_public.json");

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);

        String body = "{\n"
            + "\t\"tenant_id\": \"tenant-id\",\n"
            + "\t\"name\": \"VIP\",\n"
            + "    \"category_type\": \"SIMPLE\",\n"
            + "    \"membership_details\":{\n"
            + "        \"membership_prices\":[{\"amount\":\"30 EUR\"}],\n"
            + "        \"visibility\":\"APP\",\n"
            + "        \"description\":\"sw\"\n"
            + "    }\n"
            + "}";

        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .body(body)
            .post("/v1/categories")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_BAD_REQUEST)
            .body("localized_message", is(MEMBERSHIP_NOT_ALLOWED_FOR_SIMPLE_CATEGORY_MSG));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void createMembershipCategory_success_200ok() {
        mockTenantResponse("tenant-id", "/mock_anemone_single_tenant_public.json");
        mockSchedulerServer();
        mockSubscriptionsService(MembershipProductId.valueOf(UUID.randomUUID()));

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);

        String body = "{\n"
            + "\t\"tenant_id\": \"tenant-id\",\n"
            + "\t\"name\": \"VIP\",\n"
            + "\t\"booking_privilege\" : {\n"
            + "        \t\"days_of_booking_ahead\":10,\n"
            + "        \t\"max_number_of_active_bookings\":\"7\",\n"
            + "        \t\"max_number_of_bookings_per_day\":\"2\",\n"
            + "        \t\"cancellation_policy\": {\n"
            + "                \t\"unit\" : \"HOURS\",\n"
            + "                \t\"amount\" : 7\n"
            + "             \t}\n"
            + "          \t},\n"
            + "\t\"category_type\": \"MEMBERSHIP\",\n"
            + "\t\"membership_details\":{\n"
            + "        \t\"membership_prices\":[{\"amount\":\"30 EUR\"}],\n"
            + "        \t\"visibility\":\"APP\",\n"
            + "        \t\"description\":\"sw\"\n"
            + "    \t}"
            + "}";

        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .body(body)
            .post("/v1/categories")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_OK);
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void createMembershipCategory_membershipDetailsAreNull_400badRequest() {
        mockTenantResponse("tenant-id", "/mock_anemone_single_tenant_public.json");

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);

        String bodyNoMemberDetailField = "{\n"
            + "\t\"tenant_id\": \"tenant-id\",\n"
            + "\t\"name\": \"VIP\",\n"
            + "\t\"category_type\": \"MEMBERSHIP\"\n"
            + "}";

        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .body(bodyNoMemberDetailField)
            .post("/v1/categories")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_BAD_REQUEST)
            .body("localized_message", is(MEMBERSHIP_DETAILS_MUST_BE_SET_FOR_MEMBERSHIP_CATEGORY_MSG));

        String bodyInvalidMembershipDetails = "{\n"
            + "\t\"tenant_id\": \"tenant-id\",\n"
            + "\t\"name\": \"VIP\",\n"
            + "\t\"category_type\": \"MEMBERSHIP\",\n"
            + "\t\"membership_details\":{\n"
            + "     \t\"membership_prices\":[],\n"
            + "     \t\"visibility\":\"APP\",\n"
            + "     \t\"description\":\"sw\"\n"
            + "     }"
            + "}";

        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .body(bodyInvalidMembershipDetails)
            .post("/v1/categories")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_BAD_REQUEST);
    }


    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void createMembershipCategory_expirationIsNotNull_400badRequest() {
        mockTenantResponse("tenant-id", "/mock_anemone_single_tenant_public.json");

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);

        String bodyNoMemberDetailField = "{"
            + "\t\"tenant_id\": \"tenant-id\",\n"
            + "\t\"name\": \"VIP\",\n"
            + "\t\"expiration\": {\n"
            + "        \t\"unit\" : \"DAYS\",\n"
            + "        \t\"value\" : 6\n"
            + "    },\n"
            + "\t\"category_type\": \"MEMBERSHIP\",\n"
            + "\t\"membership_details\":{\n"
            + "        \t\"membership_prices\":[{\"amount\":\"30 EUR\"}],\n"
            + "        \t\"visibility\":\"APP\",\n"
            + "        \t\"description\":\"sw\"\n"
            + "    \t}"
            + "}";

        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .body(bodyNoMemberDetailField)
            .post("/v1/categories")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_BAD_REQUEST)
            .body("localized_message", is(EXPIRATION_NOT_ALLOWED_FOR_MEMBERSHIP_CATEGORY_MSG));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void getCategory_byId_ok() {
        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);

        categoryRepository.save(new CategoryDocument(CategoryId.valueOf("86243c8b-b33c-44c8-829f-beeb4314cb67"),
            TenantId.valueOf("tenant-id"),
            "VIP",
            new CategoryExpirationField(ExpirationUnit.DAYS, 7),
            new BookingPrivilegeField(10, 5, 3, Duration.ofHours(2)), null, null));

        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .get("/v1/categories/86243c8b-b33c-44c8-829f-beeb4314cb67")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_OK)
            .body("tenant_id", is("tenant-id"))
            .body("name", is("VIP"))
            .body("category_id", notNullValue())
            .body("expiration", notNullValue())
            .body("expiration.unit", is("DAYS"))
            .body("expiration.value", is(7))
            .body("booking_privilege", notNullValue())
            .body("booking_privilege.days_of_booking_ahead", is(10))
            .body("booking_privilege.max_number_of_active_bookings", is(5))
            .body("booking_privilege.max_number_of_bookings_per_day", is(3))
            .body("booking_privilege.cancellation_policy.amount", is(2))
            .body("booking_privilege.cancellation_policy.unit", is("HOURS"));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void updateCategory_ok() {
        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);

        categoryRepository.save(new CategoryDocument(CategoryId.valueOf("86243c8b-b33c-44c8-829f-beeb4314cb67"),
            TenantId.valueOf("tenant-id"),
            "VIP",
            new CategoryExpirationField(ExpirationUnit.DAYS, 7),
            new BookingPrivilegeField(10, 5, 3, Duration.ofHours(2)), null, null));

        String body = "{"
            + "\"name\":\"VIP\", "
            + "\"allow_single_payment_when_price_is_customized\": false,"
            + "\"expiration\" : {"
            + "     \"unit\":\"DAYS\", "
            + "     \"value\":\"7\""
            + " }, "
            + "\"booking_privilege\" : {"
            + "     \"days_of_booking_ahead\":\"10\", "
            + "     \"max_number_of_active_bookings\":\"5\", "
            + "     \"max_number_of_bookings_per_day\":\"3\", "
            + "     \"cancellation_policy\": {"
            + "         \"amount\":\"2\", "
            + "         \"unit\":\"HOURS\""
            + "     }"
            + " }"
            + "}";

        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .body(body)
            .log()
            .all()
            .put("/v1/categories/86243c8b-b33c-44c8-829f-beeb4314cb67")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_OK)
            .body("tenant_id", is("tenant-id"))
            .body("name", is("VIP"))
            .body("category_id", notNullValue())
            .body("expiration", notNullValue())
            .body("expiration.unit", is("DAYS"))
            .body("expiration.value", is(7))
            .body("booking_privilege", notNullValue())
            .body("booking_privilege.days_of_booking_ahead", is(10))
            .body("booking_privilege.max_number_of_active_bookings", is(5))
            .body("booking_privilege.max_number_of_bookings_per_day", is(3))
            .body("booking_privilege.cancellation_policy.amount", is(2))
            .body("booking_privilege.cancellation_policy.unit", is("HOURS"));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void updateCategory_withExistingName_error() {
        mockTenantResponse("tenant-id", "/mock_anemone_single_tenant_public.json");
        CategoryDocument gold = categoryRepository.save(new CategoryDocument(CategoryId.valueOf("77913c8b-b99c-00c8-111f-beeb4314cb11"),
            TenantId.valueOf("tenant-id"),
            "Gold",
            new CategoryExpirationField(ExpirationUnit.DAYS, 7),
            new BookingPrivilegeField(10, 5, 3, Duration.ofHours(2)), null, null));

        CategoryDocument vip = categoryRepository.save(new CategoryDocument(CategoryId.valueOf("86243c8b-b33c-44c8-829f-beeb4314cb67"),
            TenantId.valueOf("tenant-id"),
            "VIP",
            new CategoryExpirationField(ExpirationUnit.DAYS, 7),
            new BookingPrivilegeField(10, 5, 3, Duration.ofHours(2)), null, null));

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);

        String body = "{"
            + "\"name\":\"VIP\","
            + "\"allow_single_payment_when_price_is_customized\": false"
            + "}";

        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .body(body)
            .put("/v1/categories/" + gold.getId())
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_BAD_REQUEST)
            .body("localized_message", is("This name already exists"))
            .body("status", is("NAME_ALREADY_EXISTS"));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void updateCategory_withExistingNameIgnoreCase_error() {
        mockTenantResponse("tenant-id", "/mock_anemone_single_tenant_public.json");
        CategoryDocument gold = categoryRepository.save(new CategoryDocument(CategoryId.valueOf("77913c8b-b99c-00c8-111f-beeb4314cb11"),
            TenantId.valueOf("tenant-id"),
            "Gold",
            new CategoryExpirationField(ExpirationUnit.DAYS, 7),
            new BookingPrivilegeField(10, 5, 3, Duration.ofHours(2)), null, null));

        CategoryDocument vip = categoryRepository.save(new CategoryDocument(CategoryId.valueOf("86243c8b-b33c-44c8-829f-beeb4314cb67"),
            TenantId.valueOf("tenant-id"),
            "VIP",
            new CategoryExpirationField(ExpirationUnit.DAYS, 7),
            new BookingPrivilegeField(10, 5, 3, Duration.ofHours(2)), null, null));

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);

        String body = "{"
            + "\"name\":\"viP\","
            + "\"allow_single_payment_when_price_is_customized\": false"
            + "}";

        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .body(body)
            .put("/v1/categories/" + gold.getId())
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_BAD_REQUEST)
            .body("localized_message", is("This name already exists"))
            .body("status", is("NAME_ALREADY_EXISTS"));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void updateCategory_withNullName_error() {
        mockTenantResponse("tenant-id", "/mock_anemone_single_tenant_public.json");

        categoryRepository.save(new CategoryDocument(CategoryId.valueOf("86243c8b-b33c-44c8-829f-beeb4314cb67"),
            TenantId.valueOf("tenant-id"),
            "VIP",
            new CategoryExpirationField(ExpirationUnit.DAYS, 7),
            new BookingPrivilegeField(10, 5, 3, Duration.ofHours(2)), null, null));

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);

        String body = "{"
            + "\"name\": null,"
            + "\"allow_single_payment_when_price_is_customized\": false"
            + "}";

        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .body(body)
            .put("/v1/categories/86243c8b-b33c-44c8-829f-beeb4314cb67")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_BAD_REQUEST)
            .body("localized_message", is("Invalid value null for name, must not be null"))
            .body("status", is("VALIDATION_FAILED"));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void updateCategory_withNullAllowSinglePaymentWhenPriceIsCustomized_error() {
        mockTenantResponse("tenant-id", "/mock_anemone_single_tenant_public.json");

        categoryRepository.save(new CategoryDocument(CategoryId.valueOf("86243c8b-b33c-44c8-829f-beeb4314cb67"),
            TenantId.valueOf("tenant-id"),
            "VIP",
            new CategoryExpirationField(ExpirationUnit.DAYS, 7),
            new BookingPrivilegeField(10, 5, 3, Duration.ofHours(2)), null, null));

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);

        String body = "{"
            + "\"name\": \"Veep\""
            + "}";

        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .body(body)
            .put("/v1/categories/86243c8b-b33c-44c8-829f-beeb4314cb67")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_BAD_REQUEST)
            .body("localized_message", is("Invalid value null for allow_single_payment_when_price_is_customized, must not be null"))
            .body("status", is("VALIDATION_FAILED"));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void updateCategory_withInvalidVatRate_badRequest() {
        mockTenantResponse("tenant-id", "/mock_anemone_single_tenant_public.json");

        categoryRepository.save(new CategoryDocument(CategoryId.valueOf("86243c8b-b33c-44c8-829f-beeb4314cb67"),
            TenantId.valueOf("tenant-id"),
            "VIP",
            new CategoryExpirationField(ExpirationUnit.DAYS, 7),
            new BookingPrivilegeField(10, 5, 3, Duration.ofHours(2)), null, null));

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);

        {
            String body = "{"
                + "\"name\":\"VIP\", "
                + "\"allow_single_payment_when_price_is_customized\": false,"
                + "\"expiration\" : {"
                + "     \"unit\":\"DAYS\", "
                + "     \"value\":\"7\""
                + " }, "
                + "\"booking_privilege\" : {"
                + "     \"days_of_booking_ahead\":\"10\", "
                + "     \"max_number_of_active_bookings\":\"5\", "
                + "     \"max_number_of_bookings_per_day\":\"3\", "
                + "     \"cancellation_policy\": {"
                + "         \"amount\":\"2\", "
                + "         \"unit\":\"HOURS\""
                + "     }"
                + " },"
                + "\"allow_single_payment_when_price_is_customized\": false,"
                + "\"vat_rate\": -0.12"
                + "}";

            given()
                .contentType(ContentType.APPLICATION_JSON.toString())
                .header("Authorization", authHeader)
                .body(body)
                .put("/v1/categories/86243c8b-b33c-44c8-829f-beeb4314cb67")
                .then()
                .log()
                .all()
                .statusCode(HttpStatus.SC_BAD_REQUEST)
                .body("localized_message", is("Invalid value -0.12 for vat_rate, must be greater than or equal to 0"))
                .body("status", is("VALIDATION_FAILED"));
        }

        {
            String body = "{"
                + "\"name\":\"VIP\", "
                + "\"allow_single_payment_when_price_is_customized\": false,"
                + "\"expiration\" : {"
                + "     \"unit\":\"DAYS\", "
                + "     \"value\":\"7\""
                + " }, "
                + "\"booking_privilege\" : {"
                + "     \"days_of_booking_ahead\":\"10\", "
                + "     \"max_number_of_active_bookings\":\"5\", "
                + "     \"max_number_of_bookings_per_day\":\"3\", "
                + "     \"cancellation_policy\": {"
                + "         \"amount\":\"2\", "
                + "         \"unit\":\"HOURS\""
                + "     }"
                + " },"
                + "\"allow_single_payment_when_price_is_customized\": false,"
                + "\"vat_rate\": 1.12"
                + "}";

            given()
                .contentType(ContentType.APPLICATION_JSON.toString())
                .header("Authorization", authHeader)
                .body(body)
                .put("/v1/categories/86243c8b-b33c-44c8-829f-beeb4314cb67")
                .then()
                .log()
                .all()
                .statusCode(HttpStatus.SC_BAD_REQUEST)
                .body("localized_message", is("Invalid value 1.12 for vat_rate, must be less than or equal to 1"))
                .body("status", is("VALIDATION_FAILED"));
        }
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void updateSimpleCategoryPatch_withMembersShipDetails_badRequest() {
        mockTenantResponse("tenant-id", "/mock_anemone_single_tenant_public.json");

        categoryRepository.save(new CategoryDocument(CategoryId.valueOf("86243c8b-b33c-44c8-829f-beeb4314cb67"),
            TenantId.valueOf("tenant-id"),
            "VIP",
            new CategoryExpirationField(ExpirationUnit.DAYS, 7),
            new BookingPrivilegeField(10, 5, 3, Duration.ofHours(2)), null, null));

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);

        {
            String body = "{\n"
                + " \"membership_details\": {\n"
                + "        \"description\": \"dadsdesc\"\n"
                + "    }\n"
                + "}";

            given()
                .contentType(ContentType.APPLICATION_JSON.toString())
                .header("Authorization", authHeader)
                .body(body)
                .patch("/v1/categories/86243c8b-b33c-44c8-829f-beeb4314cb67")
                .then()
                .log()
                .all()
                .statusCode(HttpStatus.SC_BAD_REQUEST)
                .body("localized_message", is("Description cannot be set or updated in simple categories"))
                .body("status", is("CATEGORY_UPDATE_REJECTED"))
            ;
        }

        {
            String body = "{\n"
                + " \"membership_details\": {\n"
                + "        \"visibility\": \"APP\"\n"
                + "    }\n"
                + "}";

            given()
                .contentType(ContentType.APPLICATION_JSON.toString())
                .header("Authorization", authHeader)
                .body(body)
                .patch("/v1/categories/86243c8b-b33c-44c8-829f-beeb4314cb67")
                .then()
                .log()
                .all()
                .statusCode(HttpStatus.SC_BAD_REQUEST)
                .body("localized_message", is("Visibility cannot be set or updated in simple categories"))
                .body("status", is("CATEGORY_UPDATE_REJECTED"))
            ;
        }

    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void updateSimpleCategoryPut_withMembersShipDetails_badRequest() {
        mockTenantResponse("tenant-id", "/mock_anemone_single_tenant_public.json");

        categoryRepository.save(new CategoryDocument(CategoryId.valueOf("86243c8b-b33c-44c8-829f-beeb4314cb67"),
            TenantId.valueOf("tenant-id"),
            "VIP",
            new CategoryExpirationField(ExpirationUnit.DAYS, 7),
            new BookingPrivilegeField(10, 5, 3, Duration.ofHours(2)), null, null));

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);

        {
            String body = "{"
                + "\"name\":\"VIP\", "
                + "\"expiration\" : {"
                + "     \"unit\":\"DAYS\", "
                + "     \"value\":\"7\""
                + " }, "
                + "\"booking_privilege\" : {"
                + "     \"days_of_booking_ahead\":\"10\", "
                + "     \"max_number_of_active_bookings\":\"5\", "
                + "     \"max_number_of_bookings_per_day\":\"3\", "
                + "     \"cancellation_policy\": {"
                + "         \"amount\":\"2\", "
                + "         \"unit\":\"HOURS\""
                + "     }"
                + " },"
                + "\"allow_single_payment_when_price_is_customized\": false,"
                + "\"vat_rate\": 0.12,"
                + "\"membership_details\":{\n"
                + "        \"visibility\": \"APP\"\n,"
                + "        \"description\": \"desc\"\n"
                + "    }"
                + "}";

            given()
                .contentType(ContentType.APPLICATION_JSON.toString())
                .header("Authorization", authHeader)
                .body(body)
                .put("/v1/categories/86243c8b-b33c-44c8-829f-beeb4314cb67")
                .then()
                .log()
                .all()
                .statusCode(HttpStatus.SC_BAD_REQUEST)
                .body("localized_message", is("Visibility cannot be set or updated in simple categories"))
                .body("status", is("CATEGORY_UPDATE_REJECTED"))
            ;
        }

    }


    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void updateMembershipCategoryPut_membershipCategory_badRequest() {
        mockTenantResponse("tenant-id", "/mock_anemone_single_tenant_public.json");

        String categoryId = "86243c8b-b33c-44c8-829f-beeb4314cb67";

        MembershipDetailsField membershipDetailsField = MembershipDetailsField.builder()
            .membershipProductId(MembershipProductId.valueOf("96243c8b-b33c-44c8-829f-beeb4314cb67"))
            .visibility(Visibility.HIDDEN)
            .description("desc")
            .build();

        categoryRepository.save(new CategoryDocument(CategoryId.valueOf(categoryId),
            TenantId.valueOf("tenant-id"),
            "VIP",
            new CategoryExpirationField(ExpirationUnit.DAYS, 7),
            new BookingPrivilegeField(10, 5, 3, Duration.ofHours(2)), CategoryType.MEMBERSHIP,
            membershipDetailsField));

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);

        // expiration date
        {
            String body = "{"
                + "\"name\":\"VIP\", "
                + "\"expiration\" : {"
                + "     \"unit\":\"DAYS\", "
                + "     \"value\":\"7\""
                + " }, "
                + "\"booking_privilege\" : {"
                + "     \"days_of_booking_ahead\":\"10\", "
                + "     \"max_number_of_active_bookings\":\"5\", "
                + "     \"max_number_of_bookings_per_day\":\"3\", "
                + "     \"cancellation_policy\": {"
                + "         \"amount\":\"2\", "
                + "         \"unit\":\"HOURS\""
                + "     }"
                + " },"
                + "\"allow_single_payment_when_price_is_customized\": false,"
                + "\"vat_rate\": 0.12"
                + "}";

            given()
                .contentType(ContentType.APPLICATION_JSON.toString())
                .header("Authorization", authHeader)
                .body(body)
                .put("/v1/categories/" + categoryId)
                .then()
                .log()
                .all()
                .statusCode(HttpStatus.SC_BAD_REQUEST)
                .body("localized_message", is("Category expiration default cannot be update for membership categories"))
                .body("status", is("CATEGORY_UPDATE_REJECTED"));
        }

        // Membership details null
        {
            String body = "{"
                + "\"name\":\"VIP\", "
                + "\"booking_privilege\" : {"
                + "     \"days_of_booking_ahead\":\"10\", "
                + "     \"max_number_of_active_bookings\":\"5\", "
                + "     \"max_number_of_bookings_per_day\":\"3\", "
                + "     \"cancellation_policy\": {"
                + "         \"amount\":\"2\", "
                + "         \"unit\":\"HOURS\""
                + "     }"
                + " },"
                + "\"allow_single_payment_when_price_is_customized\": false,"
                + "\"vat_rate\": 0.12,"
                + "\"membership_details\": null"
                + "}";

            given()
                .contentType(ContentType.APPLICATION_JSON.toString())
                .header("Authorization", authHeader)
                .body(body)
                .put("/v1/categories/" + categoryId)
                .then()
                .log()
                .all()
                .statusCode(HttpStatus.SC_BAD_REQUEST)
                .body("localized_message", is("Visibility cannot be null for membership categories"))
                .body("status", is("CATEGORY_UPDATE_REJECTED"));
        }

        // Membership description
        {
            String body = "{"
                + "\"name\":\"VIP\", "
                + "\"booking_privilege\" : {"
                + "     \"days_of_booking_ahead\":\"10\", "
                + "     \"max_number_of_active_bookings\":\"5\", "
                + "     \"max_number_of_bookings_per_day\":\"3\", "
                + "     \"cancellation_policy\": {"
                + "         \"amount\":\"2\", "
                + "         \"unit\":\"HOURS\""
                + "     }"
                + " },"
                + "\"allow_single_payment_when_price_is_customized\": false,"
                + "\"vat_rate\": 0.12,"
                + "\"membership_details\":{\n"
                + "        \"visibility\": \"APP\"\n"
                + "    }"
                + "}";

            given()
                .contentType(ContentType.APPLICATION_JSON.toString())
                .header("Authorization", authHeader)
                .body(body)
                .put("/v1/categories/" + categoryId)
                .then()
                .log()
                .all()
                .statusCode(HttpStatus.SC_BAD_REQUEST)
                .body("localized_message", is("Invalid value null for description, must not be null"))
                .body("status", is("VALIDATION_FAILED"));
        }

        String corruptCategoryId = "16243c8b-b33c-44c8-829f-beeb4314cb67";

        categoryRepository.save(new CategoryDocument(CategoryId.valueOf(corruptCategoryId),
            TenantId.valueOf("tenant-id"),
            "VIsP",
            new CategoryExpirationField(ExpirationUnit.DAYS, 7),
            new BookingPrivilegeField(10, 5, 3, Duration.ofHours(2)), CategoryType.MEMBERSHIP,
            null));

        // Corrupt category file
        {
            String body = "{"
                + "\"name\":\"VIsP\", "
                + "\"booking_privilege\" : {"
                + "     \"days_of_booking_ahead\":\"10\", "
                + "     \"max_number_of_active_bookings\":\"5\", "
                + "     \"max_number_of_bookings_per_day\":\"3\", "
                + "     \"cancellation_policy\": {"
                + "         \"amount\":\"2\", "
                + "         \"unit\":\"HOURS\""
                + "     }"
                + " },"
                + "\"allow_single_payment_when_price_is_customized\": false,"
                + "\"vat_rate\": 0.12,"
                + "\"membership_details\":{\n"
                + "        \"visibility\": \"APP\",\n"
                + "        \"description\": \"APP\"\n"
                + "    }"
                + "}";

            given()
                .contentType(ContentType.APPLICATION_JSON.toString())
                .header("Authorization", authHeader)
                .body(body)
                .put("/v1/categories/" + corruptCategoryId)
                .then()
                .log()
                .all()
                .statusCode(HttpStatus.SC_BAD_REQUEST)
                .body("localized_message", is("Categories of type membership must have non null membership details"))
                .body("status", is("CATEGORY_UPDATE_REJECTED"));
        }

    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void updateMembershipCategoryPut_membershipCategory_ok() {

        MembershipProductId membershipProductId = MembershipProductId.valueOf("96243c8b-b33c-44c8-829f-beeb4314cb67");
        mockSubscriptionsService(membershipProductId);

        mockTenantResponse("tenant-id", "/mock_anemone_single_tenant_public.json");

        String categoryId = "86243c8b-b33c-44c8-829f-beeb4314cb67";

        MembershipDetailsField membershipDetailsField = MembershipDetailsField.builder()
            .membershipProductId(membershipProductId)
            .visibility(Visibility.HIDDEN)
            .description("desc")
            .build();

        categoryRepository.save(new CategoryDocument(CategoryId.valueOf(categoryId),
            TenantId.valueOf("tenant-id"),
            "VIP",
            null,
            new BookingPrivilegeField(10, 5, 3, Duration.ofHours(2)), CategoryType.MEMBERSHIP,
            membershipDetailsField));

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);

        // expiration date
        {
            String body = "{"
                + "\"name\":\"VIPd\", "
                + "\"allow_single_payment_when_price_is_customized\": true,"
                + "\"booking_privilege\" : {"
                + "     \"days_of_booking_ahead\":\"11\", "
                + "     \"max_number_of_active_bookings\":\"4\", "
                + "     \"max_number_of_bookings_per_day\":\"1\", "
                + "     \"cancellation_policy\": {"
                + "         \"amount\":\"3\", "
                + "         \"unit\":\"HOURS\""
                + "     }"
                + " },"
                + "\"vat_rate\": 0.11,"
                + "\"membership_details\":{\n"
                + "        \"visibility\": \"APP\",\n"
                + "        \"description\": \"desc1\"\n"
                + "    }"
                + "}";

            given()
                .contentType(ContentType.APPLICATION_JSON.toString())
                .header("Authorization", authHeader)
                .body(body)
                .put("/v1/categories/" + categoryId)
                .then()
                .log()
                .all()
                .statusCode(HttpStatus.SC_OK)
                .body("tenant_id", is("tenant-id"))
                .body("name", is("VIPd"))
                .body("category_id", notNullValue())
                .body("booking_privilege", notNullValue())
                .body("booking_privilege.days_of_booking_ahead", is(11))
                .body("booking_privilege.max_number_of_active_bookings", is(4))
                .body("booking_privilege.max_number_of_bookings_per_day", is(1))
                .body("booking_privilege.cancellation_policy.amount", is(3))
                .body("booking_privilege.cancellation_policy.unit", is("HOURS"))
                .body("membership_details.visibility", is("APP"))
                .body("membership_details.description", is("desc1"))
            ;

            mockSubscriptionsService(membershipDetailsField.getMembershipProductId())
                .verify(HttpRequest.request()
                        .withPath("/v1/membership_products/" + membershipProductId)
                        .withMethod("PUT"),
                    VerificationTimes.exactly(1));
        }
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void updateMembershipCategoryPatch_membershipCategory_badRequest() {
        mockTenantResponse("tenant-id", "/mock_anemone_single_tenant_public.json");

        String categoryId = "86243c8b-b33c-44c8-829f-beeb4314cb67";

        MembershipDetailsField membershipDetailsField = MembershipDetailsField.builder()
            .membershipProductId(MembershipProductId.valueOf("96243c8b-b33c-44c8-829f-beeb4314cb67"))
            .visibility(Visibility.HIDDEN)
            .description("desc")
            .build();

        categoryRepository.save(new CategoryDocument(CategoryId.valueOf(categoryId),
            TenantId.valueOf("tenant-id"),
            "VIP",
            null,
            new BookingPrivilegeField(10, 5, 3, Duration.ofHours(2)), CategoryType.MEMBERSHIP,
            membershipDetailsField));

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);

        // visibility
        {
            String body = "{"
                + "\"membership_details\":{\n"
                + "        \"visibility\": \"ASK\""
                + "    }"
                + "}";

            given()
                .contentType(ContentType.APPLICATION_JSON.toString())
                .header("Authorization", authHeader)
                .body(body)
                .log()
                .all()
                .patch("/v1/categories/" + categoryId)
                .then()
                .log()
                .all()
                .statusCode(HttpStatus.SC_BAD_REQUEST)
                .body("status", is("400 BAD_REQUEST"));
        }

        // description
        {
            String body = "{"
                + "\"membership_details\":{\n"
                + "        \"description\": \"\""
                + "    }"
                + "}";

            given()
                .contentType(ContentType.APPLICATION_JSON.toString())
                .header("Authorization", authHeader)
                .body(body)
                .patch("/v1/categories/" + categoryId)
                .then()
                .log()
                .all()
                .statusCode(HttpStatus.SC_BAD_REQUEST)
                .body("localized_message", is("Description cannot be null or empty for membership categories"))
                .body("status", is("CATEGORY_UPDATE_REJECTED"));
        }

    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void updateMembershipCategoryPatch_membershipCategory_ok() {

        MembershipProductId membershipProductId = MembershipProductId.valueOf("96243c8b-b33c-44c8-829f-beeb4314cb67");
        mockSubscriptionsService(membershipProductId);

        mockTenantResponse("tenant-id", "/mock_anemone_single_tenant_public.json");

        String categoryId = "86243c8b-b33c-44c8-829f-beeb4314cb67";

        MembershipDetailsField membershipDetailsField = MembershipDetailsField.builder()
            .membershipProductId(membershipProductId)
            .visibility(Visibility.HIDDEN)
            .description("desc")
            .build();

        categoryRepository.save(new CategoryDocument(CategoryId.valueOf(categoryId),
            TenantId.valueOf("tenant-id"),
            "VIP",
            null,
            new BookingPrivilegeField(10, 5, 3, Duration.ofHours(2)), CategoryType.MEMBERSHIP,
            membershipDetailsField));

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);

        // visibility
        {
            String body = "{"
                + "\"membership_details\":{\n"
                + "        \"visibility\": \"APP\","
                + "        \"description\": \"desc\""
                + "    }"
                + "}";

            given()
                .contentType(ContentType.APPLICATION_JSON.toString())
                .header("Authorization", authHeader)
                .body(body)
                .log()
                .all()
                .patch("/v1/categories/" + categoryId)
                .then()
                .log()
                .all()
                .statusCode(HttpStatus.SC_OK)
                .body("tenant_id", is("tenant-id"))
                .body("name", is("VIP"))
                .body("category_id", notNullValue())
                .body("membership_details.visibility", is("APP"))
                .body("membership_details.description", is("desc"))
            ;

            mockSubscriptionsService(membershipDetailsField.getMembershipProductId())
                .verify(HttpRequest.request()
                        .withPath("/v1/membership_products/" + membershipProductId)
                        .withMethod("PUT"),
                    VerificationTimes.exactly(1));
        }
    }


    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void assignUsersToCategory_ok() {
        MockServerClient schedulerMockServer = mockSchedulerServer();
        String tenantId = "tenant-id";
        mockTenantResponse(tenantId, "/mock_anemone_single_tenant_public.json");

        MockServerClient emailServerMock = mockEmailServer();

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);

        UserEntity user = createUser("User Test", "ok@email.com");
        LinkedAccountEntity linkedAccountEntity = new LinkedAccountEntity(user, "tenant-id", "1", null, null);
        user.setLinkedAccounts(Collections.singleton(linkedAccountEntity));
        user = userRepository.save(user);

        categoryRepository.save(new CategoryDocument(CategoryId.valueOf("86243c8b-b33c-44c8-829f-beeb4314cb67"),
            TenantId.valueOf("tenant-id"),
            "VIP",
            new CategoryExpirationField(ExpirationUnit.DAYS, 7),
            new BookingPrivilegeField(10, 5, 3, Duration.ofHours(2)), null, null));

        Instant expiresAtInFuture = clockProvider.getClock().instant().plus(7, ChronoUnit.DAYS);
        String body = "[{"
            + "\"user_id\" : " + user.getId() + ", "
            + "\"expires_at\" : \"" + expiresAtInFuture + "\""
            + "}]";
        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .body(body)
            .post("/v1/categories/86243c8b-b33c-44c8-829f-beeb4314cb67/members")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_NO_CONTENT);

        emailServerMock.verify(
            HttpRequest.request()
                .withPath("/v1/emails_batch")
                .withMethod("POST"),
            VerificationTimes.once());
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void assignUsersToCategory_whenSameWasExpiredIsPresent_error() {
        MockServerClient schedulerMockServer = mockSchedulerServer();
        MockServerClient emailServerMock = mockEmailServer();
        String tenantId = "tenant-id";
        mockTenantResponse(tenantId, "/mock_anemone_single_tenant_public.json");

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);

        CategoryDocument category = categoryRepository.save(new CategoryDocument(CategoryId.valueOf("86243c8b-b33c-44c8-829f-beeb4314cb67"),
            TenantId.valueOf("tenant-id"),
            "VIP",
            new CategoryExpirationField(ExpirationUnit.DAYS, 7),
            new BookingPrivilegeField(10, 5, 3, Duration.ofHours(2)), null, null));
        UserEntity user = createUser("User Test", "ok@email.com");
        LinkedAccountEntity linkedAccountEntity = new LinkedAccountEntity(user, "tenant-id", "1", null, null);
        user.setLinkedAccounts(Collections.singleton(linkedAccountEntity));
        var now = clockProvider.getClock().instant();
        user.addCategory(category, now.minus(2, ChronoUnit.DAYS));
        user = userRepository.save(user);

        var expiresAtInFuture = now.plus(7, ChronoUnit.DAYS);
        var body = "[{"
            + "\"user_id\" : " + user.getId() + ", "
            + "\"expires_at\" : \"" + expiresAtInFuture + "\""
            + "}]";
        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .body(body)
            .post("/v1/categories/86243c8b-b33c-44c8-829f-beeb4314cb67/members")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_INTERNAL_SERVER_ERROR);
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void assignUsersToCategory_whenExpiredIsPresent_ok() {
        MockServerClient schedulerMockServer = mockSchedulerServer();
        MockServerClient emailServerMock = mockEmailServer();
        String tenantId = "tenant-id";
        mockTenantResponse(tenantId, "/mock_anemone_single_tenant_public.json");

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);

        CategoryDocument vip = categoryRepository.save(new CategoryDocument(CategoryId.valueOf("86243c8b-b33c-44c8-829f-beeb4314cb67"),
            TenantId.valueOf("tenant-id"),
            "VIP",
            new CategoryExpirationField(ExpirationUnit.DAYS, 7),
            new BookingPrivilegeField(10, 5, 3, Duration.ofHours(2)), null, null));
        UserEntity user = createUser("User Test", "ok@email.com");
        LinkedAccountEntity linkedAccountEntity = new LinkedAccountEntity(user, "tenant-id", "1", null, null);
        user.setLinkedAccounts(Collections.singleton(linkedAccountEntity));
        var now = clockProvider.getClock().instant();
        user.addCategory(vip, now.minus(2, ChronoUnit.DAYS));
        user = userRepository.save(user);

        CategoryDocument gold = categoryRepository.save(new CategoryDocument(CategoryId.valueOf("77243c8b-b33c-44c8-829f-beeb4314cb67"),
            TenantId.valueOf("tenant-id"),
            "Gold",
            new CategoryExpirationField(ExpirationUnit.DAYS, 7),
            new BookingPrivilegeField(10, 5, 3, Duration.ofHours(2)), null, null));
        var expiresAtInFuture = now.plus(7, ChronoUnit.DAYS);
        var body = "[{"
            + "\"user_id\" : " + user.getId() + ", "
            + "\"expires_at\" : \"" + expiresAtInFuture + "\""
            + "}]";
        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .body(body)
            .post("/v1/categories/77243c8b-b33c-44c8-829f-beeb4314cb67/members")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_NO_CONTENT);
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void assignUsersToCategory_pastDate_error() {
        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);

        UserEntity user = createUser("User Test", "ok@email.com");
        LinkedAccountEntity linkedAccountEntity = new LinkedAccountEntity(user, "tenant-id", "1", null, null);
        user.setLinkedAccounts(Collections.singleton(linkedAccountEntity));
        user = userRepository.save(user);

        categoryRepository.save(new CategoryDocument(CategoryId.valueOf("86243c8b-b33c-44c8-829f-beeb4314cb67"),
            TenantId.valueOf("tenant-id"),
            "VIP",
            new CategoryExpirationField(ExpirationUnit.DAYS, 7),
            new BookingPrivilegeField(10, 5, 3, Duration.ofHours(2)), null, null));

        String body = "[{"
            + "\"user_id\" : " + user.getId() + ", "
            + "\"expires_at\" : \"2012-01-01\""
            + "}]";
        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .body(body)
            .post("/v1/categories/86243c8b-b33c-44c8-829f-beeb4314cb67/members")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_BAD_REQUEST);
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void assignUsersToCategory_nullUserId_error() {
        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);

        categoryRepository.save(new CategoryDocument(CategoryId.valueOf("86243c8b-b33c-44c8-829f-beeb4314cb67"),
            TenantId.valueOf("tenant-id"),
            "VIP",
            new CategoryExpirationField(ExpirationUnit.DAYS, 7),
            new BookingPrivilegeField(10, 5, 3, Duration.ofHours(2)), null, null));

        String body = "[{"
            + "\"user_id\" : null, "
            + "\"expires_at\" : null"
            + "}]";
        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .body(body)
            .post("/v1/categories/86243c8b-b33c-44c8-829f-beeb4314cb67/members")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_BAD_REQUEST);
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void assignUsersTocategory_expires_at_null_ok() {
        MockServerClient schedulerServer = mockSchedulerServer();
        MockServerClient emailServer = mockEmailServer();
        String tenantId = "tenant-id";
        mockTenantResponse(tenantId, "/mock_anemone_single_tenant_public.json");
        mockEmailServer();

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);

        UserEntity user = createUser("User Test", "ok@email.com");
        LinkedAccountEntity linkedAccountEntity = new LinkedAccountEntity(user, "tenant-id", "1", null, null);
        user.setLinkedAccounts(Collections.singleton(linkedAccountEntity));
        user = userRepository.save(user);

        categoryRepository.save(new CategoryDocument(CategoryId.valueOf("86243c8b-b33c-44c8-829f-beeb4314cb67"),
            TenantId.valueOf("tenant-id"),
            "VIP",
            new CategoryExpirationField(ExpirationUnit.DAYS, 7),
            new BookingPrivilegeField(10, 5, 3, Duration.ofHours(2)), null, null));

        String body = "[{"
            + "\"user_id\" : " + user.getId() + ", "
            + "\"expires_at\" : null"
            + "}]";
        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .body(body)
            .post("/v1/categories/86243c8b-b33c-44c8-829f-beeb4314cb67/members")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_NO_CONTENT);

        emailServer.verify(
            HttpRequest.request()
                .withPath("/v1/emails_batch")
                .withMethod("POST"),
            VerificationTimes.once());

        schedulerServer.verifyZeroInteractions();
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void assignUsersToCategory_membershipCategory_notAllowed_bad_request() {
        MockServerClient schedulerServer = mockSchedulerServer();
        MockServerClient emailServer = mockEmailServer();
        String tenantId = "tenant-id";
        mockTenantResponse(tenantId, "/mock_anemone_single_tenant_public.json");
        mockEmailServer();

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);

        UserEntity user = createUser("User Test", "ok@email.com");
        LinkedAccountEntity linkedAccountEntity = new LinkedAccountEntity(user, "tenant-id", "1", null, null);
        user.setLinkedAccounts(Collections.singleton(linkedAccountEntity));
        user = userRepository.save(user);

        categoryRepository.save(new CategoryDocument(CategoryId.valueOf("86243c8b-b33c-44c8-829f-beeb4314cb67"),
            TenantId.valueOf("tenant-id"),
            "VIP",
            new CategoryExpirationField(ExpirationUnit.DAYS, 7),
            new BookingPrivilegeField(10, 5, 3, Duration.ofHours(2)), CategoryType.MEMBERSHIP, null));

        String body = "[{"
            + "\"user_id\" : " + user.getId() + ", "
            + "\"expires_at\" : null"
            + "}]";
        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .body(body)
            .post("/v1/categories/86243c8b-b33c-44c8-829f-beeb4314cb67/members")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_BAD_REQUEST);
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void assignUsersTocategory_expires_at_nonNullAfter15days_ok() {
        String tenantId = "tenant-id";
        mockTenantResponse(tenantId, "/mock_anemone_single_tenant_public.json");
        MockServerClient emailServer = mockEmailServer();
        MockServerClient schedulerServer = mockSchedulerServer();

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);

        // test category duration > 15 days
        UserEntity user = createUser("User Test", "ok@email.com");
        LinkedAccountEntity linkedAccountEntity = new LinkedAccountEntity(user, "tenant-id", "1", null, null);
        user.setLinkedAccounts(Collections.singleton(linkedAccountEntity));
        user = userRepository.save(user);

        String categoryId = UUID.randomUUID().toString();
        categoryRepository.save(new CategoryDocument(CategoryId.valueOf(categoryId),
            TenantId.valueOf("tenant-id"),
            "VIP",
            new CategoryExpirationField(ExpirationUnit.DAYS, 7),
            new BookingPrivilegeField(10, 5, 3, Duration.ofHours(2)), null, null));

        String body = "[{"
            + "\"user_id\" : " + user.getId() + ", "
            + "\"expires_at\" : \"" + clockProvider.getClock().instant().plus(20, ChronoUnit.DAYS) + "\""
            + "}]";

        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .body(body)
            .post("/v1/categories/" + categoryId + "/members")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_NO_CONTENT);

        emailServer.verify(
            HttpRequest.request()
                .withPath("/v1/emails_batch")
                .withMethod("POST"),
            VerificationTimes.once());

        schedulerServer.verify(
            HttpRequest.request()
                .withPath("/v1/scheduler/tasks")
                .withMethod("POST"),
            VerificationTimes.exactly(2));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void assignUsersToMembershipCategory_expires_at_nonNull_badRequest() {
        String tenantId = "tenant-id";
        mockTenantResponse(tenantId, "/mock_anemone_single_tenant_public.json");
        MockServerClient emailServer = mockEmailServer();
        MockServerClient schedulerServer = mockSchedulerServer();

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);

        // test category duration > 15 days
        UserEntity user = createUser("User Test", "ok@email.com");
        LinkedAccountEntity linkedAccountEntity = new LinkedAccountEntity(user, "tenant-id", "1", null, null);
        user.setLinkedAccounts(Collections.singleton(linkedAccountEntity));
        user = userRepository.save(user);

        String categoryId = UUID.randomUUID().toString();
        categoryRepository.save(new CategoryDocument(CategoryId.valueOf(categoryId),
            TenantId.valueOf("tenant-id"),
            "VIP",
            new CategoryExpirationField(ExpirationUnit.DAYS, 7),
            new BookingPrivilegeField(10, 5, 3, Duration.ofHours(2)), CategoryType.MEMBERSHIP, null));

        String body = "[{"
            + "\"user_id\" : " + user.getId() + ", "
            + "\"expires_at\" : \"" + clockProvider.getClock().instant().plus(20, ChronoUnit.DAYS) + "\""
            + "}]";

        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .body(body)
            .post("/v1/categories/" + categoryId + "/members")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_BAD_REQUEST);

        emailServer.verify(
            HttpRequest.request()
                .withPath("/v1/emails_batch")
                .withMethod("POST"),
            VerificationTimes.exactly(0));

        schedulerServer.verify(
            HttpRequest.request()
                .withPath("/v1/scheduler/tasks")
                .withMethod("POST"),
            VerificationTimes.exactly(0));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void assignUsersTocategory_expires_at_nonNullBefore15days_ok() {
        String tenantId = "tenant-id";
        mockTenantResponse(tenantId, "/mock_anemone_single_tenant_public.json");
        MockServerClient emailServer = mockEmailServer();
        MockServerClient schedulerServer = mockSchedulerServer();

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);

        // test category duration > 15 days
        UserEntity user = createUser("User Test", "ok@email.com");
        LinkedAccountEntity linkedAccountEntity = new LinkedAccountEntity(user, "tenant-id", "1", null, null);
        user.setLinkedAccounts(Collections.singleton(linkedAccountEntity));
        user = userRepository.save(user);

        String categoryId = UUID.randomUUID().toString();
        categoryRepository.save(new CategoryDocument(CategoryId.valueOf(categoryId),
            TenantId.valueOf("tenant-id"),
            "VIP",
            new CategoryExpirationField(ExpirationUnit.DAYS, 7),
            new BookingPrivilegeField(10, 5, 3, Duration.ofHours(2)), null, null));

        String body = "[{"
            + "\"user_id\" : " + user.getId() + ", "
            + "\"expires_at\" : \"" + clockProvider.getClock().instant().plus(10, ChronoUnit.DAYS) + "\""
            + "}]";

        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .body(body)
            .post("/v1/categories/" + categoryId + "/members")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_NO_CONTENT);

        emailServer.verify(
            HttpRequest.request()
                .withPath("/v1/emails_batch")
                .withMethod("POST"),
            VerificationTimes.once());

        schedulerServer.verify(
            HttpRequest.request()
                .withPath("/v1/scheduler/tasks")
                .withMethod("POST"),
            VerificationTimes.exactly(1));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void assignUsersToCategory_disabledCategory_error() {
        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);

        UserEntity user = createUser("User Test", "ok@email.com");
        LinkedAccountEntity linkedAccountEntity = new LinkedAccountEntity(user, "tenant-id", "1", null, null);
        user.setLinkedAccounts(Collections.singleton(linkedAccountEntity));
        user = userRepository.save(user);

        categoryRepository.save(new CategoryDocument(CategoryId.valueOf("86243c8b-b33c-44c8-829f-beeb4314cb67"),
            TenantId.valueOf("tenant-id"),
            "VIP",
            Status.DISABLED,
            new CategoryExpirationField(ExpirationUnit.DAYS, 7),
            new BookingPrivilegeField(10, 5, 3, Duration.ofHours(2)),
            null,
            false,
            null, null, null));

        String body = "[{"
            + "\"user_id\" : " + user.getId() + ", "
            + "\"expires_at\" : null"
            + "}]";
        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .body(body)
            .post("/v1/categories/86243c8b-b33c-44c8-829f-beeb4314cb67/members")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_BAD_REQUEST)
            .body("status", is("CATEGORY_IS_DISABLED"));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void assignUsersToCategory_withoutLinkedAccount_error() {
        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);

        UserEntity user = createUser("User Test", "ok@email.com");
        user = userRepository.save(user);

        categoryRepository.save(new CategoryDocument(CategoryId.valueOf("86243c8b-b33c-44c8-829f-beeb4314cb67"),
            TenantId.valueOf("tenant-id"),
            "VIP",
            new CategoryExpirationField(ExpirationUnit.DAYS, 7),
            new BookingPrivilegeField(10, 5, 3, Duration.ofHours(2)), null, null));

        mockTenantResponse("tenant-id", "/mock_anemone_single_tenant_public.json");

        String body = "[{"
            + "\"user_id\" : " + user.getId() + ", "
            + "\"expires_at\" : null"
            + "}]";
        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .body(body)
            .post("/v1/categories/86243c8b-b33c-44c8-829f-beeb4314cb67/members")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_FORBIDDEN);
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void assignUsersToCategory_invalidCategoryId_error() {
        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);
        UserEntity user = createUser("User Test", "ok@email.com");
        LinkedAccountEntity linkedAccountEntity = new LinkedAccountEntity(user, "tenant-id", "1", null, null);
        user.setLinkedAccounts(Collections.singleton(linkedAccountEntity));
        user = userRepository.save(user);

        String body = "[{"
            + "\"user_id\" : " + user.getId() + ", "
            + "\"expires_at\" : null"
            + "}]";
        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .body(body)
            .post("/v1/categories/86243c8b-b33c-44c8-829f-beeb4314cb67/members")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_NOT_FOUND);
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void assignUsersToCategory_userAlreadyAssignedToCategory_error() {
        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);
        CategoryDocument category = categoryRepository.save(new CategoryDocument(CategoryId.valueOf("86243c8b-b33c-44c8-829f-beeb4314cb67"),
            TenantId.valueOf("tenant-id"),
            "VIP",
            new CategoryExpirationField(ExpirationUnit.DAYS, 7),
            new BookingPrivilegeField(10, 5, 3, Duration.ofHours(2)), null, null));
        UserEntity user = createUser("User Test", "ok@email.com");
        LinkedAccountEntity linkedAccountEntity = new LinkedAccountEntity(user, "tenant-id", "1", null, null);
        user.setLinkedAccounts(Collections.singleton(linkedAccountEntity));
        user.addCategory(category, null);
        user = userRepository.save(user);

        mockTenantResponse("tenant-id", "/mock_anemone_single_tenant_public.json");

        String body = "[{"
            + "\"user_id\" : " + user.getId() + ", "
            + "\"expires_at\" : null"
            + "}]";
        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .body(body)
            .post("/v1/categories/86243c8b-b33c-44c8-829f-beeb4314cb67/members")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_BAD_REQUEST);
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void updateUsersToCategory_userAlreadyAssignedToCategory_ok() {
        MockServerClient schedulerMockServer = mockSchedulerServer();
        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        mockTenantResponse("tenant-id", "/mock_anemone_single_tenant_public.json");
        String authHeader = createAuthHeader(extraClaims);
        CategoryDocument category = categoryRepository.save(new CategoryDocument(CategoryId.valueOf("86243c8b-b33c-44c8-829f-beeb4314cb67"),
            TenantId.valueOf("tenant-id"),
            "VIP",
            new CategoryExpirationField(ExpirationUnit.DAYS, 7),
            new BookingPrivilegeField(10, 5, 3, Duration.ofHours(2)), null, null));
        UserEntity user = createUser("User Test", "ok@email.com");
        LinkedAccountEntity linkedAccountEntity = new LinkedAccountEntity(user, "tenant-id", "1", null, null);
        user.setLinkedAccounts(Collections.singleton(linkedAccountEntity));
        user.addCategory(category, null);
        user = userRepository.save(user);

        LocalDateTime expiresAt = LocalDateTime.ofInstant(clockProvider.getClock().instant().plus(20, ChronoUnit.DAYS), ZoneId.systemDefault());
        String body = "[{"
            + "\"user_id\" : " + user.getId() + ", "
            + "\"expires_at\" : \"" + expiresAt + "\""
            + "}]";
        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .body(body)
            .put("/v1/categories/86243c8b-b33c-44c8-829f-beeb4314cb67/members")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_NO_CONTENT);

        schedulerMockServer.verify(
            HttpRequest.request()
                .withPath("/v1/scheduler/tasks")
                .withMethod("POST"),
            VerificationTimes.exactly(2));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void updateUsersToMembershipCategory_expires_at_nonNull_badRequest() {
        MockServerClient schedulerMockServer = mockSchedulerServer();
        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        mockTenantResponse("tenant-id", "/mock_anemone_single_tenant_public.json");
        String authHeader = createAuthHeader(extraClaims);
        CategoryDocument category = categoryRepository.save(new CategoryDocument(CategoryId.valueOf("86243c8b-b33c-44c8-829f-beeb4314cb67"),
            TenantId.valueOf("tenant-id"),
            "VIP",
            new CategoryExpirationField(ExpirationUnit.DAYS, 7),
            new BookingPrivilegeField(10, 5, 3, Duration.ofHours(2)), CategoryType.MEMBERSHIP, null));
        UserEntity user = createUser("User Test", "ok@email.com");
        LinkedAccountEntity linkedAccountEntity = new LinkedAccountEntity(user, "tenant-id", "1", null, null);
        user.setLinkedAccounts(Collections.singleton(linkedAccountEntity));
        user.addCategory(category, null);
        user = userRepository.save(user);

        LocalDateTime expiresAt = LocalDateTime.ofInstant(clockProvider.getClock().instant().plus(20, ChronoUnit.DAYS), ZoneId.systemDefault());
        String body = "[{"
            + "\"user_id\" : " + user.getId() + ", "
            + "\"expires_at\" : \"" + expiresAt + "\""
            + "}]";
        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .body(body)
            .put("/v1/categories/86243c8b-b33c-44c8-829f-beeb4314cb67/members")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_BAD_REQUEST);

        schedulerMockServer.verify(
            HttpRequest.request()
                .withPath("/v1/scheduler/tasks")
                .withMethod("POST"),
            VerificationTimes.exactly(0));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void updateUsersToMembershipCategory_expires_at_null_ok() {
        MockServerClient schedulerMockServer = mockSchedulerServer();
        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        mockTenantResponse("tenant-id", "/mock_anemone_single_tenant_public.json");
        String authHeader = createAuthHeader(extraClaims);
        CategoryDocument category = categoryRepository.save(new CategoryDocument(CategoryId.valueOf("86243c8b-b33c-44c8-829f-beeb4314cb67"),
            TenantId.valueOf("tenant-id"),
            "VIP",
            new CategoryExpirationField(ExpirationUnit.DAYS, 7),
            new BookingPrivilegeField(10, 5, 3, Duration.ofHours(2)), CategoryType.MEMBERSHIP, null));
        UserEntity user = createUser("User Test", "ok@email.com");
        LinkedAccountEntity linkedAccountEntity = new LinkedAccountEntity(user, "tenant-id", "1", null, null);
        user.setLinkedAccounts(Collections.singleton(linkedAccountEntity));
        user.addCategory(category, null);
        user = userRepository.save(user);

        String body = "[{"
            + "\"user_id\" : " + user.getId()
            + "}]";
        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .body(body)
            .put("/v1/categories/86243c8b-b33c-44c8-829f-beeb4314cb67/members")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_NO_CONTENT);

        schedulerMockServer.verify(
            HttpRequest.request()
                .withPath("/v1/scheduler/tasks")
                .withMethod("POST"),
            VerificationTimes.exactly(0));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void deleteMembersFromCategory_all_ok() {
        String tenantId = "tenant-id";
        mockTenantResponse(tenantId, "/mock_anemone_single_tenant_public.json");

        MockServerClient emailServerMock = mockEmailServer();
        mockEmailServer();

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);
        CategoryDocument category = categoryRepository.save(new CategoryDocument(CategoryId.valueOf("86243c8b-b33c-44c8-829f-beeb4314cb67"),
            TenantId.valueOf("tenant-id"),
            "VIP",
            new CategoryExpirationField(ExpirationUnit.DAYS, 7),
            new BookingPrivilegeField(10, 5, 3, Duration.ofHours(2)), null, null));
        UserEntity user1 = createUser("User Test", "ok@email.com");
        user1.setLinkedAccounts(Collections.singleton(new LinkedAccountEntity(user1, "tenant-id", "1", null, null)));
        user1.addCategory(category, null);
        user1 = userRepository.save(user1);

        UserEntity user2 = createUser("User Test", "ok@email.com");
        user2.setLinkedAccounts(Collections.singleton(new LinkedAccountEntity(user2, "tenant-id", "1", null, null)));
        user2.addCategory(category, null);
        user2 = userRepository.save(user2);
        assertThat(tenantTagRepository.countByTagAndType("86243c8b-b33c-44c8-829f-beeb4314cb67", Type.ANEMONE_CATEGORY)).isEqualTo(2);

        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .delete("/v1/categories/86243c8b-b33c-44c8-829f-beeb4314cb67/members")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_NO_CONTENT);

        assertThat(tenantTagRepository.countByTagAndType("86243c8b-b33c-44c8-829f-beeb4314cb67", Type.ANEMONE_CATEGORY)).isZero();

        emailServerMock.verify(
            HttpRequest.request()
                .withPath("/v1/emails_batch")
                .withMethod("POST"),
            VerificationTimes.once());
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void deleteMembersFromCategory_user_id_ok() {
        String tenantId = "tenant-id";
        mockTenantResponse(tenantId, "/mock_anemone_single_tenant_public.json");

        mockEmailServer();
        Map<String, List<String>> claimData = tenantsIdsClaimData(tenantId);
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);
        CategoryDocument category = categoryRepository.save(new CategoryDocument(CategoryId.valueOf("86243c8b-b33c-44c8-829f-beeb4314cb67"),
            TenantId.valueOf(tenantId),
            "VIP",
            new CategoryExpirationField(ExpirationUnit.DAYS, 7),
            new BookingPrivilegeField(10, 5, 3, Duration.ofHours(2)), null, null));
        UserEntity user1 = createUser("User Test", "ok@email.com");
        user1.setLinkedAccounts(Collections.singleton(new LinkedAccountEntity(user1, tenantId, "1", null, null)));
        user1.addCategory(category, null);
        user1 = userRepository.save(user1);

        UserEntity user2 = createUser("User Test", "ok@email.com");
        user2.setLinkedAccounts(Collections.singleton(new LinkedAccountEntity(user2, tenantId, "1", null, null)));
        user2.addCategory(category, null);
        userRepository.save(user2);

        assertThat(tenantTagRepository.countByTagAndType("86243c8b-b33c-44c8-829f-beeb4314cb67", Type.ANEMONE_CATEGORY)).isEqualTo(2);

        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .param("user_id", user1.getId())
            .delete("/v1/categories/86243c8b-b33c-44c8-829f-beeb4314cb67/members")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_NO_CONTENT);

        assertThat(tenantTagRepository.countByTagAndType("86243c8b-b33c-44c8-829f-beeb4314cb67", Type.ANEMONE_CATEGORY)).isEqualTo(1);
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void assignUsersToCategory_noAccessToTenant_error() {
        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);
        CategoryDocument category = categoryRepository.save(new CategoryDocument(CategoryId.valueOf("86243c8b-b33c-44c8-829f-beeb4314cb67"),
            TenantId.valueOf("tenant-id-no-access"),
            "VIP",
            new CategoryExpirationField(ExpirationUnit.DAYS, 7),
            new BookingPrivilegeField(10, 5, 3, Duration.ofHours(2)), null, null));
        UserEntity user = createUser("User Test", "ok@email.com");
        LinkedAccountEntity linkedAccountEntity = new LinkedAccountEntity(user, "tenant-id-no-access", "1", null, null);
        user.setLinkedAccounts(Collections.singleton(linkedAccountEntity));
        user.addCategory(category, null);
        user = userRepository.save(user);

        String body = "[{"
            + "\"user_id\" : " + user.getId() + ", "
            + "\"expires_at\" : null"
            + "}]";
        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .body(body)
            .post("/v1/categories/86243c8b-b33c-44c8-829f-beeb4314cb67/members")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_FORBIDDEN);
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void changeCategoryStatus_ok() {
        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);
        CategoryDocument category = categoryRepository.save(new CategoryDocument(CategoryId.valueOf("96243c8b-b33c-44c8-829f-beeb4314cb67"),
            TenantId.valueOf("tenant-id"),
            "VIP",
            new CategoryExpirationField(ExpirationUnit.DAYS, 7),
            new BookingPrivilegeField(10, 5, 3, Duration.ofHours(2)), null, null));

        String body = "{"
            + "\"status\" : \"DISABLED\""
            + "}";
        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .body(body)
            .patch("/v1/categories/96243c8b-b33c-44c8-829f-beeb4314cb67")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_OK);

        body = "{"
            + "\"status\" : \"ENABLED\""
            + "}";
        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .body(body)
            .patch("/v1/categories/96243c8b-b33c-44c8-829f-beeb4314cb67")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_OK);
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void changeCategoryStatus_withAssignedMembers_error() {
        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);
        CategoryDocument category = categoryRepository.save(new CategoryDocument(CategoryId.valueOf("86243c8b-b33c-44c8-829f-beeb4314cb67"),
            TenantId.valueOf("tenant-id"),
            "VIP",
            new CategoryExpirationField(ExpirationUnit.DAYS, 7),
            new BookingPrivilegeField(10, 5, 3, Duration.ofHours(2)), null, null));
        UserEntity user = createUser("User Test", "ok@email.com");
        LinkedAccountEntity linkedAccountEntity = new LinkedAccountEntity(user, "tenant-id", "1", null, null);
        user.setLinkedAccounts(Collections.singleton(linkedAccountEntity));
        user.addCategory(category, null);
        user = userRepository.save(user);

        String body = "{"
            + "\"status\" : \"DISABLED\""
            + "}";
        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .body(body)
            .patch("/v1/categories/86243c8b-b33c-44c8-829f-beeb4314cb67")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_BAD_REQUEST)
            .body("status", is("CATEGORY_CANNOT_BE_DISABLED"));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void changeCategoryPricingType_ok() {
        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);
        CategoryDocument category = categoryRepository.save(new CategoryDocument(CategoryId.valueOf("86243c8b-b33c-44c8-829f-beeb4314cb67"),
            TenantId.valueOf("tenant-id"),
            "VIP",
            new CategoryExpirationField(ExpirationUnit.DAYS, 7),
            new BookingPrivilegeField(10, 5, 3, Duration.ofHours(2)), null, null));
        UserEntity user = createUser("User Test", "ok@email.com");
        LinkedAccountEntity linkedAccountEntity = new LinkedAccountEntity(user, "tenant-id", "1", null, null);
        user.setLinkedAccounts(Collections.singleton(linkedAccountEntity));
        user.addCategory(category, null);
        userRepository.save(user);

        assertThat(category.isAllowSinglePaymentWhenPriceIsCustomized()).isFalse();

        String body = "{"
            + "\"pricing_type\" : null"
            + "}";
        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .body(body)
            .patch("/v1/categories/86243c8b-b33c-44c8-829f-beeb4314cb67")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_OK)
            .body("allow_single_payment_when_price_is_customized", is(false));

        body = "{"
            + "\"pricing_type\" : \"SIMPLE\""
            + "}";

        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .body(body)
            .patch("/v1/categories/86243c8b-b33c-44c8-829f-beeb4314cb67")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_OK)
            .body("pricing_type", is("SIMPLE"))
            .body("allow_single_payment_when_price_is_customized", is(false));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void changeCategoryAllowSinglePaymentWhenPriceIsCustomized_ok() {
        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        String authHeader = createAuthHeader(extraClaims);
        CategoryDocument category = categoryRepository.save(new CategoryDocument(CategoryId.valueOf("86243c8b-b33c-44c8-829f-beeb4314cb67"),
            TenantId.valueOf("tenant-id"),
            "VIP",
            new CategoryExpirationField(ExpirationUnit.DAYS, 7),
            new BookingPrivilegeField(10, 5, 3, Duration.ofHours(2)), null, null));
        UserEntity user = createUser("User Test", "ok@email.com");
        LinkedAccountEntity linkedAccountEntity = new LinkedAccountEntity(user, "tenant-id", "1", null, null);
        user.setLinkedAccounts(Collections.singleton(linkedAccountEntity));
        user.addCategory(category, null);
        userRepository.save(user);

        assertThat(category.isAllowSinglePaymentWhenPriceIsCustomized()).isFalse();

        String body =  "{"
            + "\"allow_single_payment_when_price_is_customized\" : true"
            + "}";

        given()
            .contentType(ContentType.APPLICATION_JSON.toString())
            .header("Authorization", authHeader)
            .body(body)
            .patch("/v1/categories/86243c8b-b33c-44c8-829f-beeb4314cb67")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_OK)
            .body("allow_single_payment_when_price_is_customized", is(true));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_ADMIN)
    void sendExpiringEmail_expiring_expiresAtNotChanged() throws JsonProcessingException {
        String tenantId = "tenant-1";
        mockTenantResponse(tenantId, "/mock_anemone_single_tenant_public.json");
        mockTenantResponseToGetByIds(tenantId);

        MockServerClient emailMockServer = mockEmailServer();
        String categoryId = UUID.randomUUID().toString();
        Instant expiresAt = clockProvider.getClock().instant().plus(20, ChronoUnit.DAYS).truncatedTo(ChronoUnit.SECONDS);

        UserEntity userWithExpiredCategory = createUser("User Test", "ok@email.com");
        TenantTagEntity shouldExpire = new TenantTagEntity();
        shouldExpire.setUser(userWithExpiredCategory);
        shouldExpire.setTag(categoryId);
        shouldExpire.setExpiresAt(expiresAt);
        shouldExpire.setTenantId(tenantId);
        shouldExpire.setType(Type.ANEMONE_CATEGORY);
        userWithExpiredCategory.getTenantTags().add(shouldExpire);
        userRepository.save(userWithExpiredCategory);

        assertThat(tenantTagRepository.count()).isEqualTo(1);

        ObjectMapper objectMapper = customMappingJackson2HttpMessageConverter.getObjectMapper();
        MemberTaskDetails taskDetails = MemberTaskDetails.builder()
            .userId(userWithExpiredCategory.getId().toString())
            .expiresAt(expiresAt)
            .tenantId(tenantId)
            .tenantName("some-club")
            .categoryName("VIP")
            .tenantZoneId(ZoneId.of("Europe/Madrid"))
            .build();

        given()
            .header("Authorization", createAuthHeader())
            .contentType(ContentType.APPLICATION_JSON.toString())
            .body(objectMapper.writeValueAsString(taskDetails))
            .post("/v1/categories/" + categoryId + "/members/send-expiration-reminder")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_NO_CONTENT);

        emailMockServer.verify(
            HttpRequest.request()
                .withPath("/v1/emails_batch")
                .withMethod("POST"),
            VerificationTimes.once());

        assertThat(tenantTagRepository.count()).isEqualTo(1);

    }

    @Test
    @WithMockUser(role = UserRole.ROLE_ADMIN)
    void sendExpiringEmail_expiring_expiresAtChanged() throws JsonProcessingException {
        String tenantId = "tenant-1";
        mockTenantResponse(tenantId, "/mock_anemone_single_tenant_public.json");
        mockTenantResponseToGetByIds(tenantId);

        MockServerClient emailMockServer = mockEmailServer();
        String categoryId = UUID.randomUUID().toString();
        Instant expiresAt = clockProvider.getClock().instant().plus(20, ChronoUnit.DAYS);

        UserEntity userWithExpiredCategory = createUser("User Test", "ok@email.com");
        TenantTagEntity shouldExpire = new TenantTagEntity();
        shouldExpire.setUser(userWithExpiredCategory);
        shouldExpire.setTag(categoryId);
        shouldExpire.setExpiresAt(expiresAt);
        shouldExpire.setTenantId(tenantId);
        shouldExpire.setType(Type.ANEMONE_CATEGORY);
        userWithExpiredCategory.getTenantTags().add(shouldExpire);
        userRepository.save(userWithExpiredCategory);

        assertThat(tenantTagRepository.count()).isEqualTo(1);

        ObjectMapper objectMapper = customMappingJackson2HttpMessageConverter.getObjectMapper();
        MemberTaskDetails taskDetails = MemberTaskDetails.builder()
            .userId(userWithExpiredCategory.getId().toString())
            .expiresAt(expiresAt.minus(5, ChronoUnit.DAYS))
            .tenantId(tenantId)
            .tenantName("some-club")
            .categoryName("VIP")
            .tenantZoneId(ZoneId.of("Europe/Madrid"))
            .build();

        given()
            .header("Authorization", createAuthHeader())
            .contentType(ContentType.APPLICATION_JSON.toString())
            .body(objectMapper.writeValueAsString(taskDetails))
            .post("/v1/categories/" + categoryId + "/members/send-expiration-reminder")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_NO_CONTENT);

        emailMockServer.verifyZeroInteractions();

        assertThat(tenantTagRepository.count()).isEqualTo(1);

    }

    @Test
    @WithMockUser(role = UserRole.ROLE_ADMIN)
    void deleteExpired_expired_expiresAtNotChanged() throws JsonProcessingException {
        String tenantId = "tenant-1";
        mockTenantResponse(tenantId, "/mock_anemone_single_tenant_public.json");
        mockTenantResponseToGetByIds(tenantId);

        MockServerClient emailMockServer = mockEmailServer();
        String categoryId = UUID.randomUUID().toString();
        Instant expiresAt = clockProvider.getClock().instant().truncatedTo(ChronoUnit.SECONDS);

        UserEntity userWithExpiredCategory = createUser("User Test", "ok@email.com");
        TenantTagEntity shouldExpire = new TenantTagEntity();
        shouldExpire.setUser(userWithExpiredCategory);
        shouldExpire.setTag(categoryId);
        shouldExpire.setExpiresAt(expiresAt);
        shouldExpire.setTenantId(tenantId);
        shouldExpire.setType(Type.ANEMONE_CATEGORY);
        userWithExpiredCategory.getTenantTags().add(shouldExpire);
        userRepository.save(userWithExpiredCategory);

        assertThat(tenantTagRepository.count()).isEqualTo(1);

        ObjectMapper objectMapper = customMappingJackson2HttpMessageConverter.getObjectMapper();
        MemberTaskDetails taskDetails = MemberTaskDetails.builder()
            .userId(userWithExpiredCategory.getId().toString())
            .expiresAt(expiresAt)
            .tenantId(tenantId)
            .tenantName("some-club")
            .categoryName("VIP")
            .tenantZoneId(ZoneId.of("Europe/Madrid"))
            .build();

        given()
            .header("Authorization", createAuthHeader())
            .contentType(ContentType.APPLICATION_JSON.toString())
            .body(objectMapper.writeValueAsString(taskDetails))
            .post("/v1/categories/" + categoryId + "/members/expired-deletion")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_NO_CONTENT);

        emailMockServer.verify(
            HttpRequest.request()
                .withPath("/v1/emails_batch")
                .withMethod("POST"),
            VerificationTimes.once());

        assertThat(tenantTagRepository.count()).isZero();
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_ADMIN)
    void deleteExpired_expired_expiresAtChanged() throws JsonProcessingException {
        String tenantId = "tenant-1";
        mockTenantResponse(tenantId, "/mock_anemone_single_tenant_public.json");
        mockTenantResponseToGetByIds(tenantId);

        MockServerClient emailMockServer = mockEmailServer();
        String categoryId = UUID.randomUUID().toString();
        Instant expiresAt = clockProvider.getClock().instant();

        UserEntity userWithExpiredCategory = createUser("User Test", "ok@email.com");
        TenantTagEntity shouldExpire = new TenantTagEntity();
        shouldExpire.setUser(userWithExpiredCategory);
        shouldExpire.setTag(categoryId);
        shouldExpire.setExpiresAt(expiresAt);
        shouldExpire.setTenantId(tenantId);
        shouldExpire.setType(Type.ANEMONE_CATEGORY);
        userWithExpiredCategory.getTenantTags().add(shouldExpire);
        userRepository.save(userWithExpiredCategory);

        assertThat(tenantTagRepository.count()).isEqualTo(1);

        ObjectMapper objectMapper = customMappingJackson2HttpMessageConverter.getObjectMapper();
        MemberTaskDetails taskDetails = MemberTaskDetails.builder()
            .userId(userWithExpiredCategory.getId().toString())
            .expiresAt(expiresAt.minus(5, ChronoUnit.DAYS))
            .tenantId(tenantId)
            .tenantName("some-club")
            .categoryName("VIP")
            .tenantZoneId(ZoneId.of("Europe/Madrid"))
            .build();

        given()
            .header("Authorization", createAuthHeader())
            .contentType(ContentType.APPLICATION_JSON.toString())
            .body(objectMapper.writeValueAsString(taskDetails))
            .post("/v1/categories/" + categoryId + "/members/expired-deletion")
            .then()
            .log()
            .all()
            .statusCode(HttpStatus.SC_NO_CONTENT);

        emailMockServer.verifyZeroInteractions();
        assertThat(tenantTagRepository.count()).isEqualTo(1);
    }

    @Nonnull
    public static Map<String, List<String>> tenantsIdsClaimData(@Nonnull String... tenantIds) {
        return Map.of("tenant_ids", Arrays.asList(tenantIds));
    }

    @Nonnull
    public User getCurrentUser() {
        AnemoneUserPrincipal currentUserDetails =
            (AnemoneUserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return currentUserDetails.getUser();
    }

    @Nonnull
    public String createAuthHeader(@Nullable Map<String, Object> extraClaims) {
        return createAuthHeader(getCurrentUser().getId(), extraClaims);
    }

    @Nonnull
    private String createAuthHeader(@Nonnull UserId userId, @Nullable Map<String, Object> extraClaims) {
        Collection<GrantedAuthority> authorities = testCredentialsService.getTestPrincipal().getUser().getOriginalAuthorities();

        AccessJwtToken token = extraClaims == null ?
            jwtTokenFactory.createAccessJwtToken(userId.toString(), null, authorities) :
            jwtTokenFactory.createAccessJwtTokenWithCustomClaims(userId.toString(), null, authorities, extraClaims);

        return "Bearer " + token.getToken();
    }

    private void mockTenantResponse(@Nonnull String tenantId, @Nonnull String responseBodyPath) {
        String responseBody = readAsText(getCurrentPackageAsClasspath() + responseBodyPath);

        getMockServer(MOCK_TENANTS_PORT).
            when(request().
                withPath("/v1/tenants/" + tenantId)
            ).
            respond(response().
                withHeaders(new Header("Content-Type", "application/json; charset=utf-8")).
                withStatusCode(200).
                withBody(responseBody));
    }

    @Nonnull
    private String createAuthHeader() {
        return createAuthHeader(getCurrentUser().getId(), null);
    }

    @Nonnull
    private UserEntity createUser(@Nonnull String name, @Nonnull String email) {
        String hashPassword = new BCryptPasswordEncoder().encode("password");
        UserEntity userEntity = new UserEntity(name, hashPassword, email, true, null, false, null,null, "ES", PlaytomicUserType.ONLINE);

        userEntity.setAddressState("Tests tests");
        userEntity.setAddressStreet("Tests Street");
        userEntity.setAddressZipCode("Test zip code");
        userEntity.setAddressCity("Test city");

        return userRepository.save(userEntity);
    }

    @Nonnull
    private MockServerClient mockEmailServer() {
        MockServerClient emailServerMock = getMockServer(EMAIL_MOCK_SERVER_PORT);
        emailServerMock.when(request().
            withPath("/v1/emails")
        ).
            respond(response().
                withHeaders(new Header("Content-Type", "application/json")).
                withStatusCode(HttpStatusCode.OK_200.code()));

        emailServerMock.when(request().
            withPath("/v1/emails_batch")
        ).
            respond(response().
                withHeaders(new Header("Content-Type", "application/json")).
                withStatusCode(HttpStatusCode.OK_200.code()));
        return emailServerMock;
    }

    private void mockTenantResponseToGetByIds(@Nonnull String tenantId) {

        String responseBody = readAsText(getCurrentPackageAsClasspath() + "/mock_anemone_single_tenant_public.json");

        getMockServer(MOCK_TENANTS_PORT).
            when(request()
                .withPath("/v1/tenants")
                .withQueryStringParameter("tenant_id", tenantId))
            .respond(response().
                withHeaders(new Header("Content-Type", "application/json; charset=utf-8"))
                .withStatusCode(200)
                .withBody("[" + responseBody + "]"));
    }

    @Nonnull
    private MockServerClient mockSchedulerServer() {

        MockServerClient mockServer = getMockServer(SCHEDULER_MOCK_SERVER_PORT);
        mockServer.when(request()
            .withPath("/v1/scheduler/tasks"))
            .respond(response().
                withHeaders(new Header("Content-Type", "application/json; charset=utf-8"))
                .withStatusCode(200));
        return mockServer;
    }

    @Nonnull
    private MockServerClient mockSubscriptionsService(MembershipProductId id) {

        MockServerClient mockServer = getMockServer(SUBSCRIPTIONS_MOCK_SERVER_PORT);

        mockServer.when(request()
                .withPath("/v1/membership_products"))
            .respond(response().
                withHeaders(new Header("Content-Type", "application/json; charset=utf-8"))
                .withStatusCode(200)
                .withBody(id.getValue().toString()));

        mockServer.when(request()
                .withPath("/v1/membership_products/" + id))
            .respond(response()
                .withHeaders(new Header("Content-Type", "application/json; charset=utf-8"))
                .withStatusCode(200));

        return mockServer;
    }

}

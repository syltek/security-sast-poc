package com.playtomic.anemone.user.api.v3;

import static io.restassured.RestAssured.given;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockserver.model.HttpRequest.request;
import static org.mockserver.model.JsonBody.json;

import com.playtomic.anemone.UserApplication;
import com.playtomic.anemone.domain.Email;
import com.playtomic.anemone.domain.user.UserId;
import com.playtomic.anemone.domain.user.UserRole;
import com.playtomic.anemone.jwt.JwtTokenFactory;
import com.playtomic.anemone.jwt.RawAccessJwtToken;
import com.playtomic.anemone.spring.config.AnemoneUserPrincipal;
import com.playtomic.anemone.test.TestCredentialsService;
import com.playtomic.anemone.test.WithMockUser;
import com.playtomic.anemone.user.config.AbstractTestContainersSupport;
import com.playtomic.anemone.user.dao.JwtTokenEntity;
import com.playtomic.anemone.user.dao.JwtTokenRepository;
import com.playtomic.anemone.user.dao.PermissionRepository;
import com.playtomic.anemone.user.dao.PlaytomicUserType;
import com.playtomic.anemone.user.dao.UserEntity;
import com.playtomic.anemone.user.dao.UserRepository;
import com.playtomic.anemone.user.dao.UserRoleEntity;
import com.playtomic.anemone.user.dao.permissions.PermissionDocument;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import com.playtomic.anemone.user.model.permissions.PermissionLevel;
import com.playtomic.anemone.user.model.permissions.PermissionName;
import com.playtomic.anemone.user.model.role.PlaytomicUserRole;
import com.playtomic.anemone.user.service.UserCredentialService;
import com.playtomic.anemone.user.service.anemone.EmailServiceClient;
import com.playtomic.anemone.user.service.apple.AppleId;
import com.playtomic.anemone.user.service.apple.AppleService;
import com.playtomic.anemone.user.service.apple.AppleUserData;
import com.playtomic.anemone.user.service.email.EmailMessage;
import com.playtomic.anemone.user.service.exception.UserNotFoundException;
import com.playtomic.anemone.user.service.facebook.FacebookId;
import com.playtomic.anemone.user.service.facebook.FacebookService;
import com.playtomic.anemone.user.service.facebook.FacebookUserData;
import com.playtomic.anemone.user.service.google.GoogleId;
import com.playtomic.anemone.user.service.google.GoogleService;
import com.playtomic.anemone.user.service.google.GoogleUserData;
import io.restassured.http.ContentType;
import io.restassured.response.ExtractableResponse;
import io.restassured.response.Response;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import javax.annotation.Nonnull;
import org.apache.http.HttpStatus;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockserver.client.MockServerClient;
import org.mockserver.matchers.MatchType;
import org.mockserver.model.HttpResponse;
import org.mockserver.model.HttpStatusCode;
import org.mockserver.verify.VerificationTimes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.util.Assert;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = UserApplication.class)
@ExtendWith(SpringExtension.class)
public class AuthenticationControllerV3IT extends AbstractTestContainersSupport {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PermissionRepository permissionRepository;

    @Autowired
    private JwtTokenRepository jwtTokenRepository;

    @MockBean
    private FacebookService facebookService;

    @MockBean
    private GoogleService googleService;

    @MockBean
    private AppleService appleService;

    @Autowired
    private UserCredentialService userCredentialService;

    @Autowired
    private TestCredentialsService testCredentialsService;

    @Autowired
    private JwtTokenFactory jwtTokenFactory;

    private final String CHECK_AUTH_LOGIN = "/v3/auth/login";
    private final String CHECK_AUTH_REGISTER = "/v3/auth/register";
    private final String CHECK_IMPERSONATE = "/v3/auth/impersonation";
    private final String CHECK_AUTH_REFRESH = "/v3/auth/token";

    private final String CREATE_VOUCHER = "/v1/vouchers";
    private final static Integer VOUCHERS_MOCK_SERVER_PORT = 10001;

    private final static Integer SUBSCRIPTIONS_MOCK_SERVER_PORT = 10026;

    @MockBean
    private EmailServiceClient emailServiceClient;

    @BeforeEach
    public void setup() {
        doNothing().when(emailServiceClient).sendEmail(any());
    }

    @AfterEach
    public void clearRepos() {
        userRepository.deleteAll();
    }

    @Test
    public void test_impersonate_denied() {
        UserEntity user = createUser("One user", "One@email.com", true, "+34 123456789", false);

        JSONObject body = new JSONObject()
                .put("user_id", user.getId().toString());

        given()
                .contentType("application/json")
                .body(body.toString())
                .when()
                .post(CHECK_IMPERSONATE)
                .then()
                .statusCode(HttpStatus.SC_FORBIDDEN);
    }

    @WithMockUser(role = UserRole.ROLE_ADMIN)
    @Test
    public void test_impersonate_ok() {
        UserEntity user = createUser("One user", "One@email.com", true, "+34 123456789", false);

        JSONObject body = new JSONObject()
                .put("user_id", user.getId().toString());

        given()
                .contentType("application/json")
                .header("Authorization", testCredentialsService.createAuthorizationHeader())
                .body(body.toString())
                .when()
                .post(CHECK_IMPERSONATE)
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("user_id", is(user.getId().toString()))
        ;
    }

    // Auth - EMAIL/PASSWORD
    @Test
    public void test_email_register_methods() {
        UserEntity oldUser = createUser("Old user", "otherold@email.com", true, "+34 123456789", false);

        String body = "{"
                + "\"email\":\"existing@domain.com\","
                + "\"password\":\"MyPassword1337\","
                + "\"name\":\"my name\","
                + "\"phone\":\"+34 1234 56 789\","
                + "\"phone_token\":\"" + userCredentialService.hashPhone("+34 123456789") + "\""
                + "}";

        MockServerClient client = mockUpdatePeopleInteractionEvents(HttpStatusCode.OK_200);

        given()
                .contentType("application/json")
                .body(body)
                .when()
                .post(CHECK_AUTH_REGISTER)
                .then()
                .statusCode(HttpStatus.SC_OK).body("access_token", notNullValue());

        client.verify(
                request()
                        .withPath(CREATE_VOUCHER)
                        .withMethod("POST")
                        .withBody(
                                json("{\"search_id\":\"WELCOME\"}", MatchType.ONLY_MATCHING_FIELDS)
                        ),
                VerificationTimes.once());

        UserEntity user = userRepository.findUserByEmail("existing@domain.com")
                        .orElseThrow(() -> new IllegalStateException("user repo should contain created user"));
        Assert.isTrue(new BCryptPasswordEncoder().matches("MyPassword1337", user.getPasswordHash()), "Password is not correct");
        Assert.isTrue(!user.isEmailVerified(), "User should not have email verified");
        Assert.isTrue(user.getFullName().equals("my name"), "User name is not correct");
        Assert.isTrue(user.getPhone().equals("+34 123456789"), "Phone is not correct");
        Assert.isTrue(user.isPhoneVerified(), "Phone should be verified");
        Assert.isNull(userRepository.findById(oldUser.getId()).get().getPhone(), "Old user phone should be nullified");

        // Second time should fail
        given()
                .contentType("application/json")
                .body(body)
                .when()
                .post(CHECK_AUTH_REGISTER)
                .then()
                .statusCode(HttpStatus.SC_BAD_REQUEST)
                .body("status", is("INVALID_EMAIL"))
                .body("localized_message", notNullValue());

        // Badly formatted email
        body = "{"
                + "\"email\":\"wrong email .com\","
                + "\"password\":\"MyPassword1337\","
                + "\"name\":\"my name\""
                + "}";

        given()
                .contentType("application/json")
                .body(body)
                .when()
                .post(CHECK_AUTH_REGISTER)
                .then()
                .statusCode(HttpStatus.SC_BAD_REQUEST)
                .body("status", is("INVALID_EMAIL"))
                .body("localized_message", notNullValue());

        // Badly formatted password, should fail miserably.
        body = "{"
                + "\"email\":\"existing@domain.com\","
                + "\"password\":\"badpassword\","
                + "\"name\":\"my name\""
                + "}";

        given()
                .contentType("application/json")
                .body(body)
                .when()
                .post(CHECK_AUTH_REGISTER)
                .then()
                .statusCode(HttpStatus.SC_BAD_REQUEST)
                .body("status", is("INVALID_PASSWORD"))
                .body("localized_message", notNullValue());

        // Badly formatted phone, should fail miserably.
        body = "{"
                + "\"email\":\"new@domain.com\","
                + "\"password\":\"MyPassword1337\","
                + "\"name\":\"my name\","
                + "\"phone\":\"123-456789\""
                + "}";

        given()
                .contentType("application/json")
                .body(body)
                .when()
                .post(CHECK_AUTH_REGISTER)
                .then()
                .statusCode(HttpStatus.SC_BAD_REQUEST)
                .body("status", is("INVALID_PHONE"))
                .body("localized_message", notNullValue());

        // Already used and verified phone number should fail
        body = "{"
                + "\"email\":\"another-user@domain.com\","
                + "\"password\":\"MyPassword1337\","
                + "\"name\":\"my name\","
                + "\"phone\":\"+34 123456789\""
                + "}";
        given()
                .contentType("application/json")
                .body(body)
                .when()
                .post(CHECK_AUTH_REGISTER)
                .then()
                .statusCode(HttpStatus.SC_UNPROCESSABLE_ENTITY)
                .body("status", is("PHONE_ALREADY_IN_USE"))
                .body("localized_message", notNullValue());
    }

    @Test
    public void test_login_and_logout() {
        String body = "{"
                + "\"email\": \"non-existing@domain.com\","
                + "\"password\": \"mypassword\""
                + "}";

        given()
                .contentType(ContentType.JSON)
                .body(body)
                .when()
                .post(CHECK_AUTH_LOGIN)
                .then()
                .statusCode(HttpStatus.SC_UNAUTHORIZED);

        String hashPassword = new BCryptPasswordEncoder().encode("mypassword");
        UserEntity user = new UserEntity("user", hashPassword, "existing@domain.com", true, null, false, null,null, "ES", PlaytomicUserType.ONLINE);
        userRepository.save(user);

        body = "{"
                + "\"email\": \"existing@domain.com\","
                + "\"password\": \"mypassword\""
                + "}";

        String accessToken =
                given()
                        .contentType(ContentType.JSON)
                        .body(body)
                        .when()
                        .post(CHECK_AUTH_LOGIN)
                        .then()
                        .statusCode(HttpStatus.SC_OK)
                        .body("access_token", notNullValue())
                        .body("refresh_token", notNullValue())
                        .body("refresh_token_expiration", notNullValue())
                        .body("access_token_expiration", notNullValue())
                        .extract().path("access_token");

        JwtTokenEntity accessEntity = jwtTokenRepository.findByAccessTokenId(parseTokenId(accessToken));
        Assert.isTrue(accessEntity != null, "Token should not be null here!");

        given()
                .header("Authorization", "Bearer " + accessToken)
                .when()
                .delete(CHECK_AUTH_LOGIN)
                .then()
                .statusCode(HttpStatus.SC_NO_CONTENT);

        accessEntity = jwtTokenRepository.findByAccessTokenId(parseTokenId(accessToken));
        Assert.isNull(accessEntity, "Token should be null here!");
    }

    // Auth - facebook
    @Test
    public void test_facebook_register_and_login_not_validated() {
        FacebookId fbid = FacebookId.valueOf("testid");

        String body = "{"
                + "\"facebook_token\": \"fake_token\","
                + "\"country_code\": \"GB\""
                + "}";

        when(facebookService.getUserData(any()))
                .thenReturn(new FacebookUserData(fbid, "test-user", new Email("existing@domain.com"), false));

        MockServerClient client = mockUpdatePeopleInteractionEvents(HttpStatusCode.OK_200);

        given()
                .contentType(ContentType.JSON)
                .body(body)
                .when()
                .post(CHECK_AUTH_REGISTER)
                .then()
                .statusCode(HttpStatus.SC_OK);

        client.verify(
                request()
                        .withPath(CREATE_VOUCHER)
                        .withMethod("POST")
                        .withBody(
                                json("{\"search_id\":\"WELCOME\"}", MatchType.ONLY_MATCHING_FIELDS)
                        ),
                        VerificationTimes.once());

        verify(emailServiceClient, times(1)).sendEmail(any(EmailMessage.class));

        // We don't check the email, we check the fbId, so that this is the same user as before.
        when(facebookService.getUserData(any()))
                .thenReturn(new FacebookUserData(fbid, "test-user", new Email("non-existing@domain.com"), false));
        String accessToken =
                given()
                        .contentType(ContentType.JSON)
                        .body(body)
                        .post(CHECK_AUTH_LOGIN)
                        .then()
                        .statusCode(HttpStatus.SC_OK)
                        .body("access_token", notNullValue())
                        .extract().path("access_token");

        JwtTokenEntity accessEntity = jwtTokenRepository.findByAccessTokenId(parseTokenId(accessToken));
        UserEntity user = userRepository.findById(accessEntity.getUserId()).orElseThrow(UserNotFoundException::new);
        assertThat(user.isEmailVerified()).isFalse();
        assertThat(fbid.getValue()).isEqualTo(user.getFacebookId());
        assertThat(user.isPhoneVerified()).isFalse();
        assertThat(user.getType()).isEqualTo(PlaytomicUserType.ONLINE);
    }

    @Test
    public void test_facebook_register_merge() {
        createUser("Existing user", "existing@domain.com",  true,"+34 123456789", false);
        mockUpdatePeopleInteractionEvents(HttpStatusCode.OK_200);

        String body = "{"
                + "\"facebook_token\": \"fake_token\","
                + "\"country_code\": \"GB\""
                + "}";

        // Try to merge, but this user is not validated, so that we don't merge and fail
        FacebookId fbid = FacebookId.valueOf("testid");
        when(facebookService.getUserData(any()))
                .thenReturn(new FacebookUserData(fbid, "test-user", new Email("existing@domain.com"), false));

        given()
                .contentType(ContentType.JSON)
                .body(body)
                .when()
                .post(CHECK_AUTH_REGISTER)
                .then()
                .statusCode(HttpStatus.SC_BAD_REQUEST)
                .body("status", is("INVALID_EMAIL"));

        UserEntity user = userRepository.findUserByEmail("existing@domain.com").get();
        assertThat(user.getFacebookId()).isNull();

        // Merge ok, this time user is validated, so that we accept it.
        when(facebookService.getUserData(any()))
                .thenReturn(new FacebookUserData(fbid, "test-user", new Email("existing@domain.com"), true));
        given()
                .contentType(ContentType.JSON)
                .body(body)
                .when()
                .post(CHECK_AUTH_REGISTER)
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("access_token", notNullValue())
                .extract().path("access_token");

        // user account registry and then login.
        Assert.isTrue(userRepository.count() == 1, "There must be exactly one user");
        user = userRepository.findUserByEmail("existing@domain.com").get();
        assertThat(fbid.getValue()).isEqualTo(user.getFacebookId());
        assertThat(user.getType()).isEqualTo(PlaytomicUserType.ONLINE);

        // No registration emails
        verify(emailServiceClient, never()).sendEmail(any(EmailMessage.class));
    }

    @Test
    public void test_facebook_login_not_registered() throws Exception {
        FacebookId fbid = FacebookId.valueOf("testid");

        String body = "{"
                + "\"facebook_token\": \"fake_token\""
                + "}";

        when(facebookService.getUserData(any()))
                .thenReturn(new FacebookUserData(fbid, "test-user", new Email("existing@domain.com"), false));

        given()
                .contentType(ContentType.JSON)
                .body(body)
                .when()
                .post(CHECK_AUTH_LOGIN)
                .then()
                .statusCode(HttpStatus.SC_UNPROCESSABLE_ENTITY);
    }

    @Test
    public void test_facebook_login_merge() throws Exception {
        createUser("Existing user", "existing@domain.com",  false,"+34 123456789", false);

        FacebookId fbid = FacebookId.valueOf("testid");

        String body = "{"
                + "\"facebook_token\": \"fake_token\""
                + "}";

        // Try to login, but this user is not validated, so that we don't merge.
        when(facebookService.getUserData(any()))
                .thenReturn(new FacebookUserData(fbid, "test-user", new Email("existing@domain.com"), false));

        given()
                .contentType(ContentType.JSON)
                .body(body)
                .when()
                .post(CHECK_AUTH_LOGIN)
                .then()
                .statusCode(HttpStatus.SC_UNPROCESSABLE_ENTITY);

        // This time we login with a verified user, so we can merge info
        when(facebookService.getUserData(any()))
                .thenReturn(new FacebookUserData(fbid, "test-user", new Email("existing@domain.com"), true));

        given()
                .contentType(ContentType.JSON)
                .body(body)
                .when()
                .post(CHECK_AUTH_LOGIN).
                then()
                .statusCode(HttpStatus.SC_OK)
                .body("access_token", notNullValue());
        UserEntity user = userRepository.findUserByEmail("existing@domain.com").orElseThrow(UserNotFoundException::new);
        Assert.notNull(user, "User should have been found");
        Assert.isTrue(user.isEmailVerified(), "User should have email verified.");
        Assert.isTrue(fbid.getValue().equals(user.getFacebookId()), "Facebook id must match");
        Assert.isTrue(!user.isPhoneVerified(), "Phone should not be verified");
    }


    // Auth - google
    @Test
    public void test_google_register_and_login_not_validated() throws Exception {
        GoogleId googleId = GoogleId.valueOf("testid");

        String body = "{"
                + "\"google_token\": \"fake_token\","
                + "\"country_code\": \"GB\""
                + "}";

        when(googleService.getUserData(any()))
                .thenReturn(new GoogleUserData(googleId, "test-user", new Email("existing@domain.com"), false));

        MockServerClient client = mockUpdatePeopleInteractionEvents(HttpStatusCode.OK_200);

        given()
                .contentType(ContentType.JSON)
                .body(body)
                .when()
                .post(CHECK_AUTH_REGISTER)
                .then()
                .statusCode(HttpStatus.SC_OK);

        client.verify(
                request()
                        .withPath(CREATE_VOUCHER)
                        .withMethod("POST")
                        .withBody(
                                json("{\"search_id\":\"WELCOME\"}", MatchType.ONLY_MATCHING_FIELDS)
                        ),
                VerificationTimes.once());

        verify(emailServiceClient, times(1)).sendEmail(any(EmailMessage.class));

        // We don't check the email, we check the gId, so that this is the same user as before.
        when(googleService.getUserData(any()))
                .thenReturn(new GoogleUserData(googleId, "test-user", new Email("non-existing@domain.com"), false));
        String accessToken =
                given()
                        .contentType(ContentType.JSON)
                        .body(body)
                        .when()
                        .post(CHECK_AUTH_LOGIN)
                        .then()
                        .statusCode(HttpStatus.SC_OK)
                        .body("access_token", notNullValue())
                        .extract().path("access_token");

        JwtTokenEntity accessEntity = jwtTokenRepository.findByAccessTokenId(parseTokenId(accessToken));
        UserEntity user = userRepository.findById(accessEntity.getUserId()).orElseThrow(UserNotFoundException::new);
        Assert.notNull(user, "User should have been found");
        Assert.isTrue(!user.isEmailVerified(), "User should not have email verified.");
        Assert.isTrue(googleId.getValue().equals(user.getGoogleId()), "Google id must match");
        Assert.isTrue(!user.isPhoneVerified(), "Phone should not be verified");
    }

    @Test
    public void test_google_register_merge() throws Exception {
        createUser("Existing user", "existing@domain.com",  true,"+34 123456789", false);
        mockUpdatePeopleInteractionEvents(HttpStatusCode.OK_200);

        String body = "{"
                + "\"google_token\": \"fake_token\","
                + "\"country_code\": \"GB\""
                + "}";

        // Try to merge, but this user is not validated, so that we don't merge and fail
        GoogleId googleId = GoogleId.valueOf("testid");
        when(googleService.getUserData(any()))
                .thenReturn(new GoogleUserData(googleId, "test-user", new Email("existing@domain.com"), false));

        given()
                .contentType(ContentType.JSON)
                .body(body)
                .when()
                .post(CHECK_AUTH_REGISTER)
                .then()
                .statusCode(HttpStatus.SC_BAD_REQUEST)
                .body("status", is("INVALID_EMAIL"));

        UserEntity user = userRepository.findUserByEmail("existing@domain.com").get();
        Assert.isNull(user.getGoogleId(), "Google id must be null here");

        // Merge ok, this time user is validated, so that we accept it.
        when(googleService.getUserData(any()))
                .thenReturn(new GoogleUserData(googleId, "test-user", new Email("existing@domain.com"), true));
        given()
                .contentType(ContentType.JSON)
                .body(body)
                .when()
                .post(CHECK_AUTH_REGISTER)
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("access_token", notNullValue())
                .extract().path("access_token");

        // user account registry and then login.
        Assert.isTrue(userRepository.count() == 1, "There must be exactly one user");
        user = userRepository.findUserByEmail("existing@domain.com").get();
        Assert.isTrue(googleId.getValue().equals(user.getGoogleId()), "Google id must match");

        // No registration emails
        verify(emailServiceClient, never()).sendEmail(any(EmailMessage.class));
    }

    @Test
    public void test_google_login_not_registered() throws Exception {
        GoogleId googleId = GoogleId.valueOf("testid");

        String body = "{"
                + "\"google_token\": \"fake_token\""
                + "}";

        when(googleService.getUserData(any()))
                .thenReturn(new GoogleUserData(googleId, "test-user", new Email("existing@domain.com"), false));
        given()
                .contentType(ContentType.JSON)
                .body(body)
                .when()
                .post(CHECK_AUTH_LOGIN).
                then()
                .statusCode(HttpStatus.SC_UNPROCESSABLE_ENTITY);
    }

    @Test
    public void test_google_login_merge() throws Exception {
        createUser("Existing user", "existing@domain.com",  false,"+34 123456789", false);

        GoogleId googleId = GoogleId.valueOf("testid");

        String body = "{"
                + "\"google_token\": \"fake_token\""
                + "}";

        // Try to login, but this user is not validated, so that we don't merge.
        when(googleService.getUserData(any()))
                .thenReturn(new GoogleUserData(googleId, "test-user", new Email("existing@domain.com"), false));

        given()
                .contentType(ContentType.JSON)
                .body(body)
                .when()
                .post(CHECK_AUTH_LOGIN)
                .then()
                .statusCode(HttpStatus.SC_UNPROCESSABLE_ENTITY);

        // This time we login with a verified user, so we can merge info
        when(googleService.getUserData(any()))
                .thenReturn(new GoogleUserData(googleId, "test-user", new Email("existing@domain.com"), true));
        given()
                .contentType(ContentType.JSON)
                .body(body)
                .when()
                .post(CHECK_AUTH_LOGIN).
                then()
                .statusCode(HttpStatus.SC_OK)
                .body("access_token", notNullValue());
        UserEntity user = userRepository.findUserByEmail("existing@domain.com").orElseThrow(UserNotFoundException::new);
        Assert.notNull(user, "User should have been found");
        Assert.isTrue(user.isEmailVerified(), "User should have email verified.");
        Assert.isTrue(googleId.getValue().equals(user.getGoogleId()), "Google id must match");
        Assert.isTrue(!user.isPhoneVerified(), "Phone should not be verified");
    }


    // Auth - apple
    @Test
    public void test_apple_register_and_login_not_validated() throws Exception {
        AppleId appleId = AppleId.valueOf("testid");

        String body = "{"
                + "\"apple_token\": \"fake_token\","
                + "\"country_code\": \"GB\","
                + "\"name\": \"Angel\""
                + "}";

        when(appleService.getUserData(any()))
                .thenReturn(new AppleUserData(appleId, new Email("existing@domain.com"), false));

        MockServerClient client = mockUpdatePeopleInteractionEvents(HttpStatusCode.OK_200);

        given()
                .contentType(ContentType.JSON)
                .body(body)
                .when()
                .post(CHECK_AUTH_REGISTER)
                .then()
                .statusCode(HttpStatus.SC_OK);

        client.verify(
                request()
                        .withPath(CREATE_VOUCHER)
                        .withMethod("POST")
                        .withBody(
                                json("{\"search_id\":\"WELCOME\"}", MatchType.ONLY_MATCHING_FIELDS)
                        ),
                VerificationTimes.once());


        verify(emailServiceClient, times(1)).sendEmail(any(EmailMessage.class));

        // We don't check the email, we check the gId, so that this is the same user as before.
        when(appleService.getUserData(any()))
                .thenReturn(new AppleUserData(appleId,  new Email("non-existing@domain.com"), false));
        String accessToken =
                given()
                        .contentType(ContentType.JSON)
                        .body(body)
                        .when()
                        .post(CHECK_AUTH_LOGIN)
                        .then()
                        .statusCode(HttpStatus.SC_OK)
                        .body("access_token", notNullValue())
                        .extract().path("access_token");

        JwtTokenEntity accessEntity = jwtTokenRepository.findByAccessTokenId(parseTokenId(accessToken));
        UserEntity user = userRepository.findById(accessEntity.getUserId()).orElseThrow(UserNotFoundException::new);
        Assert.notNull(user, "User should have been found");
        Assert.isTrue(!user.isEmailVerified(), "User should not have email verified.");
        Assert.isTrue(appleId.getValue().equals(user.getAppleId()), "Apple id must match");
        Assert.isTrue(!user.isPhoneVerified(), "Phone should not be verified");
    }

    @Test
    public void test_apple_register_merge() throws Exception {
        createUser("Existing user", "existing@domain.com",  true,"+34 123456789", false);
        mockUpdatePeopleInteractionEvents(HttpStatusCode.OK_200);

        String body = "{"
                + "\"apple_token\": \"fake_token\","
                + "\"country_code\": \"GB\","
                + "\"name\": \"Angel\""
                + "}";

        // Try to merge, but this user is not validated, so that we don't merge and fail
        AppleId appleId = AppleId.valueOf("testid");
        when(appleService.getUserData(any()))
                .thenReturn(new AppleUserData(appleId, new Email("existing@domain.com"), false));

        given()
                .contentType(ContentType.JSON)
                .body(body)
                .when()
                .post(CHECK_AUTH_REGISTER)
                .then()
                .statusCode(HttpStatus.SC_BAD_REQUEST)
                .body("status", is("INVALID_EMAIL"));

        UserEntity user = userRepository.findUserByEmail("existing@domain.com").get();
        Assert.isNull(user.getAppleId(), "Apple id must be null here");

        // Merge ok, this time user is validated, so that we accept it.
        when(appleService.getUserData(any()))
                .thenReturn(new AppleUserData(appleId, new Email("existing@domain.com"), true));

        given()
                .contentType(ContentType.JSON)
                .body(body)
                .when()
                .post(CHECK_AUTH_REGISTER)
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("access_token", notNullValue())
                .extract().path("access_token");

        // user account registry and then login.
        Assert.isTrue(userRepository.count() == 1, "There must be exactly one user");
        user = userRepository.findUserByEmail("existing@domain.com").get();
        Assert.isTrue(appleId.getValue().equals(user.getAppleId()), "Apple id must match");

        // No registration emails
        verify(emailServiceClient, never()).sendEmail(any(EmailMessage.class));
    }

    @Test
    public void test_apple_login_not_registered() throws Exception {
        AppleId appleId = AppleId.valueOf("testid");

        String body = "{"
                + "\"apple_token\": \"fake_token\""
                + "}";

        when(appleService.getUserData(any()))
                .thenReturn(new AppleUserData(appleId,  new Email("existing@domain.com"), false));
        given()
                .contentType(ContentType.JSON)
                .body(body)
                .when()
                .post(CHECK_AUTH_LOGIN).
                then()
                .statusCode(HttpStatus.SC_UNPROCESSABLE_ENTITY);
    }

    @Test
    public void test_apple_login_merge() throws Exception {
        createUser("Existing user", "existing@domain.com",  false,"+34 123456789", false);

        AppleId appleId = AppleId.valueOf("testid");

        String body = "{"
                + "\"apple_token\": \"fake_token\""
                + "}";

        // Try to login, but this user is not validated, so that we don't merge.
        when(appleService.getUserData(any()))
                .thenReturn(new AppleUserData(appleId,  new Email("existing@domain.com"), false));

        given()
                .contentType(ContentType.JSON)
                .body(body)
                .when()
                .post(CHECK_AUTH_LOGIN)
                .then()
                .statusCode(HttpStatus.SC_UNPROCESSABLE_ENTITY);

        // This time we login with a verified user, so we can merge info
        when(appleService.getUserData(any()))
                .thenReturn(new AppleUserData(appleId,  new Email("existing@domain.com"), true));
        given()
                .contentType(ContentType.JSON)
                .body(body)
                .when()
                .post(CHECK_AUTH_LOGIN).
                then()
                .statusCode(HttpStatus.SC_OK)
                .body("access_token", notNullValue());
        UserEntity user = userRepository.findUserByEmail("existing@domain.com").orElseThrow(UserNotFoundException::new);
        Assert.notNull(user, "User should have been found");
        Assert.isTrue(user.isEmailVerified(), "User should have email verified.");
        Assert.isTrue(appleId.getValue().equals(user.getAppleId()), "Apple id must match");
        Assert.isTrue(!user.isPhoneVerified(), "Phone should not be verified");
    }

    //@Test //TODO enable
    public void login_user_with_permissions() {
        // Creating user
        String hashPassword = new BCryptPasswordEncoder().encode("mypassword");
        UserEntity user = new UserEntity("user", hashPassword, "existing@domain.com", true, null, false, null,null, "ES", PlaytomicUserType.ONLINE);
        userRepository.save(user);

        // Creating roles
        UserId userId = UserId.valueOf(user.getId().toString());
        String tenantId1 = UUID.randomUUID().toString();
        String tenantId2 = UUID.randomUUID().toString();

        UserRoleEntity tenantRole1 = new UserRoleEntity(user, PlaytomicUserRole.ROLE_TENANT_MANAGER, tenantId1);
        UserRoleEntity tenantRole2 = new UserRoleEntity(user, PlaytomicUserRole.ROLE_TENANT_MANAGER, tenantId2);
        user.setUserRoles(new HashSet<>(Arrays.asList(tenantRole1, tenantRole2)));
        userRepository.save(user);

        // Creating permissions
        EnumMap<PermissionName, PermissionLevel> permissions1 = new EnumMap<>(PermissionName.class);
        permissions1.put(PermissionName.COACHES_PERMISSION, PermissionLevel.READ_WRITE);
        permissions1.put(PermissionName.INVOICES_PERMISSION, PermissionLevel.READ_ONLY);
        permissions1.put(PermissionName.CUSTOMER_BENEFITS_PERMISSION, PermissionLevel.READ_ONLY);
        PermissionDocument document1 = new PermissionDocument(UUID.randomUUID().toString(), userId, TenantId.valueOf(tenantId1), permissions1);

        EnumMap<PermissionName, PermissionLevel> permissions2 = new EnumMap<>(PermissionName.class);
        permissions2.put(PermissionName.INVOICES_PERMISSION, PermissionLevel.READ_ONLY);
        PermissionDocument document2 = new PermissionDocument(UUID.randomUUID().toString(), userId, TenantId.valueOf(tenantId2), permissions2);

        permissionRepository.saveAll(Arrays.asList(document1, document2));

        // Mocking subscriptions
        mockVendorSubscriptionModules(tenantId1, "COACHES", "INVOICES");
        mockVendorSubscriptionModules(tenantId2, "INVOICES");

        String body = "{"
                + "\"email\": \"existing@domain.com\","
                + "\"password\": \"mypassword\""
                + "}";

        String accessToken =
                given()
                        .contentType(ContentType.JSON)
                        .body(body)
                        .when()
                        .post(CHECK_AUTH_LOGIN)
                        .then()
                        .statusCode(HttpStatus.SC_OK)
                        .body("access_token", notNullValue())
                        .body("refresh_token", notNullValue())
                        .extract().path("access_token");

        List<String> tenantIds = (List<String>) getClaimFromToken(accessToken, "role_tenant_manager").get("tenant_ids");
        assertThat(tenantIds).containsExactlyInAnyOrder(tenantId1, tenantId2);

        Map<String, Object> authoritiesByTenant = getClaimFromToken(accessToken, "authorities_by_tenant");
        assertThat(authoritiesByTenant).containsOnlyKeys(tenantId1, tenantId2);

        List<String> authoritiesTenant1 = (List<String>) authoritiesByTenant.get(tenantId1);
        assertThat(authoritiesTenant1).containsExactlyInAnyOrder("read_coach_accounts", "read_coach_pricing_rules", "write_coach_accounts", "write_coach_pricing_rules", "read_customer_invoices", "read_price_benefits", "read_tenant_tags");

        List<String> authoritiesTenant2 = (List<String>) authoritiesByTenant.get(tenantId2);
        assertThat(authoritiesTenant2).containsExactlyInAnyOrder("read_customer_invoices");
    }

    @Test
    public void test_refresh_token() {
        String hashPassword = new BCryptPasswordEncoder().encode("mypassword");
        UserEntity user = new UserEntity("user", hashPassword, "existing@domain.com", true, null, false, null,null, "ES", PlaytomicUserType.ONLINE);
        userRepository.save(user);

        String json = "{"
                + "\"email\": \"existing@domain.com\","
                + "\"password\": \"mypassword\""
                + "}";

        ExtractableResponse<Response> body = given()
                .contentType(ContentType.JSON)
                .body(json)
                .when()
                .post(CHECK_AUTH_LOGIN)
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("access_token", notNullValue())
                .body("refresh_token", notNullValue())
                .extract();

        String refreshToken = body.path("refresh_token");
        JwtTokenEntity refreshEntity = jwtTokenRepository.findByRefreshTokenId(parseTokenId(refreshToken));
        Assert.notNull(refreshEntity, "Token should be not null here!");

        body =
                given()
                        .contentType(ContentType.JSON)
                        .body("{\"refresh_token\":\"" + refreshToken + "\"}")
                        .when()
                        .post(CHECK_AUTH_REFRESH)
                        .then()
                        .statusCode(HttpStatus.SC_OK)
                        .extract();

        refreshEntity = jwtTokenRepository.findByRefreshTokenId(parseTokenId(refreshToken));
        Assert.isNull(refreshEntity, "Token should be null here because it was consumed!");

        String accessToken = body.path("access_token");
        JwtTokenEntity accessEntity = jwtTokenRepository.findByAccessTokenId(parseTokenId(accessToken));
        Assert.notNull(accessEntity, "Token should be not null here!");

        // Reusing refresh_token must fail.
        given()
                .contentType(ContentType.JSON)
                .body("{\"refresh_token\":\"" + refreshToken + "\"}")
                .when()
                .post(CHECK_AUTH_REFRESH)
                .then()
                .statusCode(HttpStatus.SC_UNAUTHORIZED);
    }

    @Nonnull
    private MockServerClient mockUpdatePeopleInteractionEvents(@Nonnull HttpStatusCode statusCode) {
        MockServerClient mockServerClient = getMockServer(VOUCHERS_MOCK_SERVER_PORT);

        mockServerClient
                .when(request()
                        .withMethod("POST")
                        .withPath(CREATE_VOUCHER))
                .respond(
                        HttpResponse.response()
                                .withStatusCode(statusCode.code()));

        return mockServerClient;
    }

    @Nonnull
    private String parseTokenId(@Nonnull String accessToken) {
        return jwtTokenFactory
            .validateJwtTokenAndParseClaims(new RawAccessJwtToken(accessToken))
            .getBody()
            .getId();
    }

    @Nonnull
    private Map<String, Object> getClaimFromToken(@Nonnull String token, @Nonnull String claimName) {
        return (Map<String, Object>) jwtTokenFactory
                .validateJwtTokenAndParseClaims(new RawAccessJwtToken(token))
                .getBody().get(claimName);
    }

    @Nonnull
    private UserEntity createUser(@Nonnull String name, @Nonnull String email, boolean emailVerified, @Nonnull String phone, boolean phoneVerified) {
        return createUser(name, email, emailVerified, phone, phoneVerified, PlaytomicUserType.ONSITE);
    }

    @Nonnull
    private UserEntity createUser(@Nonnull String name, @Nonnull String email, boolean emailVerified, @Nonnull String phone, boolean phoneVerified, PlaytomicUserType type) {
        String hashPassword = new BCryptPasswordEncoder().encode("password");
        UserEntity userEntity = new UserEntity(name, hashPassword, email, emailVerified, phone, phoneVerified, true, true, "ES", type);
        return userRepository.save(userEntity);
    }

    @Nonnull
    private MockServerClient mockVendorSubscriptionModules(@Nonnull String tenantId, String... subscribedModules) {
        MockServerClient mockServerClient = getMockServer(SUBSCRIPTIONS_MOCK_SERVER_PORT);
        JSONArray body = new JSONArray();
        for (String moduleType : subscribedModules) {
            JSONObject module = new JSONObject();
            module.put("module_type", moduleType);
            body.put(module);
        }

        mockServerClient
            .when(request()
                .withMethod("GET")
                .withPath("/v1/vendor_subscriptions/subscribed_modules")
                .withQueryStringParameter("tenant_id", tenantId))
            .respond(HttpResponse.response()
                .withHeader("Content-Type", "application/json")
                .withBody(body.toString())
                .withStatusCode(HttpStatusCode.OK_200.code()));

        return mockServerClient;
    }

    @Test
    void test_registerAuth_clientNotAuthenticatedAndCreatedByInfoStored_scOK() {

        String email = "pp@playtomic.io";

        JSONObject body = new JSONObject()
            .put("email", email)
            .put("password", "APassword1")
            .put("name", "An user name")
            .put("phone", "+34 657061062")
            .put("country_code", "ES");

        mockUpdatePeopleInteractionEvents(HttpStatusCode.OK_200);

        given()
            .contentType("application/json")
            .body(body.toString())
            .when()
            .post(CHECK_AUTH_REGISTER)
            .then()
            .statusCode(HttpStatus.SC_OK).body("access_token", notNullValue());

        assertThat(userRepository.findUserByEmail(email))
            .isPresent()
            .get()
            .satisfies(userEntity -> assertThat(userEntity.getEmail()).isNotBlank().isEqualTo(email))
            .satisfies(userEntity -> assertThat(userEntity.getCreatedBy()).isNull())
            .satisfies(userEntity -> assertThat(userEntity.getType()).isEqualTo(PlaytomicUserType.ONLINE));
    }

    @Test
    void test_registerAuth_OnsiteUser_scOK() {
        String email = "pp@playtomic.io";
        createUser("Existing name", email, false, "+34 123456789", false);

        JSONObject body = new JSONObject()
            .put("email", email)
            .put("password", "APassword1")
            .put("name", "New user name")
            .put("phone", "+34 657061062")
            .put("country_code", "ES");

        mockUpdatePeopleInteractionEvents(HttpStatusCode.OK_200);

        given()
            .contentType("application/json")
            .body(body.toString())
            .when()
            .post(CHECK_AUTH_REGISTER)
            .then()
            .statusCode(HttpStatus.SC_OK).body("access_token", notNullValue());

        assertThat(userRepository.findUserByEmail(email))
            .isPresent()
            .get()
            .satisfies(userEntity -> assertThat(userEntity.getEmail()).isNotBlank().isEqualTo(email))
            .satisfies(userEntity -> assertThat(userEntity.getFullName()).isEqualTo("New user name"))
            .satisfies(userEntity -> assertThat(userEntity.getPhone()).isEqualTo("+34 657061062"))
            .satisfies(userEntity -> assertThat(userEntity.isEmailVerified()).isFalse())
            .satisfies(userEntity -> assertThat(userEntity.getType()).isEqualTo(PlaytomicUserType.PENDING_VERIFICATION));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_ADMIN)
    void test_registerAuth_clientAuthenticatedAndCreatedByInfoStored_scOK() {

        AnemoneUserPrincipal userPrincipal = (AnemoneUserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

        JSONObject body = new JSONObject()
            .put("email", "pp@playtomic.io")
            .put("password", "APassword1")
            .put("name", "An user name")
            .put("phone", "+34 657061062")
            .put("country_code", "ES");

        mockUpdatePeopleInteractionEvents(HttpStatusCode.OK_200);

        String email = "pp@playtomic.io";

        given()
            .contentType("application/json")
            .header("Authorization",
                "Bearer " + jwtTokenFactory.createAccessJwtToken(userPrincipal.getId().getValue(), userPrincipal.getUser().getEmail(),
                    userPrincipal.getUser().getOriginalAuthorities()).getToken())
            .body(body.toString())
            .when()
            .post(CHECK_AUTH_REGISTER)
            .then().statusCode(HttpStatus.SC_OK).body("access_token", notNullValue());

        assertThat(userRepository.findUserByEmail(email))
            .isPresent()
            .get()
            .satisfies(userEntity -> assertThat(userEntity.getEmail()).isNotBlank().isEqualTo(email))
            .satisfies(userEntity -> assertThat(userEntity.getCreatedBy()).isNotBlank().isEqualTo(userPrincipal.getUser().getId().getValue()))
            .satisfies(userEntity -> assertThat(userEntity.getType()).isEqualTo(PlaytomicUserType.ONSITE))
        ;

    }

}

package com.playtomic.anemone.user.domain;


import org.junit.jupiter.api.Test;
import org.springframework.util.Assert;

public class PasswordGeneratorTest {

    @Test
    public void testPasswordGenerator() {
        String pass = PasswordGenerator.generate();
        String pass2 = PasswordGenerator.generate();
        Assert.isTrue(!pass.equals(pass2), "Both passwords shouldn't be equal");
    }
}
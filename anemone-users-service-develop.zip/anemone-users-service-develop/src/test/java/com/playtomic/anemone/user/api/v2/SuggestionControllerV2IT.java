package com.playtomic.anemone.user.api.v2;

import com.playtomic.anemone.UserApplication;
import com.playtomic.anemone.domain.user.UserRole;
import com.playtomic.anemone.test.WithMockUser;
import com.playtomic.anemone.user.config.AbstractTestContainersSupport;
import static io.restassured.RestAssured.given;

import com.playtomic.anemone.user.service.anemone.EmailServiceClient;
import org.apache.http.HttpStatus;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = UserApplication.class)
@ExtendWith(SpringExtension.class)
@WithMockUser(role = UserRole.ROLE_CUSTOMER)
public class SuggestionControllerV2IT extends AbstractTestContainersSupport {

    @MockBean
    EmailServiceClient emailServiceClient;

    private final String IMPROVEMENT = "/v2/suggestion/improvement";

    @Test
    public void testImprovement_Ok() {
        given().
                param("comments", "Best app ever seen.").
                post(IMPROVEMENT).
                then().
                statusCode(HttpStatus.SC_OK);
    }

    @Test
    public void testImprovement_BadRequest() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 1026; i++) {
            sb.append(i);
        }

        given().
                param("comments", sb.toString()).
                post(IMPROVEMENT).
                then().
                statusCode(HttpStatus.SC_BAD_REQUEST);
    }
}

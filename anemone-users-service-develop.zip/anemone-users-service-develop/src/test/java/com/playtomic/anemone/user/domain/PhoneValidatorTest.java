package com.playtomic.anemone.user.domain;

import org.junit.jupiter.api.Test;
import org.springframework.util.Assert;

import java.util.Arrays;
import java.util.List;

public class PhoneValidatorTest {
    @Test
    public void testValidPhone() {
        List<String> validPhones = Arrays.asList(
            "+1 1231512",
            "+34 12418790",
            "+123 02357803324",
            "+14 3",
            "934673436",
            "");

        validPhones.forEach(phone ->
            Assert.isTrue(PhoneValidator.isValid(phone), "Phone must be valid: " + phone)
        );
    }

    @Test
    public void testInvalidPhone() {
        List<String> invalidPhone = Arrays.asList(
            "34 1201247",
            "+39-1314",
            "+45 235 235423",
            "+5723500 352309j85q",
            "+",
            "+39 ");

        invalidPhone.forEach(phone ->
            Assert.isTrue(!PhoneValidator.isValid(phone), "Phone must be invalid: " + phone)
        );
    }

    @Test
    public void testInternationalPrefixValid() {
        List<String> validInternationalPrefixPhones = Arrays.asList(
            "+1 1231512",
            "+34 12418790",
            "+123 02357803324",
            "+14 3");

        validInternationalPrefixPhones.forEach(phone ->
            Assert.isTrue(PhoneValidator.checkInternationalPrefix(phone), "Phone must be valid: " + phone)
        );
    }

    @Test
    public void testInternationalPrefixInvalid() {
        List<String> invalidInternationalPrefixPhones = Arrays.asList(
            "934673436",
            "");

        invalidInternationalPrefixPhones.forEach(phone ->
            Assert.isTrue(!PhoneValidator.checkInternationalPrefix(phone), "Phone must be invalid: " + phone)
        );
    }

    @Test
    public void testPhoneFormatter() {
        Assert.isTrue(PhoneValidator.formattedPhone("687929298", "+34").get().equals("+34 687929298"));
        Assert.isTrue(PhoneValidator.formattedPhone("+45 687929298", "+34").get().equals("+45 687929298"));
        Assert.isTrue(!PhoneValidator.formattedPhone("687929298", null).isPresent());
        Assert.isTrue(PhoneValidator.formattedPhone("+34 687 929298", null).get().equals("+34 687929298"));
        Assert.isTrue(!PhoneValidator.formattedPhone("+34687929298", null).isPresent());
        Assert.isTrue(PhoneValidator.formattedPhone("+34687929298", "+34").get().equals("+34 687929298"));
        Assert.isTrue(PhoneValidator.formattedPhone("+45-687(9292)-98", "+34").get().equals("+45 687929298"));
        Assert.isTrue(PhoneValidator.formattedPhone("0034-687(9292)-98", null).get().equals("+34 687929298"));
    }

}
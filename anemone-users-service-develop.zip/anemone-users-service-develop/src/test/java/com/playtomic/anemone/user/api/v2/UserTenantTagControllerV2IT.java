package com.playtomic.anemone.user.api.v2;

import static io.restassured.RestAssured.given;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.mockserver.model.HttpRequest.request;
import static org.mockserver.model.HttpResponse.response;

import com.playtomic.anemone.UserApplication;
import com.playtomic.anemone.category.dao.CategoryDocument;
import com.playtomic.anemone.category.domain.CategoryId;
import com.playtomic.anemone.domain.user.UserRole;
import com.playtomic.anemone.jwt.AccessJwtToken;
import com.playtomic.anemone.jwt.JwtTokenFactory;
import com.playtomic.anemone.test.TestCredentialsService;
import com.playtomic.anemone.test.WithMockUser;
import com.playtomic.anemone.user.config.AbstractTestContainersSupport;
import com.playtomic.anemone.user.dao.LinkedAccountEntity;
import com.playtomic.anemone.user.dao.PlaytomicUserType;
import com.playtomic.anemone.user.dao.UserEntity;
import com.playtomic.anemone.user.dao.UserRepository;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import com.playtomic.anemone.user.domain.users.UserLegacy;
import com.playtomic.anemone.user.service.UserService;
import com.playtomic.anemone.user.service.exception.UserNotFoundException;
import io.restassured.http.ContentType;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import org.apache.http.HttpStatus;
import org.json.JSONObject;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockserver.model.Header;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = UserApplication.class)
@ExtendWith(SpringExtension.class)
public class UserTenantTagControllerV2IT extends AbstractTestContainersSupport {
  private static final String USERS_API_V2 = "/v2/users";
  private static final int MOCK_TENANTS_PORT = 10000;
  @Nonnull
  @Autowired
  private UserService userService;
  @Nonnull
  @Autowired
  private UserRepository userRepository;
  @Nonnull
  @Autowired
  private TestCredentialsService testCredentialsService;
  @Nonnull
  @Autowired
  private JwtTokenFactory jwtTokenFactory;

  @AfterEach
  public void cleanReposAfterEach() {
    userRepository.deleteAll();
  }
  @Test
  @WithMockUser(role = UserRole.ROLE_ADMIN)
  public void testAddTenantTag() {
    UserEntity user = createUser("A user", "email@email.com");
    String body = "{"
        + "\"tags\": [\"147\",\"258\"], "
        + "\"tenant_id\": \"tenant-1\" "
        + "}";

    given()
        .header("Authorization", createAuthHeader())
        .contentType("application/json")
        .body(body)
        .post(USERS_API_V2 + "/" + user.getId() + "/tenant_tags")
        .then()
        .statusCode(HttpStatus.SC_OK)
        .body("tenant_tags", hasSize(1))
        .body("tenant_tags[0].tags", hasSize(2))
        .body("tenant_tags[0].tags[0]", is("147"))
        .body("tenant_tags[0].tags[1]", is("258"))
        .body("tenant_tags[0].tenant_id", is("tenant-1"));
  }

  @Test
  @WithMockUser(role = UserRole.ROLE_CUSTOMER)
  public void testAddTenantTag_forbidden() {
    UserEntity user = createUser("A user", "email@email.com");
    String body = "{"
        + "\"tags\": [\"147\",\"258\"], "
        + "\"tenant_id\": \"tenant-1\" "
        + "}";

    given()
        .header("Authorization", createAuthHeader())
        .contentType("application/json")
        .body(body)
        .post(USERS_API_V2 + "/" + user.getId() + "/tenant_tags")
        .then()
        .statusCode(HttpStatus.SC_FORBIDDEN);
  }

  @Test
  @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
  public void test_add_tenant_tag_as_tenant_manager_forbidden() {
    UserEntity user = createUser("A user", "email@email.com");

    JSONObject body = new JSONObject()
        .put("tags", Arrays.asList("tenant-tag-benefit-id-1", "tenant-tag-benefit-id-2"))
        .put("tenant_id", "other-tenant-id");

    Map<String, List<String>> claimData = UserControllerV2IT.tenantsIdsClaimData("tenant-id-1");
    Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);

    given()
        .header("Authorization", createAuthHeader(extraClaims))
        .contentType(ContentType.JSON)
        .body(body.toString())
        .post(USERS_API_V2 + "/" + user.getId() + "/tenant_tags")
        .then()
        .statusCode(HttpStatus.SC_FORBIDDEN);
  }

  @Test
  @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
  public void test_add_tenant_tag_as_tenant_manager_ok() {
    UserEntity user = createUser("A user", "email@email.com");

    JSONObject body = new JSONObject()
        .put("tags", Arrays.asList("tenant-tag-benefit-id-1", "tenant-tag-benefit-id-2"))
        .put("tenant_id", "tenant-id-1");

    Map<String, List<String>> claimData = UserControllerV2IT.tenantsIdsClaimData("tenant-id-1");
    Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);

    given()
        .header("Authorization", createAuthHeader(extraClaims))
        .contentType(ContentType.JSON)
        .body(body.toString())
        .post(USERS_API_V2 + "/" + user.getId() + "/tenant_tags")
        .then()
        .statusCode(HttpStatus.SC_OK)
        .body("tenant_tags", hasSize(1))
        .body("tenant_tags[0].tags", hasSize(2))
        .body("tenant_tags[0].tags[0]", is("tenant-tag-benefit-id-1"))
        .body("tenant_tags[0].tags[1]", is("tenant-tag-benefit-id-2"))
        .body("tenant_tags[0].tenant_id", is("tenant-id-1"));
  }

  @Test
  @WithMockUser(role = UserRole.ROLE_ADMIN)
  public void testPutTenantTag() throws UserNotFoundException {
    UserEntity user = createUser("A user", "email@email.com");
    String body = "{"
        + "\"tags\": [\"147\",\"258\"], "
        + "\"tenant_id\": \"tenant-1\" "
        + "}";

    given()
        .header("Authorization", createAuthHeader())
        .contentType("application/json")
        .body(body)
        .post(USERS_API_V2 + "/" + user.getId() + "/tenant_tags")
        .then()
        .statusCode(HttpStatus.SC_OK)
        .body("tenant_tags", hasSize(1))
        .body("tenant_tags[0].tags", hasSize(2))
        .body("tenant_tags[0].tags[0]", is("147"))
        .body("tenant_tags[0].tags[1]", is("258"))
        .body("tenant_tags[0].tenant_id", is("tenant-1"));

    assertThat(userService.getUserById(UserLegacy.valueOf(user.getId())).getTenantTags()).hasSize(1);

    body = "{ "
        + "\"tenant_tags\": [{"
        + "\"tags\": [\"345\",\"999\"], "
        + "\"tenant_id\": \"tenant-2\" "
        + "}]"
        + "}";

    given()
        .header("Authorization", createAuthHeader())
        .contentType("application/json")
        .body(body)
        .put(USERS_API_V2 + "/" + user.getId() + "/tenant_tags")
        .then()
        .statusCode(HttpStatus.SC_OK)
        .body("tenant_tags", hasSize(1))
        .body("tenant_tags[0].tags", hasSize(2))
        .body("tenant_tags[0].tags[0]", is("345"))
        .body("tenant_tags[0].tags[1]", is("999"))
        .body("tenant_tags[0].tenant_id", is("tenant-2"));
  }

  @Test
  @WithMockUser(role = UserRole.ROLE_ADMIN)
  public void testPutNonExistingPreviousTenantTag() {
    UserEntity user = createUser("A user", "email@email.com");
    String body = "{"
        + "\"tenant_tags\": [{"
        + "\"tags\": [\"147\",\"258\"], "
        + "\"tenant_id\": \"tenant-1\" "
        + "}]"
        + "}";

    given()
        .header("Authorization", createAuthHeader())
        .contentType("application/json")
        .body(body)
        .put(USERS_API_V2 + "/" + user.getId() + "/tenant_tags")
        .then()
        .statusCode(HttpStatus.SC_OK)
        .body("tenant_tags", hasSize(1))
        .body("tenant_tags[0].tags", hasSize(2))
        .body("tenant_tags[0].tags[0]", is("147"))
        .body("tenant_tags[0].tags[1]", is("258"))
        .body("tenant_tags[0].tenant_id", is("tenant-1"));
  }

  @Test
  @WithMockUser(role = UserRole.ROLE_ADMIN)
  public void testPutEmptyTenantTag() throws UserNotFoundException {
    UserEntity user = createUser("A user", "email@email.com");
    String body = "{"
        + "\"tags\": [\"147\",\"258\"], "
        + "\"tenant_id\": \"tenant-1\" "
        + "}";

    given()
        .header("Authorization", createAuthHeader())
        .contentType("application/json")
        .body(body)
        .post(USERS_API_V2 + "/" + user.getId() + "/tenant_tags")
        .then()
        .statusCode(HttpStatus.SC_OK)
        .body("tenant_tags", hasSize(1))
        .body("tenant_tags[0].tags", hasSize(2))
        .body("tenant_tags[0].tags[0]", is("147"))
        .body("tenant_tags[0].tags[1]", is("258"))
        .body("tenant_tags[0].tenant_id", is("tenant-1"));


    body = "{ "
        + "\"tenant_tags\": []"
        + "}";

    given()
        .header("Authorization", createAuthHeader())
        .contentType("application/json")
        .body(body)
        .put(USERS_API_V2 + "/" + user.getId() + "/tenant_tags")
        .then()
        .statusCode(HttpStatus.SC_OK)
        .body("tenant_tags", hasSize(0));

    assertThat(userService.getUserById(UserLegacy.valueOf(user.getId())).getTenantTags()).hasSize(0);
  }

  @Test
  @WithMockUser(role = UserRole.ROLE_ADMIN)
  public void testPatchTenantTag() throws UserNotFoundException {
    UserEntity user = createUser("A user", "email@email.com");
    String body = "{"
        + "\"tags\": [\"147\",\"258\"], "
        + "\"tenant_id\": \"tenant-1\" "
        + "}";

    given()
        .header("Authorization", createAuthHeader())
        .contentType("application/json")
        .body(body)
        .post(USERS_API_V2 + "/" + user.getId() + "/tenant_tags")
        .then()
        .statusCode(HttpStatus.SC_OK)
        .body("tenant_tags", hasSize(1))
        .body("tenant_tags[0].tags", hasSize(2))
        .body("tenant_tags[0].tags[0]", is("147"))
        .body("tenant_tags[0].tags[1]", is("258"))
        .body("tenant_tags[0].tenant_id", is("tenant-1"));

    assertThat(userService.getUserById(UserLegacy.valueOf(user.getId())).getTenantTags()).hasSize(1);

    body = "{"
        + "\"tags\": [\"345\",\"863\",\"999\"], "
        + "\"tenant_id\": \"tenant-2\" "
        + "}";

    given()
        .header("Authorization", createAuthHeader())
        .contentType("application/json")
        .body(body)
        .post(USERS_API_V2 + "/" + user.getId() + "/tenant_tags")
        .then()
        .statusCode(HttpStatus.SC_OK)
        .body("tenant_tags", hasSize(2))
        .body("tenant_tags[0].tags", hasSize(2))
        .body("tenant_tags[0].tags[0]", is("147"))
        .body("tenant_tags[0].tags[1]", is("258"))
        .body("tenant_tags[0].tenant_id", is("tenant-1"))
        .body("tenant_tags[1].tags", hasSize(3))
        .body("tenant_tags[1].tags[0]", is("345"))
        .body("tenant_tags[1].tags[1]", is("863"))
        .body("tenant_tags[1].tags[2]", is("999"))
        .body("tenant_tags[1].tenant_id", is("tenant-2"));

    assertThat(userService.getUserById(UserLegacy.valueOf(user.getId())).getTenantTags()).hasSize(2);

    body = "{ "
        + "\"tags\": [\"345\"]"
        + "}";

    given()
        .header("Authorization", createAuthHeader())
        .contentType("application/json")
        .body(body)
        .queryParam("tenant_id", "tenant-2")
        .patch(USERS_API_V2 + "/" + user.getId() + "/tenant_tags")
        .then()
        .statusCode(HttpStatus.SC_OK)
        .body("tenant_tags", hasSize(2))
        .body("tenant_tags[0].tags", hasSize(2))
        .body("tenant_tags[0].tags[0]", is("147"))
        .body("tenant_tags[0].tags[1]", is("258"))
        .body("tenant_tags[0].tenant_id", is("tenant-1"))
        .body("tenant_tags[1].tags", hasSize(1))
        .body("tenant_tags[1].tags[0]", is("345"))
        .body("tenant_tags[1].tenant_id", is("tenant-2"));

    assertThat(userService.getUserById(UserLegacy.valueOf(user.getId())).getTenantTags()).hasSize(2);

    user.setLinkedAccounts(Collections.singleton(new LinkedAccountEntity(user, "tenant-2", "1", null, null)));
    var categoryDocument = new CategoryDocument(
        CategoryId.valueOf("86243c8b-b33c-44c8-829f-beeb4314cb67"), TenantId.valueOf("tenant-2"), "VIP", null, null, null, null);
    user.addCategory(categoryDocument, null);
    userRepository.save(user);

    assertThat(userService.getUserById(UserLegacy.valueOf(user.getId())).getTenantTags()).hasSize(2);
    body = "{ "
        + "\"tags\": [\"345\"]"
        + "}";
    //verify that PATCH tenant tags  doesn't override the category tag
    given()
        .header("Authorization", createAuthHeader())
        .contentType("application/json")
        .body(body)
        .queryParam("tenant_id", "tenant-2")
        .patch(USERS_API_V2 + "/" + user.getId() + "/tenant_tags")
        .then()
        .log().all()
        .statusCode(HttpStatus.SC_OK)
        .body("tenant_tags", hasSize(2))
        .body("tenant_tags[0].tags", hasSize(2))
        .body("tenant_tags[0].tags[0]", is("147"))
        .body("tenant_tags[0].tags[1]", is("258"))
        .body("tenant_tags[0].tenant_id", is("tenant-1"))
        .body("tenant_tags[1].tags", hasSize(2))
        .body("tenant_tags[1].tags[0]", is("345"))
        .body("tenant_tags[1].tags[1]", is("86243c8b-b33c-44c8-829f-beeb4314cb67"))
        .body("tenant_tags[1].tenant_id", is("tenant-2"));

    assertThat(userService.getUserById(UserLegacy.valueOf(user.getId())).getTenantTags()).hasSize(2);
  }

  @Test
  @WithMockUser(role = UserRole.ROLE_ADMIN)
  public void testPatchNonExistingPreviousTenantTag() {
    UserEntity user = createUser("A user", "email@email.com");
    String body = "{ "
        + "\"tags\": [\"345\"]"
        + "}";

    given()
        .header("Authorization", createAuthHeader())
        .contentType("application/json")
        .body(body)
        .queryParam("tenant_id", "tenant-1")
        .patch(USERS_API_V2 + "/" + user.getId() + "/tenant_tags")
        .then()
        .statusCode(HttpStatus.SC_OK)
        .body("tenant_tags", hasSize(1))
        .body("tenant_tags[0].tags", hasSize(1))
        .body("tenant_tags[0].tags[0]", is("345"))
        .body("tenant_tags[0].tenant_id", is("tenant-1"));
  }

  @Test
  @WithMockUser(role = UserRole.ROLE_ADMIN)
  public void testPatchEmptyTenantTag() throws UserNotFoundException {
    UserEntity user = createUser("A user", "email@email.com");
    String body = "{"
        + "\"tags\": [\"147\",\"258\"], "
        + "\"tenant_id\": \"tenant-1\" "
        + "}";

    given()
        .header("Authorization", createAuthHeader())
        .contentType("application/json")
        .body(body)
        .post(USERS_API_V2 + "/" + user.getId() + "/tenant_tags")
        .then()
        .statusCode(HttpStatus.SC_OK)
        .body("tenant_tags", hasSize(1))
        .body("tenant_tags[0].tags", hasSize(2))
        .body("tenant_tags[0].tags[0]", is("147"))
        .body("tenant_tags[0].tags[1]", is("258"))
        .body("tenant_tags[0].tenant_id", is("tenant-1"));

    body = "{ "
        + "\"tags\": []"
        + "}";

    given()
        .header("Authorization", createAuthHeader())
        .contentType("application/json")
        .body(body)
        .queryParam("tenant_id", "tenant-1")
        .patch(USERS_API_V2 + "/" + user.getId() + "/tenant_tags")
        .then()
        .statusCode(HttpStatus.SC_OK)
        .body("tenant_tags", hasSize(0));

    assertThat(userService.getUserById(UserLegacy.valueOf(user.getId())).getTenantTags()).hasSize(0);
  }

  @Test
  @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
  public void test_patch_tenant_tag_as_tenant_manager_forbidden() {
    UserEntity user = createUser("A user", "email@email.com");

    JSONObject body = new JSONObject()
        .put("tags", Arrays.asList("tenant-tag-benefit-id-1", "tenant-tag-benefit-id-2"))
        .put("tenant_id", "other-tenant-id");

    Map<String, List<String>> claimData = UserControllerV2IT.tenantsIdsClaimData("tenant-id-1");
    Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);

    // If tags don't exist for tenant then it works like a POST request (creating new ones)
    given()
        .header("Authorization", createAuthHeader(extraClaims))
        .contentType(ContentType.JSON)
        .body(body.toString())
        .queryParam("tenant_id", "other-tenant-id")
        .patch(USERS_API_V2 + "/" + user.getId() + "/tenant_tags")
        .then()
        .statusCode(HttpStatus.SC_FORBIDDEN);
  }

  @Test
  @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
  public void test_patch_tenant_tag_as_tenant_manager_ok() {
    UserEntity user = createUser("A user", "email@email.com");

    JSONObject body = new JSONObject()
        .put("tags", Arrays.asList("tenant-tag-benefit-id-1", "tenant-tag-benefit-id-2"))
        .put("tenant_id", "tenant-id-1");

    Map<String, List<String>> claimData = UserControllerV2IT.tenantsIdsClaimData("tenant-id-1");
    Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);

    // If tags don't exist for tenant then it works like a POST request (creating new ones)
    given()
        .header("Authorization", createAuthHeader(extraClaims))
        .contentType(ContentType.JSON)
        .body(body.toString())
        .queryParam("tenant_id", "tenant-id-1")
        .patch(USERS_API_V2 + "/" + user.getId() + "/tenant_tags")
        .then()
        .statusCode(HttpStatus.SC_OK)
        .body("tenant_tags", hasSize(1))
        .body("tenant_tags[0].tags", hasSize(2))
        .body("tenant_tags[0].tags[0]", is("tenant-tag-benefit-id-1"))
        .body("tenant_tags[0].tags[1]", is("tenant-tag-benefit-id-2"))
        .body("tenant_tags[0].tenant_id", is("tenant-id-1"));
  }

  @Test
  @WithMockUser(role = UserRole.ROLE_ADMIN)
  public void testDeleteTenantTag() throws UserNotFoundException {
    UserEntity user = createUser("A user", "email@email.com");
    String body = "{"
        + "\"tags\": [\"147\",\"258\"], "
        + "\"tenant_id\": \"tenant-1\" "
        + "}";

    given()
        .header("Authorization", createAuthHeader())
        .contentType("application/json")
        .body(body)
        .post(USERS_API_V2 + "/" + user.getId() + "/tenant_tags")
        .then()
        .statusCode(HttpStatus.SC_OK)
        .body("tenant_tags", hasSize(1));

    body = "{"
        + "\"tags\": [\"456\",\"789\",\"123\"], "
        + "\"tenant_id\": \"tenant-2\" "
        + "}";

    given()
        .header("Authorization", createAuthHeader())
        .contentType("application/json")
        .body(body)
        .post(USERS_API_V2 + "/" + user.getId() + "/tenant_tags")
        .then()
        .statusCode(HttpStatus.SC_OK)
        .body("tenant_tags", hasSize(2));

    given()
        .header("Authorization", createAuthHeader())
        .contentType("application/json")
        .param("tags", "789", "456")
        .param("tenant_id", "tenant-2")
        .delete(USERS_API_V2 + "/" + user.getId() + "/tenant_tags")
        .then()
        .log().all()
        .statusCode(HttpStatus.SC_OK)
        .body("tenant_tags", hasSize(2));


    Set<String> tags = userService.getUserById(UserLegacy.valueOf(user.getId())).getTenantTags().stream()
        .filter(tt -> tt.getTenantId().getValue().equals("tenant-2"))
        .findFirst().get()
        .getTags();

    assertThat(tags).hasSize(1);
    assertThat(tags).contains("123");
  }

  @Test
  @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
  public void test_delete_tenant_tag_as_tenant_manager_forbidden() {
    UserEntity user = createUser("A user", "email@email.com");

    // tenant-id-1 creates his/her tenant_tags
    JSONObject body = new JSONObject()
        .put("tags", Arrays.asList("tenant-tag-benefit-id-1", "tenant-tag-benefit-id-2"))
        .put("tenant_id", "tenant-id-1");

    Map<String, List<String>> claimData = UserControllerV2IT.tenantsIdsClaimData("tenant-id-1");
    Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);

    given()
        .header("Authorization", createAuthHeader(extraClaims))
        .contentType(ContentType.JSON)
        .body(body.toString())
        .queryParam("tenant_id", "other-tenant-id")
        .post(USERS_API_V2 + "/" + user.getId() + "/tenant_tags");

    // other-tenant-id tries to delete one of the tenant-id-1's tenant_tags
    Map<String, List<String>> otherClaimData = UserControllerV2IT.tenantsIdsClaimData("other-tenant-id");
    Map<String, Object> otherExtraClaims = Map.of("role_tenant_manager", otherClaimData);

    given()
        .header("Authorization", createAuthHeader(otherExtraClaims))
        .contentType(ContentType.JSON)
        .param("tags", "tenant-tag-benefit-id-1")
        .param("tenant_id", "tenant-id-1")
        .delete(USERS_API_V2 + "/" + user.getId() + "/tenant_tags")
        .then()
        .log().all()
        .statusCode(HttpStatus.SC_FORBIDDEN);
  }

  @Test
  @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
  public void test_delete_tenant_tag_as_tenant_manager_ok() {
    UserEntity user = createUser("A user", "email@email.com");

    // tenant-id-1 creates his/her tenant_tags
    JSONObject body = new JSONObject()
        .put("tags", Arrays.asList("tenant-tag-benefit-id-1", "tenant-tag-benefit-id-2"))
        .put("tenant_id", "tenant-id-1");

    Map<String, List<String>> claimData = UserControllerV2IT.tenantsIdsClaimData("tenant-id-1");
    Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);

    given()
        .header("Authorization", createAuthHeader(extraClaims))
        .contentType(ContentType.JSON)
        .body(body.toString())
        .queryParam("tenant_id", "other-tenant-id")
        .post(USERS_API_V2 + "/" + user.getId() + "/tenant_tags");

    // tenant-id-1 tries to delete one of his/her tenant_tags
    given()
        .header("Authorization", createAuthHeader(extraClaims))
        .contentType(ContentType.JSON)
        .param("tags", "tenant-tag-benefit-id-1")
        .param("tenant_id", "tenant-id-1")
        .delete(USERS_API_V2 + "/" + user.getId() + "/tenant_tags")
        .then()
        .log().all()
        .statusCode(HttpStatus.SC_OK)
        .body("tenant_tags", hasSize(1))
        .body("tenant_tags[0].tags", hasSize(1))
        .body("tenant_tags[0].tags[0]", is("tenant-tag-benefit-id-2"))
        .body("tenant_tags[0].tenant_id", is("tenant-id-1"));
  }

  @Nonnull
  private UserEntity createUser(String name, String email) {
    return createUser(name, email, "+34 123456789", null);
  }

  @Nonnull
  private UserEntity createUser(String name, String email, String phone, String picture) {
    String hashPassword = new BCryptPasswordEncoder().encode("password");
    UserEntity userEntity = new UserEntity(name, hashPassword, email, true, phone, false, null,null, "ES", PlaytomicUserType.ONLINE);
    userEntity.setProfilePhotoFilename(picture);
    return userRepository.save(userEntity);
  }

  @Nonnull
  private String createAuthHeader(@Nullable Map<String, Object> extraClaims) {
    Collection<GrantedAuthority> authorities = testCredentialsService.getTestPrincipal().getUser().getOriginalAuthorities();

    // sgmoratilla: this is a uber-shit because each test is creating the authorization object before
    // creating the user in db, so that we don't know the id at that point
    UserEntity anyUser = userRepository.findAll().iterator().next();

    AccessJwtToken token = extraClaims == null ?
        jwtTokenFactory.createAccessJwtToken(anyUser.getId().toString(), null, authorities) :
        jwtTokenFactory.createAccessJwtTokenWithCustomClaims(anyUser.getId().toString(), null, authorities, extraClaims);

    return "Bearer " + token.getToken();
  }

  @Nonnull
  private String createAuthHeader() {
    return createAuthHeader(null);
  }

  private void mockTenantResponse(@Nonnull String id, @Nullable String notFoundId) {
    String publicSingle = readAsText(getCurrentPackageAsClasspath() + "/mock_anemone_single_tenant_public.json");
    getMockServer(MOCK_TENANTS_PORT).
        when(request().
            withPath("/v1/tenants/" + id)).
        respond(response().
            withHeaders(new Header("Content-Type", "application/json; charset=utf-8")).
            withStatusCode(200).
            withBody(publicSingle));

    getMockServer(MOCK_TENANTS_PORT).
        when(request().
            withPath("/v1/tenants")
            .withQueryStringParameter("tenant_id", id)).
        respond(response().
            withHeaders(new Header("Content-Type", "application/json; charset=utf-8")).
            withStatusCode(200).
            withBody("[" + publicSingle + "]"));

    getMockServer(MOCK_TENANTS_PORT).
        when(request().
            withPath("/v1/tenants")
            .withQueryStringParameter("tenant_id", notFoundId)).
        respond(response().
            withHeaders(new Header("Content-Type", "application/json; charset=utf-8")).
            withStatusCode(200).
            withBody("[]"));
  }

}

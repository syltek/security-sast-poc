package com.playtomic.anemone.user.api.v1;

import com.playtomic.anemone.UserApplication;
import com.playtomic.anemone.domain.user.User;
import com.playtomic.anemone.domain.user.UserRole;
import com.playtomic.anemone.jwt.JwtTokenFactory;
import com.playtomic.anemone.spring.config.AnemoneUserPrincipal;
import com.playtomic.anemone.test.WithMockUser;
import com.playtomic.anemone.user.config.AbstractTestContainersSupport;
import com.playtomic.anemone.user.service.UserCredentialService;
import static io.restassured.RestAssured.given;
import javax.annotation.Nonnull;
import org.apache.http.HttpStatus;
import static org.hamcrest.Matchers.is;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = UserApplication.class)
@ExtendWith(SpringExtension.class)
public class PhoneTokenControllerV1IT extends AbstractTestContainersSupport {
    public static final String PHONE_TOKENS_V1 = "/v1/phone_tokens";

    @Autowired
    private JwtTokenFactory jwtTokenFactory;

    @Autowired
    private UserCredentialService userCredentialService;

    @Test
    @WithMockUser(role = UserRole.ROLE_ANEMONE)
    public void testCreatePhoneTokenWithAnemoneRole() throws Exception {
        String body = "{ \"phone\": \"+34 666 11 22 33\" }";
        given()
                .header("Authorization", createAuthToken())
                .contentType("application/json")
                .body(body)
                .post(PHONE_TOKENS_V1)
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_OK)
                .body("phone_token", is(userCredentialService.hashPhone("+34 666112233")));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_CUSTOMER)
    public void testCreatePhoneTokenWithCustomerOrAnonymousRole() throws Exception {
        String body = "{ \"phone\": \"+34 666112233\" }";
        given()
                .header("Authorization", createAuthToken())
                .contentType("application/json")
                .body(body)
                .post(PHONE_TOKENS_V1)
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_FORBIDDEN);
        given()
                .contentType("application/json")
                .body(body)
                .post(PHONE_TOKENS_V1)
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_FORBIDDEN);
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_ANEMONE)
    public void testCreatePhoneTokenWithUnformattedPhone() throws Exception {
        String body = "{ \"phone\": \"666112233\" }";
        given()
                .header("Authorization", createAuthToken())
                .contentType("application/json")
                .body(body)
                .post(PHONE_TOKENS_V1)
                .then()
                .log().body()
                .statusCode(HttpStatus.SC_BAD_REQUEST)
                .body("status", is("INVALID_PHONE"));
    }


    @Nonnull
    private User getCurrentUser() {
        AnemoneUserPrincipal currentUserDetails =
                (AnemoneUserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return currentUserDetails.getUser();
    }

    @Nonnull
    private String createAuthToken() {
        return createAuthToken(getCurrentUser());
    }

    @Nonnull
    private String createAuthToken(@Nonnull User user) {
        String token = jwtTokenFactory.createAccessJwtToken(user).getToken();
        return "Bearer " + token;
    }
}

package com.playtomic.anemone.user.api.v2;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;

import com.playtomic.anemone.Constants;
import com.playtomic.anemone.UserApplication;
import com.playtomic.anemone.category.dao.CategoryDocument;
import com.playtomic.anemone.category.dao.CategoryRepository;
import com.playtomic.anemone.category.domain.CategoryId;
import com.playtomic.anemone.domain.user.User;
import com.playtomic.anemone.domain.user.UserId;
import com.playtomic.anemone.domain.user.UserRole;
import com.playtomic.anemone.jwt.AccessJwtToken;
import com.playtomic.anemone.jwt.JwtTokenFactory;
import com.playtomic.anemone.spring.config.AnemoneUserPrincipal;
import com.playtomic.anemone.test.TestCredentialsService;
import com.playtomic.anemone.test.WithMockUser;
import com.playtomic.anemone.user.config.AbstractTestContainersSupport;
import com.playtomic.anemone.user.dao.CoachAccountEntity;
import com.playtomic.anemone.user.dao.LinkedAccountEntity;
import com.playtomic.anemone.user.dao.PlaytomicUserType;
import com.playtomic.anemone.user.dao.UserEntity;
import com.playtomic.anemone.user.dao.UserRepository;
import com.playtomic.anemone.user.dao.UserRoleEntity;
import com.playtomic.anemone.user.domain.LinkingType;
import com.playtomic.anemone.user.domain.matches.SportId;
import com.playtomic.anemone.user.domain.tenant.TenantId;
import com.playtomic.anemone.user.model.role.PlaytomicUserRole;
import io.restassured.response.Response;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.validation.ClockProvider;
import org.apache.http.HttpStatus;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
@ParametersAreNonnullByDefault
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = UserApplication.class)
class UserSuggestionsControllerV2IT extends AbstractTestContainersSupport {

    private static final String USERS_SUGGESTIONS_API_V2 = "/v2/users/suggestions";

    @Nonnull
    @Autowired
    private UserRepository userRepository;
    @Nonnull
    @Autowired
    private JwtTokenFactory jwtTokenFactory;
    @Nonnull
    @Autowired
    private TestCredentialsService testCredentialsService;
    @Nonnull
    @Autowired
    private ClockProvider clockProvider;
    @Nonnull
    @Autowired
    private CategoryRepository categoryRepository;

    @AfterEach
    public void clearRepos() {
        userRepository.deleteAll();
        categoryRepository.deleteAll();
        SecurityContextHolder.clearContext();
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_ADMIN)
    void testSearchSuggestedPlayers() {
        List<UserEntity> users = Arrays.asList(
            createUser("User Test", "ok@email.com", "+44 123456789"),
            createUser("Angel Garcia", "angelgarcia@syltek.com", "+34 687929298"),
            createUser("Manuel Gonzalez", "manuelgonzalez@syltek.com"),
            createUser("Sergio Garcia", "sergiomoratilla@syltek.com"),
            createUser("Carlos Garcia", "carlosgarcia@syltek.com"),
            createUser("Fulano Perez", "fulano@perez.com", "+34 66666666")
        );

        users.get(1).setEmailVerified(false);
        users.get(1).getLinkedAccounts().add(new LinkedAccountEntity(
            users.get(1),
            "tenant-2",
            "1234",
            true,
            LinkingType.AUTOLINK
        ));
        users.get(3).getLinkedAccounts().add(new LinkedAccountEntity(
            users.get(3),
            "tenant-1",
            "1234",
            true,
            LinkingType.AUTOLINK
        ));
        users.get(4).getLinkedAccounts().add(new LinkedAccountEntity(
            users.get(4),
            "tenant-1",
            "1234",
            true,
            LinkingType.AUTOLINK
        ));
        users.get(4).setAcceptsPrivacyPolicy(false);
        userRepository.saveAll(users);

        // Search by email
        given()
            .header("Authorization", createAuthHeader())
            .queryParam("tenant_id", "tenant-1")
            .queryParam("filter", "ok@email.com")
            .get(USERS_SUGGESTIONS_API_V2)
            .then()
            .log().body()
            .statusCode(HttpStatus.SC_OK)
            .body("$", hasSize(1))
            .body("[0].user_id", is(users.get(0).getId().toString()));

        // Search by phone
        given()
            .header("Authorization", createAuthHeader())
            .queryParam("tenant_id", "tenant-1")
            .queryParam("filter", "+34 687929298")
            .get(USERS_SUGGESTIONS_API_V2)
            .then()
            .log().body()
            .statusCode(HttpStatus.SC_OK)
            .body("$", hasSize(1))
            .body("[0].user_id", is(users.get(1).getId().toString()));

        // Search by name in tenant-1
        given()
            .header("Authorization", createAuthHeader())
            .queryParam("tenant_id", "tenant-1")
            .queryParam("filter", "rgio Garc")
            .get(USERS_SUGGESTIONS_API_V2)
            .then()
            .log().body()
            .statusCode(HttpStatus.SC_OK)
            .body("$", hasSize(1))
            .body("[0].user_id", is(users.get(3).getId().toString()));

        // Search by name in different tenant
        given()
            .header("Authorization", createAuthHeader())
            .queryParam("tenant_id", "tenant-different")
            .queryParam("filter", "rgio Garc")
            .get(USERS_SUGGESTIONS_API_V2)
            .then()
            .log().body()
            .statusCode(HttpStatus.SC_OK)
            .body("$", hasSize(0));

        // Empty search should return a value
        given()
            .header("Authorization", createAuthHeader())
            .queryParam("tenant_id", "tenant-1")
            .queryParam("filter", "")
            .get(USERS_SUGGESTIONS_API_V2)
            .then()
            .log().body()
            .statusCode(HttpStatus.SC_OK)
            .body("$", hasSize(1))
            .body("[0].user_id", is(users.get(3).getId().toString()));

        // Non matching search
        given()
            .header("Authorization", createAuthHeader())
            .queryParam("tenant_id", "tenant-1")
            .queryParam("filter", "nonexist")
            .get(USERS_SUGGESTIONS_API_V2)
            .then()
            .log().body()
            .statusCode(HttpStatus.SC_OK)
            .body("$", hasSize(0));

    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void testSearchSuggestedAdmins() {
        List<UserEntity> users = Arrays.asList(
            createUser("User Test", "ok@email.com", "+44 123456789"),
            createUser("Angel Garcia", "angelgarcia@syltek.com", "+34 687929298"),
            createUser("Manuel Gonzalez", "manuelgonzalez@syltek.com"),
            createUser("Sergio Garcia", "sergiomoratilla@syltek.com"),
            createUser("Carlos Garcia", "carlosgarcia@syltek.com"),
            createUser("Fulano Perez", "fulano@perez.com", "+34 66666666")
        );

        UserEntity garciaManagerInTenant1 = users.get(1);
        garciaManagerInTenant1.getLinkedAccounts().add(new LinkedAccountEntity(
            garciaManagerInTenant1,
            "tenant-1",
            "1234",
            true,
            LinkingType.AUTOLINK
        ));
        garciaManagerInTenant1.setUserRoles(Set.of(new UserRoleEntity(garciaManagerInTenant1, PlaytomicUserRole.ROLE_TENANT_MANAGER, "tenant-1")));
        UserEntity gonzalezManagerInTenant1 = users.get(2);
        gonzalezManagerInTenant1.getLinkedAccounts().add(new LinkedAccountEntity(
            gonzalezManagerInTenant1,
            "tenant-1",
            "1234",
            true,
            LinkingType.AUTOLINK
        ));
        gonzalezManagerInTenant1.setUserRoles(
            Set.of(new UserRoleEntity(gonzalezManagerInTenant1, PlaytomicUserRole.ROLE_TENANT_MANAGER, "tenant-1")));
        UserEntity garciaNotManagerInTenant1 = users.get(3);
        garciaNotManagerInTenant1.getLinkedAccounts().add(new LinkedAccountEntity(
            garciaNotManagerInTenant1,
            "tenant-1",
            "1234",
            true,
            LinkingType.AUTOLINK
        ));
        UserEntity garciaManagerInTenant2 = users.get(4);
        garciaManagerInTenant2.getLinkedAccounts().add(new LinkedAccountEntity(
            garciaManagerInTenant2,
            "tenant-2",
            "1234",
            true,
            LinkingType.AUTOLINK
        ));
        garciaManagerInTenant2.setUserRoles(Set.of(new UserRoleEntity(garciaManagerInTenant2, PlaytomicUserRole.ROLE_TENANT_MANAGER, "tenant-2")));

        userRepository.saveAll(users);

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-1");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        // Search by name in tenant-1
        given()
            .header("Authorization", createAuthHeader(extraClaims))
            .queryParam("tenant_id", "tenant-1")
            .queryParam("filter", "Garci")
            .get(USERS_SUGGESTIONS_API_V2 + "/admins")
            .then()
            .log().body()
            .statusCode(HttpStatus.SC_OK)
            .body("$", hasSize(1))
            .body("[0].user_id", is(garciaManagerInTenant1.getId().toString()));

        // Empty search in tenant-1
        given()
            .header("Authorization", createAuthHeader(extraClaims))
            .queryParam("tenant_id", "tenant-1")
            .queryParam("filter", "")
            .get(USERS_SUGGESTIONS_API_V2 + "/admins")
            .then()
            .log().body()
            .statusCode(HttpStatus.SC_OK)
            .body("$", hasSize(2))
            .body("[0].user_id", is(garciaManagerInTenant1.getId().toString()))
            .body("[1].user_id", is(gonzalezManagerInTenant1.getId().toString()));

        // Non matching search
        given()
            .header("Authorization", createAuthHeader(extraClaims))
            .queryParam("tenant_id", "tenant-1")
            .queryParam("filter", "nonexist")
            .get(USERS_SUGGESTIONS_API_V2 + "/admins")
            .then()
            .log().body()
            .statusCode(HttpStatus.SC_OK)
            .body("$", hasSize(0));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void testSearchSuggestedCoaches() {
        List<UserEntity> users = Arrays.asList(
            createUser("User Test", "ok@email.com", "+44 123456789"),
            createUser("Angel Garcia", "angelgarcia@syltek.com", "+34 687929298"),
            createUser("Manuel Gonzalez", "manuelgonzalez@syltek.com"),
            createUser("Sergio Garcia", "sergiomoratilla@syltek.com"),
            createUser("Carlos Garcia", "carlosgarcia@syltek.com"),
            createUser("Fulano Perez", "fulano@perez.com", "+34 66666666")
        );

        UserEntity garciaCoachInTenant1 = users.get(1);
        garciaCoachInTenant1.setCoachAccounts(Set.of(
            new CoachAccountEntity(randomId(), garciaCoachInTenant1, "tenant-1", List.of(SportId.valueOf("PADEL")), "Some experience", "Some ages",
                "Some description")));
        UserEntity gonzalezCoachInTenant1 = users.get(2);
        gonzalezCoachInTenant1.setCoachAccounts(Set.of(
            new CoachAccountEntity(randomId(), gonzalezCoachInTenant1, "tenant-1", List.of(SportId.valueOf("PADEL"), SportId.valueOf("TENNIS"), SportId.valueOf("SQUASH")), "Some experience", "Some ages",
                "Some description")));
        UserEntity garciaCoachInTenant2 = users.get(4);
        garciaCoachInTenant2.setCoachAccounts(Set.of(
            new CoachAccountEntity(randomId(), garciaCoachInTenant2, "tenant-2", List.of(SportId.valueOf("BEACH_TENNIS")), "Some experience", "Some ages",
                "Some description")));

        userRepository.saveAll(users);

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-1", "tenant-2");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        // Search by name in tenant-1
        given()
            .header("Authorization", createAuthHeader(extraClaims))
            .queryParam("tenant_id", "tenant-1")
            .queryParam("filter", "Garci")
            .get(USERS_SUGGESTIONS_API_V2 + "/coaches")
            .then()
            .log().body()
            .statusCode(HttpStatus.SC_OK)
            .body("$", hasSize(1))
            .body("[0].user_id", is(garciaCoachInTenant1.getId().toString()));

        // Empty search in tenant-1
        given()
            .header("Authorization", createAuthHeader(extraClaims))
            .queryParam("tenant_id", "tenant-1")
            .queryParam("filter", "")
            .queryParam("sort", "fullName")
            .get(USERS_SUGGESTIONS_API_V2 + "/coaches")
            .then()
            .log().body()
            .statusCode(HttpStatus.SC_OK)
            .body("$", hasSize(2))
            .body("[0].user_id", is(garciaCoachInTenant1.getId().toString()))
            .body("[1].user_id", is(gonzalezCoachInTenant1.getId().toString()));

        // Non matching search
        given()
            .header("Authorization", createAuthHeader(extraClaims))
            .queryParam("tenant_id", "tenant-1")
            .queryParam("filter", "nonexist")
            .get(USERS_SUGGESTIONS_API_V2 + "/coaches")
            .then()
            .log().body()
            .statusCode(HttpStatus.SC_OK)
            .body("$", hasSize(0));

        // Filter by sport. Checking coaches where the first sport is the requested one.
        given()
            .header("Authorization", createAuthHeader(extraClaims))
            .queryParam("tenant_id", "tenant-1")
            .queryParam("sport_id", "PADEL")
            .queryParam("sort", "fullName")
            .get(USERS_SUGGESTIONS_API_V2 + "/coaches")
            .then()
            .log().body()
            .statusCode(HttpStatus.SC_OK)
            .body("$", hasSize(2))
            .body("[0].user_id", is(garciaCoachInTenant1.getId().toString()))
            .body("[1].user_id", is(gonzalezCoachInTenant1.getId().toString()));

        // Filter by sport. Checking coaches where the middle sport is the requested one.
        given()
            .header("Authorization", createAuthHeader(extraClaims))
            .queryParam("tenant_id", "tenant-1")
            .queryParam("sport_id", "TENNIS")
            .queryParam("sort", "fullName")
            .get(USERS_SUGGESTIONS_API_V2 + "/coaches")
            .then()
            .log().body()
            .statusCode(HttpStatus.SC_OK)
            .body("$", hasSize(1))
            .body("[0].user_id", is(gonzalezCoachInTenant1.getId().toString()));

        // Filter by sport. Checking coaches where the last sport is the requested one.
        given()
            .header("Authorization", createAuthHeader(extraClaims))
            .queryParam("tenant_id", "tenant-1")
            .queryParam("sport_id", "SQUASH")
            .queryParam("sort", "fullName")
            .get(USERS_SUGGESTIONS_API_V2 + "/coaches")
            .then()
            .log().body()
            .statusCode(HttpStatus.SC_OK)
            .body("$", hasSize(1))
            .body("[0].user_id", is(gonzalezCoachInTenant1.getId().toString()));

        // Filter by TENNIS sport, this should not return anything even if one coach has BEACH_TENNIS sport.
        given()
            .header("Authorization", createAuthHeader(extraClaims))
            .queryParam("tenant_id", "tenant-2")
            .queryParam("sport_id", "TENNIS")
            .get(USERS_SUGGESTIONS_API_V2 + "/coaches")
            .then()
            .log().body()
            .statusCode(HttpStatus.SC_OK)
            .body("$", hasSize(0));

        // Filter by BEACH_TENNIS sport.
        given()
            .header("Authorization", createAuthHeader(extraClaims))
            .queryParam("tenant_id", "tenant-2")
            .queryParam("sport_id", "BEACH_TENNIS")
            .queryParam("sort", "fullName")
            .get(USERS_SUGGESTIONS_API_V2 + "/coaches")
            .then()
            .log().body()
            .statusCode(HttpStatus.SC_OK)
            .body("$", hasSize(1))
            .body("[0].user_id", is(garciaCoachInTenant2.getId().toString()));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void testSearchSuggestedCustomers() {
        List<UserEntity> users = Arrays.asList(
            createUser("User Test", "ok@email.com", "+44 123456789"),
            createUser("Angel Garcia", "angelgarcia@syltek.com", "+34 687929298"),
            createUser("Manuel Gonzalez", "manuelgonzalez@syltek.com"),
            createUser("Sergio Garcia", "sergiomoratilla@syltek.com"),
            createUser("Carlos Garcia", "carlosgarcia@syltek.com"),
            createUser("Fulano Perez", "fulano@perez.com", "+34 66666666")
        );

        UserEntity garciaManagerInTenant1 = users.get(1);
        garciaManagerInTenant1.getLinkedAccounts().add(new LinkedAccountEntity(
            garciaManagerInTenant1,
            "tenant-1",
            "1234",
            true,
            LinkingType.AUTOLINK
        ));
        UserEntity gonzalezManagerInTenant1 = users.get(2);
        gonzalezManagerInTenant1.getLinkedAccounts().add(new LinkedAccountEntity(
            gonzalezManagerInTenant1,
            "tenant-1",
            "1234",
            true,
            LinkingType.AUTOLINK
        ));
        UserEntity garciaNotManagerInTenant1 = users.get(3);
        garciaNotManagerInTenant1.setAcceptsPrivacyPolicy(false);
        garciaNotManagerInTenant1.getLinkedAccounts().add(new LinkedAccountEntity(
            garciaNotManagerInTenant1,
            "tenant-1",
            "1234",
            true,
            LinkingType.AUTOLINK
        ));
        UserEntity garciaManagerInTenant2 = users.get(4);
        garciaManagerInTenant2.getLinkedAccounts().add(new LinkedAccountEntity(
            garciaManagerInTenant2,
            "tenant-2",
            "1234",
            true,
            LinkingType.AUTOLINK
        ));

        userRepository.saveAll(users);

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-1");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        // Search by name in tenant-1
        given()
            .header("Authorization", createAuthHeader(extraClaims))
            .queryParam("tenant_id", "tenant-1")
            .queryParam("filter", "gel Gar")
            .get(USERS_SUGGESTIONS_API_V2 + "/customers")
            .then()
            .log()
            .body()
            .statusCode(HttpStatus.SC_OK)
            .body("$", hasSize(1))
            .body("[0].user_id", is(garciaManagerInTenant1.getId().toString()));

        // Search by email in tenant-1
        given()
            .header("Authorization", createAuthHeader(extraClaims))
            .queryParam("tenant_id", "tenant-1")
            .queryParam("filter", "angelgarcia@syltek.com")
            .get(USERS_SUGGESTIONS_API_V2 + "/customers")
            .then()
            .log()
            .body()
            .statusCode(HttpStatus.SC_OK)
            .body("$", hasSize(1))
            .body("[0].user_id", is(garciaManagerInTenant1.getId().toString()));

        // Search by phone in tenant-1
        given()
            .header("Authorization", createAuthHeader(extraClaims))
            .queryParam("tenant_id", "tenant-1")
            .queryParam("filter", "+34 687929298")
            .get(USERS_SUGGESTIONS_API_V2 + "/customers")
            .then()
            .log()
            .body()
            .statusCode(HttpStatus.SC_OK)
            .body("$", hasSize(1))
            .body("[0].user_id", is(garciaManagerInTenant1.getId().toString()));

        // Empty search in tenant-1
        given()
            .header("Authorization", createAuthHeader(extraClaims))
            .queryParam("tenant_id", "tenant-1")
            .queryParam("filter", "")
            .get(USERS_SUGGESTIONS_API_V2 + "/customers")
            .then()
            .log()
            .body()
            .statusCode(HttpStatus.SC_OK)
            .body("$", hasSize(2))
            .body("[0].user_id", is(garciaManagerInTenant1.getId().toString()))
            .body("[1].user_id", is(gonzalezManagerInTenant1.getId().toString()));

        // Non matching search
        given()
            .header("Authorization", createAuthHeader(extraClaims))
            .queryParam("tenant_id", "tenant-1")
            .queryParam("filter", "nonexist")
            .get(USERS_SUGGESTIONS_API_V2 + "/customers")
            .then()
            .log()
            .body()
            .statusCode(HttpStatus.SC_OK)
            .body("$", hasSize(0));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void testSearchSuggestedCustomers_containsTagsDetails() {
        UserEntity user = createUser("User Test", "ok@email.com");
        LinkedAccountEntity linkedAccount = new LinkedAccountEntity(user, "tenant-id", "1234", true, LinkingType.AUTOLINK);
        user.getLinkedAccounts().add(linkedAccount);
        Instant expiresAt = clockProvider.getClock().instant().truncatedTo(ChronoUnit.SECONDS).plus(10, ChronoUnit.DAYS);
        user.addCategory(new CategoryDocument(CategoryId.valueOf("a508786e-a11f-472e-b802-74e3a0a0805a"),
            TenantId.valueOf("tenant-id"), "VIP", null, null, null, null), expiresAt);
        userRepository.save(user);

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-id");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        Response response = given()
            .header("Authorization", createAuthHeader(extraClaims))
            .queryParam("filter", "")
            .queryParam("tenant_id", "tenant-id")
            .get(USERS_SUGGESTIONS_API_V2 + "/customers");
        response
            .then()
            .log()
            .body()
            .statusCode(HttpStatus.SC_OK)
            .body("tenant_tags", hasSize(1))
            .body("tenant_tags[0].tags", hasSize(1))
            .body("tenant_tags[0].tags[0][0]", is("a508786e-a11f-472e-b802-74e3a0a0805a"))
            .body("tenant_tags[0].tags_details", hasSize(1))
            .body("tenant_tags[0].tags_details[0].tag[0]", is("a508786e-a11f-472e-b802-74e3a0a0805a"))
            .body("tenant_tags[0].tags_details[0].type[0]", is("ANEMONE_CATEGORY"))
            .body("tenant_tags[0].tags_details[0].expires_at[0]", is(
                Constants.UTC_NO_NANOS_FORMATTER.withZone(ZoneId.from(ZoneOffset.UTC)).format(expiresAt)));
    }

    @Test
    @WithMockUser(role = UserRole.ROLE_TENANT_MANAGER)
    void testSearchSuggestedMembers() {
        List<UserEntity> users = Arrays.asList(
            createUser("User Test", "ok@email.com", "+44 123456789"),
            createUser("Angel Garcia", "angelgarcia@syltek.com", "+34 687929298"),
            createUser("Manuel Gonzalez", "manuelgonzalez@syltek.com"),
            createUser("Sergio Garcia", "sergiomoratilla@syltek.com"),
            createUser("Carlos Garcia", "carlosgarcia@syltek.com"),
            createUser("Fulano Perez", "fulano@perez.com", "+34 66666666")
        );

        CategoryDocument vip = categoryRepository.save(new CategoryDocument(CategoryId.valueOf("86243c8b-b33c-44c8-829f-beeb4314cb67"),
            TenantId.valueOf("tenant-1"), "VIP", null, null, null, null));
        UserEntity garciaManagerInVip = users.get(1);
        garciaManagerInVip.getLinkedAccounts().add(new LinkedAccountEntity(
            garciaManagerInVip,
            "tenant-1",
            "1234",
            true,
            LinkingType.AUTOLINK
        ));
        garciaManagerInVip.addCategory(vip, null);
        UserEntity gonzalezManagerWithoutCategory = users.get(2);
        gonzalezManagerWithoutCategory.getLinkedAccounts().add(new LinkedAccountEntity(
            gonzalezManagerWithoutCategory,
            "tenant-1",
            "1234",
            true,
            LinkingType.AUTOLINK
        ));
        UserEntity garciaNotManagerInVip = users.get(3);
        garciaNotManagerInVip.setAcceptsPrivacyPolicy(false);
        garciaNotManagerInVip.getLinkedAccounts().add(new LinkedAccountEntity(
            garciaNotManagerInVip,
            "tenant-1",
            "1234",
            true,
            LinkingType.AUTOLINK
        ));
        garciaNotManagerInVip.addCategory(vip, null);
        CategoryDocument gold = categoryRepository.save(new CategoryDocument(CategoryId.valueOf("26243c8b-b33c-44c8-829f-beeb4314cb67"),
            TenantId.valueOf("tenant-1"), "Gold", null, null, null, null));
        UserEntity garciaManagerInGold = users.get(4);
        garciaManagerInGold.getLinkedAccounts().add(new LinkedAccountEntity(
            garciaManagerInGold,
            "tenant-1",
            "1234",
            true,
            LinkingType.AUTOLINK
        ));
        garciaManagerInGold.addCategory(gold, null);

        userRepository.saveAll(users);

        Map<String, List<String>> claimData = tenantsIdsClaimData("tenant-1");
        Map<String, Object> extraClaims = Map.of("role_tenant_manager", claimData);
        // Search by name in vip
        given()
            .header("Authorization", createAuthHeader(extraClaims))
            .queryParam("category_id", "86243c8b-b33c-44c8-829f-beeb4314cb67")
            .queryParam("filter", "gel Gar")
            .get(USERS_SUGGESTIONS_API_V2 + "/members")
            .then()
            .log()
            .body()
            .statusCode(HttpStatus.SC_OK)
            .body("$", hasSize(1))
            .body("[0].user_id", is(garciaManagerInVip.getId().toString()));

        // Search by email in vip category
        given()
            .header("Authorization", createAuthHeader(extraClaims))
            .queryParam("category_id", "86243c8b-b33c-44c8-829f-beeb4314cb67")
            .queryParam("filter", "angelgarcia@syltek.com")
            .get(USERS_SUGGESTIONS_API_V2 + "/members")
            .then()
            .log()
            .body()
            .statusCode(HttpStatus.SC_OK)
            .body("$", hasSize(1))
            .body("[0].user_id", is(garciaManagerInVip.getId().toString()));

        // Search by phone in vip category
        given()
            .header("Authorization", createAuthHeader(extraClaims))
            .queryParam("category_id", "86243c8b-b33c-44c8-829f-beeb4314cb67")
            .queryParam("filter", "+34 687929298")
            .get(USERS_SUGGESTIONS_API_V2 + "/members")
            .then()
            .log()
            .body()
            .statusCode(HttpStatus.SC_OK)
            .body("$", hasSize(1))
            .body("[0].user_id", is(garciaManagerInVip.getId().toString()));

        // Empty search in vip category
        given()
            .header("Authorization", createAuthHeader(extraClaims))
            .queryParam("category_id", "86243c8b-b33c-44c8-829f-beeb4314cb67")
            .queryParam("filter", "")
            .queryParam("sort", "id")
            .get(USERS_SUGGESTIONS_API_V2 + "/members")
            .then()
            .log()
            .body()
            .statusCode(HttpStatus.SC_OK)
            .body("$", hasSize(2))
            .body("[0].user_id", is(garciaManagerInVip.getId().toString()))
            .body("[1].user_id", is(garciaNotManagerInVip.getId().toString()));

        // Non matching search
        given()
            .header("Authorization", createAuthHeader(extraClaims))
            .queryParam("category_id", "86243c8b-b33c-44c8-829f-beeb4314cb67")
            .queryParam("filter", "nonexist")
            .get(USERS_SUGGESTIONS_API_V2 + "/members")
            .then()
            .log()
            .body()
            .statusCode(HttpStatus.SC_OK)
            .body("$", hasSize(0));
    }

    @Nonnull
    private UserEntity createUser(String name, String email) {
        return createUser(name, email, null);
    }

    @Nonnull
    private UserEntity createUser(String name, String email, String phone) {
        String hashPassword = new BCryptPasswordEncoder().encode("password");
        UserEntity userEntity = new UserEntity(name, hashPassword, email, true, phone, phone != null, null,null, "ES", PlaytomicUserType.ONLINE);

        userEntity.setAddressState("Tests tests");
        userEntity.setAddressStreet("Tests Street");
        userEntity.setAddressZipCode("Test zip code");
        userEntity.setAddressCity("Test city");

        return userRepository.save(userEntity);
    }

    @Nonnull
    private User getCurrentUser() {
        AnemoneUserPrincipal currentUserDetails =
            (AnemoneUserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return currentUserDetails.getUser();
    }

    @Nonnull
    private Map<String, List<String>> tenantsIdsClaimData( String... tenantIds) {
        return Map.of("tenant_ids", Arrays.asList(tenantIds));
    }

    @Nonnull
    private String createAuthHeader() {
        return createAuthHeader(getCurrentUser().getId(), null);
    }

    @Nonnull
    private String createAuthHeader(@Nullable Map<String, Object> extraClaims) {
        return createAuthHeader(getCurrentUser().getId(), extraClaims);
    }

    @Nonnull
    private String createAuthHeader(UserId userId, @Nullable Map<String, Object> extraClaims) {
        Collection<GrantedAuthority> authorities = testCredentialsService.getTestPrincipal().getUser().getOriginalAuthorities();

        AccessJwtToken token = extraClaims == null ?
            jwtTokenFactory.createAccessJwtToken(userId.toString(), null, authorities) :
            jwtTokenFactory.createAccessJwtTokenWithCustomClaims(userId.toString(), null, authorities, extraClaims);

        return "Bearer " + token.getToken();
    }

    @Nonnull
    private String randomId() {
        return UUID.randomUUID().toString();
    }

}

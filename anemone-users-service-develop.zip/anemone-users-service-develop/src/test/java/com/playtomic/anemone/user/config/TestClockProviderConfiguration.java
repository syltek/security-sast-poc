package com.playtomic.anemone.user.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import java.time.Clock;
import java.time.Duration;
import javax.annotation.Nonnull;
import javax.validation.ClockProvider;


@Configuration
public class TestClockProviderConfiguration {

    @Bean
    @Primary
    @Nonnull
    @ConditionalOnMissingBean(ClockProvider.class)
    public TestClockProvider getClockProvider() {
        return new TestClockProvider();
    }

    @Getter @Setter
    public static class TestClockProvider implements ClockProvider {
        @Nonnull
        private Clock clock = Clock.systemDefaultZone();

        public void offsetMinutes(int minutes) {
            clock = Clock.offset(clock, Duration.ofMinutes(minutes));
        }

    }
}
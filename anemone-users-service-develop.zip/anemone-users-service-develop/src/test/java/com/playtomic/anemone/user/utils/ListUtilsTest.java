package com.playtomic.anemone.user.utils;

import java.util.ArrayList;
import java.util.List;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class ListUtilsTest {

    private List target;

    @BeforeEach
    public void init() {
        target = new ArrayList<String>();
    }

    @Test
    public void should_fill_list_until_get_size_four() {
        final String expectedValue = "";
        ListUtils.expandList(target, 4, expectedValue);
        target.forEach(el -> {
            Assertions.assertThat(el).isEqualTo(expectedValue);
        });
        Assertions.assertThat(target.get(3)).isNotNull();
        Assertions.assertThat(target.size()).isEqualTo(4);
    }

    @Test
    public void should_not_expand_list() {
        final String expectedValue = "position zero";
        target.add(expectedValue);
        ListUtils.expandList(target, 1, "ciao");
        Assertions.assertThat(target.size()).isEqualTo(1);
        Assertions.assertThat(target.get(0)).isEqualTo(expectedValue);
    }

    @Test
    public void should_keep_old_values() {
        target.add("oldValue");
        ListUtils.expandList(target, 4, "hi");
        Assertions.assertThat(target.get(0)).isEqualTo("oldValue");
    }
}
